#!/bin/bash
#
# Bare-metal build script for uftpd fuzzing (e.g. inside a Kali VM),
# mirrors the Dockerfile steps.  Run as a regular user with sudo rights:
#
#   ./build.sh
#
# Afterwards the fuzzing layout is:
#   ~/aflnet                 AFLNet (fuzz + aflnet-replay)
#   ~/experiments/uftpd      ASAN+instrumented build
#   ~/experiments/uftpd-gcov gcov build
#   ~/experiments/in-ftp     seed corpus
#   ~/experiments/{run,ftpclean,cov_script,crash_script,ftp.dict}
#   ~/ftpshare               FTP root (reset by ftpclean before each run)

set -e

WORKDIR="${HOME}/experiments"
FTPSHARE="${HOME}/ftpshare"
UFTPD_TAG="v2.17"
LIBUEV_TAG="v2.4.1"
LIBITE_TAG="v2.6.2"

echo "[*] Installing dependencies ..."
sudo apt-get -y update
sudo apt-get -y install build-essential git autoconf automake libtool \
     pkg-config clang llvm python3-pip netcat-openbsd gdb strace net-tools

pip3 install --user gcovr || true

mkdir -p "${WORKDIR}"

echo "[*] Building AFLNet ..."
if [ ! -d "${HOME}/aflnet" ]; then
  git clone https://github.com/profuzzbench/aflnet.git "${HOME}/aflnet"
  (cd "${HOME}/aflnet" && make clean all && cd llvm_mode && make)
fi

echo "[*] Building libuev ${LIBUEV_TAG} ..."
if ! pkg-config --atleast-version=2.2.0 libuev 2>/dev/null; then
  (cd /tmp && rm -rf libuev && \
   git clone https://github.com/troglobit/libuev.git && cd libuev && \
   git checkout ${LIBUEV_TAG} && ./autogen.sh && \
   ./configure --prefix=/usr/local && make -j"$(nproc)" && sudo make install)
fi

echo "[*] Building libite ${LIBITE_TAG} ..."
if ! pkg-config --atleast-version=1.5.0 libite 2>/dev/null; then
  (cd /tmp && rm -rf libite && \
   git clone https://github.com/troglobit/libite.git && cd libite && \
   git checkout ${LIBITE_TAG} && ./autogen.sh && \
   ./configure --prefix=/usr/local && make -j"$(nproc)" && sudo make install)
fi
sudo ldconfig

echo "[*] Building uftpd ${UFTPD_TAG} for fuzzing (ASAN + afl instrumentation) ..."
rm -rf "${WORKDIR}/uftpd"
(cd "${WORKDIR}" && git clone https://github.com/troglobit/uftpd.git && \
 cd uftpd && git checkout ${UFTPD_TAG} && \
 patch -p1 < "$(dirname "$0")/fuzzing.patch" && \
 ./autogen.sh && \
 AFL_USE_ASAN=1 CC=afl-clang-fast ./configure && \
 make -j"$(nproc)")

echo "[*] Building uftpd ${UFTPD_TAG} for coverage (gcov) ..."
rm -rf "${WORKDIR}/uftpd-gcov"
(cd "${WORKDIR}" && git clone https://github.com/troglobit/uftpd.git uftpd-gcov && \
 cd uftpd-gcov && git checkout ${UFTPD_TAG} && \
 patch -p1 < "$(dirname "$0")/gcov.patch" && \
 ./autogen.sh && \
 CFLAGS="-fprofile-arcs -ftest-coverage" LDFLAGS="-fprofile-arcs -ftest-coverage" ./configure && \
 make -j"$(nproc)")

echo "[*] Installing seeds, dict, scripts ..."
cp -r "$(dirname "$0")/in-ftp"        "${WORKDIR}/in-ftp"
cp    "$(dirname "$0")/ftp.dict"      "${WORKDIR}/ftp.dict"
cp    "$(dirname "$0")/run.sh"        "${WORKDIR}/run"
cp    "$(dirname "$0")/clean.sh"      "${WORKDIR}/ftpclean"
cp    "$(dirname "$0")/cov_script.sh" "${WORKDIR}/cov_script"
cp    "$(dirname "$0")/crash_script"  "${WORKDIR}/crash_script"
chmod +x "${WORKDIR}/run" "${WORKDIR}/ftpclean" "${WORKDIR}/cov_script" "${WORKDIR}/crash_script"

mkdir -p "${FTPSHARE}"
echo "This is a test file for uftpd fuzzing." > "${FTPSHARE}/test.txt"
mkdir -p "${FTPSHARE}/testdir"

cat <<EOF

Done.  Add to your shell profile (or export now):
  export WORKDIR=${WORKDIR}
  export AFLNET=${HOME}/aflnet
  export PATH=\$PATH:\$AFLNET:${WORKDIR}
  export AFL_I_DONT_CARE_ABOUT_MISSING_CRASHES=1 AFL_SKIP_CPUFREQ=1 AFL_NO_AFFINITY=1
  export FTPSHARE=${FTPSHARE}

Then run e.g. a 30-min AFLNet campaign:
  run aflnet uftpd-aflnet-out "" 1800 5
EOF
