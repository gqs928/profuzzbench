#!/bin/bash
#
# ProFuzzBench coverage-collection script, adapted for uftpd.
# Replay every test case produced by the fuzzer against the gcov-instrumented
# build and record line/branch coverage over time.
#
#   folder : fuzzer result folder (the -o outdir of afl-fuzz)
#   pno    : FTP control port uftpd listens on
#   step   : run gcovr after every N test cases (e.g. 5)
#   covfile: CSV output path
#   fmode  : 0 = concatenated message sequence (afl/aflnwe, queue/)
#            1 = structured message sequence    (aflnet, replayable-queue/)
#
# Run this from the gcov build directory:  ${WORKDIR}/uftpd-gcov
# Requires:  aflnet-replay on PATH, ftpclean (clean.sh) on PATH,
#            gcovr, and the gcov-built binary at src/uftpd.

folder=$1
pno=$2
step=$3
covfile=$4
fmode=$5

UFTPD_GCOV=${UFTPD_GCOV:-$(pwd)}
UFTPD_BIN=${UFTPD_BIN:-${UFTPD_GCOV}/src/uftpd}
UFTPD_ARGS="-n -o ftp=${pno},tftp=0,writable -p /tmp/uftpd.pid /home/ubuntu/ftpshare"

#delete the existing coverage file
rm -f $covfile; touch $covfile

#clear gcov data -- coverage counters accumulate across replays
cd ${UFTPD_GCOV}
gcovr -r . -s -d > /dev/null 2>&1

#output the CSV header
#Time: timestamp, l_per/b_per and l_abs/b_abs: line/branch coverage in
#percentage and absolute numbers
echo "Time,l_per,l_abs,b_per,b_abs" >> $covfile

#files stored in replayable-* folders are structured
if [ $fmode -eq "1" ]; then
  testdir="replayable-queue"
  replayer="aflnet-replay"
else
  testdir="queue"
  replayer="afl-replay"
fi

replay_one() {
  f=$1
  #terminate any still-running server
  pkill -x uftpd 2>/dev/null
  ftpclean
  $replayer $f FTP $pno 1 > /dev/null 2>&1 &
  #uftpd exits by itself when the replayed session ends; the timeout is only
  #a safety net for inputs that leave the session hanging
  timeout -k 0 3s ${UFTPD_BIN} ${UFTPD_ARGS} > /dev/null 2>&1
  wait
}

dump_cov() {
  cov_data=$(gcovr -r . -s | grep "[lb][a-z]*:")
  l_per=$(echo "$cov_data" | grep lines   | cut -d" " -f2 | rev | cut -c2- | rev)
  l_abs=$(echo "$cov_data" | grep lines   | cut -d" " -f3 | cut -c2-)
  b_per=$(echo "$cov_data" | grep branch  | cut -d" " -f2 | rev | cut -c2- | rev)
  b_abs=$(echo "$cov_data" | grep branch  | cut -d" " -f3 | cut -c2-)
  echo "$time,$l_per,$l_abs,$b_per,$b_abs" >> $covfile
}

#process initial seed corpus first
for f in $(echo $folder/$testdir/*.raw); do
  time=$(stat -c %Y $f)
  replay_one $f
  dump_cov
done

#process fuzzer-generated testcases
count=0
for f in $(echo $folder/$testdir/id*); do
  time=$(stat -c %Y $f)
  replay_one $f
  count=$(expr $count + 1)
  rem=$(expr $count % $step)
  if [ "$rem" != "0" ]; then continue; fi
  dump_cov
done

#output cov data for the last testcase(s) if step > 1
if [[ $step -gt 1 ]]; then
  dump_cov
fi
