# uftpd 模糊测试基准（ProFuzzBench 风格）

测试目标：[uftpd](https://github.com/troglobit/uftpd) v2.17 —— Joachim Wiberg
维护的 "No Nonsense FTP/TFTP Server"。使用
[AFLNet](https://github.com/profuzzbench/aflnet) 对 FTP 控制信道做协议模糊测试。

本目录结构对齐 ProFuzzBench 的 `subjects/FTP/*`:

| 文件           | 作用 |
|----------------|------|
| `Dockerfile`   | 一条命令构建可复现容器环境 |
| `build.sh`     | 等价裸机构建脚本（用于 Kali 虚拟机） |
| `fuzzing.patch`| AFL 插桩 + ASAN 构建用的源码补丁 |
| `gcov.patch`   | gcov 覆盖率构建用的源码补丁 |
| `in-ftp/`      | 种子语料（合法 FTP 会话，CRLF 行尾） |
| `ftp.dict`     | AFL 字典（FTP 命令动词与参数） |
| `run.sh`       | 启动模糊测试 + 覆盖率收集（容器内名为 `run`) |
| `clean.sh`     | 每轮测试前的状态重置（容器内名为 `ftpclean`) |
| `cov_script.sh`| 回放队列并输出 `cov_over_time.csv` |
| `crash_script` | 独立回放崩溃样本 |

## 构建方式

### Docker（推荐，一条命令）

```console
$ docker build -t uftpd-fuzz .
$ docker run -it --privileged uftpd-fuzz
```

### 裸机（Kali/Ubuntu 虚拟机）

```console
$ ./build.sh
```

脚本会装依赖、编译 AFLNet、从源码安装 libuev/libite，并产出两份 uftpd
构建：`~/experiments/uftpd`（插桩+ASAN）和 `~/experiments/uftpd-gcov`
(gcov 覆盖率）。

## 运行方式

容器内（或 `build.sh` 跑完后的虚拟机里）:

```console
# 端口 2121 上跑 30 分钟 AFLNet，每 5 个用例采一次覆盖率
$ run aflnet uftpd-aflnet-out "" 1800 5
```

等价的手动命令：

```console
$ cd ~/experiments/uftpd
$ afl-fuzz -d -i ~/experiments/in-ftp -x ~/experiments/ftp.dict \
    -o ~/experiments/uftpd-aflnet-out -N tcp://127.0.0.1/2121 \
    -c ~/experiments/ftpclean \
    ./src/uftpd -n -o ftp=2121,tftp=0,writable -p /tmp/uftpd.pid ~/ftpshare
```

`run` 结束时自动回放队列统计覆盖率，输出 `cov_over_time.csv` 和
`cov_html/` HTML 报告；崩溃样本可用下面命令独立复现：

```console
$ cd ~/experiments/uftpd && crash_script ~/experiments/uftpd-aflnet-out 2121 1
```

## 改了什么、为什么改

两个补丁都只改 `src/common.c:new_session()`，效果相同——gcov 补丁单独
存在只是为了沿用 ProFuzzBench 双补丁的惯例。

* **去掉每连接一次的 `fork()`。** 原版 uftpd 对每个 FTP 连接 fork 一个
  子进程跑会话，父进程留在 accept 循环里。而 AFLNet 是每个测试用例亲自
  拉起一次服务端进程，只观测这一个进程——如果崩溃发生在 fork 出来的
  "孙进程"里，fuzzer 完全看不到；同时会话结束后主进程仍驻留，第二次
  回放同一输入时行为就不一样了。打补丁后，会话在被拉起的进程内直接处理
  （用独立的 `uev_ctx_t`，和原来 fork 子进程的做法一致），会话一结束
  进程就干净退出，每个用例都跑在全新的进程里。

* **连带删掉 `setpgid(0, getppid())`。** 它原本是让子进程加入父进程组、
  配合父进程退出时 `killpg()` 广播的。不 fork 之后如果保留，会把
  uftpd 加进 fuzzer 自己的进程组，SIGTERM 处理路径里的 `killpg()` 可能
  把 afl-fuzz 一起杀掉。

* **协议代码零改动。** `ftpcmd.c`、`tftpcmd.c` 全部保持原样，保留协议
  核心逻辑。

## 运行时配置

* `uftpd -n` —— 前台运行，不 daemonize(AFLNet 直接控制进程生命周期）。
* `-o ftp=2121,tftp=0,writable` —— FTP 用非特权端口 2121，关掉 TFTP
  （本目标只测 FTP)，允许可写 FTP 根目录（否则 STOR/MKD 进不了写路径）。
* `-p /tmp/uftpd.pid` —— pidfile 固定到 /tmp，避免非 root 写 /run 报错。
* `~/ftpshare` —— FTP 根目录；`ftpclean` 在每轮测试前把它重置为固定
  初态（`test.txt` + `testdir/`)，因为 MKD/STOR/RMD/DELE 会改动它。
* 以普通用户 `ubuntu` 运行，uftpd 的 chroot/降权路径不会触发；会话代码
  里的崩溃依然能被 ASAN 捕获。

## 验收清单

1. 全新容器可构建：`docker build -t uftpd-fuzz .`
2. 同一种子回放 10 次稳定：`cov_script`/`crash_script` 每次回放前都用
   `ftpclean` 重置状态，结果一致。
3. 试跑 30 分钟：`run aflnet out "" 1800 5`；前台模式 + 每用例一个进程
   的设定排除了启动失败和假超时。
4. 覆盖率到达 `ftpcmd.c` 的协议处理代码；`replayable-crashes/` 中的异常
   样本能用 `crash_script` 独立回放。
