#!/bin/bash
#
# ProFuzzBench-style run script for uftpd.
#
#   FUZZER    : fuzzer name; must match the fuzzer folder inside the
#               container/home dir (e.g. aflnet, aflnwe)
#   OUTDIR    : output folder name (created under the build dir)
#   OPTIONS   : extra afl-fuzz options
#   TIMEOUT   : total fuzzing time (e.g. 1800 for a 30-min trial)
#   SKIPCOUNT : coverage sampling step, e.g. 5 -> gcovr every 5 test cases
#
# Example:
#   run aflnet uftpd-aflnet-out "" 1800 5

FUZZER=$1
OUTDIR=$2
OPTIONS=$3
TIMEOUT=$4
SKIPCOUNT=$5

PORT=${PORT:-2121}
FTPSHARE=${FTPSHARE:-/home/ubuntu/ftpshare}

strstr() {
  [ "${1#*$2*}" = "$1" ] && return 1
  return 0
}

#Commands for afl-based fuzzers (e.g., aflnet, aflnwe)
if $(strstr $FUZZER "afl"); then

  # Run fuzzer-specific commands (if any)
  if [ -e ${WORKDIR}/run-${FUZZER} ]; then
    source ${WORKDIR}/run-${FUZZER}
  fi

  TARGET_DIR=${TARGET_DIR:-"uftpd"}
  INPUTS=${INPUTS:-"${WORKDIR}/in-ftp"}

  #Step-1. Do Fuzzing
  cd $WORKDIR/${TARGET_DIR}
  timeout -k 0 --preserve-status $TIMEOUT /home/ubuntu/${FUZZER}/afl-fuzz -d -i ${INPUTS} -x ${WORKDIR}/ftp.dict -o $OUTDIR -N tcp://127.0.0.1/${PORT} $OPTIONS -c ${WORKDIR}/ftpclean ./src/uftpd -n -o ftp=${PORT},tftp=0,writable -p /tmp/uftpd.pid ${FTPSHARE}

  STATUS=$?

  #Step-2. Collect code coverage over time
  cd $WORKDIR/uftpd-gcov

  #fmode 0: concatenated message sequence (aflnwe), 1: structured (aflnet)
  if [ $FUZZER = "aflnwe" ]; then
    cov_script ${WORKDIR}/${TARGET_DIR}/${OUTDIR}/ ${PORT} ${SKIPCOUNT} ${WORKDIR}/${TARGET_DIR}/${OUTDIR}/cov_over_time.csv 0
  else
    cov_script ${WORKDIR}/${TARGET_DIR}/${OUTDIR}/ ${PORT} ${SKIPCOUNT} ${WORKDIR}/${TARGET_DIR}/${OUTDIR}/cov_over_time.csv 1
  fi

  gcovr -r . --html --html-details -o index.html
  mkdir -p ${WORKDIR}/${TARGET_DIR}/${OUTDIR}/cov_html/
  cp *.html ${WORKDIR}/${TARGET_DIR}/${OUTDIR}/cov_html/ 2>/dev/null

  #Step-3. Save the result to the ${WORKDIR} folder
  cd ${WORKDIR}/${TARGET_DIR}
  tar -zcvf ${WORKDIR}/${OUTDIR}.tar.gz ${OUTDIR}

  exit $STATUS
fi
