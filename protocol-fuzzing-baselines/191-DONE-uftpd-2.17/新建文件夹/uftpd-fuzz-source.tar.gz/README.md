# uftpd 模糊测试基准（ProFuzzBench 风格）

目标程序：[uftpd](https://github.com/troglobit/uftpd) v2.17 —— "No Nonsense
FTP/TFTP Server"，作者 Joachim Wiberg。使用
[AFLNet](https://github.com/profuzzbench/aflnet) 对 FTP 控制通道进行模糊测试。

本目录布局与 ProFuzzBench 的 `subjects/FTP/*` 保持一致：

| 文件           | 作用 |
|----------------|------|
| `Dockerfile`   | 一条命令构建可复现容器环境 |
| `build.sh`     | 等价的裸机/Kali 虚拟机构建脚本 |
| `fuzzing.patch`| AFL 插桩 + ASAN 构建所用的补丁 |
| `gcov.patch`   | gcov 覆盖率构建所用的补丁 |
| `in-ftp/`      | 种子语料（合法 FTP 会话，CRLF 行尾） |
| `ftp.dict`     | AFL 字典（FTP 命令动词和参数） |
| `run.sh`       | 启动模糊器 + 覆盖率收集（容器内为 `run`） |
| `clean.sh`     | 每轮迭代前的状态重置（容器内为 `ftpclean`） |
| `cov_script.sh`| 回放所有测试用例，输出 `cov_over_time.csv` |
| `crash_script` | 独立回放发现的崩溃样本 |

## 构建方法

### Docker（推荐，一条命令）

```console
$ docker build -t uftpd-fuzz .
$ docker run -it --privileged uftpd-fuzz
```

### 裸机 / Kali 虚拟机

```console
$ ./build.sh
```

`build.sh` 会自动安装依赖、编译 AFLNet、安装 libuev/libite，并生成与
Docker 容器内相同的目录布局。

## 运行方法

在容器内（或 Kali 虚拟机执行完 `build.sh` 并 source 环境变量之后）：

```console
# 在 2121 端口上对 AFLNet 跑 30 分钟，每 5 个用例采样一次覆盖率
$ run aflnet uftpd-aflnet-out "" 1800 5
```

等价的手动命令：

```console
$ cd ~/experiments/uftpd
$ afl-fuzz -d -i ~/experiments/in-ftp -x ~/experiments/ftp.dict \
    -o ~/experiments/uftpd-aflnet-out -N tcp://127.0.0.1/2121 \
    -c ~/experiments/ftpclean \
    ./src/uftpd -n -o ftp=2121,tftp=0,writable -p /tmp/uftpd.pid ~/ftpshare
```

`run` 结束时会自动完成覆盖率回放，生成 `cov_over_time.csv` 和 `cov_html/`
报告；对发现的崩溃可以用 `crash_script` 独立复现：

```console
$ cd ~/experiments/uftpd && crash_script ~/experiments/uftpd-aflnet-out 2121 1
```

## 改动内容及其原因

两个补丁都只修改 `src/common.c` 中的 `new_session()` 函数，效果完全
相同；拆成两个文件只是为了遵循 ProFuzzBench "fuzzing.patch / gcov.patch"
双补丁的约定。

* **禁用每个连接一次的 `fork()`。** 上游 uftpd 为每个 FTP 会话 `fork()`
  一个子进程，父进程留在 accept 循环里。AFLNet 的工作方式是：每个测试
  用例拉起一个服务端进程、发送输入、然后将其杀掉 —— 它只能观测到自己
  直接启动的那个进程。如果会话在 fork 出的孙进程里崩溃，fuzzer 完全看
  不到；而且测试结束后主进程仍然驻留，导致同一个输入第二次回放时行为
  不一致。打上补丁后，会话在 fuzzer 启动的那个进程内处理（使用独立的
  `uev_ctx_t`，与原来 fork 出的子进程逻辑一致），会话结束时进程正常退
  出。`setpgid(0, getppid())` 一并删除：既然不再有子进程组，留着它反而
  可能让 `sigquit_cb` 里的 `killpg()` 把 fuzzer 自己的进程组一起杀掉。

* **协议逻辑零改动。** `ftpcmd.c`、`tftpcmd.c` 一行未动。

## 运行时配置说明

* `uftpd -n` —— 前台运行，不 daemonize，由 AFLNet 控制进程生命周期。
* `-o ftp=2121,tftp=0,writable` —— FTP 监听非特权端口 2121，关闭 TFTP
  （本 subject 只测 FTP），允许可写 FTP 根目录。
* `-p /tmp/uftpd.pid` —— 固定且可写的 pidfile 路径，避免默认路径的权限
  问题影响可重复性。
* `~/ftpshare` —— FTP 根目录；`ftpclean` 在每轮测试前将其重置为固定初
  态（`test.txt` + `testdir/`），因为 MKD/STOR/RMD/DELE 会改变文件系统。
* 服务端以非特权 `ubuntu` 用户运行，跳过 uftpd 的 chroot 和降权路径；
  崩溃仍由 ASAN 在会话代码中捕获。

## 验收清单

1. 全新容器可构建：`docker build -t uftpd-fuzz .`
2. 同一种子回放 10 次结果稳定：`cov_script` / `crash_script` 每次回放前
   都通过 `ftpclean` 重置文件系统状态。
3. 30 分钟试跑：`run aflnet out "" 1800 5`；前台运行 + 每轮一个进程的
   设计排除了启动失败和假超时。
4. 覆盖率到达 `ftpcmd.c` 中的协议处理代码；`replayable-crashes/` 中的
   异常样本可通过 `crash_script` 独立回放复现。
