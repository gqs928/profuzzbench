#!/bin/bash
#
# uftpd state cleanup between fuzz iterations (ProFuzzBench-style).
#
# uftpd serves files from ${FTPSHARE}.  Fuzzed MKD/STOR/RMD/DELE commands
# mutate that directory, so we wipe it back to a fixed initial state before
# each test case; otherwise the same input would produce different coverage
# depending on what previous inputs left behind.
#
# Initial state (what every iteration starts from):
#   test.txt    -> target for RETR/SIZE/MDTM/DELE
#   testdir/    -> target for CWD/RMD/LIST

FTPSHARE="${FTPSHARE:-/home/ubuntu/ftpshare}"

mkdir -p "${FTPSHARE}"
find "${FTPSHARE}" -mindepth 1 -delete 2>/dev/null

echo "This is a test file for uftpd fuzzing." > "${FTPSHARE}/test.txt"
mkdir -p "${FTPSHARE}/testdir"

rm -f /tmp/uftpd.pid /tmp/uftpd.log 2>/dev/null
exit 0
