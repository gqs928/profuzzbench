/*
 * Asterisk -- An open source telephony toolkit.
 *
 * Copyright (C) 2005, Anthony Minessale II
 * Copyright (C) 2005 - 2006, Digium, Inc.
 *
 * Mark Spencer <markster@digium.com>
 * Kevin P. Fleming <kpfleming@digium.com>
 *
 * Based on app_muxmon.c provided by
 * Anthony Minessale II <anthmct@yahoo.com>
 *
 * See http://www.asterisk.org for more information about
 * the Asterisk project. Please do not directly contact
 * any of the maintainers of this project for assistance;
 * the project provides a web site, mailing lists and IRC
 * channels for your use.
 *
 * This program is free software, distributed under the terms of
 * the GNU General Public License Version 2. See the LICENSE file
 * at the top of the source tree.
 */

/*! \file
 *
 * \brief MixMonitor() - Record a call and mix the audio during the recording
 * \ingroup applications
 *
 * \author Mark Spencer <markster@digium.com>
 * \author Kevin P. Fleming <kpfleming@digium.com>
 *
 * \note Based on app_muxmon.c provided by
 * Anthony Minessale II <anthmct@yahoo.com>
 */

/*** MODULEINFO
	<use type="module">func_periodic_hook</use>
	<support_level>core</support_level>
 ***/

#include "asterisk.h"

#include "asterisk/paths.h"	/* use ast_config_AST_MONITOR_DIR */
#include "asterisk/stringfields.h"
#include "asterisk/file.h"
#include "asterisk/audiohook.h"
#include "asterisk/pbx.h"
#include "asterisk/module.h"
#include "asterisk/cli.h"
#include "asterisk/app.h"
#include "asterisk/channel.h"
#include "asterisk/autochan.h"
#include "asterisk/manager.h"
#include "asterisk/stasis.h"
#include "asterisk/stasis_channels.h"
#include "asterisk/callerid.h"
#include "asterisk/mod_format.h"
#include "asterisk/linkedlists.h"
#include "asterisk/test.h"
#include "asterisk/mixmonitor.h"
#include "asterisk/format_cache.h"
#include "asterisk/beep.h"
#include "asterisk/translate.h"

/*** DOCUMENTATION
	<application name="MixMonitor" language="en_US">
		<since>
			<version>1.2.0</version>
		</since>
		<synopsis>
			Record a call and mix the audio during the recording.  Use of StopMixMonitor is required
			to guarantee the audio file is available for processing during dialplan execution.
		</synopsis>
		<syntax>
			<parameter name="file" required="true" argsep=".">
				<argument name="filename" required="true">
					<para>If <replaceable>filename</replaceable> is an absolute path, uses that path, otherwise
					creates the file in the configured monitoring directory from <filename>asterisk.conf.</filename></para>
				</argument>
				<argument name="extension" required="true" />
			</parameter>
			<parameter name="options">
				<optionlist>
					<option name="a">
						<para>Append to the file instead of overwriting it.</para>
					</option>
					<option name="b">
						<para>Only save audio to the file while the channel is bridged.</para>
						<note><para>If you utilize this option inside a Local channel, you must make sure the Local
						channel is not optimized away. To do this, be sure to call your Local channel with the
						<literal>/n</literal> option. For example: Dial(Local/start@mycontext/n)</para></note>
					</option>
					<option name="B">
						<para>Play a periodic beep while this call is being recorded.</para>
						<argument name="interval"><para>Interval, in seconds. Default is 15.</para></argument>
					</option>
					<option name="c">
						<para>Use the real Caller ID from the channel for the voicemail Caller ID.</para>
						<para>By default, the Connected Line is used. If you want the channel caller's
						real number, you may need to specify this option.</para>
					</option>
					<option name="d">
						<para>Delete the recording file as soon as MixMonitor is done with it.</para>
						<para>For example, if you use the m option to dispatch the recording to a voicemail box,
						you can specify this option to delete the original copy of it afterwards.</para>
					</option>
					<option name="v">
						<para>Adjust the <emphasis>heard</emphasis> volume by a factor of <replaceable>x</replaceable>
						(range <literal>-4</literal> to <literal>4</literal>)</para>
						<argument name="x" required="true" />
					</option>
					<option name="V">
						<para>Adjust the <emphasis>spoken</emphasis> volume by a factor
						of <replaceable>x</replaceable> (range <literal>-4</literal> to <literal>4</literal>)</para>
						<argument name="x" required="true" />
					</option>
					<option name="W">
						<para>Adjust both, <emphasis>heard and spoken</emphasis> volumes by a factor
						of <replaceable>x</replaceable> (range <literal>-4</literal> to <literal>4</literal>)</para>
						<argument name="x" required="true" />
					</option>
					<option name="r">
						<argument name="file" required="true" />
						<para>Use the specified file to record the <emphasis>receive</emphasis> audio feed.
						Like with the basic filename argument, if an absolute path isn't given, it will create
						the file in the configured monitoring directory.</para>
					</option>
					<option name="t">
						<argument name="file" required="true" />
						<para>Use the specified file to record the <emphasis>transmit</emphasis> audio feed.
						Like with the basic filename argument, if an absolute path isn't given, it will create
						the file in the configured monitoring directory.</para>
					</option>
					<option name="D">
						<para>Interleave the audio coming from the channel and the audio
						going to the channel and output it as a 2 channel (stereo)
						raw stream rather than mixing it. You must use the
						<literal>.raw</literal> file extension. Any other extension
						will produce a corrupted file.</para>
					</option>
					<option name="n">
						<para>When the <replaceable>r</replaceable> or <replaceable>t</replaceable> option is
						used, MixMonitor will insert silence into the specified files to maintain
						synchronization between them. Use this option to disable that behavior.</para>
					</option>
					<option name="i">
						<argument name="chanvar" required="true" />
						<para>Stores the MixMonitor's ID on this channel variable.</para>
					</option>
					<option name="p">
						<para>Play a beep on the channel that starts the recording.</para>
					</option>
					<option name="P">
						<para>Play a beep on the channel that stops the recording.</para>
					</option>
					<option name="m">
						<argument name="mailbox" required="true" />
						<para>Create a copy of the recording as a voicemail in the indicated <emphasis>mailbox</emphasis>(es)
						separated by commas eg. m(1111@default,2222@default,...).  Folders can be optionally specified using
						the syntax: mailbox@context/folder</para>
					</option>
					<option name="s">
						<argument name="seconds" required="true" />
						<para>Don't record until <replaceable>seconds</replaceable> (can be fractional) have elapsed since MixMonitor was invoked.
						No audio is written to the recording file during this time. If the call ends before this period,
						no audio will be saved. This can be useful to avoid recording announcements,
						ringback tones, or other non-essential early audio.</para>
					</option>
				</optionlist>
			</parameter>
			<parameter name="command">
				<para>Will be executed when the recording is over.</para>
				<para>Any strings matching <literal>^{X}</literal> will be unescaped to <variable>X</variable>.</para>
				<para>All variables will be evaluated at the time MixMonitor is called.</para>
				<warning><para>Do not use untrusted strings such as <variable>CALLERID(num)</variable>
				or <variable>CALLERID(name)</variable> as part of the command parameters.  You
				risk a command injection attack executing arbitrary commands if the untrusted
				strings aren't filtered to remove dangerous characters.  See function
				<variable>FILTER()</variable>.</para></warning>
			</parameter>
		</syntax>
		<description>
			<para>Records the audio on the current channel to the specified file.</para>
			<para>This application does not automatically answer and should be preceded by
			an application such as Answer or Progress().</para>
			<note><para>MixMonitor runs as an audiohook.</para></note>
			<note><para>If a filename passed to MixMonitor ends with
			<literal>.wav49</literal>, Asterisk will silently convert the extension to
			<literal>.WAV</literal> for legacy reasons. <variable>MIXMONITOR_FILENAME</variable>
			will contain the actual filename that Asterisk is writing to, not necessarily the
			value that was passed in.</para></note>
			<variablelist>
				<variable name="MIXMONITOR_FILENAME">
					<para>Will contain the filename used to record.</para>
				</variable>
			</variablelist>
			<warning><para>Do not use untrusted strings such as <variable>CALLERID(num)</variable>
			or <variable>CALLERID(name)</variable> as part of ANY of the application's
			parameters.  You risk a command injection attack executing arbitrary commands
			if the untrusted strings aren't filtered to remove dangerous characters.  See
			function <variable>FILTER()</variable>.</para></warning>
			<warning><para>When using the <literal>D</literal> option to save
			interleaved audio, you MUST use <literal>.raw</literal> as the
			file extension.  Any other extension will produce a corrupted file.</para></warning>
		</description>
		<see-also>
			<ref type="application">StopMixMonitor</ref>
		</see-also>
	</application>
	<application name="StopMixMonitor" language="en_US">
		<since>
			<version>1.4.0</version>
		</since>
		<synopsis>
			Stop recording a call through MixMonitor, and free the recording's file handle.
		</synopsis>
		<syntax>
			<parameter name="MixMonitorID" required="false">
				<para>If a valid ID is provided, then this command will stop only that specific
				MixMonitor.</para>
			</parameter>
		</syntax>
		<description>
			<para>Stops the audio recording that was started with a call to <literal>MixMonitor()</literal>
			on the current channel.</para>
		</description>
		<see-also>
			<ref type="application">MixMonitor</ref>
		</see-also>
	</application>
	<manager name="MixMonitorMute" language="en_US">
		<since>
			<version>1.8.0</version>
		</since>
		<synopsis>
			Mute / unMute a Mixmonitor recording.
		</synopsis>
		<syntax>
			<xi:include xpointer="xpointer(/docs/manager[@name='Login']/syntax/parameter[@name='ActionID'])" />
			<parameter name="Channel" required="true">
				<para>Used to specify the channel to mute.</para>
			</parameter>
			<parameter name="Direction">
				<para>Which part of the recording to mute:  read, write or both (from channel, to channel or both channels).</para>
			</parameter>
			<parameter name="State">
				<para>Turn mute on or off : 1 to turn on, 0 to turn off.</para>
			</parameter>
		</syntax>
		<description>
			<para>This action may be used to mute a MixMonitor recording.</para>
		</description>
	</manager>
	<manager name="MixMonitor" language="en_US">
		<since>
			<version>11.0.0</version>
		</since>
		<synopsis>
			Record a call and mix the audio during the recording.  Use of StopMixMonitor is required
			to guarantee the audio file is available for processing during dialplan execution.
		</synopsis>
		<syntax>
			<xi:include xpointer="xpointer(/docs/manager[@name='Login']/syntax/parameter[@name='ActionID'])" />
			<parameter name="Channel" required="true">
				<para>Used to specify the channel to record.</para>
			</parameter>
			<parameter name="File">
				<para>Is the name of the file created in the monitor spool directory.
				Defaults to the same name as the channel (with slashes replaced with dashes).
				This argument is optional if you specify to record unidirectional audio with
				either the r(filename) or t(filename) options in the options field. If
				neither MIXMONITOR_FILENAME or this parameter is set, the mixed stream won't
				be recorded.</para>
			</parameter>
			<parameter name="Options">
				<para>Options that apply to the MixMonitor in the same way as they
				would apply if invoked from the MixMonitor application. For a list of
				available options, see the documentation for the mixmonitor application. </para>
			</parameter>
			<parameter name="Command">
				<para>Will be executed when the recording is over.
				Any strings matching <literal>^{X}</literal> will be unescaped to <variable>X</variable>.
				All variables will be evaluated at the time MixMonitor is called.</para>
				<warning><para>Do not use untrusted strings such as <variable>CALLERID(num)</variable>
				or <variable>CALLERID(name)</variable> as part of the command parameters.  You
				risk a command injection attack executing arbitrary commands if the untrusted
				strings aren't filtered to remove dangerous characters.  See function
				<variable>FILTER()</variable>.</para></warning>
			</parameter>
		</syntax>
		<description>
			<para>This action records the audio on the current channel to the specified file.</para>
			<variablelist>
				<variable name="MIXMONITOR_FILENAME">
					<para>Will contain the filename used to record the mixed stream.</para>
				</variable>
			</variablelist>
		</description>
	</manager>
	<manager name="StopMixMonitor" language="en_US">
		<since>
			<version>11.0.0</version>
		</since>
		<synopsis>
			Stop recording a call through MixMonitor, and free the recording's file handle.
		</synopsis>
		<syntax>
			<xi:include xpointer="xpointer(/docs/manager[@name='Login']/syntax/parameter[@name='ActionID'])" />
			<parameter name="Channel" required="true">
				<para>The name of the channel monitored.</para>
			</parameter>
			<parameter name="MixMonitorID" required="false">
				<para>If a valid ID is provided, then this command will stop only that specific
				MixMonitor.</para>
			</parameter>
		</syntax>
		<description>
			<para>This action stops the audio recording that was started with the <literal>MixMonitor</literal>
			action on the current channel.</para>
		</description>
	</manager>
	<function name="MIXMONITOR" language="en_US">
		<since>
			<version>13.0.0</version>
		</since>
		<synopsis>
			Retrieve data pertaining to specific instances of MixMonitor on a channel.
		</synopsis>
		<syntax>
			<parameter name="id" required="true">
				<para>The unique ID of the MixMonitor instance. The unique ID can be retrieved through the channel
				variable used as an argument to the <replaceable>i</replaceable> option to MixMonitor.</para>
			</parameter>
			<parameter name="key" required="true">
				<para>The piece of data to retrieve from the MixMonitor.</para>
				<enumlist>
					<enum name="filename" />
				</enumlist>
			</parameter>
		</syntax>
	</function>
	<managerEvent language="en_US" name="MixMonitorStart">
		<managerEventInstance class="EVENT_FLAG_CALL">
			<since>
				<version>16.17.0</version>
				<version>18.3.0</version>
			</since>
			<synopsis>Raised when monitoring has started on a channel.</synopsis>
			<syntax>
				<channel_snapshot/>
			</syntax>
			<see-also>
				<ref type="managerEvent">MixMonitorStop</ref>
				<ref type="application">MixMonitor</ref>
				<ref type="manager">MixMonitor</ref>
			</see-also>
		</managerEventInstance>
	</managerEvent>
	<managerEvent language="en_US" name="MixMonitorStop">
		<managerEventInstance class="EVENT_FLAG_CALL">
			<since>
				<version>16.17.0</version>
				<version>18.3.0</version>
			</since>
		<synopsis>Raised when monitoring has stopped on a channel.</synopsis>
		<syntax>
			<channel_snapshot/>
		</syntax>
		<see-also>
			<ref type="managerEvent">MixMonitorStart</ref>
			<ref type="application">StopMixMonitor</ref>
			<ref type="manager">StopMixMonitor</ref>
		</see-also>
		</managerEventInstance>
	</managerEvent>
	<managerEvent language="en_US" name="MixMonitorMute">
		<managerEventInstance class="EVENT_FLAG_CALL">
			<since>
				<version>16.17.0</version>
				<version>18.3.0</version>
			</since>
		<synopsis>Raised when monitoring is muted or unmuted on a channel.</synopsis>
		<syntax>
			<channel_snapshot/>
			<parameter name="Direction">
				<para>Which part of the recording was muted or unmuted: read, write or both
				(from channel, to channel or both directions).</para>
			</parameter>
			<parameter name="State">
				<para>If the monitoring was muted or unmuted: 1 when muted, 0 when unmuted.</para>
			</parameter>
		</syntax>
		<see-also>
			<ref type="manager">MixMonitorMute</ref>
		</see-also>
		</managerEventInstance>
	</managerEvent>


 ***/

#define get_volfactor(x) x ? ((x > 0) ? (1 << x) : ((1 << abs(x)) * -1)) : 0

#define MIN_SKIP_SECONDS 1

static const char * const app = "MixMonitor";

static const char * const stop_app = "StopMixMonitor";

static const char * const mixmonitor_spy_type = "MixMonitor";

/*!
 * \internal
 * \brief This struct is a list item holds data needed to find a vm_recipient within voicemail
 */
struct vm_recipient {
	char mailbox[AST_MAX_CONTEXT];
	char context[AST_MAX_EXTENSION];
	char folder[80];
	AST_LIST_ENTRY(vm_recipient) list;
};

struct mixmonitor {
	struct ast_audiohook audiohook;
	char *filename;
	char *filename_read;
	char *filename_write;
	char *post_process;
	char *name;
	ast_callid callid;
	unsigned int flags;
	struct ast_autochan *autochan;
	struct mixmonitor_ds *mixmonitor_ds;

	/* the below string fields describe data used for creating voicemails from the recording */
	AST_DECLARE_STRING_FIELDS(
		AST_STRING_FIELD(call_context);
		AST_STRING_FIELD(call_extension);
		AST_STRING_FIELD(call_callerchan);
		AST_STRING_FIELD(call_callerid);
	);
	int call_priority;

	/* Number of seconds (can be fractional) to skip at the start of recording */
	double skip_seconds;

	/* FUTURE DEVELOPMENT NOTICE
	 * recipient_list will need locks if we make it editable after the monitor is started */
	AST_LIST_HEAD_NOLOCK(, vm_recipient) recipient_list;
};

enum mixmonitor_flags {
	MUXFLAG_APPEND = (1 << 1),
	MUXFLAG_BRIDGED = (1 << 2),
	MUXFLAG_VOLUME = (1 << 3),
	MUXFLAG_READVOLUME = (1 << 4),
	MUXFLAG_WRITEVOLUME = (1 << 5),
	MUXFLAG_READ = (1 << 6),
	MUXFLAG_WRITE = (1 << 7),
	MUXFLAG_COMBINED = (1 << 8),
	MUXFLAG_UID = (1 << 9),
	MUXFLAG_VMRECIPIENTS = (1 << 10),
	MUXFLAG_BEEP = (1 << 11),
	MUXFLAG_BEEP_START = (1 << 12),
	MUXFLAG_BEEP_STOP = (1 << 13),
	MUXFLAG_DEPRECATED_RWSYNC = (1 << 14),
	MUXFLAG_NO_RWSYNC = (1 << 15),
	MUXFLAG_AUTO_DELETE = (1 << 16),
	MUXFLAG_REAL_CALLERID = (1 << 17),
	MUXFLAG_INTERLEAVED = (1 << 18),
	MUXFLAG_SKIP = (1 << 19),
};

enum mixmonitor_args {
	OPT_ARG_READVOLUME = 0,
	OPT_ARG_WRITEVOLUME,
	OPT_ARG_VOLUME,
	OPT_ARG_WRITENAME,
	OPT_ARG_READNAME,
	OPT_ARG_UID,
	OPT_ARG_VMRECIPIENTS,
	OPT_ARG_BEEP_INTERVAL,
	OPT_ARG_DEPRECATED_RWSYNC,
	OPT_ARG_NO_RWSYNC,
	OPT_ARG_SKIP,
	OPT_ARG_ARRAY_SIZE,	/* Always last element of the enum */
};

AST_APP_OPTIONS(mixmonitor_opts, {
	AST_APP_OPTION('a', MUXFLAG_APPEND),
	AST_APP_OPTION('b', MUXFLAG_BRIDGED),
	AST_APP_OPTION_ARG('B', MUXFLAG_BEEP, OPT_ARG_BEEP_INTERVAL),
	AST_APP_OPTION('c', MUXFLAG_REAL_CALLERID),
	AST_APP_OPTION('d', MUXFLAG_AUTO_DELETE),
	AST_APP_OPTION('p', MUXFLAG_BEEP_START),
	AST_APP_OPTION('P', MUXFLAG_BEEP_STOP),
	AST_APP_OPTION_ARG('v', MUXFLAG_READVOLUME, OPT_ARG_READVOLUME),
	AST_APP_OPTION_ARG('V', MUXFLAG_WRITEVOLUME, OPT_ARG_WRITEVOLUME),
	AST_APP_OPTION_ARG('W', MUXFLAG_VOLUME, OPT_ARG_VOLUME),
	AST_APP_OPTION_ARG('r', MUXFLAG_READ, OPT_ARG_READNAME),
	AST_APP_OPTION_ARG('t', MUXFLAG_WRITE, OPT_ARG_WRITENAME),
	AST_APP_OPTION('D', MUXFLAG_INTERLEAVED),
	AST_APP_OPTION_ARG('i', MUXFLAG_UID, OPT_ARG_UID),
	AST_APP_OPTION_ARG('m', MUXFLAG_VMRECIPIENTS, OPT_ARG_VMRECIPIENTS),
	AST_APP_OPTION_ARG('S', MUXFLAG_DEPRECATED_RWSYNC, OPT_ARG_DEPRECATED_RWSYNC),
	AST_APP_OPTION_ARG('n', MUXFLAG_NO_RWSYNC, OPT_ARG_NO_RWSYNC),
	AST_APP_OPTION_ARG('s', MUXFLAG_SKIP, OPT_ARG_SKIP),
});

struct mixmonitor_ds {
	unsigned int destruction_ok;
	ast_cond_t destruction_condition;
	ast_mutex_t lock;

	/* The filestream is held in the datastore so it can be stopped
	 * immediately during stop_mixmonitor or channel destruction. */
	int fs_quit;

	struct ast_filestream *fs;
	struct ast_filestream *fs_read;
	struct ast_filestream *fs_write;

	struct ast_audiohook *audiohook;

	unsigned int samp_rate;
	char *filename;
	char *beep_id;
};

/*!
 * \internal
 * \pre mixmonitor_ds must be locked before calling this function
 */
static void mixmonitor_ds_close_fs(struct mixmonitor_ds *mixmonitor_ds)
{
	unsigned char quitting = 0;

	if (mixmonitor_ds->fs) {
		quitting = 1;
		ast_closestream(mixmonitor_ds->fs);
		mixmonitor_ds->fs = NULL;
		ast_verb(2, "MixMonitor close filestream (mixed)\n");
	}

	if (mixmonitor_ds->fs_read) {
		quitting = 1;
		ast_closestream(mixmonitor_ds->fs_read);
		mixmonitor_ds->fs_read = NULL;
		ast_verb(2, "MixMonitor close filestream (read)\n");
	}

	if (mixmonitor_ds->fs_write) {
		quitting = 1;
		ast_closestream(mixmonitor_ds->fs_write);
		mixmonitor_ds->fs_write = NULL;
		ast_verb(2, "MixMonitor close filestream (write)\n");
	}

	if (quitting) {
		mixmonitor_ds->fs_quit = 1;
	}
}

static void mixmonitor_ds_destroy(void *data)
{
	struct mixmonitor_ds *mixmonitor_ds = data;

	ast_mutex_lock(&mixmonitor_ds->lock);
	mixmonitor_ds->audiohook = NULL;
	mixmonitor_ds->destruction_ok = 1;
	ast_free(mixmonitor_ds->filename);
	ast_free(mixmonitor_ds->beep_id);
	ast_cond_signal(&mixmonitor_ds->destruction_condition);
	ast_mutex_unlock(&mixmonitor_ds->lock);
}

static const struct ast_datastore_info mixmonitor_ds_info = {
	.type = "mixmonitor",
	.destroy = mixmonitor_ds_destroy,
};

static void destroy_monitor_audiohook(struct mixmonitor *mixmonitor)
{
	if (mixmonitor->mixmonitor_ds) {
		ast_mutex_lock(&mixmonitor->mixmonitor_ds->lock);
		mixmonitor->mixmonitor_ds->audiohook = NULL;
		ast_mutex_unlock(&mixmonitor->mixmonitor_ds->lock);
	}
	/* kill the audiohook.*/
	ast_audiohook_lock(&mixmonitor->audiohook);
	ast_audiohook_detach(&mixmonitor->audiohook);
	ast_audiohook_unlock(&mixmonitor->audiohook);
	ast_audiohook_destroy(&mixmonitor->audiohook);
}

static int startmon(struct ast_channel *chan, struct ast_audiohook *audiohook)
{
	if (!chan) {
		return -1;
	}

	return ast_audiohook_attach(chan, audiohook);
}

/*!
 * \internal
 * \brief adds recipients to a mixmonitor's recipient list
 * \param mixmonitor mixmonitor being affected
 * \param vm_recipients string containing the desired recipients to add
 */
static void add_vm_recipients_from_string(struct mixmonitor *mixmonitor, const char *vm_recipients)
{
	/* recipients are in a single string with a format format resembling "mailbox@context/INBOX,mailbox2@context2,mailbox3@context3/Work" */
	char *cur_mailbox = ast_strdupa(vm_recipients);
	char *cur_context;
	char *cur_folder;
	char *next;
	int elements_processed = 0;

	while (!ast_strlen_zero(cur_mailbox)) {
		ast_debug(3, "attempting to add next element %d from %s\n", elements_processed, cur_mailbox);
		if ((next = strchr(cur_mailbox, ',')) || (next = strchr(cur_mailbox, '&'))) {
			*(next++) = '\0';
		}

		if ((cur_folder = strchr(cur_mailbox, '/'))) {
			*(cur_folder++) = '\0';
		} else {
			cur_folder = "INBOX";
		}

		if ((cur_context = strchr(cur_mailbox, '@'))) {
			*(cur_context++) = '\0';
		} else {
			cur_context = "default";
		}

		if (!ast_strlen_zero(cur_mailbox) && !ast_strlen_zero(cur_context)) {
			struct vm_recipient *recipient;
			if (!(recipient = ast_malloc(sizeof(*recipient)))) {
				ast_log(LOG_ERROR, "Failed to allocate recipient. Aborting function.\n");
				return;
			}
			ast_copy_string(recipient->context, cur_context, sizeof(recipient->context));
			ast_copy_string(recipient->mailbox, cur_mailbox, sizeof(recipient->mailbox));
			ast_copy_string(recipient->folder, cur_folder, sizeof(recipient->folder));

			/* Add to list */
			ast_verb(4, "Adding %s@%s to recipient list\n", recipient->mailbox, recipient->context);
			AST_LIST_INSERT_HEAD(&mixmonitor->recipient_list, recipient, list);
		} else {
			ast_log(LOG_ERROR, "Failed to properly parse extension and/or context from element %d of recipient string: %s\n", elements_processed, vm_recipients);
		}

		cur_mailbox = next;
		elements_processed++;
	}
}

static void clear_mixmonitor_recipient_list(struct mixmonitor *mixmonitor)
{
	struct vm_recipient *current;
	while ((current = AST_LIST_REMOVE_HEAD(&mixmonitor->recipient_list, list))) {
		/* Clear list element data */
		ast_free(current);
	}
}

#define SAMPLES_PER_FRAME 160

/* This will allocate and free the translator path as needed so it can be re-used on subsequent calls */
static void fill_frame_buffer(struct ast_frame *source_frame,
	struct ast_format *target_format,
	struct ast_format **last_source_format,
	struct ast_trans_pvt **translator_path,
	short *dest_buf,
	size_t dest_buf_size,
	const char *direction)
{
	struct ast_frame *converted_frame = NULL;

	if (!source_frame) {
		memset(dest_buf, 0, dest_buf_size);
		return;
	}

	/*
	 * We only need to worry about translating if the frame format does not match
	 * the expected format of the frame we are writing.
	 */
	if (ast_format_cmp(target_format, source_frame->subclass.format) == AST_FORMAT_CMP_NOT_EQUAL) {
		/*
		 * If the format changed from the last frame or if this is the first frame
		 * that does not match the native format, we need to set up a new
		 * translator path.
		 */
		if (ast_format_cmp(*last_source_format, source_frame->subclass.format) == AST_FORMAT_CMP_NOT_EQUAL
			|| !*translator_path) {
			ast_debug(3, "%s frame format changed from %s to %s, building translator path to %s\n",
				direction,
				*last_source_format ? ast_format_get_name(*last_source_format) : "none",
				ast_format_get_name(source_frame->subclass.format),
				ast_format_get_name(target_format));

			if (*translator_path) {
				ast_translator_free_path(*translator_path);
			}

			*translator_path = ast_translator_build_path(target_format, source_frame->subclass.format);
		}

		if (*translator_path) {
			converted_frame = ast_translate(*translator_path, source_frame, 0);
		}

		/*
		 * If creating the translated frame or translator path failed, write silence for this frame. We will
		 * try rebuilding the translator path later if it is still needed.
		 */
		if (converted_frame) {
			memcpy(dest_buf, converted_frame->data.ptr, dest_buf_size);
			ast_frame_free(converted_frame, 1);
		} else {
			memset(dest_buf, 0, dest_buf_size);
		}
	} else {
		memcpy(dest_buf, source_frame->data.ptr, dest_buf_size);

		/*
		 * If we are doing native frame copying, we can free the translator path if
		 * it exists. We will create a new one later if needed.
		 */
		if (*translator_path) {
			ast_translator_free_path(*translator_path);
			*translator_path = NULL;
			ast_debug(3, "%s frame format changed from %s to %s, translator path no longer needed\n",
				direction,
				*last_source_format ? ast_format_get_name(*last_source_format) : "none",
				ast_format_get_name(source_frame->subclass.format));
		}
	}

	*last_source_format = source_frame->subclass.format;
}

static void mixmonitor_free(struct mixmonitor *mixmonitor)
{
	if (mixmonitor) {
		if (mixmonitor->mixmonitor_ds) {
			ast_mutex_destroy(&mixmonitor->mixmonitor_ds->lock);
			ast_cond_destroy(&mixmonitor->mixmonitor_ds->destruction_condition);
			ast_free(mixmonitor->mixmonitor_ds);
		}

		ast_free(mixmonitor->name);
		ast_free(mixmonitor->post_process);
		ast_free(mixmonitor->filename);
		ast_free(mixmonitor->filename_write);
		ast_free(mixmonitor->filename_read);

		/* Free everything in the recipient list */
		clear_mixmonitor_recipient_list(mixmonitor);

		/* clean stringfields */
		ast_string_field_free_memory(mixmonitor);

		ast_free(mixmonitor);
	}
}

/*!
 * \internal
 * \brief Copies the mixmonitor to all voicemail recipients
 * \param mixmonitor The mixmonitor that needs to forward its file to recipients
 * \param ext Format of the file that was saved
 * \param filename
 */
static void copy_to_voicemail(struct mixmonitor *mixmonitor, const char *ext, const char *filename)
{
	struct vm_recipient *recipient = NULL;
	struct ast_vm_recording_data recording_data;
	if (ast_string_field_init(&recording_data, 512)) {
		ast_log(LOG_ERROR, "Failed to string_field_init, skipping copy_to_voicemail\n");
		return;
	}

	/* Copy strings to stringfields that will be used for all recipients */
	ast_string_field_set(&recording_data, recording_file, filename);
	ast_string_field_set(&recording_data, recording_ext, ext);
	ast_string_field_set(&recording_data, call_context, mixmonitor->call_context);
	ast_string_field_set(&recording_data, call_extension, mixmonitor->call_extension);
	ast_string_field_set(&recording_data, call_callerchan, mixmonitor->call_callerchan);
	ast_string_field_set(&recording_data, call_callerid, mixmonitor->call_callerid);
	/* and call_priority gets copied too */
	recording_data.call_priority = mixmonitor->call_priority;

	AST_LIST_TRAVERSE(&mixmonitor->recipient_list, recipient, list) {
		/* context, mailbox, and folder need to be set per recipient */
		ast_string_field_set(&recording_data, context, recipient->context);
		ast_string_field_set(&recording_data, mailbox, recipient->mailbox);
		ast_string_field_set(&recording_data, folder, recipient->folder);

		ast_verb(4, "MixMonitor attempting to send voicemail copy to %s@%s\n", recording_data.mailbox,
			recording_data.context);
		ast_app_copy_recording_to_vm(&recording_data);
	}

	/* Free the string fields for recording_data before exiting the function. */
	ast_string_field_free_memory(&recording_data);
}

static void mixmonitor_save_prep(struct mixmonitor *mixmonitor, char *filename, struct ast_filestream **fs, unsigned int *oflags, int *errflag, char **ext)
{
	/* Initialize the file if not already done so */
	char *last_slash = NULL;
	if (!ast_strlen_zero(filename)) {
		if (!*fs && !*errflag && !mixmonitor->mixmonitor_ds->fs_quit) {
			*oflags = O_CREAT | O_WRONLY;
			*oflags |= ast_test_flag(mixmonitor, MUXFLAG_APPEND) ? O_APPEND : O_TRUNC;

			last_slash = strrchr(filename, '/');

			if ((*ext = strrchr(filename, '.')) && (*ext > last_slash)) {
				**ext = '\0';
				*ext = *ext + 1;
			} else {
				*ext = "raw";
			}

			if (!(*fs = ast_writefile(filename, *ext, NULL, *oflags, 0, 0666))) {
				ast_log(LOG_ERROR, "Cannot open %s.%s\n", filename, *ext);
				*errflag = 1;
			} else {
				struct ast_filestream *tmp = *fs;
				mixmonitor->mixmonitor_ds->samp_rate = MAX(mixmonitor->mixmonitor_ds->samp_rate, ast_format_get_sample_rate(tmp->fmt->format));
			}
		}
	}
}

static int mixmonitor_autochan_is_bridged(struct ast_autochan *autochan)
{
	int is_bridged;

	ast_autochan_channel_lock(autochan);
	is_bridged = ast_channel_is_bridged(autochan->chan);
	ast_autochan_channel_unlock(autochan);
	return is_bridged;
}

static void *mixmonitor_thread(void *obj)
{
	struct mixmonitor *mixmonitor = obj;
	char *fs_ext = "";
	char *fs_read_ext = "";
	char *fs_write_ext = "";

	struct ast_filestream **fs = NULL;
	struct ast_filestream **fs_read = NULL;
	struct ast_filestream **fs_write = NULL;

	struct ast_format *last_format_read = NULL;
	struct ast_format *last_format_write = NULL;
	struct ast_trans_pvt *trans_pvt_read = NULL;
	struct ast_trans_pvt *trans_pvt_write = NULL;

	unsigned int oflags;
	int errflag = 0;
	struct ast_format *format_slin;

	struct timeval skip_start = ast_tvnow();

	/* Keep callid association before any log messages */
	if (mixmonitor->callid) {
		ast_callid_threadassoc_add(mixmonitor->callid);
	}

	ast_verb(2, "Begin MixMonitor Recording %s\n", mixmonitor->name);

	fs = &mixmonitor->mixmonitor_ds->fs;
	fs_read = &mixmonitor->mixmonitor_ds->fs_read;
	fs_write = &mixmonitor->mixmonitor_ds->fs_write;

	ast_mutex_lock(&mixmonitor->mixmonitor_ds->lock);
	mixmonitor_save_prep(mixmonitor, mixmonitor->filename, fs, &oflags, &errflag, &fs_ext);
	mixmonitor_save_prep(mixmonitor, mixmonitor->filename_read, fs_read, &oflags, &errflag, &fs_read_ext);
	mixmonitor_save_prep(mixmonitor, mixmonitor->filename_write, fs_write, &oflags, &errflag, &fs_write_ext);

	format_slin = ast_format_cache_get_slin_by_rate(mixmonitor->mixmonitor_ds->samp_rate);

	ast_mutex_unlock(&mixmonitor->mixmonitor_ds->lock);

	if (mixmonitor->skip_seconds > 0.0) {
		ast_debug(3, "%s skipping initial %.3f seconds\n",
			mixmonitor->name, mixmonitor->skip_seconds);
	}

	/* The audiohook must enter and exit the loop locked */
	ast_audiohook_lock(&mixmonitor->audiohook);
	while (mixmonitor->audiohook.status == AST_AUDIOHOOK_STATUS_RUNNING && !mixmonitor->mixmonitor_ds->fs_quit) {
		struct ast_frame *fr = NULL;
		struct ast_frame *fr_read = NULL;
		struct ast_frame *fr_write = NULL;

		if (!(fr = ast_audiohook_read_frame_all(&mixmonitor->audiohook, SAMPLES_PER_FRAME, format_slin,
						&fr_read, &fr_write))) {
			ast_audiohook_trigger_wait(&mixmonitor->audiohook);

			if (mixmonitor->audiohook.status != AST_AUDIOHOOK_STATUS_RUNNING) {
				break;
			}
			continue;
		}

		/* audiohook lock is not required for the next block.
		 * Unlock it, but remember to lock it before looping or exiting */
		ast_audiohook_unlock(&mixmonitor->audiohook);

		if (!ast_test_flag(mixmonitor, MUXFLAG_BRIDGED)
			|| mixmonitor_autochan_is_bridged(mixmonitor->autochan)) {
			ast_mutex_lock(&mixmonitor->mixmonitor_ds->lock);

			/* Skip writing audio for the first N seconds */
			if (mixmonitor->skip_seconds > 0.0) {
				struct timeval now = ast_tvnow();
				double elapsed = ast_tvdiff_ms(now, skip_start) / 1000.0;

				if (elapsed < mixmonitor->skip_seconds) {
					ast_mutex_unlock(&mixmonitor->mixmonitor_ds->lock);
					/* Skip this frame and continue */
					goto frame_cleanup;
				} else {
					ast_debug(3, "%s skip period %.3f seconds elapsed; starting to write audio\n",
						mixmonitor->name, mixmonitor->skip_seconds);
					mixmonitor->skip_seconds = 0.0;
				}
			}

			/* Write out the frame(s) */
			if ((*fs_read) && (fr_read)) {
				struct ast_frame *cur;

				for (cur = fr_read; cur; cur = AST_LIST_NEXT(cur, frame_list)) {
					ast_writestream(*fs_read, cur);
				}
			}

			if ((*fs_write) && (fr_write)) {
				struct ast_frame *cur;

				for (cur = fr_write; cur; cur = AST_LIST_NEXT(cur, frame_list)) {
					ast_writestream(*fs_write, cur);
				}
			}

			if (ast_test_flag(mixmonitor, MUXFLAG_INTERLEAVED)) {
				/* The 'D' option is set, so mix the frame as an interleaved dual channel frame */
				int i;
				/*
				 * We are fed by a call to ast_audiohook_read_frame_all specifying format_slin. However
				 * we may get frames back in a different format. Either way, we we will translate them
				 * to the format with the correct frame size before writing into these buffers.
				 */
				short read_buf[SAMPLES_PER_FRAME];
				short write_buf[SAMPLES_PER_FRAME];
				short stereo_buf[SAMPLES_PER_FRAME * 2];
				struct ast_frame stereo_frame = {
					.frametype = AST_FRAME_VOICE,
					.datalen = sizeof(stereo_buf),
					.samples = SAMPLES_PER_FRAME,
				};

				if (fr) {
					ast_frame_free(fr, 0);
					fr = NULL;
				}

				/*
				 * Depending on the input codec's rate (which may change during the call) we may get frames in
				 * a slin format that does not match the native format_slin of the mixmonitor.  In that case
				 * we need to translate.
				 */
				fill_frame_buffer(fr_read, format_slin, &last_format_read, &trans_pvt_read,
					read_buf, sizeof(read_buf), "Read");

				fill_frame_buffer(fr_write, format_slin, &last_format_write, &trans_pvt_write,
					write_buf, sizeof(write_buf), "Write");

				for (i = 0; i < SAMPLES_PER_FRAME; i++) {
					stereo_buf[i * 2] = read_buf[i];
					stereo_buf[i * 2 + 1] = write_buf[i];
				}

				stereo_frame.data.ptr = stereo_buf;
				stereo_frame.subclass.format = format_slin;

				fr = ast_frdup(&stereo_frame);
			}

			if ((*fs) && (fr)) {
				struct ast_frame *cur;

				for (cur = fr; cur; cur = AST_LIST_NEXT(cur, frame_list)) {
					ast_writestream(*fs, cur);
				}
			}
			ast_mutex_unlock(&mixmonitor->mixmonitor_ds->lock);
		}

frame_cleanup:
		/* All done! free it. */
		if (fr) {
			ast_frame_free(fr, 0);
		}
		if (fr_read) {
			ast_frame_free(fr_read, 0);
		}
		if (fr_write) {
			ast_frame_free(fr_write, 0);
		}

		fr = NULL;
		fr_write = NULL;
		fr_read = NULL;

		ast_audiohook_lock(&mixmonitor->audiohook);
	}

	ast_audiohook_unlock(&mixmonitor->audiohook);

	if (ast_test_flag(mixmonitor, MUXFLAG_BEEP_STOP)) {
		ast_autochan_channel_lock(mixmonitor->autochan);
		ast_stream_and_wait(mixmonitor->autochan->chan, "beep", "");
		ast_autochan_channel_unlock(mixmonitor->autochan);
	}

	ast_autochan_destroy(mixmonitor->autochan);

	/* Datastore cleanup.  close the filestream and wait for ds destruction */
	ast_mutex_lock(&mixmonitor->mixmonitor_ds->lock);
	mixmonitor_ds_close_fs(mixmonitor->mixmonitor_ds);
	if (!mixmonitor->mixmonitor_ds->destruction_ok) {
		ast_cond_wait(&mixmonitor->mixmonitor_ds->destruction_condition, &mixmonitor->mixmonitor_ds->lock);
	}
	ast_mutex_unlock(&mixmonitor->mixmonitor_ds->lock);

	/* Free the translate paths */
	if (trans_pvt_read) {
		ast_translator_free_path(trans_pvt_read);
		trans_pvt_read = NULL;
	}
	if (trans_pvt_write) {
		ast_translator_free_path(trans_pvt_write);
		trans_pvt_write = NULL;
	}

	/* kill the audiohook */
	destroy_monitor_audiohook(mixmonitor);

	if (mixmonitor->post_process) {
		ast_verb(2, "Executing [%s]\n", mixmonitor->post_process);
		ast_safe_system(mixmonitor->post_process);
	}

	ast_verb(2, "End MixMonitor Recording %s\n", mixmonitor->name);
	ast_test_suite_event_notify("MIXMONITOR_END", "File: %s\r\n", mixmonitor->filename);

	if (!AST_LIST_EMPTY(&mixmonitor->recipient_list)) {
		if (ast_strlen_zero(fs_ext)) {
			ast_log(LOG_ERROR, "No file extension set for Mixmonitor %s. Skipping copy to voicemail.\n",
				mixmonitor -> name);
		} else {
			ast_verb(3, "Copying recordings for Mixmonitor %s to voicemail recipients\n", mixmonitor->name);
			copy_to_voicemail(mixmonitor, fs_ext, mixmonitor->filename);
		}
		if (!ast_strlen_zero(fs_read_ext)) {
			ast_verb(3, "Copying read recording for Mixmonitor %s to voicemail recipients\n", mixmonitor->name);
			copy_to_voicemail(mixmonitor, fs_read_ext, mixmonitor->filename_read);
		}
		if (!ast_strlen_zero(fs_write_ext)) {
			ast_verb(3, "Copying write recording for Mixmonitor %s to voicemail recipients\n", mixmonitor->name);
			copy_to_voicemail(mixmonitor, fs_write_ext, mixmonitor->filename_write);
		}
	} else {
		ast_debug(3, "No recipients to forward monitor to, moving on.\n");
	}

	if (ast_test_flag(mixmonitor, MUXFLAG_AUTO_DELETE)) {
		ast_debug(3, "Deleting our copies of recording files\n");
		if (!ast_strlen_zero(fs_ext)) {
			ast_filedelete(mixmonitor->filename, fs_ext);
		}
		if (!ast_strlen_zero(fs_read_ext)) {
			ast_filedelete(mixmonitor->filename_read, fs_ext);
		}
		if (!ast_strlen_zero(fs_write_ext)) {
			ast_filedelete(mixmonitor->filename_write, fs_ext);
		}
	}

	mixmonitor_free(mixmonitor);

	ast_module_unref(ast_module_info->self);
	return NULL;
}

static int setup_mixmonitor_ds(struct mixmonitor *mixmonitor, struct ast_channel *chan, char **datastore_id, const char *beep_id)
{
	struct ast_datastore *datastore = NULL;
	struct mixmonitor_ds *mixmonitor_ds;

	if (!(mixmonitor_ds = ast_calloc(1, sizeof(*mixmonitor_ds)))) {
		return -1;
	}

	if (ast_asprintf(datastore_id, "%p", mixmonitor_ds) == -1) {
		ast_log(LOG_ERROR, "Failed to allocate memory for MixMonitor ID.\n");
		ast_free(mixmonitor_ds);
		return -1;
	}

	ast_mutex_init(&mixmonitor_ds->lock);
	ast_cond_init(&mixmonitor_ds->destruction_condition, NULL);

	if (!(datastore = ast_datastore_alloc(&mixmonitor_ds_info, *datastore_id))) {
		ast_mutex_destroy(&mixmonitor_ds->lock);
		ast_cond_destroy(&mixmonitor_ds->destruction_condition);
		ast_free(mixmonitor_ds);
		return -1;
	}

	if (ast_test_flag(mixmonitor, MUXFLAG_BEEP_START)) {
		ast_autochan_channel_lock(mixmonitor->autochan);
		ast_stream_and_wait(mixmonitor->autochan->chan, "beep", "");
		ast_autochan_channel_unlock(mixmonitor->autochan);
	}

	mixmonitor_ds->samp_rate = 8000;
	mixmonitor_ds->audiohook = &mixmonitor->audiohook;
	mixmonitor_ds->filename = ast_strdup(mixmonitor->filename);
	if (!ast_strlen_zero(beep_id)) {
		mixmonitor_ds->beep_id = ast_strdup(beep_id);
	}
	datastore->data = mixmonitor_ds;

	ast_channel_lock(chan);
	ast_channel_datastore_add(chan, datastore);
	ast_channel_unlock(chan);

	mixmonitor->mixmonitor_ds = mixmonitor_ds;
	return 0;
}

static void mixmonitor_ds_remove_and_free(struct ast_channel *chan, const char *datastore_id)
{
	struct ast_datastore *datastore;

	ast_channel_lock(chan);

	datastore = ast_channel_datastore_find(chan, &mixmonitor_ds_info, datastore_id);

	if (datastore) {
		ast_channel_datastore_remove(chan, datastore);
		ast_datastore_free(datastore);
	}

	ast_channel_unlock(chan);
}

static int launch_monitor_thread(struct ast_channel *chan, const char *filename,
				  unsigned int flags, int readvol, int writevol,
				  const char *post_process, const char *filename_write,
				  char *filename_read, const char *uid_channel_var,
				  const char *recipients, const char *beep_id, double skip_seconds)
{
	pthread_t thread;
	struct mixmonitor *mixmonitor;
	char postprocess2[1024] = "";
	char *datastore_id = NULL;

	postprocess2[0] = 0;
	/* If a post process system command is given attach it to the structure */
	if (!ast_strlen_zero(post_process)) {
		char *p1, *p2;

		p1 = ast_strdupa(post_process);
		for (p2 = p1; *p2; p2++) {
			if (*p2 == '^' && *(p2+1) == '{') {
				*p2 = '$';
			}
		}
		ast_channel_lock(chan);
		pbx_substitute_variables_helper(chan, p1, postprocess2, sizeof(postprocess2) - 1);
		ast_channel_unlock(chan);
	}

	/* Pre-allocate mixmonitor structure and spy */
	if (!(mixmonitor = ast_calloc(1, sizeof(*mixmonitor)))) {
		return -1;
	}

	/* Now that the struct has been calloced, go ahead and initialize the string fields. */
	if (ast_string_field_init(mixmonitor, 512)) {
		mixmonitor_free(mixmonitor);
		return -1;
	}

	/* Setup the actual spy before creating our thread */
	if (ast_audiohook_init(&mixmonitor->audiohook, AST_AUDIOHOOK_TYPE_SPY, mixmonitor_spy_type, 0)) {
		mixmonitor_free(mixmonitor);
		return -1;
	}

	/* Copy over flags and channel name */
	mixmonitor->flags = flags;
	mixmonitor->skip_seconds = skip_seconds;
	if (!(mixmonitor->autochan = ast_autochan_setup(chan))) {
		mixmonitor_free(mixmonitor);
		return -1;
	}

	if (!ast_strlen_zero(filename)) {
		mixmonitor->filename = ast_strdup(filename);
	}

	if (!ast_strlen_zero(filename_write)) {
		mixmonitor->filename_write = ast_strdup(filename_write);
	}

	if (!ast_strlen_zero(filename_read)) {
		mixmonitor->filename_read = ast_strdup(filename_read);
	}

	if (setup_mixmonitor_ds(mixmonitor, chan, &datastore_id, beep_id)) {
		ast_autochan_destroy(mixmonitor->autochan);
		mixmonitor_free(mixmonitor);
		ast_free(datastore_id);
		return -1;
	}

	if (!ast_strlen_zero(uid_channel_var)) {
		if (datastore_id) {
			pbx_builtin_setvar_helper(chan, uid_channel_var, datastore_id);
		}
	}

	mixmonitor->name = ast_strdup(ast_channel_name(chan));

	if (!ast_strlen_zero(postprocess2)) {
		mixmonitor->post_process = ast_strdup(postprocess2);
	}

	if (!ast_strlen_zero(recipients)) {
		char callerid[256];

		ast_channel_lock(chan);

		/* We use the connected line of the invoking channel for caller ID,
		 * unless we've been told to use the Caller ID.
		 * The initial use for this relied on Connected Line to get the
		 * actual number for recording with Digium phones,
		 * but in generic use the Caller ID is likely what people want.
		 */

		if (ast_test_flag(mixmonitor, MUXFLAG_REAL_CALLERID)) {
			struct ast_party_caller *caller;
			caller = ast_channel_caller(chan);
			ast_debug(3, "Caller ID = %d - %s : %d - %s\n", caller->id.name.valid,
				caller->id.name.str, caller->id.number.valid,
				caller->id.number.str);
			ast_callerid_merge(callerid, sizeof(callerid),
				S_COR(caller->id.name.valid, caller->id.name.str, NULL),
				S_COR(caller->id.number.valid, caller->id.number.str, NULL),
				"Unknown");
		} else {
			struct ast_party_connected_line *connected;
			connected = ast_channel_connected(chan);
			ast_debug(3, "Connected Line CID = %d - %s : %d - %s\n", connected->id.name.valid,
				connected->id.name.str, connected->id.number.valid,
				connected->id.number.str);
			ast_callerid_merge(callerid, sizeof(callerid),
				S_COR(connected->id.name.valid, connected->id.name.str, NULL),
				S_COR(connected->id.number.valid, connected->id.number.str, NULL),
				"Unknown");
		}

		ast_string_field_set(mixmonitor, call_context, ast_channel_context(chan));
		ast_string_field_set(mixmonitor, call_extension, ast_channel_exten(chan));
		ast_string_field_set(mixmonitor, call_callerchan, ast_channel_name(chan));
		ast_string_field_set(mixmonitor, call_callerid, callerid);
		mixmonitor->call_priority = ast_channel_priority(chan);

		ast_channel_unlock(chan);

		add_vm_recipients_from_string(mixmonitor, recipients);
	}

	ast_set_flag(&mixmonitor->audiohook, AST_AUDIOHOOK_TRIGGER_SYNC);
	if (!ast_test_flag(mixmonitor, MUXFLAG_NO_RWSYNC)) {
		ast_set_flag(&mixmonitor->audiohook, AST_AUDIOHOOK_SUBSTITUTE_SILENCE);
	}

	if (readvol)
		mixmonitor->audiohook.options.read_volume = readvol;
	if (writevol)
		mixmonitor->audiohook.options.write_volume = writevol;

	if (startmon(chan, &mixmonitor->audiohook)) {
		ast_log(LOG_WARNING, "Unable to add '%s' spy to channel '%s'\n",
			mixmonitor_spy_type, ast_channel_name(chan));
		mixmonitor_ds_remove_and_free(chan, datastore_id);
		ast_free(datastore_id);
		ast_autochan_destroy(mixmonitor->autochan);
		ast_audiohook_destroy(&mixmonitor->audiohook);
		mixmonitor_free(mixmonitor);
		return -1;
	}

	ast_free(datastore_id);

	/* reference be released at mixmonitor destruction */
	mixmonitor->callid = ast_read_threadstorage_callid();

	return ast_pthread_create_detached_background(&thread, NULL, mixmonitor_thread, mixmonitor);
}

/* a note on filename_parse: creates directory structure and assigns absolute path from relative paths for filenames */
/* requires immediate copying of string from return to retain data since otherwise it will immediately lose scope */
static char *filename_parse(char *filename, char *buffer, size_t len)
{
	char *slash;
	char *ext;

	ast_assert(len > 0);

	if (ast_strlen_zero(filename)) {
		ast_log(LOG_WARNING, "No file name was provided for a file save option.\n");
		buffer[0] = 0;
		return buffer;
	}

	/* If we don't have an absolute path, make one */
	if (*filename != '/') {
		char *build = ast_alloca(strlen(ast_config_AST_MONITOR_DIR) + strlen(filename) + 3);
		sprintf(build, "%s/%s", ast_config_AST_MONITOR_DIR, filename);
		filename = build;
	}

	ast_copy_string(buffer, filename, len);

	/* If the provided filename has a .wav49 extension, we need to convert it to .WAV to
	   match the behavior of build_filename in main/file.c. Otherwise MIXMONITOR_FILENAME
	   ends up referring to a file that does not/will not exist */
	ext = strrchr(buffer, '.');
	if (ext && !strcmp(ext, ".wav49")) {
		/* Change to WAV - we know we have at least 6 writeable bytes where 'ext' points,
		 * so this is safe */
		memcpy(ext, ".WAV", sizeof(".WAV"));
	}

	if ((slash = strrchr(filename, '/'))) {
		*slash = '\0';
	}
	ast_mkdir(filename, 0777);

	return buffer;
}

static int mixmonitor_exec(struct ast_channel *chan, const char *data)
{
	int x, readvol = 0, writevol = 0;
	double skip_seconds = 0.0;
	char *filename_read = NULL;
	char *filename_write = NULL;
	char filename_buffer[1024] = "";
	char *uid_channel_var = NULL;
	char beep_id[64] = "";

	struct ast_flags flags = { 0 };
	char *recipients = NULL;
	char *parse;
	RAII_VAR(struct stasis_message *, message, NULL, ao2_cleanup);
	AST_DECLARE_APP_ARGS(args,
		AST_APP_ARG(filename);
		AST_APP_ARG(options);
		AST_APP_ARG(post_process);
	);

	if (ast_strlen_zero(data)) {
		ast_log(LOG_WARNING, "MixMonitor requires an argument (filename or ,t(filename) and/or r(filename)\n");
		return -1;
	}

	parse = ast_strdupa(data);

	AST_STANDARD_APP_ARGS(args, parse);

	if (args.options) {
		char *opts[OPT_ARG_ARRAY_SIZE] = { NULL, };

		ast_app_parse_options(mixmonitor_opts, &flags, opts, args.options);

		if (ast_test_flag(&flags, MUXFLAG_DEPRECATED_RWSYNC)) {
			ast_log(LOG_NOTICE, "The synchronization behavior enabled by the 'S' option is now the default"
				" and does not need to be specified.\n");
		}

		if (ast_test_flag(&flags, MUXFLAG_READVOLUME)) {
			if (ast_strlen_zero(opts[OPT_ARG_READVOLUME])) {
				ast_log(LOG_WARNING, "No volume level was provided for the heard volume ('v') option.\n");
			} else if ((sscanf(opts[OPT_ARG_READVOLUME], "%2d", &x) != 1) || (x < -4) || (x > 4)) {
				ast_log(LOG_NOTICE, "Heard volume must be a number between -4 and 4, not '%s'\n", opts[OPT_ARG_READVOLUME]);
			} else {
				readvol = get_volfactor(x);
			}
		}

		if (ast_test_flag(&flags, MUXFLAG_WRITEVOLUME)) {
			if (ast_strlen_zero(opts[OPT_ARG_WRITEVOLUME])) {
				ast_log(LOG_WARNING, "No volume level was provided for the spoken volume ('V') option.\n");
			} else if ((sscanf(opts[OPT_ARG_WRITEVOLUME], "%2d", &x) != 1) || (x < -4) || (x > 4)) {
				ast_log(LOG_NOTICE, "Spoken volume must be a number between -4 and 4, not '%s'\n", opts[OPT_ARG_WRITEVOLUME]);
			} else {
				writevol = get_volfactor(x);
			}
		}

		if (ast_test_flag(&flags, MUXFLAG_VOLUME)) {
			if (ast_strlen_zero(opts[OPT_ARG_VOLUME])) {
				ast_log(LOG_WARNING, "No volume level was provided for the combined volume ('W') option.\n");
			} else if ((sscanf(opts[OPT_ARG_VOLUME], "%2d", &x) != 1) || (x < -4) || (x > 4)) {
				ast_log(LOG_NOTICE, "Combined volume must be a number between -4 and 4, not '%s'\n", opts[OPT_ARG_VOLUME]);
			} else {
				readvol = writevol = get_volfactor(x);
			}
		}

		if (ast_test_flag(&flags, MUXFLAG_VMRECIPIENTS)) {
			if (ast_strlen_zero(opts[OPT_ARG_VMRECIPIENTS])) {
				ast_log(LOG_WARNING, "No voicemail recipients were specified for the vm copy ('m') option.\n");
			} else {
				recipients = ast_strdupa(opts[OPT_ARG_VMRECIPIENTS]);
			}
		}

		if (ast_test_flag(&flags, MUXFLAG_WRITE)) {
			filename_write = ast_strdupa(filename_parse(opts[OPT_ARG_WRITENAME], filename_buffer, sizeof(filename_buffer)));
		}

		if (ast_test_flag(&flags, MUXFLAG_READ)) {
			filename_read = ast_strdupa(filename_parse(opts[OPT_ARG_READNAME], filename_buffer, sizeof(filename_buffer)));
		}

		if (ast_test_flag(&flags, MUXFLAG_UID)) {
			uid_channel_var = opts[OPT_ARG_UID];
		}

		if (ast_test_flag(&flags, MUXFLAG_BEEP)) {
			const char *interval_str = S_OR(opts[OPT_ARG_BEEP_INTERVAL], "15");
			unsigned int interval = 15;

			if (sscanf(interval_str, "%30u", &interval) != 1) {
				ast_log(LOG_WARNING, "Invalid interval '%s' for periodic beep. Using default of %u\n",
						interval_str, interval);
			}

			if (ast_beep_start(chan, interval, beep_id, sizeof(beep_id))) {
				ast_log(LOG_WARNING, "Unable to enable periodic beep, please ensure func_periodic_hook is loaded.\n");
				return -1;
			}
		}

		if (ast_test_flag(&flags, MUXFLAG_SKIP)) {
			if (ast_strlen_zero(opts[OPT_ARG_SKIP])) {
				ast_log(LOG_WARNING, "No skip value provided for the 's' (skip) option; skipping will be ignored as no default exists.\n");
			} else {
				char *endptr = NULL;
				double val = strtod(opts[OPT_ARG_SKIP], &endptr);
				if (endptr == opts[OPT_ARG_SKIP] || *endptr != '\0') {
					ast_log(LOG_WARNING, "Skip value '%s' is not a valid number; ignoring skip.\n", opts[OPT_ARG_SKIP]);
				} else if (val < (double) MIN_SKIP_SECONDS) {
					ast_log(LOG_WARNING, "Skip value %.3f is below minimum %d; ignoring skip.\n", val, MIN_SKIP_SECONDS);
				} else {
					skip_seconds = val;
				}
			}
		}
	}
	/* If there are no file writing arguments/options for the mix monitor, send a warning message and return -1 */

	if (!ast_test_flag(&flags, MUXFLAG_WRITE) && !ast_test_flag(&flags, MUXFLAG_READ) && ast_strlen_zero(args.filename)) {
		ast_log(LOG_WARNING, "MixMonitor requires an argument (filename)\n");
		return -1;
	}

	/* If filename exists, try to create directories for it */
	if (!(ast_strlen_zero(args.filename))) {
		args.filename = ast_strdupa(filename_parse(args.filename, filename_buffer, sizeof(filename_buffer)));
	}

	pbx_builtin_setvar_helper(chan, "MIXMONITOR_FILENAME", args.filename);

	/* If launch_monitor_thread works, the module reference must not be released until it is finished. */
	ast_module_ref(ast_module_info->self);
	if (launch_monitor_thread(chan,
			args.filename,
			flags.flags,
			readvol,
			writevol,
			args.post_process,
			filename_write,
			filename_read,
			uid_channel_var,
			recipients,
			beep_id,
			skip_seconds)) {
		ast_module_unref(ast_module_info->self);
	}

	message = ast_channel_blob_create_from_cache(ast_channel_uniqueid(chan),
		ast_channel_mixmonitor_start_type(), NULL);
	if (message) {
		stasis_publish(ast_channel_topic(chan), message);
	}

	return 0;
}

static int stop_mixmonitor_full(struct ast_channel *chan, const char *data)
{
	struct ast_datastore *datastore = NULL;
	char *parse = "";
	struct mixmonitor_ds *mixmonitor_ds;
	const char *beep_id = NULL;
	RAII_VAR(struct stasis_message *, message, NULL, ao2_cleanup);

	AST_DECLARE_APP_ARGS(args,
		AST_APP_ARG(mixmonid);
	);

	if (!ast_strlen_zero(data)) {
		parse = ast_strdupa(data);
	}

	AST_STANDARD_APP_ARGS(args, parse);

	ast_channel_lock(chan);

	datastore = ast_channel_datastore_find(chan, &mixmonitor_ds_info,
		S_OR(args.mixmonid, NULL));
	if (!datastore) {
		ast_channel_unlock(chan);
		return -1;
	}
	mixmonitor_ds = datastore->data;

	ast_mutex_lock(&mixmonitor_ds->lock);

	/* closing the filestream here guarantees the file is available to the dialplan
	 * after calling StopMixMonitor */
	mixmonitor_ds_close_fs(mixmonitor_ds);

	/* The mixmonitor thread may be waiting on the audiohook trigger.
	 * In order to exit from the mixmonitor loop before waiting on channel
	 * destruction, poke the audiohook trigger. */
	if (mixmonitor_ds->audiohook) {
		if (mixmonitor_ds->audiohook->status != AST_AUDIOHOOK_STATUS_DONE) {
			ast_audiohook_update_status(mixmonitor_ds->audiohook, AST_AUDIOHOOK_STATUS_SHUTDOWN);
		}
		ast_audiohook_lock(mixmonitor_ds->audiohook);
		ast_cond_signal(&mixmonitor_ds->audiohook->trigger);
		ast_audiohook_unlock(mixmonitor_ds->audiohook);
		mixmonitor_ds->audiohook = NULL;
	}

	if (!ast_strlen_zero(mixmonitor_ds->beep_id)) {
		beep_id = ast_strdupa(mixmonitor_ds->beep_id);
	}

	ast_mutex_unlock(&mixmonitor_ds->lock);

	/* Remove the datastore so the monitor thread can exit */
	if (!ast_channel_datastore_remove(chan, datastore)) {
		ast_datastore_free(datastore);
	}

	ast_channel_unlock(chan);

	if (!ast_strlen_zero(beep_id)) {
		ast_beep_stop(chan, beep_id);
	}

	message = ast_channel_blob_create_from_cache(ast_channel_uniqueid(chan),
	                                             ast_channel_mixmonitor_stop_type(),
	                                             NULL);
	if (message) {
		stasis_publish(ast_channel_topic(chan), message);
	}

	return 0;
}

static int stop_mixmonitor_exec(struct ast_channel *chan, const char *data)
{
	stop_mixmonitor_full(chan, data);
	return 0;
}

static char *handle_cli_mixmonitor(struct ast_cli_entry *e, int cmd, struct ast_cli_args *a)
{
	struct ast_channel *chan;
	struct ast_datastore *datastore = NULL;
	struct mixmonitor_ds *mixmonitor_ds = NULL;

	switch (cmd) {
	case CLI_INIT:
		e->command = "mixmonitor {start|stop|list}";
		e->usage =
			"Usage: mixmonitor start <chan_name> [args]\n"
			"         The optional arguments are passed to the MixMonitor application.\n"
			"       mixmonitor stop <chan_name> [args]\n"
			"         The optional arguments are passed to the StopMixMonitor application.\n"
			"       mixmonitor list <chan_name>\n";
		return NULL;
	case CLI_GENERATE:
		return ast_complete_channels(a->line, a->word, a->pos, a->n, 2);
	}

	if (a->argc < 3) {
		return CLI_SHOWUSAGE;
	}

	if (!(chan = ast_channel_get_by_name_prefix(a->argv[2], strlen(a->argv[2])))) {
		ast_cli(a->fd, "No channel matching '%s' found.\n", a->argv[2]);
		/* Technically this is a failure, but we don't want 2 errors printing out */
		return CLI_SUCCESS;
	}

	if (!strcasecmp(a->argv[1], "start")) {
		mixmonitor_exec(chan, (a->argc >= 4) ? a->argv[3] : "");
	} else if (!strcasecmp(a->argv[1], "stop")){
		stop_mixmonitor_exec(chan, (a->argc >= 4) ? a->argv[3] : "");
	} else if (!strcasecmp(a->argv[1], "list")) {
		ast_cli(a->fd, "MixMonitor ID\tFile\tReceive File\tTransmit File\n");
		ast_cli(a->fd, "=========================================================================\n");
		ast_channel_lock(chan);
		AST_LIST_TRAVERSE(ast_channel_datastores(chan), datastore, entry) {
			if (datastore->info == &mixmonitor_ds_info) {
				char *filename = "";
				char *filename_read = "";
				char *filename_write = "";

				mixmonitor_ds = datastore->data;
				if (mixmonitor_ds->fs) {
					filename = mixmonitor_ds->fs->filename;
				}
				if (mixmonitor_ds->fs_read) {
					filename_read = mixmonitor_ds->fs_read->filename;
				}
				if (mixmonitor_ds->fs_write) {
					filename_write = mixmonitor_ds->fs_write->filename;
				}
				ast_cli(a->fd, "%p\t%s\t%s\t%s\n", mixmonitor_ds, filename, filename_read, filename_write);
			}
		}
		ast_channel_unlock(chan);
	} else {
		chan = ast_channel_unref(chan);
		return CLI_SHOWUSAGE;
	}

	chan = ast_channel_unref(chan);

	return CLI_SUCCESS;
}

/*! \brief  Mute / unmute  an individual MixMonitor by id */
static int mute_mixmonitor_instance(struct ast_channel *chan, const char *data,
									enum ast_audiohook_flags flag, int clearmute)
{
	struct ast_datastore *datastore = NULL;
	char *parse = "";
	struct mixmonitor_ds *mixmonitor_ds;

	AST_DECLARE_APP_ARGS(args,
		AST_APP_ARG(mixmonid);
	);

	if (!ast_strlen_zero(data)) {
		parse = ast_strdupa(data);
	}

	AST_STANDARD_APP_ARGS(args, parse);

	ast_channel_lock(chan);

	datastore = ast_channel_datastore_find(chan, &mixmonitor_ds_info,
		S_OR(args.mixmonid, NULL));
	if (!datastore) {
		ast_channel_unlock(chan);
		return -1;
	}
	mixmonitor_ds = datastore->data;

	ast_mutex_lock(&mixmonitor_ds->lock);

	if (mixmonitor_ds->audiohook) {
		if (clearmute) {
			ast_clear_flag(mixmonitor_ds->audiohook, flag);
		} else {
			ast_set_flag(mixmonitor_ds->audiohook, flag);
		}
	}

	ast_mutex_unlock(&mixmonitor_ds->lock);
	ast_channel_unlock(chan);

	return 0;
}

/*! \brief  Mute / unmute  a MixMonitor channel */
static int manager_mute_mixmonitor(struct mansession *s, const struct message *m)
{
	struct ast_channel *c;
	const char *name = astman_get_header(m, "Channel");
	const char *id = astman_get_header(m, "ActionID");
	const char *state = astman_get_header(m, "State");
	const char *direction = astman_get_header(m,"Direction");
	const char *mixmonitor_id = astman_get_header(m, "MixMonitorID");
	int clearmute = 1, mutedcount = 0;
	enum ast_audiohook_flags flag;
	RAII_VAR(struct stasis_message *, stasis_message, NULL, ao2_cleanup);
	RAII_VAR(struct ast_json *, stasis_message_blob, NULL, ast_json_unref);

	if (ast_strlen_zero(direction)) {
		astman_send_error(s, m, "No direction specified. Must be read, write or both");
		return AMI_SUCCESS;
	}

	if (!strcasecmp(direction, "read")) {
		flag = AST_AUDIOHOOK_MUTE_READ;
	} else  if (!strcasecmp(direction, "write")) {
		flag = AST_AUDIOHOOK_MUTE_WRITE;
	} else  if (!strcasecmp(direction, "both")) {
		flag = AST_AUDIOHOOK_MUTE_READ | AST_AUDIOHOOK_MUTE_WRITE;
	} else {
		astman_send_error(s, m, "Invalid direction specified. Must be read, write or both");
		return AMI_SUCCESS;
	}

	if (ast_strlen_zero(name)) {
		astman_send_error(s, m, "No channel specified");
		return AMI_SUCCESS;
	}

	if (ast_strlen_zero(state)) {
		astman_send_error(s, m, "No state specified");
		return AMI_SUCCESS;
	}

	clearmute = ast_false(state);

	c = ast_channel_get_by_name(name);
	if (!c) {
		astman_send_error(s, m, "No such channel");
		return AMI_SUCCESS;
	}

	if (ast_strlen_zero(mixmonitor_id)) {
		mutedcount = ast_audiohook_set_mute_all(c, mixmonitor_spy_type, flag, clearmute);
		if (mutedcount < 0) {
			ast_channel_unref(c);
			astman_send_error(s, m, "Cannot set mute flag");
			return AMI_SUCCESS;
		}
	} else {
		if (mute_mixmonitor_instance(c, mixmonitor_id, flag, clearmute)) {
			ast_channel_unref(c);
			astman_send_error(s, m, "Cannot set mute flag");
			return AMI_SUCCESS;
		}
		mutedcount = 1;
	}


	stasis_message_blob = ast_json_pack("{s: s, s: b, s: s, s: i}",
		"direction", direction,
		"state", ast_true(state),
		"mixmonitorid", mixmonitor_id,
		"count", mutedcount);

	stasis_message = ast_channel_blob_create_from_cache(ast_channel_uniqueid(c),
		ast_channel_mixmonitor_mute_type(), stasis_message_blob);

	if (stasis_message) {
		stasis_publish(ast_channel_topic(c), stasis_message);
	}

	astman_append(s, "Response: Success\r\n");

	if (!ast_strlen_zero(id)) {
		astman_append(s, "ActionID: %s\r\n", id);
	}

	astman_append(s, "\r\n");

	ast_channel_unref(c);

	return AMI_SUCCESS;
}

static int start_mixmonitor_callback(struct ast_channel *chan, const char *filename, const char *options)
{
	char args[PATH_MAX];

	if (ast_strlen_zero(options)) {
		snprintf(args, sizeof(args), "%s", filename);
	} else {
		snprintf(args, sizeof(args), "%s,%s", filename, options);
	}

	return mixmonitor_exec(chan, args);
}

static int stop_mixmonitor_callback(struct ast_channel *chan, const char *mixmonitor_id)
{
	return stop_mixmonitor_full(chan, mixmonitor_id);
}

static int manager_mixmonitor(struct mansession *s, const struct message *m)
{
	struct ast_channel *c;
	const char *name = astman_get_header(m, "Channel");
	const char *id = astman_get_header(m, "ActionID");
	const char *file = astman_get_header(m, "File");
	const char *options = astman_get_header(m, "Options");
	const char *command = astman_get_header(m, "Command");
	char *opts[OPT_ARG_ARRAY_SIZE] = { NULL, };
	struct ast_flags flags = { 0 };
	char *uid_channel_var = NULL;
	const char *mixmonitor_id = NULL;
	int res;
	char args[PATH_MAX];

	if (ast_strlen_zero(name)) {
		astman_send_error(s, m, "No channel specified");
		return AMI_SUCCESS;
	}

	c = ast_channel_get_by_name(name);
	if (!c) {
		astman_send_error(s, m, "No such channel");
		return AMI_SUCCESS;
	}

	if (!ast_strlen_zero(options)) {
		ast_app_parse_options(mixmonitor_opts, &flags, opts, ast_strdupa(options));
	}

	snprintf(args, sizeof(args), "%s,%s,%s", file, options, command);

	res = mixmonitor_exec(c, args);

	if (ast_test_flag(&flags, MUXFLAG_UID)) {
		uid_channel_var = opts[OPT_ARG_UID];
		ast_channel_lock(c);
		mixmonitor_id = pbx_builtin_getvar_helper(c, uid_channel_var);
		mixmonitor_id = ast_strdupa(S_OR(mixmonitor_id, ""));
		ast_channel_unlock(c);
	}

	if (res) {
		ast_channel_unref(c);
		astman_send_error(s, m, "Could not start monitoring channel");
		return AMI_SUCCESS;
	}

	astman_append(s, "Response: Success\r\n");

	if (!ast_strlen_zero(id)) {
		astman_append(s, "ActionID: %s\r\n", id);
	}

	if (!ast_strlen_zero(mixmonitor_id)) {
		astman_append(s, "MixMonitorID: %s\r\n", mixmonitor_id);
	}

	astman_append(s, "\r\n");

	ast_channel_unref(c);

	return AMI_SUCCESS;
}

static int manager_stop_mixmonitor(struct mansession *s, const struct message *m)
{
	struct ast_channel *c;
	const char *name = astman_get_header(m, "Channel");
	const char *id = astman_get_header(m, "ActionID");
	const char *mixmonitor_id = astman_get_header(m, "MixMonitorID");
	int res;

	if (ast_strlen_zero(name)) {
		astman_send_error(s, m, "No channel specified");
		return AMI_SUCCESS;
	}

	c = ast_channel_get_by_name(name);
	if (!c) {
		astman_send_error(s, m, "No such channel");
		return AMI_SUCCESS;
	}

	res = stop_mixmonitor_full(c, mixmonitor_id);
	if (res) {
		ast_channel_unref(c);
		astman_send_error(s, m, "Could not stop monitoring channel");
		return AMI_SUCCESS;
	}

	astman_append(s, "Response: Success\r\n");

	if (!ast_strlen_zero(id)) {
		astman_append(s, "ActionID: %s\r\n", id);
	}

	astman_append(s, "\r\n");

	ast_channel_unref(c);

	return AMI_SUCCESS;
}

static int func_mixmonitor_read(struct ast_channel *chan, const char *cmd, char *data,
		char *buf, size_t len)
{
	struct ast_datastore *datastore;
	struct mixmonitor_ds *ds_data;
	AST_DECLARE_APP_ARGS(args,
		AST_APP_ARG(id);
		AST_APP_ARG(key);
	);

	AST_STANDARD_APP_ARGS(args, data);

	if (ast_strlen_zero(args.id) || ast_strlen_zero(args.key)) {
		ast_log(LOG_WARNING, "Not enough arguments provided to %s. "
				"An ID and key must be provided\n", cmd);
		return -1;
	}

	ast_channel_lock(chan);
	datastore = ast_channel_datastore_find(chan, &mixmonitor_ds_info, args.id);
	ast_channel_unlock(chan);

	if (!datastore) {
		ast_log(LOG_WARNING, "Could not find MixMonitor with ID %s\n", args.id);
		return -1;
	}

	ds_data = datastore->data;

	if (!strcasecmp(args.key, "filename")) {
		ast_copy_string(buf, ds_data->filename, len);
	} else {
		ast_log(LOG_WARNING, "Unrecognized %s option %s\n", cmd, args.key);
		return -1;
	}
	return 0;
}

static struct ast_custom_function mixmonitor_function = {
	.name = "MIXMONITOR",
	.read = func_mixmonitor_read,
};

static struct ast_cli_entry cli_mixmonitor[] = {
	AST_CLI_DEFINE(handle_cli_mixmonitor, "Execute a MixMonitor command")
};

static int set_mixmonitor_methods(void)
{
	struct ast_mixmonitor_methods mixmonitor_methods = {
		.start = start_mixmonitor_callback,
		.stop = stop_mixmonitor_callback,
	};

	return ast_set_mixmonitor_methods(&mixmonitor_methods);
}

static int clear_mixmonitor_methods(void)
{
	return ast_clear_mixmonitor_methods();
}

static int unload_module(void)
{
	int res;

	ast_cli_unregister_multiple(cli_mixmonitor, ARRAY_LEN(cli_mixmonitor));
	res = ast_unregister_application(stop_app);
	res |= ast_unregister_application(app);
	res |= ast_manager_unregister("MixMonitorMute");
	res |= ast_manager_unregister("MixMonitor");
	res |= ast_manager_unregister("StopMixMonitor");
	res |= ast_custom_function_unregister(&mixmonitor_function);
	res |= clear_mixmonitor_methods();

	return res;
}

static int load_module(void)
{
	int res;

	ast_cli_register_multiple(cli_mixmonitor, ARRAY_LEN(cli_mixmonitor));
	res = ast_register_application_xml(app, mixmonitor_exec);
	res |= ast_register_application_xml(stop_app, stop_mixmonitor_exec);
	res |= ast_manager_register_xml("MixMonitorMute", EVENT_FLAG_SYSTEM | EVENT_FLAG_CALL, manager_mute_mixmonitor);
	res |= ast_manager_register_xml("MixMonitor", EVENT_FLAG_SYSTEM, manager_mixmonitor);
	res |= ast_manager_register_xml("StopMixMonitor", EVENT_FLAG_SYSTEM | EVENT_FLAG_CALL, manager_stop_mixmonitor);
	res |= ast_custom_function_register(&mixmonitor_function);
	res |= set_mixmonitor_methods();

	return res;
}

AST_MODULE_INFO(ASTERISK_GPL_KEY, AST_MODFLAG_DEFAULT, "Mixed Audio Monitoring Application",
	.support_level = AST_MODULE_SUPPORT_CORE,
	.load = load_module,
	.unload = unload_module,
	.optional_modules = "func_periodic_hook",
);
