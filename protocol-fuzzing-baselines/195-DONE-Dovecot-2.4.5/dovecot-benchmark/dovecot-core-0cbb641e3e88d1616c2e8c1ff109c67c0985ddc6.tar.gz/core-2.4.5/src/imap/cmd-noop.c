/* Copyright (c) Dovecot authors, see top-level COPYING file */

#include "imap-common.h"
#include "imap-notify.h"
#include "imap-commands.h"

bool cmd_noop(struct client_command_context *cmd)
{
	if (cmd->client->notify_ctx != NULL) {
		/* flush any delayed notifications now. this is mainly useful
		   for testing. */
		imap_notify_flush(cmd->client->notify_ctx);
	}
	return cmd_sync(cmd, 0, IMAP_SYNC_FLAG_SAFE, "OK NOOP completed.");
}
