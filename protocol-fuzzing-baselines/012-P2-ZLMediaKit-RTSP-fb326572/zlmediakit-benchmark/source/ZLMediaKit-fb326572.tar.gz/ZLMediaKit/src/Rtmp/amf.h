﻿/*
 * Copyright (c) 2016-present The ZLMediaKit project authors. All Rights Reserved.
 *
 * This file is part of ZLMediaKit(https://github.com/ZLMediaKit/ZLMediaKit).
 *
 * Use of this source code is governed by MIT-like license that can be found in the
 * LICENSE file in the root of the source tree. All contributing project authors
 * may be found in the AUTHORS file in the root of the source tree.
 */

#ifndef __amf_h
#define __amf_h

#include <assert.h>
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <cstdint>
namespace toolkit {
    class BufferLikeString;
}
enum AMFType {
    AMF_NUMBER,
    AMF_INTEGER,
    AMF_BOOLEAN,
    AMF_STRING,
    AMF_OBJECT,
    AMF_NULL,
    AMF_UNDEFINED,
    AMF_ECMA_ARRAY,
    AMF_STRICT_ARRAY,
};

class AMFValue;

class AMFValue {
public:
    friend class AMFEncoder;

    using mapType = std::map<std::string, AMFValue>;
    using arrayType = std::vector<AMFValue>;

    ~AMFValue();
    AMFValue(AMFType type = AMF_NULL);
    AMFValue(const char *s);
    AMFValue(const std::string &s);
    AMFValue(double n);
    AMFValue(int i);
    AMFValue(bool b);
    AMFValue(const AMFValue &from);
    AMFValue &operator = (const AMFValue &from);

    void clear();
    AMFType type() const ;
    const std::string &as_string() const;
    double as_number() const;
    int as_integer() const;
    bool as_boolean() const;
    std::string to_string() const;
    const AMFValue &operator[](const char *str) const;
    void object_for_each(const std::function<void(const std::string &key, const AMFValue &val)> &fun) const ;
    operator bool() const;
    void set(const std::string &s, const AMFValue &val);
    void add(const AMFValue &val);

private:
    const mapType &getMap() const;
    const arrayType &getArr() const;
    void destroy();
    void init();

private:
    AMFType _type;
    union {
        std::string *string;
        double number;
        int integer;
        bool boolean;
        mapType *object;
        arrayType *array;
    } _value;
};

class AMFDecoder {
public:
    AMFDecoder(const toolkit::BufferLikeString &buf, size_t pos, int version = 0);
    template<typename TP>
    TP load();

    // 剩余未解析的字节数
    // Number of bytes not yet parsed
    size_t remain() const;

    friend std::string amfLoadLeadingString(AMFDecoder &dec);

private:
    class DepthGuard {
    public:
        explicit DepthGuard(AMFDecoder &decoder);
        ~DepthGuard();
        DepthGuard(const DepthGuard &) = delete;
        DepthGuard(DepthGuard &&) = delete;
        DepthGuard &operator=(const DepthGuard &) = delete;
        DepthGuard &operator=(DepthGuard &&) = delete;

    private:
        AMFDecoder &_decoder;
    };

    std::string load_key();
    AMFValue load_object();
    AMFValue load_ecma();
    AMFValue load_arr();
    uint8_t front();
    uint8_t pop_front();

private:
    const toolkit::BufferLikeString &buf;
    size_t pos;
    int version;
    size_t depth = 0;

    static constexpr size_t kMaxDepth = 64;
};

// 加载首个字符串, 自动跳过最多两个前置AMF0 number; 若没有数据则返回空字符串
// 兼容某些不规范的推流器(例如宇视摄像机在@setDataFrame前插入多余的AMF number)
// Load the first string, skipping at most two leading AMF0 numbers; returns an
// empty string if the stream contains no data.
// Compatible with some non-standard publishers (e.g. Uniview cameras insert
// redundant AMF numbers before @setDataFrame)
std::string amfLoadLeadingString(AMFDecoder &dec);

class AMFEncoder {
public:
    AMFEncoder & operator <<(const char *s);
    AMFEncoder & operator <<(const std::string &s);
    AMFEncoder & operator <<(std::nullptr_t);
    AMFEncoder & operator <<(const int n);
    AMFEncoder & operator <<(const double n);
    AMFEncoder & operator <<(const bool b);
    AMFEncoder & operator <<(const AMFValue &value);
    const std::string& data() const ;
    void clear() ;

private:
    void write_key(const std::string &s);
    AMFEncoder &write_undefined();

private:
    std::string buf;
};


#endif
