﻿/*
 * Copyright (c) 2016-present The ZLMediaKit project authors. All Rights Reserved.
 *
 * This file is part of ZLMediaKit(https://github.com/ZLMediaKit/ZLMediaKit).
 *
 * Use of this source code is governed by MIT-like license that can be found in the
 * LICENSE file in the root of the source tree. All contributing project authors
 * may be found in the AUTHORS file in the root of the source tree.
 */

#ifndef ZLMEDIAKIT_MULTIMEDIASOURCEMUXER_H
#define ZLMEDIAKIT_MULTIMEDIASOURCEMUXER_H

#include "Common/Stamp.h"
#include "Common/MediaSource.h"
#include "Common/MediaSink.h"
#include "Record/Recorder.h"
#include "Rtp/RtpSender.h"
#include "Record/HlsRecorder.h"
#include "Record/HlsMediaSource.h"
#include "Rtsp/RtspMediaSourceMuxer.h"
#include "Rtmp/RtmpMediaSourceMuxer.h"
#include "TS/TSMediaSourceMuxer.h"
#include "FMP4/FMP4MediaSourceMuxer.h"

namespace mediakit {

struct FrameInfo {
    CodecId codec_id = CodecInvalid;
    int64_t dts = 0;
    int64_t pts = 0;
    int64_t recv_stamp = 0;
    size_t frame_size = 0;

    int index = 0;
    bool key_frame = false;
    bool config_frame = false;
};

class MultiMediaSourceMuxer : public MediaSourceEventInterceptor, public MediaSink, public toolkit::noncopyable, public std::enable_shared_from_this<MultiMediaSourceMuxer>{
public:
    using Ptr = std::shared_ptr<MultiMediaSourceMuxer>;
    using RingType = toolkit::RingBuffer<Frame::Ptr>;
    using onCreateMuxer = std::function<MediaSinkInterface::Ptr()>;

    class Listener {
    public:
        virtual ~Listener() = default;
        virtual void onAllTrackReady() = 0;
    };

    MultiMediaSourceMuxer(const MediaTuple& tuple, float dur_sec = 0.0,const ProtocolOption &option = ProtocolOption());

    /**
     * 设置事件监听器
     * @param listener 监听器
     * Set event listener
     * @param listener Listener
     
     * [AUTO-TRANSLATED:d829419b]
     */
    void setMediaListener(const std::weak_ptr<MediaSourceEvent> &listener);

     /**
      * 设置Track就绪事件监听器
      * @param listener 事件监听器
      * Set Track ready event listener
      * @param listener Event listener
      
      * [AUTO-TRANSLATED:64262ac5]
     */
    void setTrackListener(const std::weak_ptr<Listener> &listener);

    /**
     * 返回总的消费者个数
     * Return the total number of consumers
     
     * [AUTO-TRANSLATED:5eaac131]
     */
    int totalReaderCount() const;

    /**
     * 判断是否生效(是否正在转其他协议)
     * Determine whether it is effective (whether it is being converted to another protocol)
     
     * [AUTO-TRANSLATED:ca92165c]
     */
    bool isEnabled();

    /**
     * 重置track
     * Reset track
     
     * [AUTO-TRANSLATED:95dc0b4f]
     */
    void resetTracks() override;

    /////////////////////////////////MediaSourceEvent override/////////////////////////////////

    /**
     * 观看总人数
     * @param sender 事件发送者
     * @return 观看总人数
     * Total number of viewers
     * @param sender Event sender
     * @return Total number of viewers
     
     * [AUTO-TRANSLATED:f4d7146c]
     */
    int totalReaderCount(MediaSource &sender) override;

    /**
     * 设置录制状态
     * @param type 录制类型
     * @param start 开始或停止
     * @param custom_path 开启录制时，指定自定义路径
     * @return 是否设置成功
     * Set recording status
     * @param type Recording type
     * @param start Start or stop
     * @param custom_path Specify a custom path when recording is enabled
     * @return Whether the setting is successful
     
     * [AUTO-TRANSLATED:cb1fd8a9]
     */
    bool setupRecord(MediaSource &sender, Recorder::type type, bool start, const std::string &custom_path, size_t max_second);

    /**
     * 开始录制mp4
     * @param file_path mp4相对路径
     * @param back_time_ms 回溯录制时长
     * @param forward_time_ms 后续录制时长
     * @return 录制文件绝对路径
     */
    std::string startRecord(const std::string &file_path, int back_time_ms, int forward_time_ms);

    /**
     * 获取录制状态
     * @param type 录制类型
     * @return 录制状态
     * Get recording status
     * @param type Recording type
     * @return Recording status
     
     * [AUTO-TRANSLATED:798afa71]
     */
    bool isRecording(Recorder::type type);

    /**
     * 开始发送ps-rtp流
     * @param cb 启动成功或失败回调
     */
    void startSendRtp(const MediaSourceEvent::SendRtpArgs &args, const std::function<void(uint16_t, const toolkit::SockException &)> cb);

    /**
     * 停止ps-rtp发送
     * @return 是否成功
     * Stop ps-rtp sending
     * @return Whether it is successful
     
     * [AUTO-TRANSLATED:b91e2055]
     */
    bool stopSendRtp(const std::string &ssrc);

    /**
     * 获取所属线程
     * Get the thread it belongs to
     
     * [AUTO-TRANSLATED:a4dc847e]
     */
    toolkit::EventPoller::Ptr getOwnerPoller(MediaSource &sender) override;
    
    /**
     * 关闭流
     * @return 是否成功
     */
    bool close(MediaSource &sender) override;

    /**
     * 获取本对象
     * Get this object
     
     * [AUTO-TRANSLATED:5e119bb3]
     */
    std::shared_ptr<MultiMediaSourceMuxer> getMuxer(MediaSource &sender) const override;

    // 获取frame ring reader
    RingType::RingReader::Ptr getFrameReader();

    const ProtocolOption &getOption() const;
    const MediaTuple &getMediaTuple() const;
    std::string shortUrl() const;
#if defined(ENABLE_RTPPROXY)
    void forEachRtpSender(const std::function<void(const std::string &ssrc, const RtpSender &sender)> &cb) const;
#endif // ENABLE_RTPPROXY

    void addProbe(uint32_t probe_ms, const std::function<void(const std::list<FrameInfo> &info_list)> &cb);

protected:
    /////////////////////////////////MediaSink override/////////////////////////////////

    /**
    * 某track已经准备好，其ready()状态返回true，
    * 此时代表可以获取其例如sps pps等相关信息了
    * @param track
     * A certain track is ready, its ready() status returns true,
     * This means that you can get information such as sps pps, etc.
     * @param track
     
     * [AUTO-TRANSLATED:05659d48]
    */
    bool onTrackReady(const Track::Ptr & track) override;

    /**
     * 所有Track已经准备好，
     * All Tracks are ready,
     
     * [AUTO-TRANSLATED:c54d02e2]
     */
    void onAllTrackReady() override;

    /**
     * 某Track输出frame，在onAllTrackReady触发后才会调用此方法
     * @param frame
     * A certain Track outputs a frame, this method will be called after onAllTrackReady is triggered
     * @param frame
     
     * [AUTO-TRANSLATED:debbd247]
     */
    bool onTrackFrame(const Frame::Ptr &frame) override;
    bool onTrackFrame_l(const Frame::Ptr &frame);

private:
    void createGopCacheIfNeed();
    std::shared_ptr<MediaSinkInterface> makeRecorder(Recorder::type type);

private:
    bool _is_enable = false;
    bool _create_in_poller = false;
    bool _video_key_pos = false;
    float _dur_sec;
    std::function<void(const Frame::Ptr &frame)> _on_frame;
    std::shared_ptr<class FramePacedSender> _paced_sender;
    MediaTuple _tuple;
    ProtocolOption _option;
    toolkit::Ticker _last_check;
    std::unordered_map<int, Stamp> _stamps;
    std::weak_ptr<Listener> _track_listener;
#if defined(ENABLE_RTPPROXY)
    std::unordered_multimap<std::string, std::tuple<RingType::RingReader::Ptr, std::weak_ptr<RtpSender>>> _rtp_sender;
#endif // ENABLE_RTPPROXY
    FMP4MediaSourceMuxer::Ptr _fmp4;
    RtmpMediaSourceMuxer::Ptr _rtmp;
    RtspMediaSourceMuxer::Ptr _rtsp;
    TSMediaSourceMuxer::Ptr _ts;
    MediaSinkInterface::Ptr _mp4;
    HlsRecorder::Ptr _hls;
    HlsFMP4Recorder::Ptr _hls_fmp4;
    toolkit::EventPoller::Ptr _poller;
    RingType::Ptr _ring;
    MediaSinkInterface::Ptr _delegate;
    // 对象个数统计  [AUTO-TRANSLATED:3b43e8c2]
    // Object count statistics
    toolkit::ObjectStatistic<MultiMediaSourceMuxer> _statistic;
};

}//namespace mediakit
#endif //ZLMEDIAKIT_MULTIMEDIASOURCEMUXER_H
