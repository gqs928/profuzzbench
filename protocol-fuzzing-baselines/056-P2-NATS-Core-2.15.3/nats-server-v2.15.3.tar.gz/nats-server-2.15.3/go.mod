module github.com/nats-io/nats-server/v2

go 1.26.0

toolchain go1.26.11

require (
	github.com/antithesishq/antithesis-sdk-go v0.9.0-default-no-op
	github.com/google/go-tpm v0.9.8
	github.com/klauspost/compress v1.20.4
	github.com/minio/highwayhash v1.0.4
	github.com/nats-io/jwt/v2 v2.8.3
	github.com/nats-io/nats.go v1.55.0
	github.com/nats-io/nkeys v0.4.17
	github.com/nats-io/nuid v1.0.1
	golang.org/x/crypto v0.58.0
	golang.org/x/sys v0.50.0
	golang.org/x/time v0.16.0
)
