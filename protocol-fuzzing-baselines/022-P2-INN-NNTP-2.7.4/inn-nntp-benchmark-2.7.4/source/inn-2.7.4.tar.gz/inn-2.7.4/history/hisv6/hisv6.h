/*
**  Internal history API interface exposed to HISxxx
**
**  Written by Alex Kiernan in 2001.
**
**  Various bug fixes, code and documentation improvements since then
**  in 2001, 2009, 2020, 2021, 2026.
*/

#ifndef HISV6_H
#define HISV6_H

#include "inn/libinn.h"

struct token;
struct histopts;
struct history;

void *hisv6_open(const char *path, int flags, struct history *);

bool hisv6_close(void *);

bool hisv6_sync(void *);

bool hisv6_lookup(void *, const char *key, time_t *arrived, time_t *posted,
                  time_t *expires, struct token *token);

bool hisv6_check(void *, const char *key);

bool hisv6_write(void *, const char *key, time_t arrived, time_t posted,
                 time_t expires, const struct token *token);

bool hisv6_replace(void *, const char *key, time_t arrived, time_t posted,
                   time_t expires, const struct token *token);

bool hisv6_expire(void *, const char *, const char *, bool, void *,
                  time_t threshold,
                  bool (*exists)(void *, time_t, time_t, time_t,
                                 struct token *));

bool hisv6_walk(void *, const char *, void *,
                bool (*)(void *, const HASH *, time_t, time_t, time_t,
                         const struct token *));

const char *hisv6_error(void *);

bool hisv6_remember(void *, const char *key, time_t arrived, time_t posted);

bool hisv6_ctl(void *, int, void *);

#endif
