/*
 * DO NOT EDIT DIRECTLY.
 *
 * This file was generated automatically by sqlite-helper-gen
 * from ovsqlite/sql-main.sql.
 *
 * DO NOT EDIT DIRECTLY.
 */

#ifndef SQL_MAIN_H
#define SQL_MAIN_H 1

#include "sqlite-helper.h"

#ifdef HAVE_SQLITE3

typedef struct sql_main_t {
    sqlite3_stmt *getmisc;
    sqlite3_stmt *setmisc;
    sqlite3_stmt *unsetmisc;
    sqlite3_stmt *begin;
    sqlite3_stmt *commit;
    sqlite3_stmt *rollback;
    sqlite3_stmt *savepoint;
    sqlite3_stmt *release_savepoint;
    sqlite3_stmt *rollback_savepoint;
    sqlite3_stmt *delete_journal;
    sqlite3_stmt *add_group;
    sqlite3_stmt *get_groupinfo;
    sqlite3_stmt *update_groupinfo_flag_alias;
    sqlite3_stmt *set_group_deleted;
    sqlite3_stmt *lookup_groupinfo;
    sqlite3_stmt *list_groups;
    sqlite3_stmt *add_article;
    sqlite3_stmt *update_groupinfo_add;
    sqlite3_stmt *get_artinfo;
    sqlite3_stmt *delete_article;
    sqlite3_stmt *update_groupinfo_delete_all;
    sqlite3_stmt *update_groupinfo_delete_low;
    sqlite3_stmt *update_groupinfo_delete_middle;
    sqlite3_stmt *start_expire_group;
    sqlite3_stmt *add_expireart;
    sqlite3_stmt *fill_expireart;
    sqlite3_stmt *expire_articles;
    sqlite3_stmt *clear_expireart;
    sqlite3_stmt *set_forgotten_deleted;
    sqlite3_stmt *delete_empty_groups;
    sqlite3_stmt *get_deleted_groupid;
    sqlite3_stmt *delete_group;
    sqlite3_stmt *list_articles;
    sqlite3_stmt *list_articles_overview;
    sqlite3_stmt *list_articles_high;
    sqlite3_stmt *list_articles_high_overview;
} sql_main_t;

extern sqlite_helper_t const sql_main_helper;

#endif /* HAVE_SQLITE3 */

#endif /* ! SQL_MAIN_H */
