/*
 * DO NOT EDIT DIRECTLY.
 *
 * This file was generated automatically by sqlite-helper-gen
 * from ovsqlite/sql-init.sql.
 *
 * DO NOT EDIT DIRECTLY.
 */

#ifndef SQL_INIT_H
#define SQL_INIT_H 1

#include "sqlite-helper.h"

#ifdef HAVE_SQLITE3

typedef struct sql_init_t {
    sqlite3_stmt *getpagesize;
} sql_init_t;

extern sqlite_helper_t const sql_init_helper;

#endif /* HAVE_SQLITE3 */

#endif /* ! SQL_INIT_H */
