/*
 * DO NOT EDIT DIRECTLY.
 *
 * This file was generated automatically by sqlite-helper-gen
 * from ovsqlite/sql-read.sql.
 *
 * DO NOT EDIT DIRECTLY.
 */


#include "sql-read.h"

#ifdef HAVE_SQLITE3

sqlite_helper_t const sql_read_helper =
{
    5,

    "pragma busy_timeout = 10000;\n"
    "\n"
    "pragma query_only = 1;\n"
    "\000"
    "getmisc\000"
    "select value from misc\n"
    "  where key=?1;\n"
    "\000"
    "get_groupinfo\000"
    "select low, high, \"count\", flag_alias from groupinfo\n"
    "  where deleted=0\n"
    "    and groupname=?1;\n"
    "\000"
    "get_artinfo\000"
    "select token\n"
    "  from groupinfo\n"
    "    natural join artinfo\n"
    "  where deleted=0\n"
    "    and groupname=?1\n"
    "    and artnum=?2;\n"
    "\000"
    "list_articles_high\000"
    "select artnum, arrived, expires, token\n"
    "  from groupinfo\n"
    "    natural join artinfo\n"
    "  where deleted=0\n"
    "    and groupname=?1\n"
    "    and artnum>=?2\n"
    "    and artnum<=?3\n"
    "  order by artnum;\n"
    "\000"
    "list_articles_high_overview\000"
    "select artnum, arrived, expires, token, overview\n"
    "  from groupinfo\n"
    "    natural join artinfo\n"
    "  where deleted=0\n"
    "    and groupname=?1\n"
    "    and artnum>=?2\n"
    "    and artnum<=?3\n"
    "  order by artnum;\n"
    "\000"
};

#endif /* HAVE_SQLITE3 */

