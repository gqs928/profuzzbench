/*
 * DO NOT EDIT DIRECTLY.
 *
 * This file was generated automatically by sqlite-helper-gen
 * from ovsqlite/sql-read.sql.
 *
 * DO NOT EDIT DIRECTLY.
 */

#ifndef SQL_READ_H
#define SQL_READ_H 1

#include "sqlite-helper.h"

#ifdef HAVE_SQLITE3

typedef struct sql_read_t {
    sqlite3_stmt *getmisc;
    sqlite3_stmt *get_groupinfo;
    sqlite3_stmt *get_artinfo;
    sqlite3_stmt *list_articles_high;
    sqlite3_stmt *list_articles_high_overview;
} sql_read_t;

extern sqlite_helper_t const sql_read_helper;

#endif /* HAVE_SQLITE3 */

#endif /* ! SQL_READ_H */
