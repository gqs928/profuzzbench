/*
 * DO NOT EDIT DIRECTLY.
 *
 * This file was generated automatically by sqlite-helper-gen
 * from ovsqlite/sql-init.sql.
 *
 * DO NOT EDIT DIRECTLY.
 */


#include "sql-init.h"

#ifdef HAVE_SQLITE3

sqlite_helper_t const sql_init_helper =
{
    1,

    "create table misc (\n"
    "  key text\n"
    "    primary key,\n"
    "  value\n"
    "    not null\n"
    ") without rowid;\n"
    "create table groupinfo (\n"
    "  groupid integer\n"
    "    primary key,\n"
    "  low integer\n"
    "    not null\n"
    "    default 1,\n"
    "  high integer\n"
    "    not null\n"
    "    default 0,\n"
    "  \"count\" integer\n"
    "    not null\n"
    "    default 0,\n"
    "  expired integer\n"
    "    not null\n"
    "    default 0,\n"
    "  deleted integer\n"
    "    not null\n"
    "    default 0,\n"
    "  groupname blob\n"
    "    not null,\n"
    "  flag_alias blob\n"
    "    not null,\n"
    "\n"
    "  unique (deleted, groupname));\n"
    "create table artinfo (\n"
    "  groupid integer\n"
    "    references groupinfo (groupid)\n"
    "      on update cascade\n"
    "      on delete restrict,\n"
    "  artnum integer,\n"
    "  arrived integer\n"
    "    not null,\n"
    "  expires integer\n"
    "    not null,\n"
    "  token blob\n"
    "    not null,\n"
    "  overview blob\n"
    "    not null,\n"
    "\n"
    "  primary key (groupid, artnum)\n"
    ") without rowid;\n"
    "\000"
    "getpagesize\000"
    "pragma page_size;\n"
    "\000"
};

#endif /* HAVE_SQLITE3 */

