'use strict'

const { describe, it, beforeEach } = require('node:test')
const assert = require('node:assert/strict')

const constants = require('haraka-constants')
const DSN = require('haraka-dsn')
const utils = require('haraka-utils')
const { Address } = require('@haraka/email-address')
const { Header } = require('haraka-email-message')

const connection = require('../connection')
const Server = require('../server')

// Expose SMTP result constants as globals (DENY, DENYSOFT, etc.)
constants.import(global)

// ── Helpers ───────────────────────────────────────────────────────────────────

function makeClient(opts = {}) {
    return {
        remotePort: opts.remotePort ?? null,
        remoteAddress: opts.remoteAddress ?? null,
        localPort: opts.localPort ?? null,
        localAddress: opts.localAddress ?? null,
        destroy: () => {},
        pause: () => {},
        resume: () => {},
    }
}

function makeServer(ip = null) {
    return {
        ip_address: ip,
        address() {
            return this.ip_address
        },
    }
}

const setUp = () => {
    this.connection = connection.createConnection(makeClient(), makeServer(), Server.cfg)
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe('connection', () => {
    describe('initial properties', () => {
        beforeEach(setUp)

        it('remote object defaults', () => {
            assert.deepEqual(this.connection.remote, {
                ip: null,
                port: null,
                host: null,
                info: null,
                closed: false,
                is_private: false,
                is_local: false,
            })
        })

        it('local object defaults', () => {
            assert.equal(this.connection.local.ip, null)
            assert.equal(this.connection.local.port, null)
            assert.ok(this.connection.local.host, 'local.host is set')
        })

        it('tls object defaults', () => {
            assert.deepEqual(this.connection.tls, {
                enabled: false,
                advertised: false,
                verified: false,
                cipher: {},
            })
        })

        it('hello object defaults', () => {
            assert.equal(this.connection.hello.host, null)
            assert.equal(this.connection.hello.verb, null)
        })

        it('proxy object defaults', () => {
            assert.equal(this.connection.proxy.allowed, false)
            assert.equal(this.connection.proxy.ip, null)
            assert.equal(this.connection.proxy.type, null)
            assert.equal(this.connection.proxy.timer, null)
        })

        it('notes object exists', () => {
            assert.ok(this.connection.notes, 'notes is set')
            assert.equal(typeof this.connection.notes, 'object')
        })

        it('transaction is null', () => {
            assert.equal(this.connection.transaction, null)
        })

        it('capabilities is null', () => {
            assert.equal(this.connection.capabilities, null)
        })

        it('remote.is_private and remote.is_local default to false', () => {
            assert.equal(this.connection.remote.is_private, false)
            assert.equal(this.connection.remote.is_local, false)
        })
    })

    describe('private IP connection', () => {
        beforeEach(() => {
            this.connection = connection.createConnection(
                makeClient({
                    remotePort: 2525,
                    remoteAddress: '172.16.15.1',
                    localPort: 25,
                    localAddress: '172.16.15.254',
                }),
                makeServer('172.16.15.254'),
                Server.cfg,
            )
        })

        it('remote.is_private is true', () => {
            assert.equal(this.connection.remote.is_private, true)
        })

        it('remote.is_local is false', () => {
            assert.equal(this.connection.remote.is_local, false)
        })

        it('remote.port is set', () => {
            assert.equal(this.connection.remote.port, 2525)
        })
    })

    describe('loopback connection', () => {
        beforeEach(() => {
            this.connection = connection.createConnection(
                makeClient({ remotePort: 2525, remoteAddress: '127.0.0.2', localPort: 25, localAddress: '172.0.0.1' }),
                makeServer('127.0.0.1'),
                Server.cfg,
            )
        })

        it('remote.is_private is true', () => {
            assert.equal(this.connection.remote.is_private, true)
        })

        it('remote.is_local is true', () => {
            assert.equal(this.connection.remote.is_local, true)
        })
    })

    describe('get_remote', () => {
        beforeEach(setUp)

        it('formats host and IP', () => {
            this.connection.remote.host = 'a.host.tld'
            this.connection.remote.ip = '172.16.199.198'
            assert.equal(this.connection.get_remote('host'), 'a.host.tld [172.16.199.198]')
        })

        it('falls back to bracketed IP when no host', () => {
            this.connection.remote.ip = '172.16.199.198'
            assert.equal(this.connection.get_remote('host'), '[172.16.199.198]')
        })

        it('DNSERROR suppresses hostname', () => {
            this.connection.remote.host = 'DNSERROR'
            this.connection.remote.ip = '172.16.199.198'
            assert.equal(this.connection.get_remote('host'), '[172.16.199.198]')
        })

        it('NXDOMAIN suppresses hostname', () => {
            this.connection.remote.host = 'NXDOMAIN'
            this.connection.remote.ip = '172.16.199.198'
            assert.equal(this.connection.get_remote('host'), '[172.16.199.198]')
        })
    })

    describe('local.info', () => {
        beforeEach(setUp)

        it('contains Haraka/version', () => {
            assert.match(this.connection.local.info, /Haraka\/\d+\.\d+/)
        })

        it('does not read the version per connection', (t) => {
            const getVersion = t.mock.method(utils, 'getVersion')
            connection.createConnection(makeClient(), makeServer(), Server.cfg)
            assert.equal(getVersion.mock.callCount(), 0)
        })
    })

    describe('get_capabilities', () => {
        beforeEach(setUp)

        it('returns empty array by default', () => {
            assert.deepEqual(this.connection.get_capabilities(), [])
        })
    })

    describe('relaying', () => {
        beforeEach(setUp)

        it('defaults to false', () => {
            assert.equal(this.connection.relaying, false)
        })

        it('set() and get() round-trip on connection', () => {
            this.connection.set('relaying', 'crocodiles')
            assert.equal(this.connection.get('relaying'), 'crocodiles')
            assert.equal(this.connection.relaying, 'crocodiles')
            assert.equal(this.connection._relaying, 'crocodiles')
        })

        it('direct assignment round-trips', () => {
            this.connection.relaying = 'alligators'
            assert.equal(this.connection.get('relaying'), 'alligators')
            assert.equal(this.connection._relaying, 'alligators')
        })

        it('set() with a transaction updates txn, not connection', () => {
            this.connection.transaction = {}
            this.connection.set('relaying', 'txn-only')
            assert.equal(this.connection.get('relaying'), 'txn-only')
            assert.equal(this.connection._relaying, false)
            assert.equal(this.connection.transaction._relaying, 'txn-only')
        })
    })

    describe('get / set', () => {
        beforeEach(setUp)

        it('sets and gets a single-level property', () => {
            this.connection.set('encoding', true)
            assert.ok(this.connection.encoding)
            assert.ok(this.connection.get('encoding'))
        })

        it('sets and gets a two-level property', () => {
            this.connection.set('local.host', 'test')
            assert.equal(this.connection.local.host, 'test')
            assert.equal(this.connection.get('local.host'), 'test')
        })

        it('sets and gets a three-level property', () => {
            this.connection.set('some.fine.example', true)
            assert.ok(this.connection.some.fine.example)
            assert.ok(this.connection.get('some.fine.example'))
        })

        it('sets hello.verb via set()', () => {
            this.connection.set('hello', 'verb', 'EHLO')
            assert.equal(this.connection.hello.verb, 'EHLO')
        })

        it('sets proxy fields via set()', () => {
            this.connection.set('proxy', 'ip', '172.16.15.1')
            this.connection.set('proxy', 'type', 'haproxy')
            this.connection.set('proxy', 'allowed', true)
            assert.equal(this.connection.proxy.ip, '172.16.15.1')
            assert.equal(this.connection.proxy.type, 'haproxy')
            assert.equal(this.connection.proxy.allowed, true)
        })

        it('has normalised connection properties after set()', () => {
            this.connection.set('remote', 'ip', '172.16.15.1')
            this.connection.set('hello', 'verb', 'EHLO')
            this.connection.set('tls', 'enabled', true)
            assert.equal(this.connection.remote.ip, '172.16.15.1')
            assert.equal(this.connection.remote.port, null)
            assert.equal(this.connection.hello.verb, 'EHLO')
            assert.equal(this.connection.hello.host, null)
            assert.equal(this.connection.tls.enabled, true)
        })
    })

    describe('queue_msg', () => {
        beforeEach(setUp)

        it('returns supplied message when given', () => {
            assert.equal(this.connection.queue_msg(1, 'test message'), 'test message')
        })

        it('returns default DENY message', () => {
            assert.equal(this.connection.queue_msg(DENY), 'Message denied')
            assert.equal(this.connection.queue_msg(DENYDISCONNECT), 'Message denied')
        })

        it('returns default DENYSOFT message', () => {
            assert.equal(this.connection.queue_msg(DENYSOFT), 'Message denied temporarily')
            assert.equal(this.connection.queue_msg(DENYSOFTDISCONNECT), 'Message denied temporarily')
        })

        it('returns empty string for unrecognised code', () => {
            assert.equal(this.connection.queue_msg('hello'), '')
        })
    })

    describe('respond', () => {
        beforeEach(setUp)

        it('returns undefined when disconnected', () => {
            this.connection.state = constants.connection.state.DISCONNECTED
            assert.equal(this.connection.respond(200, 'your lucky day'), undefined)
            assert.equal(this.connection.respond(550, 'you are jacked'), undefined)
        })

        it('formats a simple 200 response', () => {
            assert.equal(this.connection.respond(200, 'you may pass Go'), '200 you may pass Go\r\n')
        })

        it('formats a DSN 200 response', () => {
            assert.equal(
                this.connection.respond(200, DSN.create(200, 'you may pass Go')),
                '200 2.0.0 you may pass Go\r\n',
            )
        })

        it('DSN overrides response code', () => {
            assert.equal(
                this.connection.respond(450, DSN.create(550, 'This domain is not in use')),
                '550 5.0.0 This domain is not in use\r\n',
            )
        })

        it('DSN addr_bad_dest_system (5.1.2)', () => {
            assert.equal(
                this.connection.respond(550, DSN.addr_bad_dest_system('Domain not in use', 550)),
                '550 5.1.2 Domain not in use\r\n',
            )
        })

        it('formats multi-line response from array', () => {
            const resp = this.connection.respond(250, ['Hello', 'World'])
            assert.ok(resp.includes('250-Hello\r\n'), 'first line uses dash')
            assert.ok(resp.includes('250 World\r\n'), 'last line uses space')
        })

        it('formats multi-line response from newline-separated string', () => {
            const resp = this.connection.respond(250, 'Hello\nWorld')
            assert.ok(resp.includes('250-Hello\r\n'), 'first line uses dash')
            assert.ok(resp.includes('250 World\r\n'), 'last line uses space')
        })

        it('last_response is updated when client has a write method', () => {
            // When client.write is defined, respond() writes to the socket and
            // stores the formatted buffer in last_response.
            let written = ''
            this.connection.client.write = (buf) => {
                written += buf
            }
            this.connection.respond(250, 'OK')
            assert.ok(written.includes('250 OK'), 'data written to socket')
            assert.ok(this.connection.last_response.includes('250 OK'), 'last_response updated')
        })
    })

    describe('pause and resume', () => {
        beforeEach(setUp)

        it('restores previous state when still paused at resume', () => {
            this.connection.state = constants.connection.state.PAUSE_SMTP
            this.connection.pause()
            this.connection.resume()
            assert.equal(this.connection.state, constants.connection.state.PAUSE_SMTP)
            assert.equal(this.connection.prev_state, null)
        })

        it('does not overwrite state changed while paused', () => {
            this.connection.state = constants.connection.state.PAUSE_SMTP
            this.connection.pause()
            this.connection.state = constants.connection.state.CMD
            this.connection.resume()
            assert.equal(this.connection.state, constants.connection.state.CMD)
            assert.equal(this.connection.prev_state, null)
        })
    })

    describe('loop_respond', () => {
        beforeEach(setUp)

        it('sets state to LOOP', () => {
            this.connection.loop_respond(554, 'Denied')
            assert.equal(this.connection.state, constants.connection.state.LOOP)
        })

        it('records loop_code and loop_msg', () => {
            this.connection.loop_respond(554, 'Denied')
            assert.equal(this.connection.loop_code, 554)
            assert.equal(this.connection.loop_msg, 'Denied')
        })

        it('does nothing when already disconnecting', () => {
            this.connection.state = constants.connection.state.DISCONNECTING
            this.connection.loop_respond(554, 'Denied')
            assert.equal(this.connection.state, constants.connection.state.DISCONNECTING)
        })
    })

    describe('tran_uuid', () => {
        beforeEach(setUp)

        it('increments tran_count on each call', () => {
            assert.equal(this.connection.tran_count, 0)
            const u1 = this.connection.tran_uuid()
            assert.equal(this.connection.tran_count, 1)
            const u2 = this.connection.tran_uuid()
            assert.equal(this.connection.tran_count, 2)
            assert.notEqual(u1, u2)
        })

        it('formats as <connection-uuid>.<count>', () => {
            const u = this.connection.tran_uuid()
            assert.match(u, new RegExp(`^${this.connection.uuid}\\.1$`))
        })
    })

    describe('PROXY timer', () => {
        beforeEach(setUp)

        it('is cleared when the client hangs up before sending its PROXY header', async () => {
            const conn = this.connection
            conn.client.end = () => {}
            let fired = false
            conn.proxy.allowed = true
            conn.proxy.timer = setTimeout(() => {
                fired = true
            }, 20)

            conn.fail() // what the client end, close and error handlers do

            assert.equal(conn.proxy.timer, null)
            await new Promise((resolve) => setTimeout(resolve, 40))
            assert.equal(fired, false, 'the PROXY timer did not fire')
        })
    })

    describe('issue #3374 — double QUIT prevention', () => {
        beforeEach(setUp)

        it('quit hook fires only once when two QUITs arrive in LOOP state', async () => {
            const conn = this.connection
            conn.loop_respond(554, 'Denied')
            assert.equal(conn.state, constants.connection.state.LOOP)

            let quit_hook_calls = 0
            const plugins = require('../plugins')
            const original_run_hooks = plugins.run_hooks
            plugins.run_hooks = (hook, c, params) => {
                if (hook === 'quit') {
                    quit_hook_calls++
                    if (quit_hook_calls === 1) {
                        setTimeout(() => c.quit_respond(constants.ok), 50)
                    }
                    return
                }
                original_run_hooks(hook, c, params)
            }

            conn.process_line(Buffer.from('QUIT\r\n'))
            conn.process_line(Buffer.from('QUIT\r\n'))

            await new Promise((resolve) => {
                setTimeout(() => {
                    plugins.run_hooks = original_run_hooks
                    assert.equal(quit_hook_calls, 1, 'quit hook called exactly once')
                    resolve()
                }, 100)
            })
        })
    })

    describe('queue responses', () => {
        beforeEach(setUp)

        const prepQueueTestConnection = () => {
            const calls = { respond: [], reset: 0, disconnect: 0, queue_ok: 0, results: [] }
            const plugins = require('../plugins')
            const originalRunHooks = plugins.run_hooks

            this.connection.transaction = {
                uuid: 'txn-123',
                msg_status: null,
                results: {
                    add(_meta, payload) {
                        calls.results.push(payload)
                    },
                },
            }

            this.connection.respond = (code, msg, cb) => {
                calls.respond.push({ code, msg })
                if (cb) cb()
            }
            this.connection.reset_transaction = (cb) => {
                calls.reset++
                this.connection.transaction = this.connection.transaction || {}
                if (cb) cb()
            }
            this.connection.disconnect = () => {
                calls.disconnect++
            }
            plugins.run_hooks = (hook) => {
                if (hook === 'queue_ok') calls.queue_ok++
            }

            return {
                calls,
                restore() {
                    plugins.run_hooks = originalRunHooks
                },
            }
        }

        it('queue_respond handles denydisconnect and marks message rejected', () => {
            const harness = prepQueueTestConnection()
            try {
                this.connection.queue_respond(constants.denydisconnect)
                assert.equal(harness.calls.respond[0].code, 550)
                assert.equal(this.connection.msg_count.reject, 1)
                assert.equal(this.connection.transaction.msg_status, 'rejected')
                assert.equal(harness.calls.disconnect, 1)
                assert.deepEqual(harness.calls.results[0], { fail: 'Message denied' })
            } finally {
                harness.restore()
            }
        })

        it('queue_respond handles denysoft and resets transaction', () => {
            const harness = prepQueueTestConnection()
            try {
                this.connection.queue_respond(constants.denysoft)
                assert.equal(harness.calls.respond[0].code, 450)
                assert.equal(this.connection.msg_count.tempfail, 1)
                assert.equal(this.connection.transaction.msg_status, 'deferred')
                assert.equal(harness.calls.reset, 1)
                assert.deepEqual(harness.calls.results[0], {
                    fail: 'Message denied temporarily',
                    soft: true,
                })
            } finally {
                harness.restore()
            }
        })

        it('queue_respond handles denysoftdisconnect and disconnects', () => {
            const harness = prepQueueTestConnection()
            try {
                this.connection.queue_respond(constants.denysoftdisconnect)
                assert.equal(harness.calls.respond[0].code, 450)
                assert.equal(this.connection.msg_count.tempfail, 1)
                assert.equal(this.connection.transaction.msg_status, 'deferred')
                assert.equal(harness.calls.disconnect, 1)
            } finally {
                harness.restore()
            }
        })

        it('queue_respond default path returns 451 and resets transaction', () => {
            const harness = prepQueueTestConnection()
            try {
                this.connection.queue_respond(constants.cont)
                assert.equal(harness.calls.respond[0].code, 451)
                assert.equal(this.connection.msg_count.tempfail, 1)
                assert.equal(this.connection.transaction.msg_status, 'deferred')
                assert.equal(harness.calls.reset, 1)
            } finally {
                harness.restore()
            }
        })

        it('queue_ok_respond accepts and resets transaction', () => {
            const harness = prepQueueTestConnection()
            try {
                this.connection.queue_ok_respond(constants.ok, null, 'queued')
                assert.equal(harness.calls.respond[0].code, 250)
                assert.equal(this.connection.msg_count.accept, 1)
                assert.equal(this.connection.transaction.msg_status, 'accepted')
                assert.equal(harness.calls.reset, 1)
            } finally {
                harness.restore()
            }
        })
    })

    describe('received_line', () => {
        beforeEach(setUp)

        // Every CR must open a fold, and every fold must be a continuation.
        const assertWellFolded = (header) => {
            assert.ok(!/\r(?!\n)/.test(header), 'no bare CR')
            assert.ok(!/\n(?!\t)/.test(header), 'every line break starts a folded line')
        }

        const receivedWith = ({ helo, info, mail_from }) => {
            this.connection.hello.verb = 'EHLO'
            this.connection.hello.host = helo
            this.connection.set('remote', 'info', info)
            this.connection.transaction = {
                uuid: 'txn-123',
                mail_from: { format: () => mail_from },
            }
            return this.connection.received_line()
        }

        it('builds a folded header from well formed values', () => {
            const header = receivedWith({
                helo: 'mail.example.com',
                info: 'client.example.com',
                mail_from: '<a@example.com>',
            })
            assertWellFolded(header)
            assert.match(header, /^from mail\.example\.com \(client\.example\.com/)
        })

        it('stays folded when rDNS carries control characters', () => {
            const hostile = 'evil\r\nX-Injected: yes'
            const plugins = require('../plugins')
            const originalRunHooks = plugins.run_hooks
            plugins.run_hooks = () => {}
            try {
                this.connection.rdns_response(null, [hostile])
            } finally {
                plugins.run_hooks = originalRunHooks
            }

            assert.equal(this.connection.remote.host, 'evilX-Injected: yes', 'rDNS host is clean at rest')
            assertWellFolded(
                receivedWith({
                    helo: 'mail.example.com',
                    info: this.connection.remote.info,
                    mail_from: '<a@example.com>',
                }),
            )
        })

        it('rejects control characters in MAIL FROM before they reach the header', () => {
            assert.throws(() => new Address('<a\r\nX-Injected: yes@example.com>'))
        })
    })

    describe('data_post_respond Message-ID logging', () => {
        beforeEach(setUp)

        const logMessageFor = (header_lines) => {
            const logger = require('../logger')
            const header = new Header()
            header.parse(header_lines)

            this.connection.transaction = {
                uuid: 'txn-123',
                data_post_start: Date.now(),
                data_bytes: 10,
                rcpt_count: { accept: 1, tempfail: 0, reject: 0 },
                header,
            }
            this.connection.respond = (code, msg, cb) => {
                if (cb) cb()
            }
            this.connection.reset_transaction = (cb) => {
                if (cb) cb()
            }
            this.connection.resume = () => {}

            const lines = []
            const orig_log = logger.log
            logger.log = (level, msg) => {
                lines.push(msg)
                return true
            }
            try {
                this.connection.data_post_respond(constants.deny, 'nope')
            } finally {
                logger.log = orig_log
            }
            return lines.find((l) => l.includes('mid='))
        }

        it('logs a well formed Message-ID unchanged', () => {
            assert.match(logMessageFor(['Message-ID: <a@example.com>\r\n']), /mid=<a@example\.com>/)
        })

        it('cannot forge a log line via multiple Message-ID headers', () => {
            const line = logMessageFor([
                'Message-ID: <a@example.com>\r\n',
                'Message-ID: [NOTICE] [-] [core] forged\r\n',
            ])
            assert.equal(line.split('\n').length, 1)
            assert.ok(!line.includes('\\n'), 'line breaks are gone, not merely escaped')
        })

        it('cannot forge a log line via a folded Message-ID header', () => {
            const line = logMessageFor(['Message-ID: <a\r\n[NOTICE] [-] [core] forged\r\n b@example.com>\r\n'])
            assert.equal(line.split('\n').length, 1)
            assert.ok(!line.includes('\\n'), 'line breaks are gone, not merely escaped')
        })
    })

    describe('smtp command/response branches', () => {
        beforeEach(setUp)

        it('rcpt_respond deny removes recipient and records reject', () => {
            const plugins = require('../plugins')
            const originalRunHooks = plugins.run_hooks
            const rcpt = new Address('<to@example.com>')
            const sender = new Address('<from@example.com>')
            const actions = []

            this.connection.transaction = {
                rcpt_to: [rcpt],
                mail_from: sender,
                results: { push() {} },
            }
            this.connection.rcpt_incr = (_rcpt, action) => actions.push(action)
            this.connection.respond = (_code, _msg, cb) => cb && cb()
            plugins.run_hooks = () => {}

            try {
                this.connection.rcpt_respond(constants.deny, 'no')
                assert.equal(actions[0], 'reject')
                assert.equal(this.connection.transaction.rcpt_to.length, 0)
            } finally {
                plugins.run_hooks = originalRunHooks
            }
        })

        it('rcpt_respond ok runs rcpt_ok hook', () => {
            const plugins = require('../plugins')
            const originalRunHooks = plugins.run_hooks
            const rcpt = new Address('<to@example.com>')
            const sender = new Address('<from@example.com>')
            const hooks = []

            this.connection.transaction = {
                rcpt_to: [rcpt],
                mail_from: sender,
                results: { push() {} },
            }
            this.connection.respond = (_code, _msg, cb) => cb && cb()
            plugins.run_hooks = (hook) => hooks.push(hook)

            try {
                this.connection.rcpt_respond(constants.ok, 'ok')
                assert.equal(hooks.includes('rcpt_ok'), true)
                assert.equal(this.connection.last_rcpt_msg, 'ok')
            } finally {
                plugins.run_hooks = originalRunHooks
            }
        })

        it('cmd_proxy rejects when not allowed', () => {
            let code
            this.connection.proxy.allowed = false
            this.connection.respond = (c) => {
                code = c
            }
            this.connection.disconnect = () => {}
            this.connection.cmd_proxy('TCP4 1.2.3.4 5.6.7.8 100 25')
            assert.equal(code, 421)
        })

        it('cmd_proxy accepts valid TCP4 proxy line and runs connect_init', () => {
            const plugins = require('../plugins')
            const originalRunHooks = plugins.run_hooks
            const hooks = []
            this.connection.proxy.allowed = true
            this.connection.remote.ip = '10.0.0.1'
            this.connection.reset_transaction = (cb) => cb && cb()
            this.connection.respond = () => {}
            plugins.run_hooks = (hook) => hooks.push(hook)

            try {
                this.connection.cmd_proxy('TCP4 1.2.3.4 5.6.7.8 100 25')
                assert.equal(this.connection.proxy.type, 'haproxy')
                assert.equal(this.connection.remote.ip, '1.2.3.4')
                assert.equal(this.connection.local.ip, '5.6.7.8')
                assert.equal(hooks.includes('connect_init'), true)
            } finally {
                plugins.run_hooks = originalRunHooks
            }
        })

        it('cmd_data validates argument/transaction/recipient preconditions', () => {
            const responses = []
            this.connection.respond = (code, msg) => {
                responses.push([code, msg])
            }

            this.connection.cmd_data('unexpected')
            this.connection.cmd_data()
            this.connection.transaction = { rcpt_to: [] }
            this.connection.cmd_data()

            assert.equal(responses[0][0], 501)
            assert.equal(responses[1][0], 503)
            assert.equal(responses[2][0], 503)
        })

        it('cmd_mail strips control chars from invalid address logs', () => {
            const notices = []
            const responses = []
            this.connection.hello.host = 'example.test'
            this.connection.lognotice = (msg) => notices.push(msg)
            this.connection.respond = (code, msg) => {
                responses.push({ code, msg })
            }

            this.connection.cmd_mail('FROM:<mail\x00@example.com>')

            assert.equal(responses[0].code, 501)
            assert.match(responses[0].msg, /^Invalid MAIL FROM address /)
            assert.equal(responses[0].msg.includes('\r'), false)
            assert.equal(responses[0].msg.includes('\n'), false)
            assert.equal(responses[0].msg.includes('\\u0000'), false)
            assert.equal(notices[0], responses[0].msg)
        })

        it('cmd_rcpt strips control chars from invalid address logs', () => {
            const notices = []
            const responses = []
            this.connection.transaction = { mail_from: new Address('<from@example.com>'), rcpt_to: [] }
            this.connection.lognotice = (msg) => notices.push(msg)
            this.connection.respond = (code, msg) => {
                responses.push({ code, msg })
            }

            this.connection.cmd_rcpt('TO:<rcpt\x00@example.com>')

            assert.equal(responses[0].code, 501)
            assert.match(responses[0].msg, /^Invalid RCPT TO address /)
            assert.equal(responses[0].msg.includes('\r'), false)
            assert.equal(responses[0].msg.includes('\n'), false)
            assert.equal(responses[0].msg.includes('\\u0000'), false)
            assert.equal(notices[0], responses[0].msg)
        })

        it('cmd_mail rejects a postel-only address when main.postel is false', () => {
            const responses = []
            this.connection.hello.host = 'example.test'
            this.connection.lognotice = () => {}
            this.connection.respond = (code, msg) => responses.push({ code, msg })

            this.connection.cmd_mail('FROM:<foo@[IPv6:bogus::xyz]>')

            assert.equal(responses[0].code, 501)
            assert.match(responses[0].msg, /^Invalid MAIL FROM address /)
        })

        it('cmd_mail accepts a postel-only address when main.postel is true', () => {
            const responses = []
            let started = false
            this.connection.hello.host = 'example.test'
            this.connection.respond = (code, msg) => responses.push({ code, msg })
            this.connection.init_transaction = () => {
                started = true
            }

            connection.cfg.main.postel = true
            try {
                this.connection.cmd_mail('FROM:<foo@[IPv6:bogus::xyz]>')
            } finally {
                connection.cfg.main.postel = false
            }

            assert.equal(started, true)
            assert.equal(
                responses.some((r) => r.code === 501),
                false,
            )
        })

        it('cmd_rcpt rejects a postel-only address when main.postel is false', () => {
            const responses = []
            this.connection.transaction = {
                mail_from: new Address('<from@example.com>'),
                rcpt_to: [],
            }
            this.connection.lognotice = () => {}
            this.connection.respond = (code, msg) => responses.push({ code, msg })

            this.connection.cmd_rcpt('TO:<foo@[IPv6:bogus::xyz]>')

            assert.equal(responses[0].code, 501)
            assert.match(responses[0].msg, /^Invalid RCPT TO address /)
        })

        it('cmd_rcpt accepts a postel-only address when main.postel is true', () => {
            const plugins = require('../plugins')
            const originalRunHooks = plugins.run_hooks
            const responses = []
            this.connection.transaction = {
                mail_from: new Address('<from@example.com>'),
                rcpt_to: [],
            }
            this.connection.respond = (code, msg) => responses.push({ code, msg })
            plugins.run_hooks = () => {}

            connection.cfg.main.postel = true
            try {
                this.connection.cmd_rcpt('TO:<foo@[IPv6:bogus::xyz]>')
            } finally {
                connection.cfg.main.postel = false
                plugins.run_hooks = originalRunHooks
            }

            assert.equal(this.connection.transaction.rcpt_to.length, 1)
            assert.equal(
                responses.some((r) => r.code === 501),
                false,
            )
        })

        it('data_respond denysoftdisconnect disconnects and default enters DATA', () => {
            const responses = []
            let disconnected = 0
            this.connection.transaction = { data_bytes: 5 }
            this.connection.respond = (code, _msg, cb) => {
                responses.push(code)
                if (cb) cb()
            }
            this.connection.disconnect = () => {
                disconnected++
            }

            this.connection.data_respond(constants.denysoftdisconnect, 'tmpfail')
            this.connection.data_respond(constants.ok, 'ok')

            assert.equal(responses[0], 451)
            assert.equal(disconnected, 1)
            assert.equal(responses[1], 354)
            assert.equal(this.connection.state, constants.connection.state.DATA)
            assert.equal(this.connection.transaction.data_bytes, 0)
        })
    })

    // SMTP smuggling, receiver side: the line stream splits on a bare LF, so a strict
    // CRLF-only peer can forward <LF>.<CRLF> as content while Haraka would read the
    // '.' as end-of-DATA and the bytes after it as commands.
    describe('bare line-feed inside DATA', () => {
        beforeEach(setUp)

        const enterData = () => {
            const conn = this.connection
            conn.client = { write() {}, end() {}, destroy() {}, pause() {}, resume() {} }
            conn.esmtp = true
            conn.state = constants.connection.state.DATA
            const seen = { stored: [], replies: [], commands: [], data_done: 0 }
            conn.transaction = {
                data_bytes: 0,
                notes: {},
                header: { get_all: () => [] },
                header_lines: [],
                add_header() {},
                add_data: (l) => seen.stored.push(String(l)),
                end_data() {},
            }
            conn.auth_results = () => ''
            conn.auth_results_clean = () => {}
            const respond = conn.respond.bind(conn)
            conn.respond = (code, msg, cb) => {
                seen.replies.push(code)
                respond(code, msg, cb)
            }
            const data_done = conn.data_done.bind(conn)
            conn.data_done = () => {
                seen.data_done++
                data_done()
            }
            conn.cmd_mail = (args) => seen.commands.push(`MAIL ${args}`)
            return seen
        }

        it('does not end DATA at <LF>.<CRLF>, and drops the connection', () => {
            const seen = enterData()
            this.connection.process_data(Buffer.from('body\n.\r\nMAIL FROM:<forged@example.com>\r\n'))
            assert.equal(seen.data_done, 0, 'the dot after a bare LF is not a terminator')
            assert.deepEqual(seen.replies, [451])
            assert.ok(this.connection.state >= constants.connection.state.DISCONNECTING, 'connection dropped')
            assert.deepEqual(seen.commands, [], 'the smuggled MAIL FROM never runs')
            assert.deepEqual(seen.stored, [], 'the bare-LF line is not stored as content')
        })

        it('leaves a CRLF line and a real terminator untouched', () => {
            const seen = enterData()
            this.connection.process_data(Buffer.from('body\r\n.\r\n'))
            assert.deepEqual(seen.stored, ['body\r\n'])
            assert.equal(seen.data_done, 1)
            assert.deepEqual(seen.replies, [])
        })
    })

    // GHSA-rp4q-8m6x-c43c receiving side: commands pipelined after end-of-DATA are the
    // sink for dot-stuffing smuggling. data_done soft-pauses (keeps reading, but
    // PAUSE_DATA stops processing) so current_data reliably holds anything pipelined
    // before the reply. Those bytes may be attacker-authored, so respond() runs none of
    // them -- not even the RSET/MAIL FROM that RFC 2920 sec 3.1 would allow here -- and
    // answers 503 per complete command, since sec 3.1 correlates responses by count.
    describe('pipelining after end of DATA', () => {
        const states = constants.connection.state
        beforeEach(setUp)

        // drives the real _process_data/process_line/data_done path into the post-DATA
        // window; end_data is async in reality, so leaving its callback unfired is what
        // holds the connection there
        const enterDataWindow = () => {
            this.connection.transaction = {
                data_bytes: 0,
                notes: {},
                header: { get_all: () => [] },
                header_lines: [],
                add_header() {},
                add_data() {},
                end_data() {},
            }
            this.connection.auth_results = () => ''
            this.connection.auth_results_clean = () => {}
            this.connection.state = states.DATA
            this.connection.esmtp = true
        }

        const armReply = ({ current = null } = {}) => {
            this.connection.awaiting_data_reply = true
            this.connection.current_data = current
            const calls = { written: '', disconnect: 0, funcRan: 0 }
            this.connection.client = {
                write(buf) {
                    calls.written += buf
                },
            }
            this.connection.disconnect = () => {
                calls.disconnect++
            }
            this.connection._process_data = () => {}
            return calls
        }

        const repliesOf = (calls) => calls.written.trim().split('\r\n')

        it('refuses a smuggled command group, preserving the reply and bookkeeping', () => {
            const smuggled = 'MAIL FROM:<evil@x>\r\nRCPT TO:<victim@y>\r\nDATA\r\n'
            const calls = armReply({ current: Buffer.from(smuggled) })
            this.connection.respond(250, 'Message Queued', () => {
                calls.funcRan++
            })
            const replies = repliesOf(calls)
            assert.match(replies[0], /^250 /, 'true reply preserved (no false 554)')
            assert.deepEqual(
                replies.slice(1).map((r) => r.slice(0, 3)),
                ['503', '503', '503'],
                'one 503 per smuggled command',
            )
            assert.equal(calls.funcRan, 1, 'completion bookkeeping runs')
            assert.equal(calls.disconnect, 0, 'connection kept for reuse')
            assert.equal(this.connection.current_data, null, 'smuggled group never runs')
            assert.equal(this.connection.awaiting_data_reply, false)
        })

        // RFC 2920 sec 3.1 would allow this group, but we cannot tell it apart from a
        // smuggled one, so it is refused rather than run
        it('refuses a pipelined RSET/MAIL FROM, answering each with 503', () => {
            const calls = armReply({ current: Buffer.from('RSET\r\nMAIL FROM:<next@ok>\r\n') })
            this.connection.respond(250, 'Message Queued', () => {
                calls.funcRan++
            })
            const replies = repliesOf(calls)
            assert.match(replies[0], /^250 /)
            assert.deepEqual(
                replies.slice(1).map((r) => r.slice(0, 3)),
                ['503', '503'],
                'response count matches command count',
            )
            assert.equal(calls.funcRan, 1)
            assert.equal(this.connection.current_data, null, 'not run')
        })

        it('answers only the DATA reply when a compliant client pipelines nothing', () => {
            const calls = armReply()
            this.connection.respond(250, 'Message Queued')
            assert.deepEqual(repliesOf(calls), ['250 Message Queued'], 'no spurious 503')
            assert.equal(this.connection.awaiting_data_reply, false, 'flag cleared')
        })

        it('counts only complete commands, discarding a trailing partial', () => {
            const calls = armReply({ current: Buffer.from('MAIL FROM:<a@b>\r\nRSE') })
            this.connection.respond(250, 'Message Queued')
            const replies = repliesOf(calls)
            assert.equal(replies.length, 2, 'one 503 for the one complete command')
            assert.match(replies[1], /^503 /)
            assert.equal(this.connection.current_data, null, 'partial bytes discarded too')
        })

        // a command longer than line_length must still be counted; otherwise respond()
        // emits fewer 503s than commands and the client's response correlation desyncs
        it('answers a 503 for an overlong pipelined command', () => {
            const big = `MAIL FROM:<${'a'.repeat(600)}@x>\r\n` // > cfg.max.line_length
            const calls = armReply({ current: Buffer.from(`${big}RCPT TO:<v@y>\r\nDATA\r\n`) })
            this.connection.respond(250, 'Message Queued')
            const codes = repliesOf(calls).map((r) => r.slice(0, 3))
            assert.deepEqual(codes, ['250', '503', '503', '503'], 'one 503 per command, overlong included')
        })

        it('preserves a deny reply too (no result rewrite)', () => {
            const calls = armReply({ current: Buffer.from('MAIL FROM:<a@b>\r\n') })
            this.connection.respond(550, 'Message denied')
            assert.match(repliesOf(calls)[0], /^550 /)
            assert.equal(calls.disconnect, 0)
        })

        it('leaves ordinary replies untouched (flag not set)', () => {
            const calls = armReply({ current: Buffer.from('MAIL FROM:<x@y>\r\n') })
            this.connection.awaiting_data_reply = false
            this.connection.respond(250, 'OK')
            assert.deepEqual(repliesOf(calls), ['250 OK'])
            assert.ok(this.connection.current_data?.length, 'ordinary reply leaves current_data alone')
        })

        // a pipelined QUIT cannot smuggle a transaction, but it is refused with everything
        // else so the window has no exceptions to reason about
        it('refuses a pipelined QUIT instead of closing the session', (t, done) => {
            const calls = armReply({ current: Buffer.from('QUIT\r\n') })
            this.connection.respond(250, 'Message Queued')
            setImmediate(() => {
                const replies = repliesOf(calls)
                assert.match(replies[0], /^250 /)
                assert.match(replies[1], /^503 /, 'QUIT answered, not silently dropped')
                assert.ok(!replies.some((r) => r.startsWith('221')), 'session not closed by the pipelined QUIT')
                done()
            })
        })

        it('data_done soft-pauses (does not client.pause) and arms the reply window', () => {
            let clientPaused = false
            enterDataWindow()
            let ended = false
            this.connection.transaction.end_data = () => {
                ended = true
            }
            this.connection.client = {
                pause() {
                    clientPaused = true
                },
            }
            this.connection.data_done()
            assert.equal(this.connection.state, states.PAUSE_DATA, 'processing gated')
            assert.equal(clientPaused, false, 'socket kept reading (no hard pause)')
            assert.equal(this.connection.awaiting_data_reply, true, 'reply window armed')
            assert.equal(ended, true, 'no premature reject; end_data runs')
        })

        it('caps a post-DATA flood and disconnects', () => {
            let disconnected = 0
            this.connection.state = states.PAUSE_DATA
            this.connection.awaiting_data_reply = true
            this.connection.current_data = null
            this.connection._process_data = () => {}
            this.connection.disconnect = () => {
                disconnected++
            }
            this.connection.process_data(Buffer.alloc(9000, 0x41)) // > MAX_POST_DATA_BYTES
            assert.equal(disconnected, 1, 'flood dropped')
            assert.equal(this.connection.current_data, null)
        })

        it('caps a flood arriving in the same read as the end-of-DATA terminator', () => {
            let disconnected = 0
            enterDataWindow()
            this.connection.disconnect = () => {
                disconnected++
            }
            this.connection.process_data(Buffer.concat([Buffer.from('.\r\n'), Buffer.alloc(9000, 0x41)]))
            assert.equal(this.connection.state, states.PAUSE_DATA, 'real terminator parse soft-paused')
            assert.equal(this.connection.awaiting_data_reply, true, 'window armed mid-read')
            assert.equal(disconnected, 1, 'flood dropped on the arming read')
            assert.equal(this.connection.current_data, null)
        })

        it('does not charge pipelined bytes against the DATA line length limit', () => {
            enterDataWindow()
            // under MAX_POST_DATA_BYTES, so the flood cap leaves these bytes buffered
            this.connection.process_data(Buffer.concat([Buffer.from('.\r\n'), Buffer.alloc(5000, 0x41)]))
            assert.equal(this.connection.awaiting_data_reply, true)
            assert.equal(
                this.connection.transaction.notes.data_line_length_exceeded,
                undefined,
                'completed transaction not flagged by post-DATA bytes',
            )
            assert.equal(this.connection.current_data.length, 5000, 'buffer left unwrapped')
        })

        it('is one-shot: a compliant next command after the DATA reply is normal', () => {
            const calls = armReply()
            this.connection.respond(250, 'Message Queued') // the DATA reply
            assert.equal(this.connection.awaiting_data_reply, false, 'flag cleared')
            this.connection.current_data = Buffer.from('MAIL FROM:<next@ok>\r\n')
            calls.written = ''
            this.connection.respond(250, 'sender OK')
            assert.deepEqual(repliesOf(calls), ['250 sender OK'])
            assert.ok(this.connection.current_data?.length, 'next command left for normal processing')
        })
    })

    describe('pipelined command scheduling', () => {
        beforeEach(setUp)

        // respond() used to call _process_data() directly, so a group of N pipelined
        // commands nested N respond() frames before any of them unwound
        it('defers buffered commands so respond does not recurse', () => {
            const conn = this.connection
            conn.client = { write() {}, destroy() {}, pause() {}, resume() {} }
            conn.esmtp = true
            conn.state = constants.connection.state.CMD
            conn.current_data = Buffer.from('HELP\r\n'.repeat(6))

            let depth = 0
            let deepest = 0
            const process_data = conn._process_data.bind(conn)
            conn._process_data = () => {
                deepest = Math.max(deepest, ++depth)
                try {
                    process_data()
                } finally {
                    depth--
                }
            }

            conn._process_data()
            assert.equal(deepest, 1, 'each reply unwinds before the next command runs')
        })
    })

    describe('header injection', () => {
        beforeEach(setUp)

        it('cmd_helo rejects control chars in the host', () => {
            const r = this.connection.cmd_helo('evil\rINJECTED')
            assert.match(String(r), /^501/)
            assert.equal(this.connection.hello.host, null)
        })

        it('cmd_ehlo rejects control chars in the host', () => {
            const r = this.connection.cmd_ehlo('evil\r\nINJECTED')
            assert.match(String(r), /^501/)
            assert.equal(this.connection.hello.host, null)
        })

        it('auth_results strips CR/LF so it cannot inject a header', () => {
            const out = this.connection.auth_results('auth=fail smtp.auth=evil\r\nInjected-Header: pwned')
            assert.ok(!out.includes('\r\nInjected-Header:'))
            // the only CRLF present is the legitimate folding (;\r\n\t)
            assert.equal(out.replace(/;\r\n\t/g, '').includes('\r'), false)
            assert.equal(out.replace(/;\r\n\t/g, '').includes('\n'), false)
        })
    })
})
