'use strict'

exports.register = () => {}
