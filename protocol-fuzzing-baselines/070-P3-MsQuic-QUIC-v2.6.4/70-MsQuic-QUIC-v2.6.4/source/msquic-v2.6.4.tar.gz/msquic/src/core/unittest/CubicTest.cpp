/*++

    Copyright (c) Microsoft Corporation.
    Licensed under the MIT License.

Abstract:

    Unit tests for CUBIC congestion control.

--*/

#include "main.h"
#ifdef QUIC_CLOG
#include "CubicTest.cpp.clog.h"
#endif

extern "C" uint32_t CubeRoot(uint32_t Radicand);

//
// Test: CubeRoot - Integer Cube Root Function
// Parametric test covering perfect cubes, non-perfect cubes (floor behavior),
// boundary values (0, 1, UINT32_MAX), large inputs, and values used by CUBIC's
// KCubic computation.
//
struct CubeRootTestParam {
    uint32_t Input;
    uint32_t Expected;
};

class CubeRootTest : public ::testing::TestWithParam<CubeRootTestParam> {};

TEST_P(CubeRootTest, ReturnsExpectedValue)
{
    auto param = GetParam();
    ASSERT_EQ(CubeRoot(param.Input), param.Expected);
}

INSTANTIATE_TEST_SUITE_P(
    CubeRootCases,
    CubeRootTest,
    ::testing::Values(
        // Boundary values
        CubeRootTestParam{0, 0},
        CubeRootTestParam{1, 1},
        CubeRootTestParam{UINT32_MAX, 1625},
        // Perfect cubes
        CubeRootTestParam{8, 2},
        CubeRootTestParam{27, 3},
        CubeRootTestParam{64, 4},
        CubeRootTestParam{125, 5},
        CubeRootTestParam{1000, 10},
        CubeRootTestParam{4096, 16},
        // Non-perfect cubes: floors to integer cube root
        CubeRootTestParam{2, 1},       // between 1^3 and 2^3
        CubeRootTestParam{7, 1},       // just below 2^3
        CubeRootTestParam{9, 2},       // just above 2^3
        CubeRootTestParam{26, 2},      // just below 3^3
        CubeRootTestParam{100, 4},     // between 4^3(64) and 5^3(125)
        // Large values
        CubeRootTestParam{1000000, 100},
        CubeRootTestParam{1000000000, 1000}
    ));

//
// Helper to create a minimal valid connection for testing CUBIC initialization.
// Uses a real QUIC_CONNECTION structure to ensure proper memory layout when
// QuicCongestionControlGetConnection() does CXPLAT_CONTAINING_RECORD pointer arithmetic.
//
static void InitializeMockConnection(
    QUIC_CONNECTION& Connection,
    uint16_t Mtu)
{
    Connection.Paths[0].Mtu = Mtu;
    Connection.Paths[0].IsActive = TRUE;
    Connection.Send.NextPacketNumber = 0;
    Connection.Settings.PacingEnabled = FALSE;
    Connection.Settings.HyStartEnabled = FALSE;
    Connection.Paths[0].GotFirstRttSample = FALSE;
    Connection.Paths[0].SmoothedRtt = 0;
}

//
// Helper to construct a QUIC_ACK_EVENT with common defaults.
// Fields not specified here (IsImplicit, HasLoss, IsLargestAckedPacketAppLimited,
// AckedPackets) default to 0/FALSE/NULL via {} initialization.
//
static QUIC_ACK_EVENT MakeAckEvent(
    uint64_t TimeNow,
    uint64_t LargestAck,
    uint64_t LargestSentPacketNumber,
    uint32_t BytesAcked,
    uint64_t SmoothedRtt = 50000,
    uint64_t MinRtt = 45000,
    BOOLEAN MinRttValid = TRUE)
{
    QUIC_ACK_EVENT Ack{};
    Ack.TimeNow = TimeNow;
    Ack.LargestAck = LargestAck;
    Ack.LargestSentPacketNumber = LargestSentPacketNumber;
    Ack.NumRetransmittableBytes = BytesAcked;
    Ack.NumTotalAckedRetransmittableBytes = BytesAcked;
    Ack.SmoothedRtt = SmoothedRtt;
    Ack.MinRtt = MinRtt;
    Ack.MinRttValid = MinRttValid;
    Ack.AdjustedAckTime = TimeNow;
    return Ack;
}

//
// Helper to construct a QUIC_LOSS_EVENT with common defaults.
//
static QUIC_LOSS_EVENT MakeLossEvent(
    uint32_t LostBytes,
    uint64_t LargestPacketNumberLost,
    uint64_t LargestSentPacketNumber,
    BOOLEAN PersistentCongestion = FALSE)
{
    QUIC_LOSS_EVENT Loss{};
    Loss.NumRetransmittableBytes = LostBytes;
    Loss.LargestPacketNumberLost = LargestPacketNumberLost;
    Loss.LargestSentPacketNumber = LargestSentPacketNumber;
    Loss.PersistentCongestion = PersistentCongestion;
    return Loss;
}

//
// GoogleTest fixture for CUBIC congestion control tests.
// Provides Connection, Settings, and Cubic members with a parameterized
// InitializeWithDefaults() helper that covers the common setup variations.
//
class CubicTest : public ::testing::Test {
protected:
    static constexpr uint16_t kIPv6UdpOverhead = 48; // IPv6 (40) + UDP (8) header bytes

    // HyStart++ RTT constants for delay increase/decrease detection tests.
    // Activation threshold = kHyStartBaselineRtt + kHyStartBaselineRtt/N_SAMPLING = 45000.
    static constexpr uint64_t kHyStartBaselineRtt = 40000;       // MinRttInLastRound baseline
    static constexpr uint64_t kHyStartRttAboveThreshold = 46000; // > activation threshold (45000)
    static constexpr uint64_t kHyStartRttBelowThreshold = 42000; // < activation threshold (45000)
    static constexpr uint64_t kHyStartRttDecrease = 38000;       // < CssBaselineMinRtt → triggers ACTIVE → NOT_STARTED

    QUIC_CONNECTION Connection{};
    QUIC_SETTINGS_INTERNAL Settings{};
    QUIC_CONGESTION_CONTROL_CUBIC* Cubic;
    QUIC_CONGESTION_CONTROL* CC;

    //
    // Common setup: initializes mock connection, configures settings, and
    // calls CubicCongestionControlInitialize. Covers all recurring variations.
    //
    void InitializeWithDefaults(
        uint32_t WindowPackets = 10,
        bool HyStart = false,
        uint16_t Mtu = 1280,
        uint32_t IdleTimeoutMs = 1000,
        bool GotRttSample = false,
        uint64_t SmoothedRtt = 50000,
        bool SetMinRtt = false,
        uint64_t MinRtt = 40000,
        uint64_t RttVariance = 5000
    )
    {
        Settings.InitialWindowPackets = WindowPackets;
        Settings.SendIdleTimeoutMs = IdleTimeoutMs;
        Settings.HyStartEnabled = HyStart ? TRUE : FALSE;

        InitializeMockConnection(Connection, Mtu);
        Connection.Settings.HyStartEnabled = HyStart ? TRUE : FALSE;
        if (GotRttSample) {
            Connection.Paths[0].GotFirstRttSample = TRUE;
            Connection.Paths[0].SmoothedRtt = SmoothedRtt;
        }
        if (SetMinRtt) {
            Connection.Paths[0].MinRtt = MinRtt;
            Connection.Paths[0].RttVariance = RttVariance;
        }
        CC = &Connection.CongestionControl;
        CubicCongestionControlInitialize(CC, &Settings);
        Cubic = &CC->Cubic;
    }

    void InitializeDefaultWithRtt(uint32_t WindowPackets = 10, bool HyStart = true) {
        InitializeWithDefaults(/*WindowPackets=*/WindowPackets, /*HyStart=*/HyStart, /*Mtu=*/1280, /*IdleTimeoutMs=*/1000, /*GotRttSample=*/true, /*SmoothedRtt=*/50000);
    }

    //
    // Helper to enter congestion avoidance from slow start.
    // Sends full window, triggers loss, sends additional data, then exits
    // recovery via an ACK. After this call:
    //   - IsInRecovery = FALSE, HasHadCongestionEvent = TRUE
    //   - CongestionWindow = SlowStartThreshold = pre-loss window * 7/10
    //   - TimeOfCongAvoidStart = 1050000
    //   - Connection.Send.NextPacketNumber = 15
    // Returns the post-loss CongestionWindow.
    //
    uint32_t EnterCongestionAvoidance(uint32_t LostBytes = 2400) {
        CC->QuicCongestionControlOnDataSent(CC, Cubic->CongestionWindow);
        Connection.Send.NextPacketNumber = 10;

        QUIC_LOSS_EVENT LossEvent = MakeLossEvent(LostBytes, 5, 10);
        CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

        Connection.Send.NextPacketNumber = 15;
        CC->QuicCongestionControlOnDataSent(CC, 5000);

        QUIC_ACK_EVENT ExitAck = MakeAckEvent(1050000, 11, 20, 1200);
        CC->QuicCongestionControlOnDataAcknowledged(CC, &ExitAck);

        return Cubic->CongestionWindow;
    }

    //
    // Helper to transition HyStart++ from NOT_STARTED to ACTIVE state via
    // delay increase detection. Requires InitializeDefaultWithRtt(..., HyStart=true)
    // to have been called first.
    //
    // Mechanism: Sets MinRttInLastRound to kHyStartBaselineRtt, then sends
    // N_SAMPLING (8) ACKs with MinRtt=kHyStartRttAboveThreshold to complete
    // sampling. The 9th ACK triggers delay increase detection because
    // MinRttInCurrentRound >= kHyStartBaselineRtt + Eta (= activation threshold).
    //
    // After this call:
    //   - HyStartState = HYSTART_ACTIVE
    //   - CWndSlowStartGrowthDivisor = 4
    //   - ConservativeSlowStartRounds = 5 (QUIC_CONSERVATIVE_SLOW_START_DEFAULT_ROUNDS)
    //   - CssBaselineMinRtt = kHyStartRttAboveThreshold
    //   - MinRttInLastRound = kHyStartBaselineRtt
    //   - Connection.Send.NextPacketNumber = 100, HyStartRoundEnd = 100
    //
    void EnterHyStartActive() {
        Connection.Send.NextPacketNumber = 100;
        Cubic->HyStartRoundEnd = 100;
        Cubic->MinRttInLastRound = kHyStartBaselineRtt;

        for (uint32_t i = 0; i < QUIC_HYSTART_DEFAULT_N_SAMPLING; i++) {
            CC->QuicCongestionControlOnDataSent(CC, 1200);
            QUIC_ACK_EVENT AckEvent = MakeAckEvent(
                1000000 + (i * 10000), 10 + i, 15 + i, 1200,
                50000, kHyStartRttAboveThreshold);
            CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);
        }

        CC->QuicCongestionControlOnDataSent(CC, 1200);
        QUIC_ACK_EVENT TriggerAck = MakeAckEvent(1100000, 20, 25, 1200, 50000, kHyStartRttAboveThreshold + 1000);
        CC->QuicCongestionControlOnDataAcknowledged(CC, &TriggerAck);
    }
};

//====================================================================
//
//  Specification-conformance tests
//
//  These tests validate behavior defined by RFC 8312 (CUBIC),
//  RFC 9002 (QUIC Loss Detection), and RFC 9406 (HyStart++).
//  They would remain valid across any conforming implementation.
//
//  References:
//    https://www.rfc-editor.org/rfc/rfc8312
//    https://www.rfc-editor.org/rfc/rfc9002
//    https://www.rfc-editor.org/rfc/rfc9406
//
//====================================================================

//
// Test: OnDataAcknowledged - Basic ACK Processing in Slow Start
// Scenario: Tests CubicCongestionControlOnDataAcknowledged for basic slow-start
// window growth. Sends data via OnDataSent (properly tracking BytesInFlightMax),
// then acknowledges a portion. The window should grow by BytesAcked since we are
// in slow start (CongestionWindow < SlowStartThreshold) with HyStart disabled
// (CWndSlowStartGrowthDivisor = 1).
//
TEST_F(CubicTest, OnDataAcknowledged_BasicAck)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ false);

    uint32_t InitialWindow = Cubic->CongestionWindow;

    // Send data via OnDataSent to properly track BytesInFlightMax.
    // Must send enough that BytesInFlightMax > (InitialWindow + BytesAcked) / 2
    // to avoid the 2*BytesInFlightMax clamping guard.
    uint32_t BytesSent = 10000;
    CC->QuicCongestionControlOnDataSent(CC, BytesSent);

    uint32_t BytesAcked = 5000;
    QUIC_ACK_EVENT AckEvent = MakeAckEvent(1050000, 5, 10, BytesAcked);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

    // Slow start growth: window increases by BytesAcked (divisor=1, HyStart disabled)
    // NewWindow = 12320 + 5000 = 17320, clamped by 2*BytesInFlightMax = 2*10000 = 20000 (no clamp)
    ASSERT_EQ(Cubic->CongestionWindow, InitialWindow + BytesAcked);
    ASSERT_EQ(Cubic->BytesInFlight, BytesSent - BytesAcked);
}

//
// Test: OnDataLost - Packet Loss Handling and Window Reduction
// Scenario: Tests CUBIC's response to packet loss. When packets are declared lost,
// the congestion window should be reduced by beta (0.7) and the connection enters
// recovery. Verifies window reduction, threshold update, and recovery state flags.
//
TEST_F(CubicTest, OnDataLost_WindowReduction)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20, /*HyStart = */ true);
    uint32_t InitialWindow = Cubic->CongestionWindow;

    // Send data via OnDataSent to properly track BytesInFlightMax
    CC->QuicCongestionControlOnDataSent(CC, 10000);

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(3600, 10, 15);

    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    // Verify window was reduced (CUBIC multiplicative decrease)
    // New window = InitialWindow * 0.7 = InitialWindow * 7 / 10
    // InitialWindow = (1280 - 48) * 20 = 24640 (IPv6 formula: MTU - 40 - 8)
    // Expected = 24640 * 7 / 10 = 17248
    uint32_t ExpectedWindow = InitialWindow * 7 / 10;
    ASSERT_EQ(Cubic->CongestionWindow, ExpectedWindow);
    ASSERT_EQ(Cubic->SlowStartThreshold, ExpectedWindow);

    // Verify recovery state transitions
    ASSERT_TRUE(Cubic->IsInRecovery);
    ASSERT_TRUE(Cubic->HasHadCongestionEvent);
}

//
// Test: OnEcn - ECN Marking Handling
// Scenario: Tests Explicit Congestion Notification (ECN) handling. When ECN-marked packets
// are received, CUBIC should treat it as a congestion signal and reduce the window.
// Unlike loss, ECN does NOT save previous state (`if (!Ecn)` guard),
// so spurious congestion rollback cannot undo an ECN event.
//
TEST_F(CubicTest, OnEcn_CongestionSignal)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20, /*HyStart = */ true);
    uint32_t InitialWindow = Cubic->CongestionWindow;

    // Send data via OnDataSent to properly track BytesInFlightMax
    CC->QuicCongestionControlOnDataSent(CC, 10000);

    QUIC_ECN_EVENT EcnEvent{};
    EcnEvent.LargestPacketNumberAcked = 10;
    EcnEvent.LargestSentPacketNumber = 15;

    CC->QuicCongestionControlOnEcn(CC, &EcnEvent);

    // Verify window was reduced due to ECN congestion signal (same as loss: 0.7x)
    // InitialWindow = (1280 - 48) * 20 = 24640 (IPv6 formula: MTU - 40 - 8)
    // Expected = 24640 * 7 / 10 = 17248
    uint32_t ExpectedWindow = InitialWindow * 7 / 10;
    ASSERT_EQ(Cubic->CongestionWindow, ExpectedWindow);

    // Verify recovery state transitions
    ASSERT_TRUE(Cubic->IsInRecovery);
    ASSERT_TRUE(Cubic->HasHadCongestionEvent);
}

//
// Test: Fast Convergence - Window Reduction Path
// Scenario: Tests CUBIC's fast convergence algorithm. When a new congestion event occurs
// before reaching the previous WindowMax, CUBIC applies an additional reduction factor
// to converge faster with other flows. This tests the WindowLastMax > WindowMax path.
//
TEST_F(CubicTest, FastConvergence_AdditionalReduction)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 30, /*HyStart = */ true);

    // Simulate first congestion event to establish WindowMax
    // Send data to fill the window
    uint32_t InitialWindow = Cubic->CongestionWindow;
    CC->QuicCongestionControlOnDataSent(CC, InitialWindow);

    // Trigger first loss event
    QUIC_LOSS_EVENT FirstLoss = MakeLossEvent(3000, 5, 10);

    CC->QuicCongestionControlOnDataLost(CC, &FirstLoss);

    // ACK while still in recovery (LargestAck == RecoverySentPacketNumber, so
    // recovery doesn't exit). Window stays at post-loss value.
    QUIC_ACK_EVENT AckEvent = MakeAckEvent(1000000, 10, 15, 5000);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

    // Send more data
    CC->QuicCongestionControlOnDataSent(CC, 3000);

    // Trigger second loss event (before reaching previous WindowMax)
    // Must use LargestPacketNumberLost > RecoverySentPacketNumber (which is 10 from first loss)
    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(3000, 15, 20);

    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    // Fast convergence fires on the second loss because WindowLastMax (36960, set
    // during first loss) > WindowMax (25872, the current CW at second loss entry).
    // The code sets WindowLastMax = WindowMax = 25872, then applies:
    //   WindowMax = WindowMax * (10 + BETA) / 20 = 25872 * 17 / 20 = 21991
    uint32_t WindowAfterFirstLoss = InitialWindow * 7 / 10;  // 25872
    uint32_t ExpectedWindowMax = WindowAfterFirstLoss * 17 / 20;  // 21991
    ASSERT_EQ(Cubic->WindowMax, ExpectedWindowMax);
}

//
// Test: Recovery Exit Path
// Scenario: Tests exiting from recovery state when an ACK is received for a packet
// sent after recovery started (LargestAck > RecoverySentPacketNumber). Uses a
// non-persistent loss to enter recovery cleanly.
//
TEST_F(CubicTest, Recovery_ExitOnNewAck)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);

    // Enter recovery via non-persistent loss
    CC->QuicCongestionControlOnDataSent(CC, 5000);
    Connection.Send.NextPacketNumber = 10;

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(1200, 8, 10);

    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    // Now in recovery state
    ASSERT_TRUE(Cubic->IsInRecovery);
    ASSERT_FALSE(Cubic->IsInPersistentCongestion);

    // Send new packet after recovery started
    Connection.Send.NextPacketNumber = 15;

    QUIC_ACK_EVENT AckEvent = MakeAckEvent(1000000, 15, 20, 1200);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

    // Should exit recovery
    ASSERT_FALSE(Cubic->IsInRecovery);
    ASSERT_FALSE(Cubic->IsInPersistentCongestion);
}

//
// Test: ACK During Recovery Stays in Recovery
// Scenario: When an ACK is received with LargestAck <= RecoverySentPacketNumber,
// the connection remains in recovery. Only an ACK for a packet sent after
// recovery started (LargestAck > RecoverySentPacketNumber) exits recovery.
//
TEST_F(CubicTest, Recovery_StayOnOldAck)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20, /*HyStart = */ false);

    CC->QuicCongestionControlOnDataSent(CC, 5000);
    Connection.Send.NextPacketNumber = 10;

    // Enter recovery via loss. RecoverySentPacketNumber = 10.
    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(1200, 5, 10);
    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    ASSERT_TRUE(Cubic->IsInRecovery);
    uint32_t WindowInRecovery = Cubic->CongestionWindow;

    // ACK with LargestAck == RecoverySentPacketNumber (10): should stay in recovery
    QUIC_ACK_EVENT StayAck = MakeAckEvent(1050000, 10, 15, 1200);
    CC->QuicCongestionControlOnDataAcknowledged(CC, &StayAck);

    ASSERT_TRUE(Cubic->IsInRecovery);
    // Window should not grow during recovery (goes to Exit label)
    ASSERT_EQ(Cubic->CongestionWindow, WindowInRecovery);

    // ACK with LargestAck < RecoverySentPacketNumber (8): also stays
    QUIC_ACK_EVENT OlderAck = MakeAckEvent(1060000, 8, 15, 600);
    CC->QuicCongestionControlOnDataAcknowledged(CC, &OlderAck);

    ASSERT_TRUE(Cubic->IsInRecovery);
    ASSERT_EQ(Cubic->CongestionWindow, WindowInRecovery);

    // ACK with LargestAck > RecoverySentPacketNumber: exits recovery
    Connection.Send.NextPacketNumber = 20;
    QUIC_ACK_EVENT ExitAck = MakeAckEvent(1100000, 11, 25, 600);
    CC->QuicCongestionControlOnDataAcknowledged(CC, &ExitAck);

    ASSERT_FALSE(Cubic->IsInRecovery);
}

//
// Test: Double Loss During Recovery - No Additional Window Reduction
// Scenario: When a second loss occurs during recovery with LargestPacketNumberLost
// <= RecoverySentPacketNumber, the guard at cubic.c prevents a second window
// reduction. Only BytesInFlight is decremented; the congestion window stays at
// its post-first-loss value.
//
TEST_F(CubicTest, Recovery_DoubleLossNoDoubleReduction)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20, /*HyStart = */ false);

    CC->QuicCongestionControlOnDataSent(CC, 10000);
    Connection.Send.NextPacketNumber = 10;

    // First loss: enters recovery, reduces window
    QUIC_LOSS_EVENT FirstLoss = MakeLossEvent(1200, 5, 10);
    CC->QuicCongestionControlOnDataLost(CC, &FirstLoss);

    ASSERT_TRUE(Cubic->IsInRecovery);
    uint32_t WindowAfterFirstLoss = Cubic->CongestionWindow;
    uint32_t BytesInFlightAfterFirstLoss = Cubic->BytesInFlight;

    // Second loss during recovery: LargestPacketNumberLost (8) <= RecoverySentPacketNumber (10)
    // Guard prevents window reduction; only BytesInFlight decreases.
    uint32_t SecondLostBytes = 600;
    QUIC_LOSS_EVENT SecondLoss = MakeLossEvent(SecondLostBytes, 8, 10);
    CC->QuicCongestionControlOnDataLost(CC, &SecondLoss);

    ASSERT_TRUE(Cubic->IsInRecovery);
    ASSERT_EQ(Cubic->CongestionWindow, WindowAfterFirstLoss);
    ASSERT_EQ(Cubic->BytesInFlight, BytesInFlightAfterFirstLoss - SecondLostBytes);
}

//
// Test: Minimum Window Floor After Loss
// Scenario: When the congestion window is very small and loss occurs, the
// multiplicative decrease (CW * 0.7) would produce a value below the minimum
// window (2 * DatagramPayloadLength). The CXPLAT_MAX guard ensures the window
// never drops below this floor.
//
TEST_F(CubicTest, MinimumWindowFloor_AfterLoss)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 2, /*HyStart = */ false);
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);
    uint32_t InitialWindow = Cubic->CongestionWindow;
    // CW = 2 * 1232 = 2464. CW * 7/10 = 1724.
    // MinimumWindow = 2 * 1232 = 2464. 1724 < 2464 → floor kicks in.
    ASSERT_EQ(InitialWindow, (uint32_t)DatagramPayloadLength * 2);

    CC->QuicCongestionControlOnDataSent(CC, 1200);
    Connection.Send.NextPacketNumber = 10;

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(600, 5, 10);
    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    // Window should be clamped to the minimum, not the 0.7× value
    uint32_t MinimumWindow = DatagramPayloadLength * QUIC_PERSISTENT_CONGESTION_WINDOW_PACKETS;
    uint32_t BetaReduced = InitialWindow * 7 / 10;
    ASSERT_LT(BetaReduced, MinimumWindow); // Verify floor actually matters
    ASSERT_EQ(Cubic->CongestionWindow, MinimumWindow);
    ASSERT_EQ(Cubic->SlowStartThreshold, MinimumWindow);
}

//
// Test: Slow Start 2×BytesInFlightMax Clamp
// Scenario: When slow start grows the congestion window beyond 2×BytesInFlightMax,
// the window is clamped to prevent growth without network feedback. This fires
// when the application doesn't fully utilize the window (BytesInFlightMax stays
// small relative to CW).
//
TEST_F(CubicTest, SlowStart_BytesInFlightMaxClamp)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ false);
    uint32_t InitialWindow = Cubic->CongestionWindow; // 12320

    // Artificially lower BytesInFlightMax to simulate app-limited sending
    Cubic->BytesInFlightMax = 2000;

    // Send and ACK 1200 bytes. BytesInFlight peaks at 1200 < 2000 so max unchanged.
    CC->QuicCongestionControlOnDataSent(CC, 1200);

    QUIC_ACK_EVENT AckEvent = MakeAckEvent(1050000, 5, 10, 1200);
    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

    // Slow start growth: CW = 12320 + 1200 = 13520, but 2*BytesInFlightMax = 4000.
    // Since 13520 > 4000, CW is clamped to 4000.
    ASSERT_EQ(Cubic->CongestionWindow, 2 * 2000u);
    ASSERT_LT(Cubic->CongestionWindow, InitialWindow + 1200);
}

//
// Test: Congestion Avoidance AIMD vs CUBIC Window Selection
// Scenario: After loss triggers recovery and an ACK exits recovery, a subsequent
// ACK in congestion avoidance exercises the CUBIC formula and AIMD accumulator.
// The max(CUBIC, AIMD) selection determines the new window.
//
TEST_F(CubicTest, CongestionAvoidance_AIMDvsCubicSelection)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);

    EnterCongestionAvoidance();

    // ACK in congestion avoidance: CUBIC/AIMD selection runs
    CC->QuicCongestionControlOnDataSent(CC, 3000);

    QUIC_ACK_EVENT CongAvoidAck = MakeAckEvent(1100000, 15, 25, 1200);

    uint32_t WindowBeforeCongAvoid = Cubic->CongestionWindow;

    CC->QuicCongestionControlOnDataAcknowledged(CC, &CongAvoidAck);

    // Congestion avoidance ran: CW >= SSThresh so slow start is skipped,
    // CUBIC formula and AIMD both execute, max() selects the winner.
    ASSERT_FALSE(Cubic->IsInRecovery);

    // Reproduce the CUBIC window formula using state already computed by the
    // production code during EnterCongestionAvoidance (KCubic, WindowMax, etc.).
    uint32_t KCubic = Cubic->KCubic;     // Computed by production code on loss
    uint32_t WindowMax = Cubic->WindowMax;

    uint64_t TimeInCongAvoidUs = CongAvoidAck.TimeNow - Cubic->TimeOfCongAvoidStart;
    int64_t DeltaT =
        ((int64_t)TimeInCongAvoidUs -
         (int64_t)KCubic * 1000 +     // MS_TO_US
         (int64_t)CongAvoidAck.SmoothedRtt) / 1000; // US_TO_MS

    int64_t CubicWindow =
        ((((DeltaT * DeltaT) >> 10) * DeltaT *
         (int64_t)(DatagramPayloadLength * 4 / 10)) >> 20) +
        (int64_t)WindowMax;

    // CUBIC > AIMD → bounded growth path selected
    ASSERT_GT(CubicWindow, (int64_t)Cubic->AimdWindow);

    uint64_t TargetWindow = CXPLAT_MAX(
        WindowBeforeCongAvoid,
        CXPLAT_MIN((uint64_t)CubicWindow, (uint64_t)WindowBeforeCongAvoid + (WindowBeforeCongAvoid >> 1)));
    uint32_t ExpectedGrowth =
        (uint32_t)(((TargetWindow - WindowBeforeCongAvoid) * DatagramPayloadLength) / WindowBeforeCongAvoid);

    ASSERT_GT(Cubic->CongestionWindow, WindowBeforeCongAvoid);
    ASSERT_EQ(Cubic->CongestionWindow, WindowBeforeCongAvoid + ExpectedGrowth);
}

//
// Test: AIMD Sequential Linear Convergence
// Scenario: Verifies that multiple sequential ACKs produce linear AIMD window
// growth across several rounds. After entering congestion avoidance with
// AimdWindow >= WindowPrior (full-rate accumulation), each ACK of BytesAcked
// bytes adds BytesAcked to AimdAccumulator. When AimdAccumulator exceeds
// AimdWindow, the window grows by 1 DatagramPayloadLength and the accumulator
// wraps by subtracting the new AimdWindow. Over N ACKs, AimdWindow should
// grow by exactly floor(totalBytesAcked / averageAimdWindow) * DPL,
// demonstrating the linear AIMD convergence required by RFC 8312 §4.3.
//
TEST_F(CubicTest, AIMD_SequentialLinearConvergence)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);

    EnterCongestionAvoidance();

    // Set up for full-rate AIMD (AimdWindow >= WindowPrior).
    // Use a small AimdWindow so each ACK triggers exactly one growth.
    // BytesAcked per ACK = AimdWindow + DPL + 100 ensures:
    //   1. Accumulator exceeds AimdWindow → triggers growth
    //   2. Remainder is small → no double-growth in a single ACK
    uint32_t InitialAimdWindow = 1000;
    Cubic->AimdWindow = InitialAimdWindow;
    Cubic->WindowPrior = InitialAimdWindow; // full-rate path
    Cubic->AimdAccumulator = 0;

    // Send data to cover upcoming ACKs
    CC->QuicCongestionControlOnDataSent(CC, 20000);

    // Track expected state manually across multiple ACKs
    uint32_t ExpectedAimdWindow = InitialAimdWindow;
    uint32_t ExpectedAccumulator = 0;
    uint64_t TimeUs = 1100000;
    uint32_t PacketNum = 21;

    const int NumAcks = 5;
    for (int i = 0; i < NumAcks; i++) {
        uint32_t BytesAcked = ExpectedAimdWindow + DatagramPayloadLength + 100;

        QUIC_ACK_EVENT Ack = MakeAckEvent(TimeUs, PacketNum, PacketNum + 1, BytesAcked);
        CC->QuicCongestionControlOnDataAcknowledged(CC, &Ack);

        // Full-rate: accumulator += BytesAcked
        ExpectedAccumulator += BytesAcked;
        // Accumulator exceeds AimdWindow → grow by 1 DPL
        ExpectedAimdWindow += DatagramPayloadLength;
        ExpectedAccumulator -= ExpectedAimdWindow;

        ASSERT_EQ(Cubic->AimdWindow, ExpectedAimdWindow)
            << "AimdWindow mismatch after ACK " << (i + 1);
        ASSERT_EQ(Cubic->AimdAccumulator, ExpectedAccumulator)
            << "AimdAccumulator mismatch after ACK " << (i + 1);

        TimeUs += 50000; // advance 50ms per ACK
        PacketNum += 2;
    }

    // After 5 ACKs, AimdWindow should have grown by exactly 5 * DPL
    ASSERT_EQ(Cubic->AimdWindow, InitialAimdWindow + NumAcks * DatagramPayloadLength);
}

//
// Test: Reno-Friendly Region (CW = AimdWindow path)
// Scenario: After a loss with a small initial window (3 packets), a large ACK
// in congestion avoidance grows AimdWindow past CubicWindow via the AIMD
// accumulator. Since AimdWindow > CubicWindow, the Reno-friendly region
// CW is set to AimdWindow directly, instead of using the
// bounded growth formula from the concave/convex region.
//
TEST_F(CubicTest, CongestionAvoidance_RenoFriendlyRegion)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 3, /*HyStart = */ false);
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);

    uint32_t WindowAfterLoss = EnterCongestionAvoidance(/*LostBytes=*/1200);

    // Large ACK in congestion avoidance.
    // BytesAcked=10000 grows AimdAccumulator by 5000 (half-rate: AimdWindow < WindowPrior).
    // 5000 > AimdWindow(2587) → AimdWindow += 1232 = 3819, accumulator = 5000 - 3819 = 1181.
    //
    // KCubic = CubeRoot((3696/1232 * 3 << 9) / 4) = CubeRoot(1152) = 10
    // KCubic = S_TO_MS(10) = 10000; >>3 = 1250
    // TimeInCongAvoid = 1051000 - 1050000 = 1000 µs
    // DeltaT = US_TO_MS(1000 - 1250000 + 50000) = -1199
    // CubicWindow = ((-1199²>>10) * -1199 * 492 >> 20) + 3696 = -790 + 3696 = 2906
    //
    // AimdWindow(3819) > CubicWindow(2906) → Reno-friendly region: CW = AimdWindow
    CC->QuicCongestionControlOnDataSent(CC, 10000);

    QUIC_ACK_EVENT CongAvoidAck = MakeAckEvent(1051000, 21, 25, 10000);
    CC->QuicCongestionControlOnDataAcknowledged(CC, &CongAvoidAck);

    // Verify CW was set from AimdWindow (Reno-friendly), not bounded growth.
    uint32_t ExpectedAimdWindow = WindowAfterLoss + DatagramPayloadLength; // 2587 + 1232 = 3819
    ASSERT_EQ(Cubic->AimdWindow, ExpectedAimdWindow);
    ASSERT_EQ(Cubic->CongestionWindow, ExpectedAimdWindow);
}

//
// Test: Congestion Avoidance - Bounded Growth Clamp
// Scenario: When the CUBIC formula produces a window far exceeding the current
// CongestionWindow (e.g., due to large DeltaT with KCubic=0), the bounded
// growth clamp constrains TargetWindow to at most 1.5×CW.
// This prevents unrealistic single-ACK window jumps. The growth per ACK is
// then (TargetWindow - CW) * DatagramPayloadLength / CW.
//
TEST_F(CubicTest, CongestionAvoidance_BoundedGrowthClamp)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ false);
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);

    // Force into congestion avoidance
    uint32_t CW = 20000;
    Cubic->SlowStartThreshold = 10000;
    Cubic->CongestionWindow = CW;

    // Set WindowMax to maximum value. With KCubic=0 and long TimeInCongAvoid,
    // DeltaT is capped to 2.5M, producing a huge positive
    // CubicWindow. The bounded growth clamp limits TargetWindow to 1.5*CW.
    Cubic->WindowMax = UINT32_MAX;
    Cubic->BytesInFlightMax = 50000;

    uint64_t TimeNowUs = 30000000000ULL; // 30000 seconds
    Cubic->TimeOfCongAvoidStart = 1000000;
    Cubic->KCubic = 0;
    Cubic->TimeOfLastAckValid = TRUE;
    Cubic->TimeOfLastAck = TimeNowUs - 100000;

    uint32_t BytesToSend = 1200;
    CC->QuicCongestionControlOnDataSent(CC, BytesToSend);

    QUIC_ACK_EVENT AckEvent = MakeAckEvent(TimeNowUs, 10, 15, BytesToSend, 50000, 45000, FALSE);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

    // CubicWindow is huge positive (DeltaT³ term dominates), exceeding 1.5*CW.
    // Bounded growth clamp: TargetWindow = max(CW, min(CubicWindow, CW + CW/2))
    //                     = max(20000, min(huge, 30000)) = 30000
    // Growth = (TargetWindow - CW) * DatagramPayloadLength / CW
    //        = (30000 - 20000) * 1232 / 20000 = 616
    // NewCW = 20000 + 616 = 20616
    uint32_t TargetWindow = CW + CW / 2;
    uint32_t ExpectedGrowth = (uint32_t)(((uint64_t)(TargetWindow - CW) * DatagramPayloadLength) / CW);
    ASSERT_EQ(Cubic->CongestionWindow, CW + ExpectedGrowth);
}

//
// Test: Spurious Congestion Event Rollback
// Scenario: Tests the spurious congestion event handling. When a congestion event
// is determined to be spurious (false positive), CUBIC should restore the previous
// state before the congestion event occurred.
//
TEST_F(CubicTest, SpuriousCongestion_StateRollback)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);
    uint32_t InitialWindow = DatagramPayloadLength * Settings.InitialWindowPackets;

    // Trigger a congestion event first
    CC->QuicCongestionControlOnDataSent(CC, 10000);
    uint32_t WindowBeforeLoss = Cubic->CongestionWindow;
    ASSERT_EQ(WindowBeforeLoss, InitialWindow);
    Connection.Send.NextPacketNumber = 15;

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(2400, 10, 15);

    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    // After loss: Window = InitialWindow * 7 / 10
    uint32_t ExpectedWindowAfterLoss = WindowBeforeLoss * 7 / 10;
    uint32_t WindowAfterLoss = Cubic->CongestionWindow;
    ASSERT_EQ(WindowAfterLoss, ExpectedWindowAfterLoss);

    // Now declare it spurious — returns TRUE if blocked state changed
    BOOLEAN SpuriousResult = CC->QuicCongestionControlOnSpuriousCongestionEvent(CC);

    // State should be restored
    ASSERT_EQ(Cubic->CongestionWindow, WindowBeforeLoss);
    ASSERT_FALSE(Cubic->IsInRecovery);
    ASSERT_FALSE(Cubic->HasHadCongestionEvent);
    // Before rollback: CanSend = TRUE (BIF=7600 < CW=17248).
    // After rollback: CanSend = TRUE (BIF=7600 < CW=24640). No state change → FALSE.
    ASSERT_FALSE(SpuriousResult);
}

// ==========================================================================================================================================
// HyStart++ State Transition Tests
//
// State Transition Table
// | From State          | To State            | Condition                                | Tested By                                       |
// |---------------------|---------------------|------------------------------------------|-------------------------------------------------|
// | HYSTART_NOT_STARTED | HYSTART_ACTIVE      | RTT increase detected (delay increase)   | DelayIncreaseDetection_TriggerActiveTransition  |
// | HYSTART_NOT_STARTED | HYSTART_DONE        | Loss, ECN, or persistent congestion      | NotStartedToDone_ViaLoss, _ViaECN,              |
// |                     |                     |                                          | AnyToDone_ViaPersistentCongestion               |
// | HYSTART_ACTIVE      | HYSTART_DONE        | Conservative slow start rounds completed | ConservativeSlowStartRounds_TransitionToDone    |
// | HYSTART_ACTIVE      | HYSTART_DONE        | Loss, ECN, or persistent congestion      | ActiveToDone_ViaLoss, _ViaECN                   |
// | HYSTART_ACTIVE      | HYSTART_NOT_STARTED | RTT decrease detected (spurious exit)    | RttDecreaseDetection_ReturnToNotStarted         |
// | HYSTART_DONE        | (no transitions)    | Terminal / absorbing state               | TerminalState_DoneIsAbsorbing                   |
// ==========================================================================================================================================
//

//
// Test: HyStart++ NOT_STARTED → DONE via Loss
// Scenario: Tests direct transition from NOT_STARTED to DONE when packet loss
// occurs before HyStart++ detection logic activates. Window reduction mechanics
// are verified by OnDataLost_WindowReduction; this test focuses on state transition.
//
TEST_F(CubicTest, HyStart_NotStartedToDone_ViaLoss)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);
    // Precondition: Verify in NOT_STARTED state
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);

    // Send data to have bytes in flight
    CC->QuicCongestionControlOnDataSent(CC, 8000);
    Connection.Send.NextPacketNumber = 10;

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(2400, 5, 10);
    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 1u);
}

//
// Test: HyStart++ NOT_STARTED → DONE via ECN
// Scenario: Tests direct transition from NOT_STARTED to DONE when ECN marking
// is received. Window reduction mechanics are verified by OnEcn_CongestionSignal;
// this test focuses on state transition.
//
TEST_F(CubicTest, HyStart_NotStartedToDone_ViaECN)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);
    // Precondition: Verify in NOT_STARTED state
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);

    // Send data
    CC->QuicCongestionControlOnDataSent(CC, 8000);
    Connection.Send.NextPacketNumber = 15;

    QUIC_ECN_EVENT EcnEvent{};
    EcnEvent.LargestPacketNumberAcked = 10;
    EcnEvent.LargestSentPacketNumber = 15;

    CC->QuicCongestionControlOnEcn(CC, &EcnEvent);

    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 1u);
}

//
// Test: HyStart++ ACTIVE → DONE via Loss
// Scenario: Tests transition from ACTIVE to DONE when loss occurs during
// conservative slow start. This is a different entry point than
// NOT_STARTED → DONE and verifies the CWndSlowStartGrowthDivisor is
// reset from 4 back to 1.
//
TEST_F(CubicTest, HyStart_ActiveToDone_ViaLoss)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);

    EnterHyStartActive();
    ASSERT_EQ(Cubic->HyStartState, HYSTART_ACTIVE);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 4u);

    // Trigger loss while in ACTIVE state
    CC->QuicCongestionControlOnDataSent(CC, 5000);
    Connection.Send.NextPacketNumber = 30;

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(2400, 25, 30);
    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    // Should transition ACTIVE → DONE
    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 1u); // Reset from 4 to 1
    ASSERT_TRUE(Cubic->IsInRecovery);
    ASSERT_TRUE(Cubic->HasHadCongestionEvent);
}

//
// Test: HyStart++ ACTIVE → DONE via ECN
// Scenario: Same as ACTIVE → DONE via Loss, but triggered by an ECN
// congestion signal.
//
TEST_F(CubicTest, HyStart_ActiveToDone_ViaECN)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);

    EnterHyStartActive();
    ASSERT_EQ(Cubic->HyStartState, HYSTART_ACTIVE);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 4u);

    // Trigger ECN while in ACTIVE state
    Connection.Send.NextPacketNumber = 30;

    QUIC_ECN_EVENT EcnEvent{};
    EcnEvent.LargestPacketNumberAcked = 25;
    EcnEvent.LargestSentPacketNumber = 30;

    CC->QuicCongestionControlOnEcn(CC, &EcnEvent);

    // Should transition ACTIVE → DONE
    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 1u); // Reset from 4 to 1
    ASSERT_TRUE(Cubic->IsInRecovery);
}

//
// Test: HyStart++ Any State → DONE via Persistent Congestion
// Scenario: Tests transition from any state to DONE when persistent congestion
// is detected. This is the most severe congestion signal, causing drastic
// window reduction to minimum (2 packets).
//
TEST_F(CubicTest, HyStart_AnyToDone_ViaPersistentCongestion)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 30, /*HyStart = */ true);
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);
    // Precondition: Can be in any state (we'll test from NOT_STARTED)
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    // Send data
    CC->QuicCongestionControlOnDataSent(CC, 15000);
    Connection.Send.NextPacketNumber = 20;

    // Trigger persistent congestion
    QUIC_LOSS_EVENT PersistentLoss = MakeLossEvent(8000, 15, 20, TRUE);

    CC->QuicCongestionControlOnDataLost(CC, &PersistentLoss);

    // Postcondition: Drastic reduction to minimum window
    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
    ASSERT_TRUE(Cubic->IsInPersistentCongestion);
    ASSERT_TRUE(Cubic->IsInRecovery);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 1u);

    // Window should be reduced to minimum (2 packets)
    uint32_t ExpectedMinWindow = DatagramPayloadLength * QUIC_PERSISTENT_CONGESTION_WINDOW_PACKETS;
    ASSERT_EQ(Cubic->CongestionWindow, ExpectedMinWindow);
}

//
// Test: HyStart++ Terminal State - DONE is Absorbing
// Scenario: Once in DONE, neither ACK-based detection nor loss/ECN events can
// change the state. Two focused patterns cover both code paths.
//
TEST_F(CubicTest, HyStart_TerminalState_DoneIsAbsorbing)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);

    // Transition to DONE state via loss
    CC->QuicCongestionControlOnDataSent(CC, 5000);
    Connection.Send.NextPacketNumber = 10;

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(2400, 5, 10);
    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);
    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);

    // Exit recovery to enable ACK processing
    Connection.Send.NextPacketNumber = 20;
    QUIC_ACK_EVENT RecoveryExitAck = MakeAckEvent(1500000, 20, 25, 0, 50000, 48000);
    CC->QuicCongestionControlOnDataAcknowledged(CC, &RecoveryExitAck);
    ASSERT_FALSE(Cubic->IsInRecovery);

    // Pattern 1: ACK with high RTT (would trigger NOT_STARTED → ACTIVE if not in DONE)
    CC->QuicCongestionControlOnDataSent(CC, 1200);
    QUIC_ACK_EVENT HighRttAck = MakeAckEvent(2000000, 25, 30, 1200, 50000, kHyStartRttAboveThreshold);
    CC->QuicCongestionControlOnDataAcknowledged(CC, &HighRttAck);
    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);

    // Pattern 2: Another loss (would transition non-DONE states)
    CC->QuicCongestionControlOnDataSent(CC, 3000);
    Connection.Send.NextPacketNumber = 40;
    QUIC_LOSS_EVENT SecondLoss = MakeLossEvent(1200, 35, 40);
    CC->QuicCongestionControlOnDataLost(CC, &SecondLoss);
    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
}

//
// Test: HyStart++ Delay Increase Detection - Trigger ACTIVE Transition
// Scenario: Triggers the delay increase detection logic with
// a significant RTT increase that causes transition from NOT_STARTED to ACTIVE state.
//
TEST_F(CubicTest, HyStart_DelayIncreaseDetection_TriggerActiveTransition)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);
    // Verify initial state
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    EnterHyStartActive();

    // Verify all state changes from the NOT_STARTED → ACTIVE transition
    ASSERT_EQ(Cubic->HyStartState, HYSTART_ACTIVE);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 4u); // QUIC_CONSERVATIVE_SLOW_START_DEFAULT_GROWTH_DIVISOR
    ASSERT_EQ(Cubic->ConservativeSlowStartRounds, 5u); // QUIC_CONSERVATIVE_SLOW_START_DEFAULT_ROUNDS
    ASSERT_EQ(Cubic->CssBaselineMinRtt, kHyStartRttAboveThreshold); // Set to MinRttInCurrentRound
}

//
// Test: HyStart++ RTT Decrease Detection - Return to NOT_STARTED
// Scenario: Covers the RTT decrease detection logic.
// When in HYSTART_ACTIVE state, if RTT decreases below the baseline, the algorithm
// assumes the previous slow start exit was spurious and returns to NOT_STARTED state.
//
TEST_F(CubicTest, HyStart_RttDecreaseDetection_ReturnToNotStarted)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);
    // Verify initial state
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    EnterHyStartActive();
    ASSERT_EQ(Cubic->HyStartState, HYSTART_ACTIVE);

    // Cross a round boundary to reset HyStartAckCount
    // This will move MinRttInCurrentRound to MinRttInLastRound
    // and reset MinRttInCurrentRound to UINT64_MAX for new sampling
    {
        // Update NextPacketNumber so HyStartRoundEnd will be set to a high value
        Connection.Send.NextPacketNumber = 200;

        uint32_t BytesToSend = 1200;
        CC->QuicCongestionControlOnDataSent(CC, BytesToSend);

        QUIC_ACK_EVENT AckEvent = MakeAckEvent(1200000, 100, 105, BytesToSend, 50000, kHyStartRttAboveThreshold);

        CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

        // Still in HYSTART_ACTIVE, but round has been reset
        // HyStartRoundEnd should now be 200
        ASSERT_EQ(Cubic->HyStartState, HYSTART_ACTIVE);
        ASSERT_EQ(Cubic->HyStartAckCount, 0u); // Reset by round boundary crossing
        ASSERT_EQ(Cubic->MinRttInLastRound, kHyStartRttAboveThreshold); // Moved from current round
        ASSERT_EQ(Cubic->MinRttInCurrentRound, UINT64_MAX); // Reset for new round
        ASSERT_EQ(Cubic->HyStartRoundEnd, 200u); // Set to NextPacketNumber
    }

    // Phase 4: Collect samples in new round with LOWER RTT values
    // This will set MinRttInCurrentRound to kHyStartRttDecrease
    for (uint32_t i = 0; i < QUIC_HYSTART_DEFAULT_N_SAMPLING; i++) {
        uint32_t BytesToSend = 1200;
        CC->QuicCongestionControlOnDataSent(CC, BytesToSend);

        QUIC_ACK_EVENT AckEvent = MakeAckEvent(
            1300000 + (i * 10000), 110 + i, 115 + i, BytesToSend,
            50000, kHyStartRttDecrease);

        CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);
    }

    ASSERT_EQ(Cubic->HyStartAckCount, 8u);
    ASSERT_EQ(Cubic->MinRttInCurrentRound, kHyStartRttDecrease);

    // Phase 5: Send one more ACK to trigger RTT decrease detection
    // Now HyStartAckCount >= 8 and HyStartState == HYSTART_ACTIVE
    // MinRttInCurrentRound < CssBaselineMinRtt (kHyStartRttAboveThreshold), so should transition
    {
        uint32_t BytesToSend = 1200;
        CC->QuicCongestionControlOnDataSent(CC, BytesToSend);

        QUIC_ACK_EVENT AckEvent = MakeAckEvent(1400000, 120, 125, BytesToSend, 50000, kHyStartRttDecrease + 1000);

        CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

        // Should transition back to NOT_STARTED due to RTT decrease
        ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
        ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 1u); // Reset to normal slow start
    }
}

//
// Test: HyStart++ Conservative Slow Start Rounds - Transition to DONE
// Scenario: Covers the round boundary crossing logic
// when in HYSTART_ACTIVE state. After completing the configured number of
// conservative slow start rounds, the algorithm transitions to HYSTART_DONE.
//
TEST_F(CubicTest, HyStart_ConservativeSlowStartRounds_TransitionToDone)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);
    // Verify initial state
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    EnterHyStartActive();
    ASSERT_EQ(Cubic->HyStartState, HYSTART_ACTIVE);
    ASSERT_EQ(Cubic->ConservativeSlowStartRounds, QUIC_CONSERVATIVE_SLOW_START_DEFAULT_ROUNDS); // Default = 5

    // Cross QUIC_CONSERVATIVE_SLOW_START_DEFAULT_ROUNDS + 1 round boundaries to
    // decrement ConservativeSlowStartRounds
    // Each round boundary crossing when LargestAck >= HyStartRoundEnd will decrement the counter
    for (uint32_t round = 0; round < QUIC_CONSERVATIVE_SLOW_START_DEFAULT_ROUNDS + 1; round++) {
        // Set NextPacketNumber to a higher value for the next round
        Connection.Send.NextPacketNumber = 100 + (round + 1) * 100;

        uint32_t BytesToSend = 1200;
        CC->QuicCongestionControlOnDataSent(CC, BytesToSend);

        // Use LargestAck >= current HyStartRoundEnd to trigger round boundary
        QUIC_ACK_EVENT AckEvent = MakeAckEvent(
            1200000 + (round * 100000),
            Cubic->HyStartRoundEnd,
            Connection.Send.NextPacketNumber + 10,
            BytesToSend, 50000, kHyStartRttAboveThreshold);

        CC->QuicCongestionControlOnDataAcknowledged(
            CC,
            &AckEvent);

        if (round < QUIC_CONSERVATIVE_SLOW_START_DEFAULT_ROUNDS - 1) {
            // Still in HYSTART_ACTIVE for first n-1 rounds
            ASSERT_EQ(Cubic->HyStartState, HYSTART_ACTIVE);
            ASSERT_EQ(Cubic->SlowStartThreshold, UINT32_MAX); // Still at init value during ACTIVE rounds
            ASSERT_EQ(Cubic->ConservativeSlowStartRounds, QUIC_CONSERVATIVE_SLOW_START_DEFAULT_ROUNDS - 1 - round);
        } else {
            // for the rest of the rounds, state should transition
            // to HYSTART_DONE and stay there
            ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
            ASSERT_EQ(Cubic->ConservativeSlowStartRounds, 0u);
            // SlowStartThreshold is set to current congestion window when transitioning to DONE
            ASSERT_EQ(Cubic->SlowStartThreshold, Cubic->CongestionWindow);
        }
    }
}

//====================================================================
//
//  Implementation-specific tests - loosely coupled
//
//  These tests exercise MsQuic-specific features (pacing API,
//  exemptions, statistics) but assert only through public API
//  outputs. They would survive an internal refactor.
//
//====================================================================

//
// Test: CanSend scenarios
// Scenario: Comprehensive test of CanSend logic covering: available window (can send),
// congestion blocked (cannot send), and exemptions (bypass blocking). Tests the core
// congestion control decision logic.
//
TEST_F(CubicTest, CanSendScenarios)
{
    InitializeWithDefaults();
    uint32_t CongestionWindow = Cubic->CongestionWindow;

    // Scenario 1: Available window - can send
    // Simulate sending half the window
    CC->QuicCongestionControlOnDataSent(CC, CongestionWindow / 2);
    ASSERT_TRUE(CC->QuicCongestionControlCanSend(CC));

    // Scenario 2: Congestion blocked - cannot send
    // Simulate sending the rest to fill the window
    CC->QuicCongestionControlOnDataSent(CC, CongestionWindow / 2);
    ASSERT_FALSE(CC->QuicCongestionControlCanSend(CC));

    // Scenario 3: Exceeding window - still blocked
    // OnDataSent is unconditional (doesn't gate on CanSend), so BytesInFlight can exceed CongestionWindow
    CC->QuicCongestionControlOnDataSent(CC, 100);
    ASSERT_FALSE(CC->QuicCongestionControlCanSend(CC));

    // Scenario 4: With exemptions - can send even when blocked
    CC->QuicCongestionControlSetExemption(CC, 2);
    ASSERT_TRUE(CC->QuicCongestionControlCanSend(CC));
}

//
// Test: GetSendAllowance scenarios
// Scenario: Tests GetSendAllowance under different conditions: congestion blocked (returns 0),
// available window without pacing (returns full window), and invalid time (skips pacing).
// Covers the main decision paths in send allowance calculation.
//
TEST_F(CubicTest, GetSendAllowanceScenarios)
{
    InitializeWithDefaults();
    uint32_t CongestionWindow = Cubic->CongestionWindow;

    // Scenario 1: Congestion blocked - should return 0
    // Fill the window completely
    CC->QuicCongestionControlOnDataSent(CC, CongestionWindow);
    uint32_t Allowance = CC->QuicCongestionControlGetSendAllowance(CC, 1000, TRUE);
    ASSERT_EQ(Allowance, 0u);

    // Scenario 2: Available window without pacing - should return full window
    // Reset by acknowledging half the data
    Connection.Settings.PacingEnabled = FALSE;
    QUIC_ACK_EVENT AckEvent = MakeAckEvent(1000000, 5, 10, CongestionWindow / 2);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

    uint32_t ExpectedAllowance = Cubic->CongestionWindow - Cubic->BytesInFlight;
    Allowance = CC->QuicCongestionControlGetSendAllowance(CC, 1000, TRUE);
    ASSERT_EQ(Allowance, ExpectedAllowance);

    // Scenario 3: Invalid time - should skip pacing and return full window
    Connection.Settings.PacingEnabled = TRUE;
    Connection.Paths[0].GotFirstRttSample = TRUE;
    Connection.Paths[0].SmoothedRtt = 50000;
    Allowance = CC->QuicCongestionControlGetSendAllowance(CC, 1000, FALSE); // FALSE = invalid time
    ASSERT_EQ(Allowance, ExpectedAllowance);
}

//
// Test: Congestion window calculation
// Scenario: Tests that the initial congestion window is calculated correctly based on MTU and
// InitialWindowPackets. The expected congestion window is (MTU - 48) * InitialWindowPackets,
// where 48 bytes are reserved for IPv6 and UDP headers. This verifies that the initial
// congestion window is set according to the standard formula.
//
TEST_F(CubicTest, CongestionWindowCalculation)
{
    InitializeWithDefaults(/*WindowPackets=*/10, /*HyStart=*/false, /*Mtu=*/1280);
    uint32_t CongestionWindow = CC->QuicCongestionControlGetCongestionWindow(CC);
    // CongestionWindow = (MTU - 48) * InitialWindowPackets = (1280 - 48) * 10 = 12320
    uint32_t ExpectedCongestionWindow = (1280 - kIPv6UdpOverhead) * 10;
    ASSERT_EQ(CongestionWindow, ExpectedCongestionWindow);
}

//
// Test: GetNetworkStatistics - Statistics Retrieval
// Scenario: Tests retrieval of network statistics including congestion window, RTT estimates,
// and throughput metrics. Used for monitoring and diagnostics.
//
TEST_F(CubicTest, GetNetworkStatistics_RetrieveStats)
{
    InitializeWithDefaults(
        /*WindowPackets=*/10,
        /*HyStart=*/true,
        /*Mtu=*/1280,
        /*IdleTimeoutMs=*/1000,
        /*GotRttSample=*/true,
        /*SmoothedRtt=*/5000,
        /*SetMinRtt=*/true,
        /*MinRtt=*/4000,
        /*RttVariance=*/500
    );

    // Send data via OnDataSent to properly track BytesInFlightMax
    CC->QuicCongestionControlOnDataSent(CC, 8000);

    // Prepare network statistics structure (not QUIC_STATISTICS_V2)
    QUIC_NETWORK_STATISTICS NetworkStats;
    CxPlatZeroMemory(&NetworkStats, sizeof(NetworkStats));

    // Call through function pointer - note it takes Connection as first param
    CC->QuicCongestionControlGetNetworkStatistics(&Connection,CC,&NetworkStats);

    // Verify all 6 statistics fields were populated
    ASSERT_EQ(NetworkStats.CongestionWindow, Cubic->CongestionWindow);
    ASSERT_EQ(NetworkStats.BytesInFlight, Cubic->BytesInFlight);
    ASSERT_EQ(NetworkStats.SmoothedRTT, 5000u);
    // Bandwidth = CongestionWindow / SmoothedRtt = 12320 / 5000 = 2
    uint64_t ExpectedBandwidth = Cubic->CongestionWindow / Connection.Paths[0].SmoothedRtt;
    ASSERT_EQ(NetworkStats.Bandwidth, ExpectedBandwidth);
    // PostedBytes and IdealBytes come from SendBuffer, which is zero-initialized
    ASSERT_EQ(NetworkStats.PostedBytes, 0u);
    ASSERT_EQ(NetworkStats.IdealBytes, 0u);
}

//
// Test: GetNetworkStatistics - Zero SmoothedRtt returns zero Bandwidth
// Scenario: Verifies no division-by-zero occurs when SmoothedRtt is 0 at the
// time GetNetworkStatistics is called (e.g. before the first RTT sample).
// Bandwidth must be reported as 0 rather than crashing.
//
TEST_F(CubicTest, GetNetworkStatistics_ZeroSmoothedRtt_BandwidthIsZero)
{
    // Initialize without an RTT sample so SmoothedRtt stays 0.
    InitializeWithDefaults(
        /*WindowPackets=*/10,
        /*HyStart=*/false,
        /*Mtu=*/1280,
        /*IdleTimeoutMs=*/1000,
        /*GotRttSample=*/false
    );

    ASSERT_EQ(Connection.Paths[0].SmoothedRtt, 0u);

    CC->QuicCongestionControlOnDataSent(CC, 5000);

    QUIC_NETWORK_STATISTICS NetworkStats;
    CxPlatZeroMemory(&NetworkStats, sizeof(NetworkStats));

    // Must not crash with divide-by-zero when SmoothedRtt == 0.
    CC->QuicCongestionControlGetNetworkStatistics(&Connection, CC, &NetworkStats);

    ASSERT_EQ(NetworkStats.Bandwidth, 0u);
    ASSERT_EQ(NetworkStats.SmoothedRTT, 0u);
    ASSERT_EQ(NetworkStats.CongestionWindow, Cubic->CongestionWindow);
}

//
// Test: OnDataAcknowledged NetStats path - Zero SmoothedRtt returns zero Bandwidth
// Scenario: Verifies no division-by-zero occurs inside the NetStatsEventEnabled
// path of OnDataAcknowledged when an ACK arrives before the first RTT sample
// (SmoothedRtt == 0). The NETWORK_STATISTICS event must fire without crashing.
//
static QUIC_STATUS
QUIC_API
NetStatsDummyCallback(
    _In_ HQUIC /* Connection */,
    _In_opt_ void* /* Context */,
    _Inout_ QUIC_CONNECTION_EVENT* /* Event */)
{
    return QUIC_STATUS_SUCCESS;
}

TEST_F(CubicTest, OnDataAcknowledged_NetStats_ZeroSmoothedRtt_BandwidthIsZero)
{
    // Initialize without an RTT sample so SmoothedRtt stays 0.
    InitializeWithDefaults(
        /*WindowPackets=*/10,
        /*HyStart=*/false,
        /*Mtu=*/1280,
        /*IdleTimeoutMs=*/1000,
        /*GotRttSample=*/false
    );

    // Enable the NetStats event path and supply a no-op callback so
    // QuicConnIndicateEvent does not dereference a null function pointer.
    Connection.Settings.NetStatsEventEnabled = TRUE;
    Connection.ClientCallbackHandler = NetStatsDummyCallback;

    ASSERT_EQ(Connection.Paths[0].SmoothedRtt, 0u);

    Cubic->BytesInFlight = 5000;

    // Construct an ACK event with SmoothedRtt == 0 (no RTT sample yet).
    QUIC_ACK_EVENT AckEvent = MakeAckEvent(
        /*TimeNow=*/1000000,
        /*LargestAck=*/5,
        /*LargestSentPacketNumber=*/10,
        /*BytesAcked=*/1000,
        /*SmoothedRtt=*/0,
        /*MinRtt=*/0,
        /*MinRttValid=*/FALSE);

    // Must not crash.
    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);
}

//
// Test: Spurious Congestion Event - No-Op When Not In Recovery
// Scenario: Verifies OnSpuriousCongestionEvent returns FALSE with no state change
// when not in recovery (IsInRecovery=FALSE). The full rollback path is tested
// by SpuriousCongestion_StateRollback.
//
TEST_F(CubicTest, CongestionControlOnSpuriousCongestionEvent)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);
    CC->QuicCongestionControlOnDataSent(CC, Cubic->CongestionWindow);
    Connection.Send.NextPacketNumber = 10;
    // Not currently in recovery mode, so spurious congestion event should have no effect.
    ASSERT_FALSE(CC->QuicCongestionControlOnSpuriousCongestionEvent(CC));
}

//
// Test: Zero Bytes Acknowledged - Early Exit
// Scenario: Tests the early exit path when BytesAcked is zero.
// This can occur with ACKs that don't contain retransmittable data.
//
TEST_F(CubicTest, ZeroBytesAcked_EarlyExit)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);
    uint32_t InitialWindow = Cubic->CongestionWindow;

    // Send some data to have bytes in flight
    CC->QuicCongestionControlOnDataSent(CC, 5000);

    QUIC_ACK_EVENT AckEvent = MakeAckEvent(1000000, 5, 10, 0);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

    // Window should not change with zero bytes acked
    ASSERT_EQ(Cubic->CongestionWindow, InitialWindow);
}

//
// Test: App Limited API Coverage
// Scenario: Tests the IsAppLimited and SetAppLimited API functions. In the current
// CUBIC implementation, these are stub functions that don't track app-limited state.
// This test verifies the API is callable and doesn't crash.
//
TEST_F(CubicTest, AppLimited_APICoverage)
{
    InitializeWithDefaults(/*WindowPackets=*/20);

    // IsAppLimited currently always returns FALSE (stub implementation)
    BOOLEAN IsAppLimited = CC->QuicCongestionControlIsAppLimited(CC);
    ASSERT_FALSE(IsAppLimited);

    // SetAppLimited is a no-op in current implementation but should not crash
    CC->QuicCongestionControlSetAppLimited(CC);

    // Still returns FALSE after SetAppLimited (stub behavior)
    IsAppLimited = CC->QuicCongestionControlIsAppLimited(CC);
    ASSERT_FALSE(IsAppLimited);
}

//====================================================================
//
//  Implementation-specific tests - tightly coupled
//
//  These tests directly read or write internal QUIC_CONGESTION_CONTROL_CUBIC
//  struct fields. If the implementation is refactored -- even while
//  preserving identical congestion control behavior -- these tests
//  would break.
//
//====================================================================

//
// Test: Reset scenarios
// Scenario: Tests Reset function with both FullReset=FALSE (preserves BytesInFlight) and
// FullReset=TRUE (zeros BytesInFlight). Verifies that reset properly reinitializes CUBIC
// state: CongestionWindow, BytesInFlightMax, SlowStartThreshold, recovery flags,
// and HyStart state (via CubicCongestionHyStartResetPerRttRound + state change).
//
TEST_F(CubicTest, ResetScenarios)
{
    InitializeWithDefaults();
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);
    uint32_t ExpectedWindow = DatagramPayloadLength * Settings.InitialWindowPackets;

    // Scenario 1: Partial reset (FullReset=FALSE) - preserves BytesInFlight
    // First, send some data and trigger a congestion event to set internal flags
    CC->QuicCongestionControlOnDataSent(CC, 5000);

    // Trigger congestion event via loss
    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(1200, 5, 10);

    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    uint32_t BytesInFlightBefore = Cubic->BytesInFlight;

    CC->QuicCongestionControlReset(CC, FALSE);

    ASSERT_EQ(Cubic->SlowStartThreshold, UINT32_MAX);
    ASSERT_FALSE(Cubic->IsInRecovery);
    ASSERT_FALSE(Cubic->HasHadCongestionEvent);
    ASSERT_EQ(Cubic->LastSendAllowance, 0u);
    ASSERT_EQ(Cubic->BytesInFlight, BytesInFlightBefore); // Preserved

    // Window-related state re-initialized
    ASSERT_EQ(Cubic->CongestionWindow, ExpectedWindow);
    ASSERT_EQ(CC->QuicCongestionControlGetBytesInFlightMax(CC), ExpectedWindow / 2);

    // HyStart state reset
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    ASSERT_EQ(Cubic->HyStartAckCount, 0u);
    // After CubicCongestionHyStartResetPerRttRound: MinRttInCurrentRound = UINT64_MAX
    ASSERT_EQ(Cubic->MinRttInCurrentRound, UINT64_MAX);
    // TODO(bug): MinRttInLastRound should be UINT64_MAX (matching Init), but Reset
    // copies MinRttInCurrentRound before the round-reset overwrites it. The stale
    // UINT32_MAX sentinel could trigger spurious HyStart delay detection after Reset.
    // Update this assertion to UINT64_MAX when the production bug is fixed.
    ASSERT_EQ(Cubic->MinRttInLastRound, (uint64_t)UINT32_MAX);

    // Scenario 2: Full reset (FullReset=TRUE) - zeros BytesInFlight
    // Reinitialize and send data again
    CC->QuicCongestionControlOnDataSent(CC, 5000);

    // Trigger another congestion event
    LossEvent.NumRetransmittableBytes = 1200;
    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    CC->QuicCongestionControlReset(CC, TRUE);

    ASSERT_EQ(Cubic->SlowStartThreshold, UINT32_MAX);
    ASSERT_FALSE(Cubic->IsInRecovery);
    ASSERT_EQ(Cubic->BytesInFlight, 0u); // Zeroed with full reset

    // Same window/HyStart reset for full reset
    ASSERT_EQ(Cubic->CongestionWindow, ExpectedWindow);
    ASSERT_EQ(CC->QuicCongestionControlGetBytesInFlightMax(CC), ExpectedWindow / 2);
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    ASSERT_EQ(Cubic->HyStartAckCount, 0u);
    ASSERT_EQ(Cubic->MinRttInCurrentRound, UINT64_MAX);
    // TODO(bug): Same sentinel mismatch as Scenario 1. Fix with UINT64_MAX.
    ASSERT_EQ(Cubic->MinRttInLastRound, (uint64_t)UINT32_MAX);
}

//
// Test: CubicCongestionControlOnDataSent - BytesInFlight increases and exemptions decrement
// Scenario: Tests that OnDataSent correctly increments BytesInFlight when data is sent
// and decrements exemptions when probe packets are sent. This tracks outstanding data
// in the network and consumes exemptions. Verifies BytesInFlightMax is updated when
// BytesInFlight reaches a new maximum.
//
TEST_F(CubicTest, OnDataSent_IncrementsBytesInFlight)
{
    InitializeWithDefaults();

    // Scenario 1: Send less than BytesInFlightMax — max unchanged
    uint32_t InitialBytesInFlightMax = CC->QuicCongestionControlGetBytesInFlightMax(CC); // CW/2 = 6160
    uint32_t SmallSend = 1500;

    CC->QuicCongestionControlOnDataSent(CC, SmallSend);

    ASSERT_EQ(Cubic->BytesInFlight, SmallSend);
    ASSERT_EQ(CC->QuicCongestionControlGetBytesInFlightMax(CC), InitialBytesInFlightMax); // Unchanged: 1500 < 6160

    // Scenario 2: Send enough to exceed BytesInFlightMax — max updated
    uint32_t LargeSend = InitialBytesInFlightMax; // 6160, total BIF = 7660 > 6160
    CC->QuicCongestionControlOnDataSent(CC, LargeSend);

    ASSERT_EQ(Cubic->BytesInFlight, SmallSend + LargeSend);
    ASSERT_EQ(CC->QuicCongestionControlGetBytesInFlightMax(CC), SmallSend + LargeSend); // Updated: 7660 > 6160

    // Test exemption decrement
    CC->QuicCongestionControlSetExemption(CC, 5); // Set 5 exemptions
    CC->QuicCongestionControlOnDataSent(CC, 1500);
    ASSERT_EQ(CC->QuicCongestionControlGetExemptions(CC), 4u);

    // Test LastSendAllowance decrement
    // When NumRetransmittableBytes <= LastSendAllowance, allowance is reduced
    Cubic->LastSendAllowance = 2000; // Set initial allowance
    uint32_t TinySend = 500; // Send less than allowance
    CC->QuicCongestionControlOnDataSent(CC, TinySend);
    ASSERT_EQ(Cubic->LastSendAllowance, 2000u - TinySend); // Should be reduced

    // When NumRetransmittableBytes > LastSendAllowance, allowance is zeroed
    Cubic->LastSendAllowance = 1000;
    CC->QuicCongestionControlOnDataSent(CC, 3000); // 3000 > 1000
    ASSERT_EQ(Cubic->LastSendAllowance, 0u);
}

//
// Test: CubicCongestionControlOnDataInvalidated - BytesInFlight decreases
// Scenario: Tests OnDataInvalidated when sent packets are discarded (e.g., due to key
// phase change). BytesInFlight should decrease by the invalidated bytes since they're
// no longer considered in-flight. Critical for accurate congestion window management.
//
TEST_F(CubicTest, OnDataInvalidated_DecrementsBytesInFlight)
{
    InitializeWithDefaults();

    // Send data via OnDataSent to properly track BytesInFlightMax
    CC->QuicCongestionControlOnDataSent(CC, 5000);
    uint32_t BytesToInvalidate = 2000;

    CC->QuicCongestionControlOnDataInvalidated(CC, BytesToInvalidate);

    ASSERT_EQ(Cubic->BytesInFlight, 3000u);
}

//
// Test: Pacing with Slow Start Window Estimation
// Scenario: Tests pacing calculation during slow start phase. When in slow start,
// the estimated window is 2x current window (exponential growth). This covers
// the EstimatedWnd calculation branch in GetSendAllowance.
//
TEST_F(CubicTest, Pacing_SlowStartWindowEstimation)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ false);
    Connection.Settings.PacingEnabled = TRUE;

    // Ensure in slow start (SlowStartThreshold is UINT32_MAX by default after init)
    // Send data to have bytes in flight
    CC->QuicCongestionControlOnDataSent(CC, Cubic->CongestionWindow / 2);

    uint32_t Allowance = CC->QuicCongestionControlGetSendAllowance(CC, 10000, TRUE);

    // Pacing formula: (EstimatedWnd * TimeSinceLastSend) / SmoothedRtt
    // In slow start: EstimatedWnd = min(2 * CongestionWindow, SlowStartThreshold) = 24640
    // CongestionWindow = (1280 - 48) * 10 = 12320
    uint32_t CongestionWindow = Cubic->CongestionWindow;
    uint64_t SmoothedRtt = Connection.Paths[0].SmoothedRtt;
    uint32_t TimeSinceLastSend = 10000;
    uint32_t EstimatedWnd = 2 * CongestionWindow; // SSThresh == UINT32_MAX, so min(2*CW, SST) = 2*CW
    uint32_t ExpectedAllowance = (uint32_t)(((uint64_t)EstimatedWnd * TimeSinceLastSend) / SmoothedRtt);
    ASSERT_EQ(Allowance, ExpectedAllowance);

    // Now test the case where estimated window (2x current) exceeds threshold
    // Set threshold to be between current window and 2x current window
    uint32_t CurrentWindow = Cubic->CongestionWindow;
    Cubic->SlowStartThreshold = CurrentWindow + (CurrentWindow / 2); // 1.5x current window = 18480

    // Call GetSendAllowance again
    // EstimatedWnd = min(2 * 12320, 18480) = 18480
    // Allowance = LastSendAllowance + (18480 * 10000) / 50000 = 4928 + 3696 = 8624
    // BUT capped at available window = CongestionWindow - BytesInFlight = 12320 - 6160 = 6160
    uint32_t Allowance2 = CC->QuicCongestionControlGetSendAllowance(CC, 10000, TRUE);

    // Verify exact calculated value (capped at available window)
    uint32_t AvailableWindow = Cubic->CongestionWindow - Cubic->BytesInFlight;
    uint32_t ExpectedAllowance2 = AvailableWindow;  // 6160 (capped)
    ASSERT_EQ(Allowance2, ExpectedAllowance2);
}

//
// Test: Pacing with Congestion Avoidance Window Estimation
// Scenario: Tests pacing calculation during congestion avoidance phase.
// When past slow start, estimated window is 1.25x current window (linear growth).
//
TEST_F(CubicTest, Pacing_CongestionAvoidanceEstimation)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ false);
    Connection.Settings.PacingEnabled = TRUE;

    // Enter congestion avoidance: loss reduces CW to 8624, SSThresh = 8624.
    // Use custom setup (not EnterCongestionAvoidance) because we need specific
    // BytesInFlight for the pacing derivation.
    uint32_t InitialWindow = Cubic->CongestionWindow;
    CC->QuicCongestionControlOnDataSent(CC, InitialWindow);
    Connection.Send.NextPacketNumber = 10;

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(1200, 5, 10);
    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    uint32_t WindowAfterLoss = InitialWindow * 7 / 10;
    uint32_t BytesInFlightAfterLoss = InitialWindow - LossEvent.NumRetransmittableBytes;

    // Exit recovery with ACK that also reduces BytesInFlight to a known value
    Connection.Send.NextPacketNumber = 15;
    uint32_t BytesAcked = WindowAfterLoss / 2;
    QUIC_ACK_EVENT AckEvent = MakeAckEvent(1100000, 15, 20, BytesAcked);
    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

    uint32_t BytesInFlightAfterAck = BytesInFlightAfterLoss - BytesAcked;

    // Now in congestion avoidance and out of recovery
    // GetSendAllowance with TimeSinceLastSend=10000us, pacing enabled:
    // - CongestionWindow >= SlowStartThreshold, so EstimatedWnd = CongestionWindow * 1.25
    // - EstimatedWnd = 8624 + 8624/4 = 8624 + 2156 = 10780
    // - SendAllowance = LastSendAllowance + (EstimatedWnd * TimeSinceLastSend) / SmoothedRtt
    // - LastSendAllowance = 0 (first call after ACK)
    // - SendAllowance = 0 + (10780 * 10000) / 50000 = 107800000 / 50000 = 2156
    // - AvailableWindow = CongestionWindow - BytesInFlight = 8624 - 6808 = 1816
    // - SendAllowance (2156) > AvailableWindow (1816), so capped to 1816
    uint32_t Allowance = CC->QuicCongestionControlGetSendAllowance(CC, 10000, TRUE);

    uint64_t EstimatedWnd = WindowAfterLoss + (WindowAfterLoss >> 2);
    uint32_t AvailableWindow = WindowAfterLoss - BytesInFlightAfterAck;
    uint32_t CalculatedAllowance = (uint32_t)((EstimatedWnd * 10000) / 50000);
    uint32_t ExpectedAllowance = (CalculatedAllowance > AvailableWindow) ? AvailableWindow : CalculatedAllowance;

    ASSERT_EQ(Allowance, ExpectedAllowance);
}

//
// Test: Pacing LastSendAllowance Carryover
// Scenario: When pacing is enabled and GetSendAllowance is called multiple times
// without sending data, the unused allowance (LastSendAllowance) carries over
// and accumulates into the next call's result.
//
TEST_F(CubicTest, Pacing_LastSendAllowanceCarryover)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ false);
    Connection.Settings.PacingEnabled = TRUE;

    // Send some data so BytesInFlight > 0
    CC->QuicCongestionControlOnDataSent(CC, 1000);

    // First pacing call: LastSendAllowance starts at 0
    // EstimatedWnd = 2*12320 = 24640 (slow start), TimeSinceLastSend = 1ms
    // Allowance = 0 + (24640 * 1000) / 50000 = 492
    uint32_t Allowance1 = CC->QuicCongestionControlGetSendAllowance(CC, 1000, TRUE);
    ASSERT_EQ(Allowance1, (uint32_t)(((uint64_t)(2 * Cubic->CongestionWindow) * 1000) / 50000));

    // Don't send anything — LastSendAllowance stays at Allowance1

    // Second pacing call: LastSendAllowance carries over
    // Allowance = Allowance1 + (24640 * 1000) / 50000 = 2 * Allowance1
    uint32_t Allowance2 = CC->QuicCongestionControlGetSendAllowance(CC, 1000, TRUE);
    ASSERT_EQ(Allowance2, 2 * Allowance1);
    ASSERT_GT(Allowance2, Allowance1);
}

//
// Test: AIMD Accumulator - Below WindowPrior (half-rate growth)
// Scenario: In congestion avoidance with AimdWindow < WindowPrior, the AIMD
// accumulator grows at half rate (BytesAcked / 2). This tests the Reno-friendly
// region where CUBIC is still catching up to the previous maximum window.
//
TEST_F(CubicTest, AIMD_AccumulatorBelowWindowPrior)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);

    // After loss: AimdWindow = CW * 7/10, WindowPrior = original CW
    // So AimdWindow < WindowPrior → half-rate accumulator path
    EnterCongestionAvoidance();

    // ACK in congestion avoidance: AIMD accumulator exercised
    CC->QuicCongestionControlOnDataSent(CC, 3000);

    uint32_t BytesAcked = 600; // Half MTU
    QUIC_ACK_EVENT CongAvoidAck = MakeAckEvent(1100000, 16, 25, BytesAcked);

    ASSERT_EQ(Cubic->AimdAccumulator, 0u);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &CongAvoidAck);

    // AimdWindow < WindowPrior, so accumulator += BytesAcked / 2 = 300
    ASSERT_EQ(Cubic->AimdAccumulator, BytesAcked / 2);
}

//
// Test: AIMD Accumulator - Above WindowPrior (full-rate growth)
// Scenario: In congestion avoidance with AimdWindow >= WindowPrior, the AIMD
// accumulator grows at full rate (BytesAcked). This tests the path where CUBIC
// has surpassed its previous maximum and enters the convex region.
//
TEST_F(CubicTest, AIMD_AccumulatorAboveWindowPrior)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);

    EnterCongestionAvoidance();

    // Force AimdWindow >= WindowPrior so the full-rate accumulator path runs.
    // After loss, WindowPrior = original CW and AimdWindow = CW * 7/10.
    // Set AimdWindow = WindowPrior to enter the above-WindowPrior path.
    Cubic->AimdWindow = Cubic->WindowPrior;
    ASSERT_EQ(Cubic->AimdAccumulator, 0u);

    // ACK in congestion avoidance with full-rate accumulation
    CC->QuicCongestionControlOnDataSent(CC, 3000);

    uint32_t BytesAcked = 1200;
    QUIC_ACK_EVENT CongAvoidAck = MakeAckEvent(1100000, 16, 25, BytesAcked);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &CongAvoidAck);

    // AimdWindow >= WindowPrior, so accumulator += BytesAcked (full rate, not halved)
    ASSERT_EQ(Cubic->AimdAccumulator, BytesAcked);
}

//
// Test: AIMD Accumulator - Triggers Window Growth
// Scenario: When AimdAccumulator exceeds AimdWindow, AimdWindow grows by one
// DatagramPayloadLength (1 MSS). We set AimdWindow
// to a small value so a single ACK of sufficient size triggers the growth, and
// BytesAcked exceeds AimdWindow + DatagramPayloadLength to avoid unsigned
// underflow in the subtraction (AimdAccumulator -= AimdWindow).
//
TEST_F(CubicTest, AIMD_AccumulatorTriggersWindowGrowth)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);

    EnterCongestionAvoidance();

    // Set AimdWindow small enough that a single ACK triggers growth.
    // Use full-rate path: AimdWindow >= WindowPrior.
    // BytesAcked must exceed AimdWindow + DatagramPayloadLength to avoid
    // unsigned underflow in the subtraction (AimdAccumulator -= AimdWindow).
    uint32_t SmallAimdWindow = 100;
    Cubic->AimdWindow = SmallAimdWindow;
    Cubic->WindowPrior = SmallAimdWindow; // AimdWindow >= WindowPrior → full-rate
    Cubic->AimdAccumulator = 0;

    CC->QuicCongestionControlOnDataSent(CC, 3000);

    uint32_t BytesAcked = SmallAimdWindow + DatagramPayloadLength + 100; // 1432: comfortably exceeds threshold
    QUIC_ACK_EVENT GrowthAck = MakeAckEvent(1100000, 16, 25, BytesAcked);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &GrowthAck);

    // Full-rate: AimdAccumulator += BytesAcked = 1432. 1432 > 100 → trigger growth.
    // AimdWindow = 100 + DatagramPayloadLength = 1332
    // AimdAccumulator = 1432 - 1332 = 100
    ASSERT_EQ(Cubic->AimdWindow, SmallAimdWindow + DatagramPayloadLength);
    ASSERT_EQ(Cubic->AimdAccumulator, BytesAcked - (SmallAimdWindow + DatagramPayloadLength));
}

//
// Test: CubicWindow Overflow to BytesInFlightMax
// Scenario: Tests that when the CUBIC window formula overflows (producing a negative
// int64 result), the window is capped at 2*BytesInFlightMax. After exiting recovery,
// we manipulate TimeOfCongAvoidStart so the CUBIC formula's DeltaT produces a large
// negative value (KCubic >> TimeInCongAvoid), causing the cubic term to overflow.
//
TEST_F(CubicTest, CubicWindow_OverflowToBytesInFlightMax)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);

    uint32_t WindowAfterLoss = EnterCongestionAvoidance();

    // Force extreme conditions to trigger CUBIC overflow.
    // Set a huge WindowMax and a correspondingly large KCubic so that
    // DeltaT = (TimeInCongAvoid - KCubic_us + RTT) is deeply negative.
    // The cubic term DeltaT^3 then overflows, exercising the CubicWindow < 0 guard.
    Cubic->WindowMax = UINT32_MAX;
    Cubic->KCubic = 500000; // ~500 seconds — far exceeds TimeInCongAvoid (~50ms)

    // Skip time gap adjustment by invalidating the last ACK time
    Cubic->TimeOfLastAckValid = FALSE;

    // Second ACK: CUBIC formula runs with extreme KCubic, producing overflow
    CC->QuicCongestionControlOnDataSent(CC, 3000);

    QUIC_ACK_EVENT OverflowAck = MakeAckEvent(1100000, 16, 25, 1200);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &OverflowAck);

    // CUBIC formula overflow: CubicWindow < 0, capped to 2*BytesInFlightMax.
    // The final CW is determined by max(CubicWindow, AimdWindow) and then the
    // BytesInFlightMax clamp. Verify the window is reasonable (not overflowed).
    ASSERT_FALSE(Cubic->IsInRecovery);
    // CUBIC formula overflow: CubicWindow < 0, capped to 2*BytesInFlightMax (58080).
    // But bounded growth limits TargetWindow to 1.5*CW = 1.5*17248 = 25872.
    // Growth = (25872 - 17248) * 1232 / 17248 = 616. New CW = 17248 + 616 = 17864.
    ASSERT_EQ(
        Cubic->CongestionWindow,
        WindowAfterLoss + (uint32_t)((uint64_t)(WindowAfterLoss * 3 / 2 - WindowAfterLoss) * DatagramPayloadLength / WindowAfterLoss)
    );
}

//
// Test: Time Gap in ACKs - Idle Period Handling
// Scenario: Tests the idle-period time gap clamping logic.
// After exiting recovery, a large gap between ACKs (exceeding SendIdleTimeoutMs
// and RTT+4*RttVariance) should advance TimeOfCongAvoidStart to prevent the
// CUBIC formula from producing unrealistic window growth.
//
TEST_F(CubicTest, TimeGap_IdlePeriodHandling)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);
    Connection.Paths[0].RttVariance = 5000;

    // Trigger loss → recovery
    CC->QuicCongestionControlOnDataSent(CC, Cubic->CongestionWindow);
    Connection.Send.NextPacketNumber = 10;

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(1200, 5, 10);

    CC->QuicCongestionControlOnDataLost(
        CC, &LossEvent);
    ASSERT_TRUE(Cubic->IsInRecovery);

    // First ACK: exit recovery. This sets TimeOfCongAvoidStart and TimeOfLastAck.
    Connection.Send.NextPacketNumber = 15;
    CC->QuicCongestionControlOnDataSent(CC, 5000);

    QUIC_ACK_EVENT ExitAck = MakeAckEvent(1050000, 11, 20, 1200);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &ExitAck);
    ASSERT_FALSE(Cubic->IsInRecovery);
    ASSERT_TRUE(Cubic->TimeOfLastAckValid);

    uint64_t TimeOfCongAvoidBefore = Cubic->TimeOfCongAvoidStart;

    // Second ACK: small gap (50ms), well within idle timeout. No time gap adjustment.
    CC->QuicCongestionControlOnDataSent(CC, 3000);

    QUIC_ACK_EVENT NormalAck = MakeAckEvent(1100000, 14, 22, 1200);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &NormalAck);

    // Small gap: TimeOfCongAvoidStart unchanged
    ASSERT_EQ(Cubic->TimeOfCongAvoidStart, TimeOfCongAvoidBefore);

    TimeOfCongAvoidBefore = Cubic->TimeOfCongAvoidStart;

    // Third ACK: 5-second idle gap (exceeds SendIdleTimeoutMs=1000ms and
    // RTT+4*RttVar=50000+20000=70000µs). Time gap clamping should fire.
    CC->QuicCongestionControlOnDataSent(CC, 3000);

    QUIC_ACK_EVENT IdleAck = MakeAckEvent(6100000, 18, 25, 1200);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &IdleAck);

    // Time gap clamping fired: TimeOfCongAvoidStart advanced by the 5s idle gap.
    // TimeSinceLastAck = 6100000 - 1100000 = 5000000 µs.
    // New TimeOfCongAvoidStart = 1050000 + 5000000 = 6050000.
    ASSERT_EQ(Cubic->TimeOfCongAvoidStart, TimeOfCongAvoidBefore + 5000000);
}

//
// ======================================================================
// Edge Case and Boundary Condition Tests
// These tests exercise overflow guards, minimum/maximum clamps, and
// corner cases in slow start, congestion avoidance, recovery, and pacing.
// ======================================================================
//

//
// Test: Congestion Avoidance Time Gap - Overflow Protection
// Scenario: Covers the overflow protection logic when a large time gap causes
// TimeOfCongAvoidStart adjustment to overflow. Tests the boundary condition
// where TimeOfCongAvoidStart might exceed TimeNowUs after adjustment.
//
TEST_F(CubicTest, CongestionAvoidance_TimeGapOverflowProtection)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ false);
    Connection.Paths[0].RttVariance = 10000;

    // Force into congestion avoidance by setting window >= threshold
    Cubic->SlowStartThreshold = 10000;
    Cubic->CongestionWindow = 20000;

    // Set TimeOfCongAvoidStart to a value where adding a gap would overflow
    uint64_t TimeNowUs = 5000000; // 5 seconds
    Cubic->TimeOfCongAvoidStart = UINT64_MAX - 2000000; // Very close to max
    Cubic->TimeOfLastAckValid = TRUE;
    Cubic->TimeOfLastAck = TimeNowUs - 2000000; // 2 seconds ago

    // TimeSinceLastAck = 5000000 - 3000000 = 2000000 us (2 seconds)
    // This is > SendIdleTimeoutMs (1000ms = 1000000us)
    // This is > SmoothedRtt + 4*RttVariance = 50000 + 40000 = 90000us
    // So the gap adjustment will be triggered

    // TimeOfCongAvoidStart + TimeSinceLastAck would overflow:
    // (UINT64_MAX - 2000000) + 2000000 = UINT64_MAX + 0, wrapping around
    // After adding, TimeOfCongAvoidStart would be > TimeNowUs
    // Line 585 checks CxPlatTimeAtOrBefore64(TimeNowUs, TimeOfCongAvoidStart)
    // If true (TimeNowUs <= TimeOfCongAvoidStart), clamp to TimeNowUs

    // Send data
    uint32_t BytesToSend = 1200;
    CC->QuicCongestionControlOnDataSent(CC, BytesToSend);

    QUIC_ACK_EVENT AckEvent = MakeAckEvent(TimeNowUs, 10, 15, BytesToSend, 50000, 45000, FALSE);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

    // TimeOfCongAvoidStart should be clamped to TimeNowUs to prevent issues
    // in TimeInCongAvoid calculation
    ASSERT_EQ(Cubic->TimeOfCongAvoidStart, TimeNowUs);
}

//
// Test: ECN Spurious Rollback Restores Stale State
// Scenario: When ECN triggers a congestion event, the `if (!Ecn)` guard
// skips saving previous state (PrevCongestionWindow, etc.).
// If OnSpuriousCongestionEvent is called afterward, it enters the rollback path
// (IsInRecovery is TRUE) but restores the stale/zero Prev* values—NOT the
// pre-ECN state. This confirms the asymmetry between loss-based and ECN-based
// congestion events: loss saves rollback state, ECN does not.
//
TEST_F(CubicTest, ECN_SpuriousRollbackRestoresStaleState)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ false);
    uint32_t PreEcnWindow = Cubic->CongestionWindow; // 12320

    // Send some data so BytesInFlight > 0 (required for realistic state)
    CC->QuicCongestionControlOnDataSent(CC, 1200);
    Connection.Send.NextPacketNumber = 10;

    // Verify Prev* fields are zero (no prior loss-based congestion event)
    ASSERT_EQ(Cubic->PrevCongestionWindow, 0u);
    ASSERT_EQ(Cubic->PrevAimdWindow, 0u);
    ASSERT_EQ(Cubic->PrevSlowStartThreshold, 0u);

    // Trigger ECN congestion event — first congestion event in this connection
    QUIC_ECN_EVENT EcnEvent{};
    EcnEvent.LargestPacketNumberAcked = 5;
    EcnEvent.LargestSentPacketNumber = 10;

    CC->QuicCongestionControlOnEcn(CC, &EcnEvent);

    // After ECN: window reduced to 0.7x, recovery entered
    uint32_t PostEcnWindow = PreEcnWindow * 7 / 10; // 8624
    ASSERT_EQ(Cubic->CongestionWindow, PostEcnWindow);
    ASSERT_TRUE(Cubic->IsInRecovery);
    ASSERT_TRUE(Cubic->HasHadCongestionEvent);

    // ECN does NOT save Prev* (`if (!Ecn)` guard)
    ASSERT_EQ(Cubic->PrevCongestionWindow, 0u);
    ASSERT_EQ(Cubic->PrevAimdWindow, 0u);

    // Call spurious rollback — enters rollback (IsInRecovery=TRUE) but
    // restores stale zero Prev* values, NOT the pre-ECN state
    CC->QuicCongestionControlOnSpuriousCongestionEvent(CC);

    // State flags cleared
    ASSERT_FALSE(Cubic->IsInRecovery);
    ASSERT_FALSE(Cubic->HasHadCongestionEvent);

    // CW restored to PrevCongestionWindow = 0, NOT to PreEcnWindow (12320)
    // or PostEcnWindow (8624). This documents the ECN rollback asymmetry.
    ASSERT_NE(Cubic->CongestionWindow, PreEcnWindow);
    ASSERT_NE(Cubic->CongestionWindow, PostEcnWindow);
    ASSERT_EQ(Cubic->CongestionWindow, 0u);
    ASSERT_EQ(Cubic->AimdWindow, 0u);
    ASSERT_EQ(Cubic->SlowStartThreshold, 0u);
}

//
// Test: Slow Start Window Overflow After Persistent Congestion
// Scenario: After persistent congestion, window is reset to 2*MTU while threshold
// remains at a higher value, creating window < threshold condition. A large ACK
// can then trigger the overflow logic where window grows beyond threshold.
//
TEST_F(CubicTest, SlowStart_WindowOverflowAfterPersistentCongestion)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ false);

    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);
    uint32_t InitialWindow = DatagramPayloadLength * Settings.InitialWindowPackets;
    ASSERT_EQ(Cubic->CongestionWindow, InitialWindow);

    // Trigger PERSISTENT congestion directly (window will be reduced to 2*MTU)
    CC->QuicCongestionControlOnDataSent(CC, 1200);
    Connection.Send.NextPacketNumber = 25;

    QUIC_LOSS_EVENT PersistentLoss = MakeLossEvent(1200, 20, 25, TRUE);

    CC->QuicCongestionControlOnDataLost(CC, &PersistentLoss);

    // After persistent congestion:
    // - Window is reset to 2 * DatagramPayloadLength (minimum window)
    // - Threshold is set to old_window * 0.7
    uint32_t ExpectedWindowAfterPC = DatagramPayloadLength * QUIC_PERSISTENT_CONGESTION_WINDOW_PACKETS;
    uint32_t ExpectedThresholdAfterPC = InitialWindow * 7 / 10;
    uint32_t WindowAfterPC = Cubic->CongestionWindow;
    uint32_t ThresholdAfterPC = Cubic->SlowStartThreshold;

    ASSERT_EQ(WindowAfterPC, ExpectedWindowAfterPC);
    ASSERT_EQ(ThresholdAfterPC, ExpectedThresholdAfterPC);
    // Persistent congestion sets AimdWindow = CW * 7/10
    ASSERT_EQ(Cubic->AimdWindow, ExpectedThresholdAfterPC);

    // We're in recovery after persistent congestion. Need to exit recovery first.
    // Exit recovery by ACKing a packet sent after the recovery started
    Connection.Send.NextPacketNumber = 30;
    CC->QuicCongestionControlOnDataSent(CC, 1200);

    QUIC_ACK_EVENT RecoveryExitAck = MakeAckEvent(1100000, 30, 31, 1200, 50000, 45000, FALSE);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &RecoveryExitAck);

    // Recovery exits but window doesn't grow on the same ACK (code goes to Exit)
    ASSERT_FALSE(Cubic->IsInRecovery);
    ASSERT_EQ(Cubic->CongestionWindow, WindowAfterPC); // Window unchanged on recovery exit

    // Now send and ACK enough bytes to exceed threshold
    // In slow start, window grows by BytesAcked
    uint32_t BytesToExceedThreshold = ThresholdAfterPC - WindowAfterPC + 1000;

    CC->QuicCongestionControlOnDataSent(CC, BytesToExceedThreshold);

    QUIC_ACK_EVENT LargeAck = MakeAckEvent(1200000, 30, 35, BytesToExceedThreshold, 50000, 45000, FALSE);

    // Before ACK: verify we're in slow start
    // Window after recovery exit + BytesInFlight may be < threshold

    CC->QuicCongestionControlOnDataAcknowledged(CC, &LargeAck);

    // After ACK: verify overflow logic executed
    // 1. TimeOfCongAvoidStart should be set
    ASSERT_EQ(Cubic->TimeOfCongAvoidStart, LargeAck.TimeNow);

    // 2. Window should be clamped to threshold
    ASSERT_EQ(Cubic->CongestionWindow, ThresholdAfterPC);
}

//
// ================================================================================
// HyStart++ State Internal Consistency Tests
// These tests verify the internal consistency of HyStart++ state variables
// across different states and transitions, ensuring that the state machine
// maintains correct invariants and that transitions only occur when preconditions
// are met.
// ===============================================================================

//
// Test: HyStart++ Initialization State Verification
// Scenario: Verifies that when HyStartEnabled=TRUE, the system initializes
// to HYSTART_NOT_STARTED with all supporting variables correctly set.
// This establishes the precondition for all other HyStart++ transitions.
//
TEST_F(CubicTest, HyStart_InitialStateVerification)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);
    const uint16_t DatagramPayloadLength = QuicPathGetDatagramPayloadSize(&Connection.Paths[0]);
    uint32_t InitialWindow = DatagramPayloadLength * Settings.InitialWindowPackets;

    // Verify initial state
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 1u);
    ASSERT_EQ(Cubic->HyStartAckCount, 0u);
    ASSERT_EQ(Cubic->MinRttInLastRound, UINT64_MAX);
    ASSERT_EQ(Cubic->MinRttInCurrentRound, UINT64_MAX);
    ASSERT_EQ(Cubic->HyStartRoundEnd, 0u);
    // At initialization, SlowStartThreshold = UINT32_MAX (slow start mode)
    ASSERT_EQ(Cubic->CongestionWindow, InitialWindow);
    ASSERT_EQ(Cubic->SlowStartThreshold, UINT32_MAX);
}

//
// Test: HyStart++ Disabled - State Unchanged on Congestion Events
// Scenario: When HyStartEnabled=FALSE(on Connection.Settings), the loss handler's
// HyStart state transition logic is guarded by the enabled flag. The state remains
// NOT_STARTED because the code path `Cubic->HyStartState = HYSTART_DONE` is only
// executed when HyStartEnabled=TRUE. Recovery still occurs normally.
//
TEST_F(CubicTest, HyStart_Disabled_NoTransitions)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20, /*HyStart = */ false);

    // Initial state should be NOT_STARTED
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);

    // Attempt various operations that would trigger transitions if enabled

    // 1. Send ACKs with increasing RTT (would trigger NOT_STARTED → ACTIVE if enabled).
    // Two iterations suffice — the guard is checked on every ACK.
    for (int i = 0; i < 2; i++) {
        CC->QuicCongestionControlOnDataSent(CC, 1200);

        QUIC_ACK_EVENT AckEvent = MakeAckEvent(
            1000000 + (i * 10000), i, i + 5, 1200,
            50000, 50000 + (i * 2000));

        CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

        // State should remain NOT_STARTED
        ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    }

    // 2. Trigger loss (would trigger NOT_STARTED → DONE if enabled)
    Connection.Send.NextPacketNumber = 20;

    // First send more data to have BytesInFlight for the loss
    CC->QuicCongestionControlOnDataSent(CC, 5000);

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(2400, 15, 20);

    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    // HyStart state unchanged: When HyStartEnabled=FALSE, loss handler skips
    // the `Cubic->HyStartState = HYSTART_DONE` assignment. Recovery still occurs.
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    ASSERT_TRUE(Cubic->IsInRecovery); // Recovery happens independent of HyStart
}

//
// Test: HyStart++ State Invariant - Growth Divisor Consistency
// Scenario: Verifies CWndSlowStartGrowthDivisor is consistent across all
// three states by transitioning NOT_STARTED → ACTIVE → DONE:
// - NOT_STARTED → divisor = 1
// - ACTIVE → divisor = 4 (triggered via delay increase detection)
// - DONE → divisor = 1 (triggered via loss)
//
TEST_F(CubicTest, HyStart_StateInvariant_GrowthDivisor)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20,  /*HyStart = */ true);

    // Invariant 1: NOT_STARTED → divisor = 1
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 1u);

    EnterHyStartActive();

    // Invariant 2: ACTIVE → divisor = 4
    ASSERT_EQ(Cubic->HyStartState, HYSTART_ACTIVE);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 4u);

    // Transition ACTIVE → DONE via loss.
    CC->QuicCongestionControlOnDataSent(CC, 5000);
    Connection.Send.NextPacketNumber = 30;
    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(2400, 25, 30);
    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    // Invariant 3: DONE → divisor = 1
    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
    ASSERT_EQ(Cubic->CWndSlowStartGrowthDivisor, 1u);
}

//
// Test: HyStart++ Recovery Exit with State Persistence
// Scenario: When exiting recovery (IsInRecovery: TRUE → FALSE), the HyStart
// state should remain unchanged. Recovery is orthogonal to HyStart++ state.
//
TEST_F(CubicTest, HyStart_RecoveryExit_StatePersistence)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 20, /*HyStart = */ true);

    // Transition to DONE and enter recovery
    CC->QuicCongestionControlOnDataSent(CC, 8000);
    Connection.Send.NextPacketNumber = 10;

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(2400, 5, 10);

    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
    ASSERT_TRUE(Cubic->IsInRecovery);

    // Exit recovery by ACKing packet sent after recovery started
    Connection.Send.NextPacketNumber = 20;

    QUIC_ACK_EVENT ExitAck = MakeAckEvent(1100000, 20, 25, 1200, 50000, 48000);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &ExitAck);

    // Recovery should be exited but HyStart state unchanged
    ASSERT_FALSE(Cubic->IsInRecovery);
    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE); // Still DONE
}

//
// Test: HyStart++ Spurious Congestion with State Verification
// Scenario: When a congestion event is declared spurious, window state is rolled
// back but HyStart state is NOT rolled back (it remains DONE). This is because
// HyStart++ state transitions are one-way and not part of the spurious recovery.
//
TEST_F(CubicTest, HyStart_SpuriousCongestion_StateNotRolledBack)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 25, /*HyStart = */ true);
    // Precondition: Start in NOT_STARTED
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    uint32_t WindowBeforeLoss = Cubic->CongestionWindow;

    // Trigger congestion event (NOT_STARTED → DONE)
    CC->QuicCongestionControlOnDataSent(CC, 10000);
    Connection.Send.NextPacketNumber = 15;

    QUIC_LOSS_EVENT LossEvent = MakeLossEvent(3600, 10, 15);

    CC->QuicCongestionControlOnDataLost(CC, &LossEvent);

    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
    ASSERT_TRUE(Cubic->IsInRecovery);
    // After loss: Window = InitialWindow * 7 / 10
    uint32_t ExpectedWindowAfterLoss = WindowBeforeLoss * 7 / 10;
    uint32_t WindowAfterLoss = Cubic->CongestionWindow;
    ASSERT_EQ(WindowAfterLoss, ExpectedWindowAfterLoss);

    // Declare congestion event spurious
    CC->QuicCongestionControlOnSpuriousCongestionEvent(CC);

    // Window state should be rolled back
    ASSERT_EQ(Cubic->CongestionWindow, WindowBeforeLoss);
    ASSERT_FALSE(Cubic->IsInRecovery);

    // BUT HyStart state should remain DONE (not rolled back)
    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);

    // Verify HyStart logic is still bypassed after spurious recovery
    QUIC_ACK_EVENT AckEvent = MakeAckEvent(1200000, 20, 25, 1200, 50000, 55000);

    CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

    // State still DONE (HyStart++ logic bypassed)
    ASSERT_EQ(Cubic->HyStartState, HYSTART_DONE);
}

//
// Test: HyStart++ Delay Increase Detection - Eta Calculation and Condition Check
// Scenario: Covers the case of  triggering the delay increase
// detection logic after sampling phase completes. Tests the Eta calculation and
// the condition that checks if RTT has increased beyond the threshold.
//
TEST_F(CubicTest, HyStart_DelayIncreaseDetection_EtaCalculationAndCondition)
{
    InitializeDefaultWithRtt(/*WindowPackets = */ 10, /*HyStart = */ true);

    // Verify initial state
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
    ASSERT_EQ(Cubic->HyStartAckCount, 0u);

    // Set Connection.Send.NextPacketNumber to a high value so HyStartRoundEnd is high
    // This ensures our ACKs with LargestAck < 100 won't trigger round boundary crossing
    Connection.Send.NextPacketNumber = 100;
    Cubic->HyStartRoundEnd = 100;  // Manually set to match

    // Set up initial MinRttInLastRound to enable delay increase detection
    Cubic->MinRttInLastRound = kHyStartBaselineRtt;

    // Phase 1: Send N_SAMPLING (8) ACKs to complete sampling phase
    // This fills up the HyStartAckCount and sets MinRttInCurrentRound
    // Use LargestAck values < HyStartRoundEnd (100) to stay in the same round
    for (uint32_t i = 0; i < QUIC_HYSTART_DEFAULT_N_SAMPLING; i++) {
        uint32_t BytesToSend = 1200;
        CC->QuicCongestionControlOnDataSent(CC, BytesToSend);

        QUIC_ACK_EVENT AckEvent = MakeAckEvent(
            1000000 + (i * 10000), 10 + i, 15 + i, BytesToSend,
            50000, kHyStartRttBelowThreshold);

        CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);
    }

    // After 8 ACKs, we should have completed sampling
    ASSERT_EQ(Cubic->HyStartAckCount, 8u);
    ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED); // Still in NOT_STARTED
    ASSERT_EQ(Cubic->MinRttInCurrentRound, kHyStartRttBelowThreshold);

    // Phase 2: Send one more ACK with MinRtt below the activation threshold
    // This triggers HyStartAckCount >= 8 and state is NOT_STARTED
    {
        uint32_t BytesToSend = 1200;
        CC->QuicCongestionControlOnDataSent(CC, BytesToSend);

        // MinRtt = 43000 < activation threshold (kHyStartBaselineRtt + Eta = 45000)
        QUIC_ACK_EVENT AckEvent = MakeAckEvent(1100000, 20, 25, BytesToSend, 50000, kHyStartRttBelowThreshold + 1000);

        CC->QuicCongestionControlOnDataAcknowledged(CC, &AckEvent);

        // Should still be in NOT_STARTED since delay increase wasn't significant
        ASSERT_EQ(Cubic->HyStartState, HYSTART_NOT_STARTED);
        ASSERT_EQ(Cubic->HyStartAckCount, 8u); // Should still be 8, not reset
    }
}
