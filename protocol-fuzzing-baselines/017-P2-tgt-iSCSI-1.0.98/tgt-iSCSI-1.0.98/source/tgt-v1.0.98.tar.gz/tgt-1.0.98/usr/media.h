/*
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#ifndef _MEDIA_H_
#define _MEDIA_H_

enum c_type {	/* Cartridge Types - Ref: smc3r06 - Table 20, page 37 */
	CART_UNSPECIFIED,
	CART_DATA,
	CART_CLEAN,
	CART_DIAGNOSTICS,
	CART_WORM,
	CART_MICROCODE,
};

#endif /* _MEDIA_H_ */

