/*
* Author: Christian Huitema
* Copyright (c) 2025, Private Octopus, Inc.
* All rights reserved.
*
* Permission to use, copy, modify, and distribute this software for any
* purpose with or without fee is hereby granted, provided that the above
* copyright notice and this permission notice appear in all copies.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL Private Octopus, Inc. BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "picoquic_internal.h"
#include "picoquic_unified_log.h"
#include "tls_api.h"
#include <stdlib.h>
#include <string.h>

/* Path management logic.
 */

uint64_t  picoquic_tuple_challenge_time(picoquic_path_t* path_x, picoquic_tuple_t* tuple, uint64_t current_time);

static int picoquic_count_tuples(picoquic_path_t* path_x)
{
    int nb_tuples = 0;
    picoquic_tuple_t* tuple = path_x->first_tuple;

    while (tuple != NULL) {
        nb_tuples++;
        tuple = tuple->next_tuple;
    }
    return nb_tuples;
}

/* The challenge of this tuple failed.
 * Update its status, and move it to the end of the list.
 */
void picoquic_set_tuple_challenge_failed(picoquic_path_t* path_x, picoquic_tuple_t* tuple, uint64_t current_time)
{
    picoquic_tuple_t* next_tuple = path_x->first_tuple;
    picoquic_tuple_t* previous_tuple = NULL;

    tuple->challenge_failed = 1;
    tuple->demotion_time = current_time + (path_x->retransmit_timer << PICOQUIC_CHALLENGE_REPEAT_MAX);

    while (next_tuple != NULL) {
        if (next_tuple == tuple) {
            if (previous_tuple == NULL) {
                path_x->first_tuple = next_tuple->next_tuple;
                next_tuple = path_x->first_tuple;
            }
            else
            {
                previous_tuple->next_tuple = next_tuple->next_tuple;
                next_tuple = previous_tuple->next_tuple;
            }
        }
        else {
            previous_tuple = next_tuple;
            next_tuple = next_tuple->next_tuple;

        }
    }
    if (previous_tuple == NULL) {
        path_x->first_tuple = tuple;
    }
    else
    {
        previous_tuple->next_tuple = tuple;
    }
    tuple->next_tuple = NULL;
}

/* picoquic_check_tuple_challenge_expired:
 * Mark as failed the tuples for which all challenge repeats were sent and the
 * last one timed out. This is done when selecting the next path, before checking
 * whether a path needs to be abandoned, so that the failure is acted upon in the
 * same call. Otherwise, an idle connection would only notice the failed
 * challenge on its next wake up, i.e., after some unrelated event.
 */
static void picoquic_check_tuple_challenge_expired(picoquic_path_t* path_x, uint64_t current_time)
{
    picoquic_tuple_t* tuple = path_x->first_tuple;

    while (tuple != NULL) {
        if (!tuple->challenge_failed && tuple->challenge_required && !tuple->challenge_verified &&
            tuple->challenge_repeat_count >= PICOQUIC_CHALLENGE_REPEAT_MAX &&
            current_time >= picoquic_tuple_challenge_time(path_x, tuple, current_time)) {
            /* The failed tuple moves to the end of the list: restart from the top. */
            picoquic_set_tuple_challenge_failed(path_x, tuple, current_time);
            tuple = path_x->first_tuple;
        }
        else {
            tuple = tuple->next_tuple;
        }
    }
}

uint8_t* picoquic_prepare_tuple_challenge_frames(picoquic_cnx_t* cnx, picoquic_path_t* path_x,
    picoquic_tuple_t* tuple,
    uint8_t* bytes_next, uint8_t* bytes_max,
    int* more_data, int* is_pure_ack, int* is_challenge_padding_needed,
    uint64_t current_time, uint64_t* next_wake_time)
{
    if (tuple->challenge_verified == 0 && tuple->challenge_failed == 0) {
        uint64_t next_challenge_time = picoquic_tuple_challenge_time(path_x, tuple, current_time);

        if (next_challenge_time > current_time) {
            if (next_challenge_time < *next_wake_time) {
                *next_wake_time = next_challenge_time;
                SET_LAST_WAKE(cnx->quic, PICOQUIC_SENDER);
            }
        }
        else {
            uint8_t* bytes_challenge = bytes_next;

            if (tuple->challenge_repeat_count < PICOQUIC_CHALLENGE_REPEAT_MAX) {
                /* When blocked, repeat the path challenge or wait */

                bytes_next = picoquic_format_path_challenge_frame(bytes_next, bytes_max, more_data, is_pure_ack,
                    tuple->challenge[tuple->challenge_repeat_count]);
                if (bytes_next > bytes_challenge) {
                    tuple->challenge_time = current_time;
                    tuple->challenge_repeat_count++;
                    if (!tuple->is_nat_rebinding) {
                        if (cnx->client_mode || ((path_x->bytes_sent + PICOQUIC_ENFORCED_INITIAL_MTU) <= path_x->received)) {
                            *is_challenge_padding_needed = 1;
                        }
                        else {
                            /* Sending a full size packet would defeat the amplification limits, so we take
                             * advantage of the escape clause in RFC 9000, "An endpoint MUST expand datagrams
                             * that contain a PATH_CHALLENGE frame to at least the smallest allowed maximum
                             * datagram size of 1200 bytes, unless the anti-amplification limit for the path
                             * does not permit sending a datagram of this size."
                             */
                            *is_challenge_padding_needed = 0;
                        }
                    }
                    else {
                        /* never pad the packets sent in response to NAT rebinding. */
                        *is_challenge_padding_needed = 0;
                    }
                }

                /* Reset the next challenge time to match the new challenge count */
                next_challenge_time = picoquic_tuple_challenge_time(path_x, tuple, current_time);
                if (next_challenge_time < *next_wake_time) {
                    *next_wake_time = next_challenge_time;
                    SET_LAST_WAKE(cnx->quic, PICOQUIC_SENDER);
                }
            }
            else {
                /* This particular tuple failed. Normally, this is already detected
                 * when selecting the next path, see picoquic_check_tuple_challenge_expired. */
                picoquic_set_tuple_challenge_failed(path_x, tuple, current_time);
            }
        }
    }

    if (tuple->response_required) {
        uint8_t* bytes_response = bytes_next;
        if ((bytes_next = picoquic_format_path_response_frame(bytes_response, bytes_max,
            more_data, is_pure_ack, tuple->challenge_response)) > bytes_response) {
            tuple->response_required = 0;
            *is_challenge_padding_needed |= cnx->client_mode || ((path_x->bytes_sent + PICOQUIC_ENFORCED_INITIAL_MTU) <= path_x->received);
        }
    }

    /* TODO: consider adding an address discovery frame. */

    return bytes_next;
}

uint8_t* picoquic_prepare_path_challenge_frames(picoquic_cnx_t* cnx, picoquic_path_t* path_x,
    uint8_t* bytes_next, uint8_t* bytes_max,
    int* more_data, int* is_pure_ack, int* is_challenge_padding_needed,
    uint64_t current_time, uint64_t* next_wake_time)
{
    return picoquic_prepare_tuple_challenge_frames(cnx, path_x, path_x->first_tuple,
        bytes_next, bytes_max, more_data, is_pure_ack, is_challenge_padding_needed,
        current_time, next_wake_time);
}

 /* Prepare packet containing only path control frames. */
int picoquic_prepare_path_control_packet(picoquic_cnx_t* cnx, picoquic_path_t* path_x, picoquic_tuple_t* tuple,
    picoquic_packet_t* packet,
    uint64_t current_time, uint8_t* send_buffer, size_t send_buffer_max, size_t* send_length,
    uint64_t* next_wake_time)
{
    int ret = 0;
    picoquic_packet_type_enum packet_type = picoquic_packet_1rtt_protected;
    int is_pure_ack = 1;
    size_t header_length = 0;
    size_t length = 0;
    size_t checksum_overhead = picoquic_get_checksum_length(cnx, picoquic_epoch_1rtt);
    size_t send_buffer_min_max = (send_buffer_max > path_x->send_mtu) ? path_x->send_mtu : send_buffer_max;
    uint8_t* bytes = packet->bytes;
    uint8_t* bytes_max = bytes + send_buffer_min_max - checksum_overhead;
    uint8_t* bytes_next;
    int more_data = 0;
    int is_challenge_padding_needed = 0;
    picoquic_packet_context_t* pkt_ctx = (cnx->is_multipath_enabled) ?
        &path_x->pkt_ctx :
        &cnx->pkt_ctx[picoquic_packet_context_application];

    /* TODO: will use the local CID specified for the path. There should be a distinct
    * CID specified for the tuple.
     */
    packet->pc = picoquic_packet_context_application;

    length = picoquic_predict_packet_header_length(
        cnx, packet_type, pkt_ctx);
    packet->ptype = packet_type;
    packet->offset = length;
    header_length = length;
    packet->sequence_number = pkt_ctx->send_sequence;
    packet->send_time = current_time;
    packet->send_path = path_x;
    bytes_next = bytes + length;

    /* If required, prepare challenge and response frames.
     * These frames will be sent immediately, regardless of pacing or flow control.
     */
    bytes_next = picoquic_prepare_tuple_challenge_frames(cnx, path_x, tuple,
        bytes_next, bytes_max, &more_data, &is_pure_ack, &is_challenge_padding_needed,
        current_time, next_wake_time);

    /* Compute the length before pacing block */
    length = bytes_next - bytes;

    if (cnx->is_address_discovery_provider) {
        /* If a new address was learned, prepare an observed address frame */
        /* TODO: tie this code to processing of paths */
        bytes_next = picoquic_prepare_observed_address_frame(bytes_next, bytes_max,
            path_x, tuple, current_time, next_wake_time, &more_data, &is_pure_ack);
    }

    if (ret == 0 && length > header_length) {
        /* Ensure that all packets are properly padded before being sent. */

        if (is_challenge_padding_needed && length < PICOQUIC_ENFORCED_INITIAL_MTU) {
            length = picoquic_pad_to_target_length(bytes, length, (uint32_t)(send_buffer_min_max - checksum_overhead));
        }
        else {
            length = picoquic_pad_to_policy(cnx, bytes, length, (uint32_t)(send_buffer_min_max - checksum_overhead));
        }
    }
    else {
        length = 0;
    }
    packet->length = length;
    picoquic_finalize_and_protect_packet_tuple(cnx, packet,
        ret, length, header_length, checksum_overhead,
        send_length, send_buffer, send_buffer_min_max,
        path_x, current_time, tuple, !is_pure_ack);

    if (*send_length > 0) {
        *next_wake_time = current_time;
        SET_LAST_WAKE(cnx->quic, PICOQUIC_SENDER);

        if (ret == 0 && picoquic_cnx_is_still_logging(cnx)) {
            picoquic_log_cc_dump(cnx, current_time);
        }
    }
    return ret;
}


/* picoquic_tuple_challenge_time:
 * Compute the time at which the next challenge for that path should be sent.
 */
uint64_t  picoquic_tuple_challenge_time(picoquic_path_t* path_x, picoquic_tuple_t* tuple, uint64_t current_time)
{
    /* "Challenge time" holds the time at which the last challenge was set. We
     * use the value to compute an estimate of the RTT */
    uint64_t next_challenge_time = tuple->challenge_time;

    if (tuple->challenge_repeat_count == 0) {
        next_challenge_time = current_time;
    }
    else {
        if (tuple->challenge_repeat_count >= 2) {
            next_challenge_time += path_x->retransmit_timer << (tuple->challenge_repeat_count - 1);
        }
        else {
            next_challenge_time += PICOQUIC_INITIAL_RETRANSMIT_TIMER;
        }
    }

    return next_challenge_time;
}

/* Remove old tuples that are not needed anymore.
 */
void picoquic_delete_demoted_tuples(picoquic_cnx_t* cnx, uint64_t current_time, uint64_t* next_wake_time)
{
    for (int path_index = 0; path_index < cnx->nb_paths; path_index++) {
        picoquic_path_t* path_x = cnx->path[path_index];
        if (!path_x->path_is_demoted) {
            /* examine each tuple record */
            picoquic_tuple_t* tuple = path_x->first_tuple;
            picoquic_tuple_t* next_tuple;

            while (tuple != NULL && (next_tuple = tuple->next_tuple) != NULL) {
                if (next_tuple->challenge_failed) {
                    if (current_time > next_tuple->demotion_time) {
                        picoquic_delete_tuple(path_x, next_tuple, 0);
                        continue;
                    }
                    else if (*next_wake_time > next_tuple->demotion_time) {
                        *next_wake_time = next_tuple->demotion_time;
                        SET_LAST_WAKE(cnx->quic, PICOQUIC_SENDER);
                    }
                }
                tuple = next_tuple;
            }
        }
    }
    cnx->tuple_demotion_needed = 0;
}

 /* picoquic_check_path_control_needed:
  * Find whether a path needs to send a challenge or a response.
  * Todo: consider the need to keep alive the paths marked as "backup"
  */
picoquic_tuple_t* picoquic_check_path_control_needed(picoquic_cnx_t* cnx, picoquic_path_t* path_x, uint64_t current_time, uint64_t* next_wake_time)
{
    /* examine each tuple record */
    picoquic_tuple_t* tuple = path_x->first_tuple;

    while (tuple != NULL) {
        if (tuple->challenge_failed) {
            if (tuple != path_x->first_tuple && current_time > tuple->demotion_time) {
                cnx->tuple_demotion_needed = 1;
            }
            /* go to next tuple */
        }
        else if (tuple->response_required) {
            /* selected */
            break;
        }
        else if (tuple->challenge_required && !tuple->challenge_verified) {
            uint64_t next_challenge_time = picoquic_tuple_challenge_time(path_x, tuple, current_time);
            if (current_time >= next_challenge_time) {
                break;
            }
            else if (next_challenge_time < *next_wake_time) {
                *next_wake_time = next_challenge_time;
                SET_LAST_WAKE(cnx->quic, PICOQUIC_SENDER);
            }
        }
        tuple = tuple->next_tuple;
    }
    return tuple;
}

/* Path stalled: peer active within 1 RTT, but our oldest unacked packet is older than 2 RTT plus ack delay.
 * With ignore_pure_ack, only ack-eliciting packets count, since the peer may acknowledge pure ACKs late. */
int picoquic_is_ack_path_stalled(picoquic_cnx_t* cnx, picoquic_path_t* path_x, uint64_t current_time, int ignore_pure_ack)
{
    picoquic_packet_t* oldest = (ignore_pure_ack) ? picoquic_first_ack_eliciting_packet(&path_x->pkt_ctx) : path_x->pkt_ctx.pending_first;
    uint64_t delay = 2 * path_x->smoothed_rtt + cnx->remote_parameters.max_ack_delay;

    return (cnx->is_multipath_enabled && oldest != NULL && oldest->send_time + delay < current_time &&
        cnx->latest_receive_time + path_x->smoothed_rtt > current_time);
}

/* Find available paths:
* Check that there is at least one available path. If not, promote one of the candidates.
*/
int picoquic_verify_path_available(picoquic_cnx_t* cnx, picoquic_path_t** next_path, uint64_t* min_retransmit, uint64_t current_time)
{
    int backup_index = -1;
    int nb_available = 0;
    uint64_t best_available_retransmit = UINT64_MAX;
    uint64_t best_backup_retransmit = UINT64_MAX;
    picoquic_stream_head_t* next_stream = picoquic_find_ready_stream(cnx);

    *min_retransmit = 0;

    for (int path_index = 0; path_index < cnx->nb_paths; path_index++) {
        picoquic_path_t* path_x = cnx->path[path_index];
        if (path_x->first_tuple->challenge_verified &&
            !path_x->path_is_demoted) {
            /* Set the congestion algorithm if not already done */
            if (cnx->congestion_alg != NULL && path_x->congestion_alg_state == NULL) {
                cnx->congestion_alg->alg_init(path_x, cnx->congestion_alg_option_string, current_time);
            }
            /* track the available paths. A backup path that the next ready stream is
             * explicitly pinned to (picoquic_set_stream_path_affinity) is treated as
             * available here, not backup: affinity is a deliberate per-stream override,
             * and letting it fall into the backup bucket means it would only ever be
             * picked via the retransmit-count promotion below, never because the stream
             * is waiting on it. */
            if (path_x->path_is_backup && !(next_stream != NULL && next_stream->affinity_path == path_x)) {
                if (backup_index < 0 || path_x->nb_retransmit < best_backup_retransmit) {
                    best_backup_retransmit = path_x->nb_retransmit;
                    backup_index = path_index;
                }
            }
            else
            {
                if (path_x->nb_retransmit < best_available_retransmit) {
                    best_available_retransmit = path_x->nb_retransmit;
                    *next_path = path_x;
                    nb_available = 0;
                }
                nb_available++;
            }
        }
    }
    if (best_available_retransmit > 0 && best_backup_retransmit < best_available_retransmit) {
        cnx->path[backup_index]->path_is_backup = 0;
        *next_path = cnx->path[backup_index];
        nb_available = 1;
        *min_retransmit = best_backup_retransmit;
        /* TODO: some logging. Queue PATH_AVAILABLE frame? */
    }
    else
    {
        *min_retransmit = best_available_retransmit;
    }
    return nb_available;
}

/*
 * Produce a sorting of available paths
 */

/* A path is a candidate if it is validated, not demoted, has the fewest retransmits, and is not
 * a backup path. A backup path pinned by stream affinity (picoquic_set_stream_path_affinity) is
 * still a candidate, so that the pinned stream does not stall forever. */
static int picoquic_is_path_candidate(picoquic_path_t* path_x, uint64_t min_retransmit, picoquic_stream_head_t* next_stream)
{
    return (path_x->first_tuple->challenge_verified && !path_x->path_is_demoted && path_x->nb_retransmit <= min_retransmit &&
        (!path_x->path_is_backup || (next_stream != NULL && next_stream->affinity_path == path_x)));
}

/* Keep the nominal ack path unless in trouble, candidates changed, or a healthy path has rtt_min lower by 1/8. */
static int picoquic_update_nominal_ack_path(picoquic_cnx_t* cnx, uint64_t current_time, uint64_t min_retransmit,
    picoquic_stream_head_t* next_stream)
{
    int i_min_rtt = -1;
    int i_nominal = -1;
    int is_nominal_stalled = 0;
    int is_min_rtt_stalled = 0;
    int nb_candidates = 0;

    for (int path_index = 0; path_index < cnx->nb_paths; path_index++) {
        picoquic_path_t* path_x = cnx->path[path_index];
        path_x->is_nominal_ack_path = 0;
        if (picoquic_is_path_candidate(path_x, min_retransmit, next_stream)) {
            int is_stalled = picoquic_is_ack_path_stalled(cnx, path_x, current_time, 1);
            nb_candidates++;
            if (path_x->unique_path_id == cnx->nominal_ack_path_id) {
                i_nominal = path_index;
                is_nominal_stalled = is_stalled;
            }
            /* Best candidate: fewest retransmits, not stalled, lowest rtt_min */
            if (i_min_rtt < 0 ||
                path_x->nb_retransmit < cnx->path[i_min_rtt]->nb_retransmit ||
                (path_x->nb_retransmit == cnx->path[i_min_rtt]->nb_retransmit && is_stalled < is_min_rtt_stalled) ||
                (path_x->nb_retransmit == cnx->path[i_min_rtt]->nb_retransmit && is_stalled == is_min_rtt_stalled &&
                    path_x->rtt_min < cnx->path[i_min_rtt]->rtt_min)) {
                i_min_rtt = path_index;
                is_min_rtt_stalled = is_stalled;
            }
        }
    }
    if (i_nominal < 0 || nb_candidates != cnx->nominal_nb_candidates ||
        cnx->path[i_nominal]->nb_retransmit > 0 || is_nominal_stalled ||
        (i_min_rtt >= 0 && i_min_rtt != i_nominal && !is_min_rtt_stalled &&
            cnx->path[i_min_rtt]->nb_retransmit == 0 &&
            cnx->path[i_min_rtt]->rtt_min + cnx->path[i_min_rtt]->rtt_min / 8 < cnx->path[i_nominal]->rtt_min)) {
        i_nominal = i_min_rtt;
        cnx->nominal_nb_candidates = nb_candidates;
        if (i_nominal >= 0) {
            cnx->nominal_ack_path_id = cnx->path[i_nominal]->unique_path_id;
        }
    }
    if (i_nominal >= 0) {
        cnx->path[i_nominal]->is_nominal_ack_path = 1;
    }
    return i_nominal;
}

void picoquic_sort_available_paths(picoquic_cnx_t* cnx, uint64_t current_time, uint64_t* next_wake_time,
    picoquic_path_t** next_path, uint64_t min_retransmit, picoquic_tuple_t** next_tuple)
{
    int selected = -1;
    int fallback_cwin = -1;
    int fallback_pacing = -1;
    uint64_t pacing_time_next = UINT64_MAX;
    picoquic_stream_head_t* next_stream = picoquic_find_ready_stream(cnx);
    int is_cnx_data_ready = (cnx->is_datagram_ready || cnx->first_misc_frame != NULL || cnx->queue_data_repeat_tree.size > 0);
    int i_nominal = picoquic_update_nominal_ack_path(cnx, current_time, min_retransmit, next_stream);
    int is_ack_needed = (i_nominal >= 0) ? picoquic_is_ack_needed(cnx, current_time, next_wake_time, 0, 0) : 0;

    /* Round robin: select the first path allowed by pacing that is the nominal path with an ACK due, or has data and window. */
    for (int k = 0; selected < 0 && k < cnx->nb_paths; k++) {
        int path_index = (cnx->last_path_polled + 1 + k) % cnx->nb_paths;
        picoquic_path_t* path_x = cnx->path[path_index];

        if (picoquic_is_path_candidate(path_x, min_retransmit, next_stream)) {
            path_x->polled++;
            if (!picoquic_is_sending_authorized_by_pacing(cnx, path_x, current_time, &pacing_time_next)) {
                path_x->paced++;
            }
            else if (path_index == i_nominal && is_ack_needed) {
                selected = path_index;
            }
            else if (path_x->bytes_in_transit >= path_x->cwin || path_x->bytes_in_transit >= cnx->quic->cwin_max) {
                path_x->congested++;
                if (fallback_pacing < 0 || path_x->last_sent_time < cnx->path[fallback_pacing]->last_sent_time) {
                    fallback_pacing = path_index;
                }
            }
            else if (is_cnx_data_ready || path_x->is_datagram_ready ||
                (next_stream != NULL && (next_stream->affinity_path == NULL || next_stream->affinity_path == path_x))) {
                selected = path_index;
            }
            else if (fallback_cwin < 0 || path_x->last_sent_time < cnx->path[fallback_cwin]->last_sent_time) {
                fallback_cwin = path_index;
            }
        }
    }
    if (selected < 0) {
        /* Nothing ready: least recently used path with window, else paced ok, else path 0; wake up for paced paths. */
        selected = (fallback_cwin >= 0) ? fallback_cwin : ((fallback_pacing >= 0) ? fallback_pacing : 0);
        if (pacing_time_next < *next_wake_time) {
            *next_wake_time = pacing_time_next;
            SET_LAST_WAKE(cnx->quic, PICOQUIC_SENDER);
        }
    }
    cnx->last_path_polled = selected;
    *next_path = cnx->path[selected];
    (*next_path)->selected++;
    *next_tuple = (*next_path)->first_tuple;
}

/*
* For each path:
*    - For each tuple:
*         - if a first challenge is required now, the path/tuple is selected immediately.
*         - if a response is required now, the path/tuple is selected immediately.
*         - if a challenge or a response is required after the current time:
*               - the next time is update.
* If there is not an immediate selection:
*    for each path in available mode. in round robin order:
*       - if there is data or ACK to send:
*           the path is selected, with first tuple.
* If no path selected:
*    select the default path or tuple.
 */
void picoquic_select_next_path_tuple(picoquic_cnx_t* cnx, uint64_t current_time, uint64_t* next_wake_time,
    picoquic_path_t** next_path, picoquic_tuple_t** next_tuple)
{
    int nb_available = 0;
    uint64_t min_retransmit = 0;

    *next_path = NULL;
    *next_tuple = NULL;

    /* First check whether path contol messages are needed */
    for (int path_index = 0; path_index < cnx->nb_paths; path_index++)
    {
        if (cnx->path[path_index]->path_is_demoted) {
            continue;
        }

        if (path_index == 0 || cnx->cnx_state >= picoquic_state_ready) {
            /* Detect the challenges that just failed, before deciding to abandon the path */
            picoquic_check_tuple_challenge_expired(cnx->path[path_index], current_time);
        }

        if (cnx->is_multipath_enabled && cnx->path[path_index]->first_tuple->challenge_failed && !cnx->path[path_index]->path_abandon_sent) {
            if (picoquic_abandon_path(cnx, cnx->path[path_index]->unique_path_id,
                PICOQUIC_TRANSPORT_UNSTABLE_INTERFACE, current_time) == PICOQUIC_ERROR_PATH_LAST_REMAINING) {
                /* This was the only path left, and it just failed validation.
                 * There is no other path to fall back on, and very likely no
                 * way to reach the peer either: close locally, the way the
                 * idle timer does, instead of trying to deliver a
                 * CONNECTION_CLOSE that has nowhere to go. */
                cnx->local_error = PICOQUIC_ERROR_PATH_LAST_REMAINING;
                picoquic_connection_disconnect(cnx);
            }
        }
        else if (path_index > 0 && cnx->cnx_state < picoquic_state_ready) {
            /* Do not try to send packets on paths different from path[0] if
             * the connection is not fully established. At this point, the
             * other paths are not guaranteed to be fully established, and
             * there is a significant rsik of causing crashes when trying
             * to use them.
             */
            continue;
        }
        else if ((*next_tuple = picoquic_check_path_control_needed(cnx, cnx->path[path_index], current_time, next_wake_time)) != NULL) {
            *next_path = cnx->path[path_index];
            (*next_path)->challenger++;
            break;
        }
        else if (cnx->nb_paths > 0 && cnx->path[path_index]->first_tuple->challenge_verified && cnx->path[path_index]->nb_retransmit > 0 &&
            cnx->cnx_state == picoquic_state_ready && cnx->path[path_index]->bytes_in_transit == 0) {
            cnx->path[path_index]->is_multipath_probe_needed = 1;
            *next_path = cnx->path[path_index];
            *next_tuple = (*next_path)->first_tuple;
            (*next_path)->challenger++;
            break;
        }
    }
    if (*next_path != NULL) {
        /* we are done */
    }
    else  if (cnx->nb_paths == 1) {
        /* No choice, just use this path -- this is the default if multipath is not selected. */
        *next_path = cnx->path[0];
        *next_tuple = (*next_path)->first_tuple;
    }
    else if ((nb_available = picoquic_verify_path_available(cnx, next_path, &min_retransmit, current_time)) < 2) {
        /* Only 0 or 1 path to chose from. Just select that. */
        if (*next_path == NULL) {
            *next_path = cnx->path[0];
        }
        /* That path is the nominal ack path, unless stalled with ack-eliciting packets: then a healthy backup carries ACKs, without promotion. */
        picoquic_path_t* ack_path = *next_path;
        if (cnx->is_multipath_enabled && cnx->nb_paths > 1 && picoquic_is_ack_path_stalled(cnx, *next_path, current_time, 1)) {
            for (int i = 0; ack_path == *next_path && i < cnx->nb_paths; i++) {
                picoquic_path_t* path_x = cnx->path[i];
                if (path_x != *next_path && path_x->path_is_backup && path_x->first_tuple->challenge_verified &&
                    !path_x->path_is_demoted && !picoquic_is_ack_path_stalled(cnx, path_x, current_time, 1)) {
                    ack_path = path_x;
                }
            }
        }
        for (int i = 0; i < cnx->nb_paths; i++) {
            cnx->path[i]->is_nominal_ack_path = (cnx->path[i] == ack_path);
        }
        if (ack_path != *next_path && picoquic_is_ack_needed(cnx, current_time, next_wake_time, picoquic_packet_context_application, 0) &&
            picoquic_is_sending_authorized_by_pacing(cnx, ack_path, current_time, next_wake_time)) {
            *next_path = ack_path;
        }
        *next_tuple = (*next_path)->first_tuple;
    }
    else {
        /* Several paths are available. We will chose from that, looking at
        * available path that can send ACK, or paced data, or congestion
        * controlled data.
         */
        picoquic_sort_available_paths(cnx, current_time, next_wake_time, next_path, min_retransmit, next_tuple);
    }
}




 /*
 Find path of incoming packet

 A path is defined by a pair of addresses. The path is created by the client
 when it learns about a new local or remote address. It is created by the
 server when it receives data from a not yet identified address pair.

 We associate a local CID with a path. This is the CID that the peer uses
 to send packet. This is a loose association. When a packet is received, the
 packet is associated with a path based on the address tuple. If this is a
 new tuple, a new path should be created, unless too many paths have been
 created already (some heuristics needed there).

 Different scenarios play here:

  - If the incoming CID has not yet been seen, we treat arrival as a
    migration attempt and pursue the validation sequence.

  - If this is the same incoming CID as an existing path, we treat it
    as an indication of NAT rebinding. We may need some heuristic to
    decide whether this is legit or an attack. If this may be legit, we
    create a new path and send challenges on both the new and the old path.

  - If this is the same tuple and a different incoming CID, we treat that
    as an attempt by the peer to change the CID for privacy reason. On this
    event, the server picks a new CID for the path if available. (May need
    some safety there, e.g. only pick a new CID if the incoming CID sequence
    is higher than the old one.)

 NAT rebinding should only happen if the address was changed in the
 network, either by a NAT or by an attacker. NATs are:

  - rare but not unheard of in front of servers

  - rare with IPv6

   - rare if the connection is sustained

 A small problem here is that the QUIC test suite include some pretty
 unrealistic NAT rebinding simulations, so we cannot be too strict. In
 order to pass the test suites, we will accept the first rebinding
 attempt as genuine, and be more picky with the next ones. They may have
 to wait until validation timers expire.

 Local CID are kept in a list, and are associated with paths by a reference.
 If a local CID is retired, the reference is zeroed. The retired CID stays
 registered for a grace period so late packets are accepted, but it is never
 reused for a path. When a new packet arrives on path with a new CID, the
 reference is reset.

 If we cannot associate an existing path with a packet and also
 cannot create a new path, we treat the packet as arriving on the
 default path.
 */

int picoquic_find_incoming_path(picoquic_cnx_t* cnx,
    picoquic_packet_header* ph,
    struct sockaddr* addr_from,
    struct sockaddr* addr_to,
    int if_index_to,
    uint64_t current_time,
    int* p_path_id,
    picoquic_tuple_t** tuple_ptr)
{
    int ret = 0;
    picoquic_path_t* path_x = NULL;
    picoquic_tuple_t* tuple = NULL;
    int path_id = (ph->l_cid == NULL) ? 0 : picoquic_find_path_by_unique_id(cnx, ph->l_cid->path_id);

    if (path_id < 0) {
        /* Either this path has not yet been created, or it was already destroyed.
        * The packet decryption was successful, which means that the CID is valid,
        * but on the server side we might have a "probe".
         * A CID retired by the peer is never used to create a path.
         */
        if (!ph->l_cid->is_retired &&
            cnx->nb_paths < PICOQUIC_NB_PATH_TARGET &&
            (cnx->quic->is_port_blocking_disabled || !picoquic_check_addr_blocked(addr_from)) &&
            picoquic_create_path(cnx, current_time, addr_to, addr_from, if_index_to, ph->l_cid->path_id) > 0) {
            /* if we do create a new path, it should have the right path_id. We cannot
            * assume that paths will be created in the full order, so that means we may
            * have to create "empty" paths in invalid state. Or, more simply,
            * create a path and override the unique path id, which should be OK
            * as that unique ID does not exist.
            * TODO: modify path creation to force path_id, return error if impossible.
             */
            path_id = cnx->nb_paths - 1;
            path_x = cnx->path[path_id];

            /* when creating the path, we need to copy the dest CID and chose
             * destination CID with the matching path ID.
             */
            path_x->first_tuple->p_local_cnxid = picoquic_find_local_cnxid(cnx, path_x->unique_path_id, &ph->dest_cnx_id);
            picoquic_assign_peer_cnxid_to_tuple(cnx, path_x, path_x->first_tuple);
        }
        else {
            /* If we cannot create a new path, return an error.
             */
            path_id = -1;
            ret = PICOQUIC_ERROR_PATH_ID_INVALID;
        }
    }
    else
    {
        path_x = cnx->path[path_id];
        tuple = path_x->first_tuple;

        /* If the local CID is not set, set it */
        if (path_x->first_tuple->p_local_cnxid == NULL) {
            path_x->first_tuple->p_local_cnxid = picoquic_find_local_cnxid(cnx, path_x->unique_path_id, &ph->dest_cnx_id);
            /* A late packet on a retired CID leaves the reference unset, and does not renew the remote CID. */
            if (path_x->first_tuple->p_local_cnxid != NULL &&
                !cnx->client_mode && cnx->is_multipath_enabled && path_x->first_tuple->challenge_verified) {
                /* If the peer renewed its connection id, the retire connection ID frame may already
                 * have arrived on a separate path. If the server noticed that, it should also renew
                 * its "remote path" ID */
                (void)picoquic_renew_connection_id(cnx, path_id);
            }
        }

        /* Treat the special case of the unkown local address, which should only happen
         * for clients and for the first tuple. */
        if (path_x->first_tuple->local_addr.ss_family == AF_UNSPEC && addr_to->sa_family != AF_UNSPEC) {
            picoquic_store_addr(&cnx->path[path_id]->first_tuple->local_addr, addr_to);
        }

        /* Look for the best match among existing tuples */
        while (tuple != NULL) {
            /* If the addresses match, we are good. */
            if (picoquic_compare_addr(addr_from, (struct sockaddr*)&tuple->peer_addr) == 0 &&
                picoquic_compare_addr(addr_to, (struct sockaddr*)&tuple->local_addr) == 0) {
                break;
            }
            else
            {
                tuple = tuple->next_tuple;
            }
        }
        if (tuple == NULL) {
            /* If the addresses do not match, we have two possibilities:
            * either the creation of a new tuple, or a NAT rebinding on an existing tuple.
            * In all cases, we need to create a new tuple. In the NAT rebinding cases, we
            * need to be a bit more agressive, i.e., immediately promote the new tuple
            * as the default. In fact, we MUST do that if the CID also changed, otherwise
            * we will stumble on a bug if the packet asks to retire the CID.
            * 
            * We should really look mostly at whether the incoming packet is non probing,
            * but this requires decodingthe packet -- and testing that its syntax is correct,
            * not a duplicate, etc.
            * 
            */

            /* Last resort (RFC 9000 9.5): no spare peer CID but same DCID, share the current one so spoofed addresses cannot exhaust CIDs. */
            /* The number of tuples is capped, so that changing addresses cannot create unlimited tuples. */
            int is_cid_shared = picoquic_check_cid_for_new_tuple(cnx, path_x->unique_path_id) != 0 &&
                path_x->first_tuple->p_remote_cnxid != NULL && path_x->first_tuple->p_local_cnxid != NULL &&
                picoquic_count_tuples(path_x) < PICOQUIC_MAX_SHARED_CID_TUPLES &&
                picoquic_compare_connection_id(&path_x->first_tuple->p_local_cnxid->cnx_id, &ph->dest_cnx_id) == 0;

            if ((is_cid_shared || picoquic_check_cid_for_new_tuple(cnx, path_x->unique_path_id) == 0) &&
                (tuple = picoquic_create_tuple(path_x, addr_to, addr_from, if_index_to)) != NULL &&
                (is_cid_shared ? picoquic_share_peer_cnxid_with_tuple(path_x, tuple) :
                    picoquic_assign_peer_cnxid_to_tuple(cnx, path_x, tuple)) == 0) {
                picoquic_set_tuple_challenge(tuple, current_time, cnx->quic->use_constant_challenges);

#if 1
                tuple->challenge_required = 1;
#else
                if (path_x->first_tuple->p_local_cnxid != NULL &&
                    picoquic_compare_connection_id(&path_x->first_tuple->p_local_cnxid->cnx_id, &ph->dest_cnx_id) != 0 &&
                    cnx->is_multipath_enabled) {
                    /* Treat this as a NAT rebinding. */
                    picoquic_tuple_t* old_tuple = path_x->first_tuple;
                    /* We need to replace the first tuple by this tuple. */
                    picoquic_set_first_tuple(path_x, tuple);
                    /* We deliberately mark the path as verified in the case of NAT Traversal.
                    * This is a tradeoff. If this genually is a NAT traversal, continuing to 
                    * use the old path for 1 RTT before the challenge result is received leads
                    * to losing 1 RTT worth of packets. If this is a spoofed address, we will be
                    * able to recover upon receiving the challenge response from the old address,
                    * and the new address will be demoted.
                    */
                    tuple->challenge_verified = 1;
                    /* set a challenge on the old tuple to recover from spoofed addresses */
                    picoquic_set_tuple_challenge(old_tuple, current_time, cnx->quic->use_constant_challenges);
                    old_tuple->challenge_required = 1;
                    old_tuple->challenge_verified = 0;
                }
                else {
                    /* Treat this a new tuple challenge. */
                    tuple->challenge_required = 1;
                }
#endif
            }
            /* TODO: clean up in case of failure. */
        }
        else {
            /* If the addresses do match, but the CID do not, we have a case of CID migration.
             */
            if (tuple == path_x->first_tuple && path_x->first_tuple->p_local_cnxid != NULL &&
                picoquic_compare_connection_id(&path_x->first_tuple->p_local_cnxid->cnx_id, &ph->dest_cnx_id) != 0) {
                /* A late packet with a CID retired by the peer is not a migration: the lookup skips retired CID. */
                picoquic_local_cnxid_t* l_cid = picoquic_find_local_cnxid(cnx, path_x->unique_path_id, &ph->dest_cnx_id);
                if (l_cid != NULL) {
                    path_x->first_tuple->p_local_cnxid = l_cid;
                    if (cnx->client_mode == 0) {
                        (void)picoquic_renew_connection_id(cnx, path_id);
                    }
                }
            }
        }
    }
    *p_path_id = path_id;
    if (path_id >= 0 && ret == 0) {
        cnx->path[path_id]->last_packet_received_at = current_time;
    }
    *tuple_ptr = tuple;

    return ret;
}

void picoquic_promote_tuple_to_default(
    picoquic_path_t* path_x, picoquic_tuple_t* tuple, picoquic_tuple_t* previous_tuple, uint64_t current_time)
{
    picoquic_tuple_t* old_first = path_x->first_tuple;

    if (tuple != NULL && previous_tuple != NULL) {
        /* A port-only change keeps CC and RTT (RFC 9000, section 9.4) */
        int is_new_address = picoquic_compare_ip_addr((struct sockaddr*)&old_first->peer_addr,
            (struct sockaddr*)&tuple->peer_addr) != 0 ||
            (old_first->local_addr.ss_family != 0 && tuple->local_addr.ss_family != 0 &&
                picoquic_compare_ip_addr((struct sockaddr*)&old_first->local_addr,
                    (struct sockaddr*)&tuple->local_addr) != 0);

        previous_tuple->next_tuple = tuple->next_tuple;
        tuple->next_tuple = path_x->first_tuple;
        path_x->first_tuple = tuple;
        if (tuple->to_preferred_address) {
            path_x->cnx->remote_parameters.migration_disabled = 0;
            picoquic_log_app_message(path_x->cnx, "Migration to server preferred address successful on path %" PRIu64, path_x->unique_path_id);
        }
        picoquic_reset_path_mtu(path_x);
        if (is_new_address) {
            picoquic_reset_path_congestion(path_x->cnx, path_x, current_time);
        }
    }
}

void picoquic_promote_tuple_after_nat(picoquic_path_t* path_x, picoquic_tuple_t* tuple, uint64_t current_time)
{
    /* find the previous tuple */
    picoquic_tuple_t* old_tuple = path_x->first_tuple;
    picoquic_tuple_t* previous_tuple = path_x->first_tuple;
    while (previous_tuple != NULL) {
        if (previous_tuple->next_tuple == tuple) {
            picoquic_promote_tuple_to_default(path_x, tuple, previous_tuple, current_time);
            tuple->challenge_verified = 1;
            /* set a challenge on the old tuple to recover from spoofed addresses */
            picoquic_set_tuple_challenge(old_tuple, current_time, path_x->cnx->quic->use_constant_challenges);
            old_tuple->challenge_required = 1;
            old_tuple->challenge_verified = 0;
            break;
        }
        previous_tuple = previous_tuple->next_tuple;
    }
}