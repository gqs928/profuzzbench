/*
* Author: Christian Huitema
* Copyright (c) 2020, Private Octopus, Inc.
* All rights reserved.
*
* Permission to use, copy, modify, and distribute this software for any
* purpose with or without fee is hereby granted, provided that the above
* copyright notice and this permission notice appear in all copies.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL Private Octopus, Inc. BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef PICOQUIC_PACKET_LOOP_H
#define PICOQUIC_PACKET_LOOP_H

#include "picosocks.h"
#include "picoquic.h"
#include "picoquic_utils.h"
#include "picoquic_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PICOQUIC_PACKET_LOOP_SOCKETS_MAX 4
#define PICOQUIC_PACKET_LOOP_RECV_MAX 32
#ifndef PICOQUIC_PACKET_LOOP_SEND_MAX
#define PICOQUIC_PACKET_LOOP_SEND_MAX 10
#endif
#define PICOQUIC_PACKET_LOOP_SEND_DELAY_MAX 2500

typedef struct st_picoquic_network_thread_ctx_t picoquic_network_thread_ctx_t;

typedef struct st_picoquic_socket_ctx_t {
    SOCKET_TYPE fd;
    int af;
    uint16_t port; /* Port number to which the socket is bound */
    uint16_t n_port; /* value of the port number in network order htons(port) */
    uint16_t private_port; /* Port number to which the socket is bound, if not shared */
    int is_port_shared : 1; /* Whether the socket is shared with other threads, e.g., port 443 between several H3 threads */
    /* Flags */
    unsigned int is_started : 1;
    unsigned int supports_udp_send_coalesced : 1;
    unsigned int supports_udp_recv_coalesced : 1;
    struct sockaddr_storage bound_addr; /* Local address of the socket after bind, as reported by getsockname */
    /* Receive data buffer and fields */
    size_t recv_buffer_size;
    uint8_t* recv_buffer;
    void* recv_batch; /* Linux recvmmsg cache; NULL elsewhere */
    struct sockaddr_storage addr_from;
    struct sockaddr_storage addr_dest;
    socklen_t from_length;
    socklen_t dest_length;
    int dest_if;
    unsigned char received_ecn;
    int bytes_recv;
    /* Management of sendmsg */
    char cmsg_buffer[1024];
    size_t udp_coalesced_size;
#if defined(_WINDOWS)
    /* Windows specific */
    WSAOVERLAPPED overlap;
    LPFN_WSARECVMSG WSARecvMsg;
    LPFN_WSASENDMSG WSASendMsg;
    WSABUF dataBuf;
    WSAMSG msg;
    int nb_immediate_receive;
    int so_sndbuf;
    int so_rcvbuf;
#elif defined(PICOQUIC_WITH_IO_URING)
    /* Declare the buffers required for io_uring */
    struct msghdr msg;
    uint8_t* ctrl_buffer;
    struct iovec data_iovec;
    int is_io_uring_started;
#endif
} picoquic_socket_ctx_t;

/* variation of the socket descriptor for TCP sockets used by QMux
*/
#ifdef _WINDOWS
typedef struct st_picoquic_sockloop_win_buf_t {
    uint8_t* buf;
    size_t buf_size;
    size_t buf_len;
    size_t buf_offset;
    WSABUF wsaBuf;
    WSAOVERLAPPED overlap;
} picoquic_sockloop_win_buf_t;
#endif

typedef struct st_picoqmux_socket_ctx_t {
    SOCKET_TYPE fd;
    int af;
    uint16_t port; /* Port number to which the socket is bound */
    unsigned int is_listening : 1; /* this is a listening socket, do not expect to send / recv data */
    unsigned int is_accepting : 1; /* if waiting for completion of "accept call" on new socket */
    unsigned int is_connecting : 1; /* if waiting for completion of "connect call" on new socket */
    unsigned int is_sending : 1; /* if waiting for completion of a send() call */
    unsigned int is_receiving : 1; /* if waiting for completion of a recv() call */
    /* Connection context: initiated when initiating the socket, used for interactions. */
    picoquic_cnx_t* cnx;
    struct sockaddr_storage local_addr;
    struct sockaddr_storage remote_addr;
    size_t send_buffer_size;
    size_t send_buffer_length;
    size_t send_buffer_offset;
    uint8_t* send_buffer;
#if defined(_WINDOWS)
    /* Windows specific */
    picoquic_sockloop_win_buf_t winbuf_r;
    picoquic_sockloop_win_buf_t winbuf_w;
    LPFN_ACCEPTEX lpfnAcceptEx;
    SOCKET_TYPE accepting_socket;
#elif defined(PICOQUIC_WITH_IO_URING)
    /* Declare the buffers required for io_uring */
    struct msghdr msg;
    uint8_t* ctrl_buffer;
    struct iovec data_iovec;
    int is_io_uring_started;
#endif
} picoqmux_socket_ctx_t;

/* Loop action gets more complex if we have qmux options */
typedef enum {
    picoquic_packet_loop_action_none = 0,
    picoquic_packet_loop_action_timeout,
    picoquic_packet_loop_action_wake_up,
    picoquic_packet_loop_action_udp_received,
    picoquic_packet_loop_action_tcp_accept_ready,
    picoquic_packet_loop_action_tcp_recv_ready,
    picoquic_packet_loop_action_tcp_send_ready,
    picoquic_packet_loop_action_tcp_disconnected,
    picoquic_packet_loop_action_max
} picoquic_packet_loop_action_enum;


/* The packet loop will call the application back after specific events.
 */
typedef enum {
    picoquic_packet_loop_ready = 0, /* Argument type: packet loop options */
    picoquic_packet_loop_after_receive, /* Argument type size_t*: nb packets received */
    picoquic_packet_loop_after_send, /* Argument type size_t*: nb packets sent */
    picoquic_packet_loop_port_update, /* argument type struct_sockaddr*: new address for wakeup */
    picoquic_packet_loop_time_check, /* argument type packet_loop_time_check_arg_t*. Optional. */
    picoquic_packet_loop_system_call_duration, /* argument type packet_loop_system_call_duration_t*. Optional. */
    picoquic_packet_loop_wake_up, /* no argument (void* NULL). Used when loop wakeup is supported */
    picoquic_packet_loop_alt_port /* Provide alt port for testing multipath or migration */
} picoquic_packet_loop_cb_enum;

/* System call statistics.
* The socket loop uses 'zero delay' calls to check whether
* more packets are ready to be received. In theory, these calls
* return immediately. But these are system calls, and the OS
* might decide to pause the process before returning from the
* call. If the application selects the "system call duration"
* option, it will receive callbacks when the call time varies
* significantly.
 */
typedef struct st_packet_loop_system_call_duration_t {
    uint64_t scd_last;
    uint64_t scd_max;
    uint64_t scd_smoothed;
    uint64_t scd_dev;
} packet_loop_system_call_duration_t;

/* The time check option passes as argument a pointer to a structure specifying
* the current time and the proposed delta. The application uses the specified
* current time to compute an updated delta.
*/
typedef struct st_packet_loop_time_check_arg_t {
    uint64_t current_time;
    int64_t delta_t;
} packet_loop_time_check_arg_t;

typedef int (*picoquic_packet_loop_cb_fn)(picoquic_quic_t * quic, picoquic_packet_loop_cb_enum cb_mode, void * callback_ctx, void * callback_argv);

/* Packet loop option list shows support by application of optional features.
 * It is set to null initially, and then passed to the socket as argument to
 * the "ready" callback. Application should set the flags corresponding to
 * the features that it supports */
typedef struct st_picoquic_packet_loop_options_t {
    unsigned int do_time_check : 1; /* App should be polled for next time before sock select */
    unsigned int do_system_call_duration : 1; /* App should be notified if the system call duration varies */
    unsigned int provide_alt_port : 1; /* Used for simulating multipath or migrations. */
} picoquic_packet_loop_options_t;

/* Version 2 of packet loop, obsoleted by v3
 */
#define PICOQUIC_PACKET_LOOP_LOCAL_ADDR_MAX 2

typedef struct st_picoquic_packet_loop_param_t {
    uint16_t local_port; /* Default port for outgoing connection */
    int local_af;
    int dest_if;
    uint16_t public_port;
    int is_port_shared; /* public port is shared with other threads, e.g., port 443 between several H3 threads */
    uint16_t qmux_port;
    int qmux_is_port_shared; /* public qmux port is shared with other threads, e.g., port 443 between several H3 threads */
    int socket_buffer_size;
    int do_not_use_gso;
    int use_af_xdp; /* Linux: try AF_XDP TX (GSO as a TX-ring batch). Fall back to sendmsg. */
    int extra_socket_required;
    int prefer_extra_socket;
    int simulate_eio;
    size_t send_length_max;
    size_t send_batch_max; /* 0: use PICOQUIC_PACKET_LOOP_SEND_MAX */
    /* Optional bind addresses, at most one per address family. If every entry
     * has ss_family 0 (the default after zero initialization), sockets bind to
     * the wildcard address. Otherwise one socket is opened per entry, bound to
     * that address and to local_port (the port inside the entry is ignored),
     * every packet sent on that socket carries that address as its source, and
     * no socket is opened for a family that has no entry. Two entries of the
     * same family, or an entry whose family differs from a non-zero local_af,
     * are rejected. */
    struct sockaddr_storage local_addr[PICOQUIC_PACKET_LOOP_LOCAL_ADDR_MAX];
} picoquic_packet_loop_param_t;

/* Returns the entry of param->local_addr for the address family af, or NULL
 * if there is none. */
const struct sockaddr* picoquic_packet_loop_local_addr_for_af(const picoquic_packet_loop_param_t* param, int af);

/* If the socket is bound to a specific (non wildcard) address, replace the
 * address part of local_addr by that address, so the packet is sent from
 * the address the socket can receive on. The port of local_addr is kept if
 * it was set, otherwise the socket's port is used. Sockets bound to the
 * wildcard address leave local_addr untouched. On platforms without
 * IP_PKTINFO (BSD), an IPv4 local_addr is cleared instead, because
 * IP_SENDSRCADDR is refused on a bound socket; the kernel then uses the
 * bound address. */
void picoquic_packet_loop_set_send_source(const picoquic_socket_ctx_t* s_ctx, struct sockaddr_storage* local_addr);

/* Send one datagram, or a GSO batch of datagrams of send_msg_size bytes, and
 * handle send errors: an error implying that the destination is unreachable
 * is reported to last_cnx, and on EIO the batch is resent packet by packet
 * and GSO is disabled for the rest of the loop by clearing *send_msg_ptr and
 * the segment size it points to. send_msg_ptr may be NULL. If thread_ctx has
 * an AF_XDP handle, TX is attempted there first; sendmsg is the fallback.
 * thread_ctx may be NULL. */
int picoquic_packet_loop_do_udp_send(
    picoquic_quic_t* quic,
    picoquic_cnx_t* last_cnx,
    SOCKET_TYPE send_socket,
    picoquic_packet_loop_param_t* param,
    uint8_t* send_buffer,
    size_t send_length,
    struct sockaddr_storage* peer_addr,
    struct sockaddr_storage* local_addr,
    int if_index,
    size_t send_msg_size,
    size_t** send_msg_ptr,
    picoquic_connection_id_t* log_cid,
    uint64_t current_time,
    picoquic_network_thread_ctx_t* thread_ctx);

int picoquic_packet_loop_v2(picoquic_quic_t* quic,
    picoquic_packet_loop_param_t * param,
    picoquic_packet_loop_cb_fn loop_callback,
    void * loop_callback_ctx);

/* Packet loop v3, capable of managing preferred address migration.
* The argument is passed as "void*" to match the prototype of the thread function,
* but it is actually a pointer to a structure of type picoquic_network_thread_ctx_t.
* When the packet loop is started in the main thread, the application code
* should be:
* 
*        (void)picoquic_packet_loop_v3((void*)&thread_ctx);
*        ret = thread_ctx.return_code;
* 
*/

#ifdef _WINDOWS
DWORD WINAPI picoquic_packet_loop_v3(LPVOID v_ctx);
#else
void* picoquic_packet_loop_v3(void* v_ctx);
#endif

/* Threaded version of packet loop, when running picoquic in a background thread.
*
* Thread is started by calling picoquic_start_network_thread, which
* returns an argument of type picoquic_network_thread_ctx_t. Returns a NULL
* pointer if the thread could not be created, including if loop_callback is
* NULL: unlike the non-threaded picoquic_packet_loop_v3, this API requires a
* non-NULL loop_callback, because the wake up mechanism below calls it
* unconditionally.
*
* If the application needs to post new data or otherwise interact with
* the quic connections, it should call picoquic_wake_up_network_thread,
* passing the thread context as an argument. This will trigger a
* callback of type `picoquic_packet_loop_wake_up`, which executes
* in the context of the network thread. Picoquic APIs can be called
* in this context without worrying about concurrency issues.
* 
* If the application wants to close the network thread, it calls
* picoquic_close_network_thread, passing the thread context as an argument.
* The network thread context will be freed during that call.
*/
/* Zero-copy AF_XDP is not offered. It takes a NIC queue away from the
 * kernel UDP sockets that still receive. */
typedef enum {
    picoquic_tx_method_sendmsg = 0,
    picoquic_tx_method_af_xdp_copy = 1
} picoquic_tx_method_enum;

const char* picoquic_tx_method_to_string(int method);

typedef int (*picoquic_custom_thread_create_fn)(void** thread_id, picoquic_thread_fn thread_fn, void* arg);
typedef void (*picoquic_custom_thread_setname_fn)(char const* thread_name);
typedef void (*picoquic_custom_thread_delete_fn)(void** thread_id);

struct st_picoquic_network_thread_ctx_t {
    picoquic_quic_t* quic;
    picoquic_quic_t* qmux;
    picoquic_packet_loop_param_t* param;
    picoquic_packet_loop_cb_fn loop_callback;
    picoquic_custom_thread_delete_fn thread_delete_fn;
    picoquic_custom_thread_setname_fn thread_setname_fn;
    char const* thread_name;
    void* pthread; /* Can be cast to picoquic_thread_t, or custom type if using non native threads */
    void* loop_callback_ctx;
#ifdef _WINDOWS
    HANDLE wake_up_event;
#else
    int wake_up_pipe_fd[2];
#ifdef PICOQUIC_WITH_IO_URING
    struct iovec pipe_iovec;
    int is_pipe_io_uring_started;
#endif
#endif
    int is_threaded;
    int is_param_allocated;
    int wake_up_defined;
    volatile int thread_is_ready;
    volatile int thread_should_close;
    volatile int thread_is_closed;
    int return_code;
    int tx_method;
    char tx_method_reason[160];
    void* af_xdp;
};

picoquic_network_thread_ctx_t* picoquic_start_network_thread(
    picoquic_quic_t* quic,
    picoquic_packet_loop_param_t* param,
    picoquic_packet_loop_cb_fn loop_callback,
    void* loop_callback_ctx,
    int * ret);

picoquic_network_thread_ctx_t* picoquic_start_network_thread_qmux(
    picoquic_quic_t* quic,
    picoquic_quic_t* qmux,
    picoquic_packet_loop_param_t* param,
    picoquic_packet_loop_cb_fn loop_callback,
    void* loop_callback_ctx,
    int* ret);

int picoquic_wake_up_network_thread(picoquic_network_thread_ctx_t* thread_ctx);
void picoquic_delete_network_thread(picoquic_network_thread_ctx_t* thread_ctx);

/* The function picoquic_start_network_thread creates a background thread using
* the "native" threading APIs, CreateThread in Windows or pthread_create in
* Unix/Posix systems. This will not work in some environments, if for example
* the threads should be created using a game engine API. In such cases,
* developers may use the function picoquic_start_custom_network_thread,
* passing the desired thread creation function, thread deletion function
* and thread naming function as a function pointer. The thread naming
* function will be called from inside the network thread after it is
* created, as this is required in some OSes. The thread deletion
* function will be called when the thread is delete, from inside
* the thread context destruction function.
* 
* The custom thread creation function must match the prototype 
* picoquic_custom_thread_create_fn, with the following arguments:
* 
* - void** pthread: a pointer to the thread (thread HANDLE in Windows,
*   pthread_t if using pthread),
* - picoquic_thread_fn thread_fn: the function that will be instantiated when creating the thread.
* - void* arg: the argument to thread_fn.
* 
* The return code is an integer, either 0 if success or an error code if failure.
* 
* The custom thread deletion function must match the prototype 
* picoquic_custom_thread_delete_fn, with the following arguments:
* 
* - void** pthread: a pointer to the thread, carrying the value returned
*   in pthread by the custom creation function.
* 
* The custom thread naming function must match the prototype 
* picoquic_custom_thread_delete_fn, with the following arguments:
* 
* - char const * thread_name: the desired thread name. Should be less
*   than 16 characters, including the final null terminator.
* 
* The function picoquic_start_custom_network_thread takes the following
* arguments:
* 
* - picoquic_quic_t* quic: the quic context, configured by the application
*   before starting the network thread.
* - picoquic_packet_loop_param_t* param: the loop creation parameters,
* - picoquic_custom_thread_create_fn thread_create_fn: the thread creation
*   function. If the value is NULL, the OS defaults will be used.
* - picoquic_custom_thread_create_fn thread_delete_fn: the thread
*   deletion function. If the value is NULL, the OS defaults will be used.
* - char const* thread_name: the desired thread name, or NULL if the
*   default value is sufficient.
* - picoquic_packet_loop_cb_fn loop_callback: the function that will
*   be called upon packet loop events.
* - void* loop_callback_ctx: the arguments to loop callback.
* - int * ret: error code, if any.
* 
* The function will return a pointer to the thread context, or NULL
* if an error happened.
* 
* Note that these functions set the name of the thread but do attempt to set
* the priority of the thread. Setting the name during the creation makes sense,
* as the name will typically not change during the process. It is also
* reasonably easy to set the name in a system independent way. In contrast,
* the handling of priority is system dependent, with Windows and Unix using
* different concepts, and there may be good reasons to change a thread priority
* after creation. Developers can use the system or framework APIs after the
* thread is created, using the thread handle in thread_ctx->pthread.
* 
* The "_qmux" variant adds an additional parameter "picoquic_quic_t qmux", which is
* used when the thread needs to manage QMux sockets.
*/

picoquic_network_thread_ctx_t* picoquic_start_custom_network_thread(
    picoquic_quic_t* quic,
    picoquic_packet_loop_param_t* param,
    picoquic_custom_thread_create_fn thread_create_fn,
    picoquic_custom_thread_delete_fn thread_delete_fn,
    picoquic_custom_thread_setname_fn thread_setname_fn, 
    char const* thread_name,
    picoquic_packet_loop_cb_fn loop_callback,
    void* loop_callback_ctx,
    int * ret);


picoquic_network_thread_ctx_t* picoquic_start_custom_network_thread_qmux(
    picoquic_quic_t* quic, picoquic_quic_t* qmux, picoquic_packet_loop_param_t* param,
    picoquic_custom_thread_create_fn thread_create_fn,
    picoquic_custom_thread_delete_fn thread_delete_fn,
    picoquic_custom_thread_setname_fn thread_setname_fn,
    char const* thread_name,
    picoquic_packet_loop_cb_fn loop_callback, void* loop_callback_ctx, int* ret);

/* Implementations of picoquic_custom_thread_create_fn and 
* picoquic_custom_thread_delete_fn for the native thread types.
* These functions are used in calls to picoquic_start_custom_network_thread
* when the create and delete function pointers are NULL.
* They are also used in the test library to test the use of
* function pointers in the thread creation function.
 */
int picoquic_internal_thread_create(void** pthread,
    picoquic_thread_fn thread_fn, void* thread_arg);
void picoquic_internal_thread_delete(void** pthread);
void picoquic_internal_thread_setname(char const * thread_name);

/* Legacy versions the packet loop, one portable and one specialized
 * for winsock. Keeping these API for compatibility, but the implementation
 * redirects to picoquic_packet_loop_v2.
 */
int picoquic_packet_loop(picoquic_quic_t* quic,
    int local_port,
    int local_af,
    int dest_if,
    int socket_buffer_size,
    int do_not_use_gso,
    picoquic_packet_loop_cb_fn loop_callback,
    void * loop_callback_ctx);

#ifdef _WINDOWS
int picoquic_packet_loop_win(picoquic_quic_t* quic,
    int local_port,
    int local_af,
    int dest_if,
    int socket_buffer_size,
    picoquic_packet_loop_cb_fn loop_callback,
    void* loop_callback_ctx);
#endif

/* Return the thread context associated with a QUIC context,
* or a NULl pointer if there is none. */
struct st_picoquic_network_thread_ctx_t* picoquic_get_thread_ctx(picoquic_quic_t* quic);

/* Set a server context, using more parameters than the simple
* creation from configuration.
*
*
*/
int picoquic_server_set_context(picoquic_quic_t** qserver,
    picoquic_quic_config_t* config,
    uint64_t current_time,
    picoquic_stream_data_cb_fn default_callback_fn,
    void* default_callback_ctx,
    picoquic_alpn_select_fn_v2 alpn_select_fn);

/*
* Start a set of N threads. 
* Each thread manages its own quic context, which is
* created here from the config parameters. The thread interacts with the
* application through:
*
* - wake up and stop/delete calls, using the standard thread API,
* - the ALPN selection function, called when a new connection is created,
*   which can set the callback function and the callback context for the connection.
* - a callback function called from the packet loop, either when the
*  thread is woken up, or when the packet loop needs to check application delays.
* - per connection callbacks.
*
* The application will specialize the threads by providing the callback functions,
* and their default context:
* - the ALPN selection function is the same for all threads.
* - the packet loop callback is the same for all threads, and its context.
* - the default connection callback is the same for all threads.
* - the default connection callback context is the same for all threads.
*
* The packet loop callback context is the same for all threads. The function
* can retrieve the thread context from the "quic" context argument using
* the function picoquic_get_thread_ctx_from_quic().
*/

int picoquic_start_server_threads(
    struct st_picoquic_quic_config_t* config,
    uint64_t current_time,
    picoquic_alpn_select_fn_v2 alpn_select_fn,
    picoquic_stream_data_cb_fn default_callback_fn,
    void* default_callback_ctx,
    picoquic_packet_loop_cb_fn loop_callback_fn,
    void* loop_callback_ctx,
    picoquic_custom_thread_create_fn thread_create_fn,
    picoquic_custom_thread_delete_fn thread_delete_fn,
    picoquic_custom_thread_setname_fn thread_setname_fn,
    picoquic_network_thread_ctx_t** thread_ctxs,
    int nb_threads_max,
    int* nb_threads_created);

/* Following declarations are used for unit tests. */
void picoquic_packet_loop_close_socket(picoquic_socket_ctx_t* s_ctx);
int picoquic_packet_loop_open_sockets(picoquic_packet_loop_param_t* param, picoquic_socket_ctx_t* s_ctx, uint8_t ecn_value);
picoqmux_socket_ctx_t* picoquic_packet_loop_open_qmux_socket(
    int af, uint16_t public_port, int is_port_shared, int is_listening);
void picoquic_packet_loop_free_qmux_socket(picoqmux_socket_ctx_t* sqmux_sock_ctx);
int picoquic_packet_loop_do_tcp_accept(picoquic_quic_t* qmux,
    picoqmux_socket_ctx_t** sqmux_ctx, int* nb_qmux_sockets,
    int max_qmux_sockets, int socket_rank, uint64_t current_time);
int picoquic_packet_loop_do_tcp_read(picoqmux_socket_ctx_t** sqmux_ctx,
    int* qmux_socket_was_closed, int socket_rank,
    uint64_t current_time, uint8_t* qmux_buffer, size_t qmux_buffer_size);
int picoquic_packet_loop_do_tcp_send(picoqmux_socket_ctx_t** sqmux_ctx,
    int* qmux_socket_was_closed, int socket_rank,
    uint64_t current_time, uint8_t* qmux_buffer, size_t qmux_buffer_size);
int picoquic_packet_loop_check_qmux_timers(picoqmux_socket_ctx_t** sqmux_ctx,
    int nb_qmux_sockets, int* qmux_socket_was_closed,
    uint64_t current_time, uint8_t* qmux_buffer, size_t qmux_buffer_size);
void picoquic_packet_loop_abandon_socket(
    picoqmux_socket_ctx_t** sqmux_ctx,
    int* qmux_socket_was_closed,
    int socket_rank);
int picoquic_packet_loop_open_qmux_sockets(picoquic_quic_t* qmux,
    picoqmux_socket_ctx_t*** sqmux_ctx, int* nb_qmux_sockets,
    int* max_qmux_socket, int public_port);
void picoquic_packet_loop_free_qmux_sockets(picoqmux_socket_ctx_t*** sqmux_ctx,
    int nb_qmux_sockets);
#ifdef _WINDOWS
int picoquic_packet_loop_start_windows_recv(picoqmux_socket_ctx_t* sqmux_sock_ctx);
int picoquic_sockloop_finish_windows_recv(picoqmux_socket_ctx_t* sqmux_sock_ctx);
int picoquic_packet_loop_wait(picoquic_socket_ctx_t* s_ctx, int nb_sockets,
    picoqmux_socket_ctx_t** sqmux_ctx, int nb_qmux_sockets, uint64_t current_time,
    struct sockaddr_storage* addr_from, struct sockaddr_storage* addr_dest, int* dest_if,
    unsigned char* received_ecn, uint8_t** received_buffer, int64_t delta_t,
    picoquic_network_thread_ctx_t* thread_ctx, picoquic_packet_loop_action_enum* action, int* socket_rank);
#endif
#ifdef __cplusplus
}
#endif
#endif /* PICOQUIC_PACKET_LOOP_H */
