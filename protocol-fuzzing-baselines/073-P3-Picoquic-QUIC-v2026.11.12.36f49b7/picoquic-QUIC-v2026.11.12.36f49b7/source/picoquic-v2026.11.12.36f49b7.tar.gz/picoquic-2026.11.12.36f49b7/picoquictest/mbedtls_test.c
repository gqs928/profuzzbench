/*
* Author: Christian Huitema
* Copyright (c) 2023, Private Octopus, Inc.
* All rights reserved.
*
* Permission to use, copy, modify, and distribute this software for any
* purpose with or without fee is hereby granted, provided that the above
* copyright notice and this permission notice appear in all copies.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL Private Octopus, Inc. BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <stddef.h>
#include <stdint.h>
#include "picoquic.h"
#include "picoquic_internal.h"
#include "picoquic_utils.h"
#include "tls_api.h"
#include "picoquictest_internal.h"
#ifdef _WINDOWS
#include "wincompat.h"
#pragma warning(disable:4204)
#endif
#include <picotls.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "picoquic_qlog.h"
#include "picoquictest.h"
#include "picoquic_crypto_provider_api.h"
#if 0
#include "psa/crypto.h"
#include "psa/crypto_struct.h"
#endif
#include "picotls/minicrypto.h"

#ifdef PICOQUIC_WITH_MBEDTLS
#include "mbedtls/mbedtls_config.h"
#include "mbedtls/build_info.h"
#include "psa/crypto.h"
#include "psa/crypto_struct.h"
#include "psa/crypto_values.h"
#include "picotls.h"
#include "ptls_mbedtls.h"
#endif
/* Mbedtls test:
 * Use the "flag" option of tls_api_init to only load specified
 * providers -- specifically, do not load openssl.
 * Then, run a basic connection test, to check that negotiation
 * succeeds.
 * Then, unload the tls api provider and reset the control flag
 * to zero.
 */

static test_api_stream_desc_t test_scenario_mbedtls[] = {
    { 4, 0, 2000, 2000 }
};

int mbedtls_test(void)
{
    uint64_t simulated_time = 0;
    uint64_t loss_mask = 0;
    uint64_t target_time = 1000000;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    picoquic_connection_id_t initial_cid = { {0x99, 0xbe, 0xd7, 0x15, 0, 0, 0, 0}, 8 };
    int ret = 0;

    picoquic_tls_api_reset(TLS_API_INIT_FLAGS_NO_OPENSSL|TLS_API_INIT_FLAGS_NO_FUSION);

    ret = tls_api_init_ctx_ex2(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1,
        PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, NULL, NULL, 0, 0, 0, &initial_cid, 8, 0, 0, 1);
    if (ret == 0) {
        picoquic_set_qlog(test_ctx->qserver, ".");
        test_ctx->qserver->use_long_log = 1;
    }

    if (ret == 0) {
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 20000, &simulated_time);
    }

    /* Prepare to send data */
    if (ret == 0) {
        ret = test_api_init_send_recv_scenario(test_ctx, test_scenario_mbedtls, sizeof(test_scenario_mbedtls));
    }

    /* Try to complete the data sending loop */
    if (ret == 0) {
        ret = tls_api_data_sending_loop(test_ctx, &loss_mask, &simulated_time, 0);
    }

    /* verify that the transmission was complete */
    if (ret == 0) {
        ret = tls_api_one_scenario_body_verify(test_ctx, &simulated_time, target_time);
    }

    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
        test_ctx = NULL;
    }

    picoquic_tls_api_reset(0);

    return ret;
}

/* The following test verifies that the MBED TLS library is properly
* mapped to the "picotls" APIs.
 */

#ifdef PICOQUIC_WITH_MBEDTLS
#include "mbedtls/build_info.h"

extern ptls_hash_algorithm_t ptls_mbedtls_sha256;
extern ptls_hash_algorithm_t ptls_mbedtls_sha512;
#if defined(MBEDTLS_SHA384_C)
extern ptls_hash_algorithm_t ptls_mbedtls_sha384;
#endif

extern ptls_cipher_algorithm_t ptls_mbedtls_aes128ecb;
extern ptls_cipher_algorithm_t ptls_mbedtls_aes256ecb;
extern ptls_cipher_algorithm_t ptls_mbedtls_aes128ctr;
extern ptls_cipher_algorithm_t ptls_mbedtls_aes256ctr;
extern ptls_cipher_algorithm_t ptls_mbedtls_chacha20;

extern ptls_aead_algorithm_t ptls_mbedtls_aes128gcm;
extern ptls_aead_algorithm_t ptls_mbedtls_aes256gcm;
extern ptls_aead_algorithm_t ptls_mbedtls_chacha20poly1305;

extern ptls_cipher_suite_t ptls_mbedtls_aes128gcmsha256;
extern ptls_cipher_suite_t ptls_mbedtls_aes256gcmsha384;
extern ptls_cipher_suite_t ptls_mbedtls_chacha20poly1305sha256;

extern ptls_key_exchange_algorithm_t ptls_mbedtls_secp256r1;
extern ptls_key_exchange_algorithm_t ptls_mbedtls_x25519;

int ptls_mbedtls_init(void);
void ptls_mbedtls_free(void);
void ptls_mbedtls_random_bytes(void* buf, size_t len);
static int test_random(void);
static int test_hash(ptls_hash_algorithm_t* algo, ptls_hash_algorithm_t* ref);
static int test_label(ptls_hash_algorithm_t* hash, ptls_hash_algorithm_t* ref);
static int test_cipher(ptls_cipher_algorithm_t* cipher, ptls_cipher_algorithm_t* cipher_ref);
static int test_aead(ptls_aead_algorithm_t* algo, ptls_hash_algorithm_t* hash, ptls_aead_algorithm_t* ref, ptls_hash_algorithm_t* hash_ref);
static int test_key_exchange(ptls_key_exchange_algorithm_t* client, ptls_key_exchange_algorithm_t* server);

int mbedtls_crypto_test(void)
{
    ptls_cipher_algorithm_t* cipher_test[5] = {
        &ptls_mbedtls_aes128ecb,
        &ptls_mbedtls_aes128ctr,
        &ptls_mbedtls_aes256ecb,
        &ptls_mbedtls_aes256ctr,
        &ptls_mbedtls_chacha20
    };
    ptls_cipher_algorithm_t* cipher_ref[5] = {
        &ptls_minicrypto_aes128ecb,
        &ptls_minicrypto_aes128ctr,
        &ptls_minicrypto_aes256ecb,
        &ptls_minicrypto_aes256ctr,
        &ptls_minicrypto_chacha20
    };
    int ret = 0;

    /* Initialize the PSA crypto library. */
    if ((ret = ptls_mbedtls_init()) != 0) {
        DBG_PRINTF("%s", "psa_crypto_init fails.");
    }
    else {
        ret = test_random();
        DBG_PRINTF("test random returns: %d\n", ret);

        if (ret == 0) {
            ret = test_hash(&ptls_mbedtls_sha256, &ptls_minicrypto_sha256);
            DBG_PRINTF("test hash returns: %d\n", ret);
        }

        if (ret == 0) {
            ret = test_label(&ptls_mbedtls_sha256, &ptls_minicrypto_sha256);
            DBG_PRINTF("test label returns: %d\n", ret);
        }

        if (ret == 0) {
            for (int i = 0; i < 5; i++) {
                if (test_cipher(cipher_test[i], cipher_ref[i]) != 0) {
                    DBG_PRINTF("test cipher %d fails\n", i);
                    ret = -1;
                }
            }
            DBG_PRINTF("test ciphers returns: %d\n", ret);
        }

        if (ret == 0) {
            ret = test_aead(&ptls_mbedtls_aes128gcm, &ptls_mbedtls_sha256, &ptls_minicrypto_aes128gcm, &ptls_minicrypto_sha256);
            DBG_PRINTF("test aeads returns: %d\n", ret);
        }

        if (ret == 0) {
            ret = test_key_exchange(&ptls_mbedtls_secp256r1, &ptls_minicrypto_secp256r1);
            if (ret != 0) {
                DBG_PRINTF("%s", "test key exchange secp256r1 mbedtls to minicrypto fails\n");
            }
            else {
                ret = test_key_exchange(&ptls_minicrypto_secp256r1, &ptls_mbedtls_secp256r1);
                if (ret != 0) {
                    DBG_PRINTF("%s", "test key exchange secp256r1 minicrypto to mbedtls fails\n");
                }
            }
            ret = test_key_exchange(&ptls_mbedtls_x25519, &ptls_minicrypto_x25519);
            if (ret != 0) {
                DBG_PRINTF("%s", "test key exchange x25519 mbedtls to minicrypto fails\n");
            }
            else {
                ret = test_key_exchange(&ptls_minicrypto_x25519, &ptls_mbedtls_x25519);
                if (ret != 0) {
                    DBG_PRINTF("%s", "test key exchange x25519 minicrypto to mbedtls fails\n");
                }
            }
            DBG_PRINTF("test key exchange returns: %d\n", ret);
        }

        /* Keep PSA initialized, later tests in this process still use it. */
    }
    return (ret == 0) ? 0 : -1;
}

#define PTLS_MBEDTLS_RANDOM_TEST_LENGTH 1021

static int test_random(void)
{
    /* The random test is just trying to check that we call the API properly. 
    * This is done by getting a vector of 1021 bytes, computing the sum of
    * all values, and comparing to theoretical min and max,
    * computed as average +- 8*standard deviation for sum of 1021 terms.
    * 8 random deviations results in an extremely low probability of random
    * failure.
    * Note that this does not actually test the random generator.
    */

    uint8_t buf[PTLS_MBEDTLS_RANDOM_TEST_LENGTH];
    uint64_t sum = 0;
    const uint64_t max_sum_1021 = 149505;
    const uint64_t min_sum_1021 = 110849;
    int ret = 0;

    ptls_mbedtls_random_bytes(buf, PTLS_MBEDTLS_RANDOM_TEST_LENGTH);
    for (size_t i = 0; i < PTLS_MBEDTLS_RANDOM_TEST_LENGTH; i++) {
        sum += buf[i];
    }
    if (sum > max_sum_1021 || sum < min_sum_1021) {
        ret = -1;
    }

    return ret;
}

static int hash_trial(ptls_hash_algorithm_t* algo, const uint8_t* input, size_t len1, size_t len2, uint8_t* final_hash)
{
    int ret = 0;
    ptls_hash_context_t* hash_ctx = algo->create();

    hash_ctx->update(hash_ctx, input, len1);
    if (len2 > 0) {
        hash_ctx->update(hash_ctx, input + len1, len2);
    }
    hash_ctx->final(hash_ctx, final_hash, PTLS_HASH_FINAL_MODE_FREE);

    return ret;
}

static int hash_reset_trial(ptls_hash_algorithm_t* algo, const uint8_t* input, size_t len1, size_t len2, 
    uint8_t* hash1, uint8_t* hash2)
{
    int ret = 0;
    ptls_hash_context_t* hash_ctx = algo->create();

    hash_ctx->update(hash_ctx, input, len1);
    hash_ctx->final(hash_ctx, hash1, PTLS_HASH_FINAL_MODE_RESET);
    hash_ctx->update(hash_ctx, input + len1, len2);
    hash_ctx->final(hash_ctx, hash2, PTLS_HASH_FINAL_MODE_FREE);

    return ret;
}

static int test_hash(ptls_hash_algorithm_t* algo, ptls_hash_algorithm_t* ref)
{
    int ret = 0;
    uint8_t input[1234];
    uint8_t final_hash[32];
    uint8_t final_ref[32];
    uint8_t hash1[32], hash2[32], href1[32], href2[32];

    memset(input, 0xba, sizeof(input));

    ret = hash_trial(algo, input, sizeof(input), 0, final_hash);
    if (ret == 0) {
        ret = hash_trial(ref, input, sizeof(input), 0, final_ref);
    }
    if (ret == 0) {
        if (memcmp(final_hash, final_ref, ref->digest_size) != 0) {
            ret = -1;
        }
    }
    if (ret == 0) {
        ret = hash_trial(algo, input, sizeof(input) - 17, 17, final_hash);
    }
    if (ret == 0) {
        if (memcmp(final_hash, final_ref, ref->digest_size) != 0) {
            ret = -1;
        }
    }

    if (ret == 0) {
        ret = hash_reset_trial(algo, input, sizeof(input) - 126, 126, hash1, hash2);
    }
    if (ret == 0) {
        ret = hash_reset_trial(ref, input, sizeof(input) - 126, 126, href1, href2);
    }
    if (ret == 0) {
        if (memcmp(hash1, href1, ref->digest_size) != 0) {
            ret = -1;
        }
        else if (memcmp(hash2, href2, ref->digest_size) != 0) {
            ret = -1;
        }
    }

    return ret;
}

static int cipher_trial(ptls_cipher_algorithm_t * cipher, const uint8_t * key, const uint8_t * iv, int is_enc, const uint8_t * v_in, uint8_t * v_out1, uint8_t * v_out2, size_t len)
{
    int ret = 0;
    ptls_cipher_context_t* test_cipher = ptls_cipher_new(cipher, is_enc, key);
    if (test_cipher == NULL) {
        ret = -1;
    } else {
        if (test_cipher->do_init != NULL) {
            ptls_cipher_init(test_cipher, iv);
        }
        ptls_cipher_encrypt(test_cipher, v_out1, v_in, len);
        if (test_cipher->do_init != NULL) {
            ptls_cipher_init(test_cipher, iv);
        }
        ptls_cipher_encrypt(test_cipher, v_out2, v_out1, len);
        ptls_cipher_free(test_cipher);
    }

    return ret;
}

static int test_cipher(ptls_cipher_algorithm_t * cipher, ptls_cipher_algorithm_t * cipher_ref)
{
    uint8_t key[32];
    uint8_t iv[16];
    uint8_t v_in[16];
    uint8_t v_out_1a[16], v_out_2a[16], v_out_1b[16], v_out_2b[16], v_out_1d[16], v_out_2d[16];
    int ret = 0;

    /* Set initial values */
    memset(key, 0x55, sizeof(key));
    memset(iv, 0x33, sizeof(iv));
    memset(v_in, 0xaa, sizeof(v_in));

    /* Encryption test */
    ret = cipher_trial(cipher, key, iv, 1, v_in, v_out_1a, v_out_2a, 16);
    if (ret == 0) {
        ret = cipher_trial(cipher_ref, key, iv, 1, v_in, v_out_1b, v_out_2b, 16);
    }
    if (ret == 0) {
        if (memcmp(v_out_1a, v_out_1b, 16) != 0) {
            ret = -1;
        }
        else if (memcmp(v_out_2a, v_out_2b, 16) != 0) {
            ret = -1;
        }
    }
    /* decryption test */
    if (ret == 0) {
        ret = cipher_trial(cipher, key, iv, 0, v_out_2a, v_out_1d, v_out_2d, 16);
    }
    if (ret == 0) {
        if (memcmp(v_out_1a, v_out_1d, 16) != 0) {
            ret = -1;
        }
        else if (memcmp(v_out_2d, v_in, 16) != 0) {
            ret = -1;
        }
    }

    return ret;
}

static int label_test(ptls_hash_algorithm_t * hash, uint8_t * v_out, size_t o_len, const uint8_t * secret,
    char const * label, char const * label_prefix)
{
    uint8_t h_val_v[32];
    ptls_iovec_t h_val = { 0 };
    ptls_iovec_t s_vec = { 0 };
    s_vec.base = (uint8_t *)secret;
    s_vec.len = 32;
    h_val.base = h_val_v;
    h_val.len = 32;
    memset(h_val_v, 0, sizeof(h_val_v));

    ptls_hkdf_expand_label(hash, v_out, o_len, s_vec, label, h_val, label_prefix);
    return 0;
}

static int test_label(ptls_hash_algorithm_t* hash, ptls_hash_algorithm_t* ref)
{
    int ret = 0;
    uint8_t v_out[16], v_ref[16];
    uint8_t secret[32];
    char const* label = "label";
    char const* label_prefix = "label_prefix";
    memset(secret, 0x5e, sizeof(secret));

    ret = label_test(hash, v_out, 16, secret, label, label_prefix);

    if (ret == 0) {
        ret = label_test(ref, v_ref, 16, secret, label, label_prefix);
    }

    if (ret == 0 && memcmp(v_out, v_ref, 16) != 0) {
        ret = -1;
    }

    return ret;
}

static int aead_trial(ptls_aead_algorithm_t * algo, ptls_hash_algorithm_t * hash, const uint8_t * secret, int is_enc, 
    const uint8_t * v_in, size_t len, uint8_t * aad, size_t aad_len, uint64_t seq, uint8_t * v_out, size_t * o_len)
{
    int ret = 0;
    ptls_aead_context_t* aead = ptls_aead_new(algo, hash, is_enc, secret, "test_aead");

    if (aead == NULL) {
        ret = -1;
    }
    else{
        if (is_enc) {
            *o_len = ptls_aead_encrypt(aead, v_out, v_in, len, seq, aad, aad_len);
            if (*o_len != len + algo->tag_size) {
                ret = -1;
            }
        }
        else {
            *o_len = ptls_aead_decrypt(aead, v_out, v_in, len, seq, aad, aad_len);
            if (*o_len != len - algo->tag_size) {
                ret = -1;
            }
        }
        ptls_aead_free(aead);
    }
    return ret;
}

static int test_aead(ptls_aead_algorithm_t* algo, ptls_hash_algorithm_t* hash, ptls_aead_algorithm_t* ref, ptls_hash_algorithm_t* hash_ref)
{
    uint8_t secret[32];
    uint8_t v_in[1234];
    uint8_t aad[17];
    uint8_t v_out_a[1250], v_out_b[1250], v_out_r[1250];
    size_t olen_a, olen_b, olen_r;
    uint64_t seq = 12345;
    int ret = 0;

    memset(secret, 0x58, sizeof(secret));
    memset(v_in, 0x12, sizeof(v_in));
    memset(aad, 0xaa, sizeof(aad));

    ret = aead_trial(algo, hash, secret, 1, v_in, sizeof(v_in), aad, sizeof(aad), seq, v_out_a, &olen_a);
    if (ret == 0) {
        ret = aead_trial(ref, hash_ref, secret, 1, v_in, sizeof(v_in), aad, sizeof(aad), seq, v_out_b, &olen_b);
    }
    if (ret == 0 && (olen_a != olen_b || memcmp(v_out_a, v_out_b, olen_a) != 0)) {
        ret = -1;
    }
    if (ret == 0) {
        ret = aead_trial(ref, hash_ref, secret, 0, v_out_a, olen_a, aad, sizeof(aad), seq, v_out_r, &olen_r);
    }
    if (ret == 0 && (olen_r != sizeof(v_in) || memcmp(v_in, v_out_r, sizeof(v_in)) != 0)) {
        ret = -1;
    }
    return ret;
}

/* Test key exchanges. We copy paste the code from "test.h" in picotls.
* if intergarted with picotls, we should reuse this code.
*/

static int test_key_exchange(ptls_key_exchange_algorithm_t *client, ptls_key_exchange_algorithm_t *server)
{
    ptls_key_exchange_context_t *ctx;
    ptls_iovec_t client_secret, server_pubkey, server_secret;
    int f_ret;
    int ret = 0;

    /* fail */
    if ((f_ret = server->exchange(server, &server_pubkey, &server_secret, (ptls_iovec_t) { NULL })) == 0) {
        ret = -1;
    }
    if (ret == 0) {
        /* perform ecdh */
        ret = client->create(client, &ctx);
        if (ret == 0) {
            ret = server->exchange(server, &server_pubkey, &server_secret, ctx->pubkey);
        }
        if (ret == 0) {
            ret = ctx->on_exchange(&ctx, 1, &client_secret, server_pubkey);
        }
        if (ret == 0) {
            if (client_secret.len != server_secret.len ||
                memcmp(client_secret.base, server_secret.base, client_secret.len) != 0) {
                ret = -1;
            }
        }
    }

    free(client_secret.base);
    free(server_pubkey.base);
    free(server_secret.base);

    if (ret == 0) {
        /* client abort */
        ret = client->create(client, &ctx);
        if (ret == 0) {
            ret = ctx->on_exchange(&ctx, 1, NULL, ptls_iovec_init(NULL, 0));
        }
        if (ctx != NULL) {
            ret = -1;
        }
    }

    return ret;
}


/*
Series of tests for loading a key and using it to build
a signature. Verification of the signature will be done
in the "verify" tests.
*/
#ifdef _WINDOWS
#ifdef _WINDOWS64
#define ASSET_DIR ..\\..\\data
#define ASSET_RSA_KEY "..\\..\\certs\\rsa\\key.pem"
#define ASSET_RSA_PKCS8_KEY "..\\..\\certs\\rsa-pkcs8\\key.pem"
#define ASSET_SECP256R1_KEY "..\\..\\certs\\secp256r1\\key.pem"
#define ASSET_SECP384R1_KEY "..\\..\\certs\\secp384r1\\key.pem"
#define ASSET_SECP521R1_KEY "..\\..\\certs\\secp521r1\\key.pem"
#define ASSET_SECP256R1_PKCS8_KEY "..\\..\\certs\\secp256r1-pkcs8\\key.pem"
#define ASSET_ED25519_KEY "..\\..\\certs\\ed25519\\key.pem"
#define ASSET_NO_SUCH_FILE "..\\..\\certs\\no_such_file.pem"
#define ASSET_NOT_A_PEM_FILE "..\\..\\certs\\not_a_valid_pem_file.pem"
#define ASSET_RSA_CERT "..\\..\\certs\\rsa/cert.pem"
#define ASSET_RSA_PKCS8_CERT "..\\..\\certs\\rsa-pkcs8\\cert.pem"
#define ASSET_SECP256R1_CERT "..\\..\\certs\\secp256r1\\cert.pem"
#define ASSET_SECP384R1_CERT "..\\..\\certs\\secp384r1\\cert.pem"
#define ASSET_SECP521R1_CERT "..\\..\\certs\\secp521r1\\cert.pem"
#define ASSET_SECP256R1_PKCS8_CERT "..\\..\\certs\\secp256r1-pkcs8/cert.pem"
#define ASSET_ED25519_CERT "..\\..\\certs\\ed25519\\cert.pem"

#define ASSET_TEST_CA "..\\..\\certs\\test-ca.crt"
#else
#define ASSET_DIR ..\\data
#define ASSET_RSA_KEY "..\\certs\\rsa\\key.pem"
#define ASSET_RSA_PKCS8_KEY "..\\certs\\rsa-pkcs8\\key.pem"
#define ASSET_SECP256R1_KEY "..\\certs\\secp256r1\\key.pem"
#define ASSET_SECP384R1_KEY "..\\certs\\secp384r1\\key.pem"
#define ASSET_SECP521R1_KEY "..\\certs\\secp521r1\\key.pem"
#define ASSET_SECP256R1_PKCS8_KEY "..\\certs\\secp256r1-pkcs8\\key.pem"
#define ASSET_ED25519_KEY "..\\certs\\ed25519\\key.pem"
#define ASSET_NO_SUCH_FILE "..\\certs\\no_such_file.pem"
#define ASSET_NOT_A_PEM_FILE "..\\certs\\not_a_valid_pem_file.pem"
#define ASSET_RSA_CERT "..\\certs\\rsa/cert.pem"
#define ASSET_RSA_PKCS8_CERT "..\\certs\\rsa-pkcs8\\cert.pem"
#define ASSET_SECP256R1_CERT "..\\certs\\secp256r1\\cert.pem"
#define ASSET_SECP384R1_CERT "..\\certs\\secp384r1\\cert.pem"
#define ASSET_SECP521R1_CERT "..\\certs\\secp521r1\\cert.pem"
#define ASSET_SECP256R1_PKCS8_CERT "..\\certs\\secp256r1-pkcs8/cert.pem"
#define ASSET_ED25519_CERT "..\\certs\\ed25519\\cert.pem"

#define ASSET_TEST_CA "data\\test-ca.crt"
#endif
#else
#define ASSET_DIR data
#define ASSET_RSA_KEY "certs/rsa/key.pem"
#define ASSET_RSA_PKCS8_KEY "certs/rsa-pkcs8/key.pem"
#define ASSET_SECP256R1_KEY "certs/secp256r1/key.pem"
#define ASSET_SECP384R1_KEY "certs/secp384r1/key.pem"
#define ASSET_SECP521R1_KEY "certs/secp521r1/key.pem"
#define ASSET_SECP256R1_PKCS8_KEY "certs/secp256r1-pkcs8/key.pem"
#define ASSET_ED25519_KEY "certs/ed25519/key.pem"
#define ASSET_NO_SUCH_FILE "certs/no_such_file.pem"
#define ASSET_NOT_A_PEM_FILE "certs/not_a_valid_pem_file.pem"
#define ASSET_RSA_CERT "certs/rsa/cert.pem"
#define ASSET_RSA_PKCS8_CERT "certs/rsa-pkcs8/cert.pem"
#define ASSET_SECP256R1_CERT "certs/secp256r1/cert.pem"
#define ASSET_SECP384R1_CERT "certs/secp384r1/cert.pem"
#define ASSET_SECP521R1_CERT "certs/secp521r1/cert.pem"
#define ASSET_SECP256R1_PKCS8_CERT "certs/secp256r1-pkcs8/cert.pem"
#define ASSET_ED25519_CERT "certs/ed25519/cert.pem"

#define ASSET_TEST_CA "certs/test-ca.crt"
#endif

#define ASSET_RSA_NAME "rsa.test.example.com"
#define ASSET_RSA_PKCS8_NAME "rsa.test.example.com"
#define ASSET_SECP256R1_NAME "test.example.com"
#define ASSET_SECP384R1_NAME "secp384r1.test.example.com"
#define ASSET_SECP521R1_NAME "secp521r1.test.example.com"
#define ASSET_SECP256R1_PKCS8_NAME "test.example.com"

static int mbedtls_test_load_one_der_key(char const* path_ref)
{
    int ret = -1;
    unsigned char hash[32];
    const unsigned char h0[32] = {
        1, 2, 3, 4, 5, 6, 7, 8,
        9, 10, 11, 12, 13, 14, 15, 16,
        17, 18, 19, 20, 21, 22, 23, 24,
        25, 26, 27, 28, 29, 30, 31, 32
    };
    ptls_context_t ctx = { 0 };

    char path[512];

    if ((ret = picoquic_get_input_path(path, sizeof(path), picoquic_solution_dir, path_ref)) != 0) {
        DBG_PRINTF("Cannot build path from %s", path_ref);
    }
    else {
        ret = ptls_mbedtls_load_private_key(path, &ctx);
        if (ret != 0) {
            DBG_PRINTF("Cannot create sign_certificate from: %s\n", path);
        }
        else if (ctx.sign_certificate == NULL) {
            DBG_PRINTF("Sign_certificate not set in ptls context for: %s\n", path);
            ret = -1;
        }
        else {
            /* Try to sign something */
            int ret;
            ptls_mbedtls_sign_certificate_t* signer = (ptls_mbedtls_sign_certificate_t*)
                (((unsigned char*)ctx.sign_certificate) - offsetof(struct st_ptls_mbedtls_sign_certificate_t, super));
            ptls_buffer_t outbuf;
            uint8_t outbuf_smallbuf[256];
            ptls_iovec_t input = { hash, sizeof(hash) };
            uint16_t selected_algorithm = 0;
            int num_algorithms = 0;
            uint16_t algorithms[16];
            memcpy(hash, h0, 32);
            while (signer->schemes[num_algorithms].scheme_id != UINT16_MAX && num_algorithms < 16) {
                algorithms[num_algorithms] = signer->schemes[num_algorithms].scheme_id;
                num_algorithms++;
            }

            ptls_buffer_init(&outbuf, outbuf_smallbuf, sizeof(outbuf_smallbuf));

            ret = ptls_mbedtls_sign_certificate(ctx.sign_certificate, NULL, NULL, &selected_algorithm,
                &outbuf, input, algorithms, num_algorithms);
            if (ret == 0) {
                DBG_PRINTF("Signed a message, key: %s, scheme: %x, signature size: %zu\n", path, selected_algorithm, outbuf.off);
            }
            else {
                DBG_PRINTF("Sign failed, key: %s, scheme: %x, signature size: %zu\n", path, selected_algorithm, outbuf.off);
            }
            ptls_buffer_dispose(&outbuf);
            ptls_mbedtls_dispose_sign_certificate(&signer->super);
            free(signer);
        }
    }

    return ret;
}

int mbedtls_load_key_test(void)
{
    int ret = 0;


    /* Initialize the PSA crypto library. */
    if ((ret = ptls_mbedtls_init()) != 0) {
        DBG_PRINTF("%s", "psa_crypto_init fails.");
    }
    else {
        if (ret == 0) {
            ret = mbedtls_test_load_one_der_key(ASSET_RSA_KEY);
        }

        if (ret == 0) {
            ret = mbedtls_test_load_one_der_key(ASSET_SECP256R1_KEY);
        }

        if (ret == 0) {
            ret = mbedtls_test_load_one_der_key(ASSET_SECP384R1_KEY);
        }

        if (ret == 0) {
            ret = mbedtls_test_load_one_der_key(ASSET_SECP521R1_KEY);
        }

        if (ret == 0) {
            ret = mbedtls_test_load_one_der_key(ASSET_SECP256R1_PKCS8_KEY);
        }

        if (ret == 0) {
            ret = mbedtls_test_load_one_der_key(ASSET_RSA_PKCS8_KEY);
        }
#if 0
        /* Commenting out ED25519 for now, probably not supported yet in MBEDTLS/PSA */
        if (ret == 0) {
            ret = mbedtls_test_load_one_der_key(ASSET_ED25519_KEY);
        }
#endif
        /* Keep PSA initialized, later tests in this process still use it. */
    }

    return ret;
}

/*
* Testing of failure modes.
* 
* Testing the various reasons why loading of key should fail:
* - key file does not exist
* - key file is empty, no PEM keyword
* - key file does not contain a key (we use a cert file for that)
* - key file is for ED25559, which is not supported
*/
int mbedtls_load_key_fail_test(void)
{
    int ret = 0;


    if ((ret = ptls_mbedtls_init()) != 0) {
        DBG_PRINTF("%s", "psa_crypto_init fails.");
    }
    else {
        if (ret == 0 && mbedtls_test_load_one_der_key(ASSET_NO_SUCH_FILE) == 0)
        {
            ret = -1;
        }

        if (ret == 0 && mbedtls_test_load_one_der_key(ASSET_NOT_A_PEM_FILE) == 0)
        {
            ret = -1;
        }

        if (ret == 0 && mbedtls_test_load_one_der_key(ASSET_RSA_CERT) == 0)
        {
            ret = -1;
        }

        if (ret == 0 && mbedtls_test_load_one_der_key(ASSET_ED25519_KEY) == 0)
        {
            ret = -1;
        }

        /* Keep PSA initialized, later tests in this process still use it. */
    }

    return ret;
}


/* testing of public key export.
* The API to export a public key directly from the certificate is not present
* in older versions of MbedTLS, which might be installed by default in
* old versions of operating systems. Instead, we develop a robust way to
* export the key bits from the "raw public key" bytes in the certificate.
* But we need to test that this work properly, and we do that by
* comparing to the export of key bits from the private key, because for
* these tests we know the private key.
*/
int ptls_mbedtls_get_public_key_info(const unsigned char* pk_raw, size_t pk_raw_len,
    psa_key_attributes_t* attributes,
    size_t* key_index, size_t* key_length);

static int test_retrieve_pubkey_one(char const* key_path_ref, char const* cert_path_ref)
{
    int ret = 0;
    ptls_context_t ctx = { 0 };
    mbedtls_x509_crt* chain_head = (mbedtls_x509_crt*)malloc(sizeof(mbedtls_x509_crt));
    uint8_t pubkey_ref[1024];
    size_t pubkey_ref_len = 0;
    char cert_path[512];
    char key_path[512];

    if (chain_head != NULL) {
        mbedtls_x509_crt_init(chain_head);
    }
    if ((ret = picoquic_get_input_path(cert_path, sizeof(cert_path), picoquic_solution_dir, cert_path_ref)) != 0 ||
        (ret = picoquic_get_input_path(key_path, sizeof(key_path), picoquic_solution_dir, key_path_ref)) != 0) {
        DBG_PRINTF("Cannot build path from %s or %s", cert_path_ref, key_path_ref);
    }
    else {
        /* Preparation: load the certificate and the private key */
        if (chain_head == NULL) {
            ret = PTLS_ERROR_NO_MEMORY;
        }
        if (ret == 0 && mbedtls_x509_crt_parse_file(chain_head, cert_path) != 0) {
            ret = -1;
        }
        if (ret == 0) {
            ret = ptls_mbedtls_load_private_key(key_path, &ctx);
            if (ret != 0) {
                DBG_PRINTF("Cannot create load private key from: %s, ret = %d (0x%x, -0x%x)", key_path, ret, ret, (int16_t)-ret);
            }
        }
        /* Export the pubkey bits from the private key, for reference */
        if (ret == 0) {
            ptls_mbedtls_sign_certificate_t* signer = (ptls_mbedtls_sign_certificate_t*)
                (((unsigned char*)ctx.sign_certificate) - offsetof(struct st_ptls_mbedtls_sign_certificate_t, super));
            if (psa_export_public_key(signer->key_id, pubkey_ref, sizeof(pubkey_ref), &pubkey_ref_len) != 0) {
                ret = -1;
            }
        }
        /* Obtain the key bits from the certificate */
        if (ret == 0) {
            uint8_t* pk_raw = chain_head->pk_raw.p;
            size_t pk_raw_len = chain_head->pk_raw.len;
            size_t key_index;
            size_t key_length;
            psa_key_attributes_t attributes = psa_key_attributes_init();

            ret = ptls_mbedtls_get_public_key_info(pk_raw, pk_raw_len,
                &attributes, &key_index, &key_length);

            if (ret == 0) {
                /* Compare key bits */
                if (pubkey_ref_len != key_length ||
                    memcmp(pubkey_ref, chain_head->pk_raw.p + key_index, key_length) != 0) {
                    ret = -1;
                    DBG_PRINTF("%s", "Fail, retrieved key does not match public key.");
                }
            }
            else {
                DBG_PRINTF("%s", "Fail");
            }
        }
    }
    /* Clean up */
    if (ctx.sign_certificate != NULL) {
        ptls_mbedtls_dispose_sign_certificate(ctx.sign_certificate);
        free(ctx.sign_certificate);
    }
    if (chain_head != NULL) {
        mbedtls_x509_crt_free(chain_head);
        free(chain_head);
    }
    return ret;
}

int mbedtls_retrieve_pubkey_test(void)
{
    int ret = 0;
    if ((ret = ptls_mbedtls_init()) != 0) {
        DBG_PRINTF("%s", "psa_crypto_init fails.");
    }
    else {
        if (ret == 0) {
            ret = test_retrieve_pubkey_one(ASSET_RSA_KEY, ASSET_RSA_CERT);
        }

        if (ret == 0) {
            ret = test_retrieve_pubkey_one(ASSET_SECP256R1_KEY, ASSET_SECP256R1_CERT);
        }

        if (ret == 0) {
            ret = test_retrieve_pubkey_one(ASSET_SECP384R1_KEY, ASSET_SECP384R1_CERT);
        }

        if (ret == 0) {
            ret = test_retrieve_pubkey_one(ASSET_SECP521R1_KEY, ASSET_SECP521R1_CERT);
        }

        /* Keep PSA initialized, later tests in this process still use it. */
    }

    return ret;
}


/*
* End to end testing of signature and verifiers:
* The general scenario is:
* - prepare a signature of a test string using a simulated
*   server programmed with a private key and a certificate
*   list.
* - verify the signature in a simulated client programmed
*   with a list of trusted certificates.
* 
* The test is configured with the file names for the key,
* certificate list, and trusted certificates. 
* 
* Ideally, we should be able to run the test by mixing and 
* matching mbedtls server or clients with other backends.
* However, using openssl will require some plumbing,
* which will be done when integrating this code in 
* picotls. For now, we will only do self tests, and test with
* minicrypto if the key is supported.
*/

const unsigned char test_sign_verify_message[] = {
    0,  1,  2,  3,  4,  5,  6,  7,  8,  9 , 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
    20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
    40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59,
    60, 61, 62, 63, 64
};
const size_t test_sign_verify_message_size = sizeof(test_sign_verify_message);

uint16_t test_sign_signature_algorithms[] = {
    0x0401, 0x0403, 0x501, 0x0503, 0x0601, 0x0603,
    0x0804, 0x0805, 0x0806, 0x0807, 0x0808
};

size_t num_test_sign_signature_algorithms = sizeof(test_sign_signature_algorithms) / sizeof(uint16_t);

static int test_sign_init_server_mbedtls(ptls_context_t* ctx, char const* key_path, char const* cert_path)
{
    int ret = ptls_mbedtls_load_private_key(key_path, ctx);
    if (ret == 0 &&
        (ctx->certificates.list = picoquic_mbedtls_get_certs_from_file(cert_path, &ctx->certificates.count)) == NULL){
        ret = -1;
    }
    return ret;
}

static int test_sign_init_server_minicrypto(ptls_context_t* ctx, char const* key_path, char const* cert_path)
{
    int ret = ptls_minicrypto_load_private_key(ctx, key_path);
    if (ret == 0) {
        ret = ptls_load_certificates(ctx, cert_path);
    }
    return ret;
}

static void test_sign_free_certificates(ptls_context_t* ctx)
{
    if (ctx->certificates.list != NULL) {
        for (int i = 0; i < ctx->certificates.count; i++) {
            free(ctx->certificates.list[i].base);
        }
        free(ctx->certificates.list);
    }
    ctx->certificates.list = NULL;
    ctx->certificates.count = 0;
}

static void test_sign_free_context(ptls_context_t* ctx, int config)
{
    /* Free the server context */
    if (ctx == NULL) {
        return;
    }
    test_sign_free_certificates(ctx);
    if (ctx->sign_certificate != NULL) {
        switch (config) {
        case 0:
            ptls_mbedtls_dispose_sign_certificate(ctx->sign_certificate);
            free(ctx->sign_certificate);
            ctx->sign_certificate = NULL;
            break;
        case 1:
        default:
            free(ctx->sign_certificate);
            ctx->sign_certificate = NULL;
        }
    }

    if (ctx->verify_certificate != NULL) {
        switch (config) {
        case 0:
            ptls_mbedtls_dispose_verify_certificate(ctx->verify_certificate);
            ctx->verify_certificate = NULL;
            break;
        default:
            break;
        }
    }

    free(ctx);
}

static ptls_context_t* test_sign_set_ptls_context(char const* key_path, char const* cert_path, char const* trusted_path, int is_server, int config)
{
    int ret = 0;
    ptls_context_t* ctx = (ptls_context_t*)malloc(sizeof(ptls_context_t));

    if (ctx == NULL) {
        return NULL;
    }

    memset(ctx, 0, sizeof(ptls_context_t));
    ctx->get_time = &ptls_get_time;

    switch (config) {
    case 0:
        ctx->random_bytes = ptls_mbedtls_random_bytes;
        break;
    case 1:
    default:
        ctx->random_bytes = ptls_minicrypto_random_bytes;
        break;
    }

    if (is_server) {
        /* First, create the "signer" plug-in */
        switch (config) {
        case 0: /* MbedTLS */
            ret = test_sign_init_server_mbedtls(ctx, key_path, cert_path);
            break;
        case 1: /* Minicrypto */
            ret = test_sign_init_server_minicrypto(ctx, key_path, cert_path);
            break;
        default:
            ret = -1;
            break;
        }
    }
    else {
        /* Initialize the client verify context */
        unsigned int is_cert_store_not_empty = 0;
        switch (config) {
        case 0: /* MbedTLS */
            ctx->verify_certificate = ptls_mbedtls_get_certificate_verifier(trusted_path,
                &is_cert_store_not_empty);
            break;
        default:
            ret = -1;
            break;
        }
    }

    if (ret != 0) {
        /* Release and return NULL */
        test_sign_free_context(ctx, config);
        ctx = NULL;
    }
    return ctx;
}

static int test_sign_verify_one(char const* key_path_ref, char const * cert_path_ref, char const * trusted_path_ref,
    char const * server_name, int server_config, int client_config)
{
    int ret = 0;
    char cert_path[512];
    char key_path[512];
    char trusted_path[512];

    if ((ret = picoquic_get_input_path(cert_path, sizeof(cert_path), picoquic_solution_dir, cert_path_ref)) != 0 ||
        (ret = picoquic_get_input_path(key_path, sizeof(key_path), picoquic_solution_dir, key_path_ref)) != 0 ||
        (ret = picoquic_get_input_path(trusted_path, sizeof(trusted_path), picoquic_solution_dir, trusted_path_ref)) != 0) {
        DBG_PRINTF("Cannot build path from %s, %s or %s", cert_path_ref, key_path_ref, trusted_path_ref);
    }
    else {
        ptls_context_t* server_ctx = test_sign_set_ptls_context(key_path, cert_path, trusted_path, 1, server_config); 
        ptls_context_t* client_ctx = test_sign_set_ptls_context(key_path, cert_path, trusted_path, 0, client_config);
        ptls_t* client_tls = NULL;
        ptls_t* server_tls = NULL;
        uint16_t selected_algorithm = 0;
        uint8_t signature_smallbuf[256];
        ptls_buffer_t signature;
        struct {
            int (*cb)(void *verify_ctx, uint16_t algo, ptls_iovec_t data, ptls_iovec_t signature);
            void *verify_ctx;
        } certificate_verify;
        ptls_iovec_t input;

        input.base = (uint8_t*)test_sign_verify_message;
        input.len = test_sign_verify_message_size;

        ptls_buffer_init(&signature, signature_smallbuf, sizeof(signature_smallbuf));

        if (server_ctx == NULL || client_ctx == NULL) {
            ret = -1;
        }

        if (ret == 0) {
            /* Then, create a tls context for the server. */
            server_tls = ptls_new(server_ctx, 1);
            if (server_tls == NULL) {
                DBG_PRINTF("ptls_new (server, %s) returns NULL", key_path);
                ret = -1;
            }
        }

        if (ret == 0) {
            /* Then, create the signature messages */
            ret = server_ctx->sign_certificate->cb(server_ctx->sign_certificate, server_tls, NULL,
                &selected_algorithm, &signature, input,
                test_sign_signature_algorithms, num_test_sign_signature_algorithms);
            if (ret != 0) {
                DBG_PRINTF("sign_certificate (%s) returns 0x%x (%d)", key_path, ret, ret);
            }
        }

        if (ret == 0) {
            /* Then, create a tls context for the client. */
            client_tls = ptls_new(client_ctx, 0);
            if (client_tls == NULL) {
                    DBG_PRINTF("ptls_new (client, %s) returns NULL", key_path);
                ret = -1;
            }
        }

        if (ret == 0) {
            /* verify the certificates */
            ret = client_ctx->verify_certificate->cb(client_ctx->verify_certificate, client_tls, server_name,
                &certificate_verify.cb, &certificate_verify.verify_ctx,
                server_ctx->certificates.list, server_ctx->certificates.count);
            if (ret == 0) {
                /* verify the signature */
                ptls_iovec_t sig;
                sig.base = signature.base;
                sig.len = signature.off;

                ret = certificate_verify.cb(certificate_verify.verify_ctx, selected_algorithm, input, sig);
                if (ret != 0) {
                    DBG_PRINTF("verify_signature (%s) returns 0x%x (%d)", key_path, ret, ret);
                    ret = -1;
                }
            } 
            else if (certificate_verify.cb != NULL) {
                /* In case of failure, call with null args to free memory. */
                DBG_PRINTF("verify_certificate (%s) returns 0x%x (%d)", cert_path, ret, ret);
                ptls_iovec_t empty;
                empty.base = NULL;
                empty.len = 0;
                (void)certificate_verify.cb(certificate_verify.verify_ctx, 0, empty, empty);
            }
        }
        if (ret == 0) {
            DBG_PRINTF("verify_signature (%s) and cert (%s) succeeds.", key_path, cert_path);
        }

        ptls_buffer_dispose(&signature);

        if (client_tls != NULL) {
            ptls_free(client_tls);
        }
        if (server_tls != NULL) {
            ptls_free(server_tls);
        }

        test_sign_free_context(server_ctx, server_config);
        test_sign_free_context(client_ctx, client_config);
    }
    return ret;
}

int mbedtls_sign_verify_test(void)
{
    int ret = 0;

    if ((ret = ptls_mbedtls_init()) != 0) {
        DBG_PRINTF("%s", "psa_crypto_init fails.");
    }
    else {
        if (ret == 0) {
            ret = test_sign_verify_one(ASSET_RSA_KEY, ASSET_RSA_CERT, ASSET_TEST_CA, ASSET_RSA_NAME, 0, 0);
        }

        if (ret == 0) {
            ret = test_sign_verify_one(ASSET_SECP256R1_KEY, ASSET_SECP256R1_CERT, ASSET_TEST_CA, ASSET_SECP256R1_NAME, 0, 0);
        }

        if (ret == 0) {
            ret = test_sign_verify_one(ASSET_SECP384R1_KEY, ASSET_SECP384R1_CERT, ASSET_TEST_CA, ASSET_SECP384R1_NAME, 0, 0);
        }

        if (ret == 0) {
            ret = test_sign_verify_one(ASSET_SECP521R1_KEY, ASSET_SECP521R1_CERT, ASSET_TEST_CA, ASSET_SECP521R1_NAME, 0, 0);
        }

        if (ret == 0) {
            ret = test_sign_verify_one(ASSET_SECP256R1_PKCS8_KEY, ASSET_SECP256R1_PKCS8_CERT, ASSET_TEST_CA, ASSET_SECP256R1_PKCS8_NAME, 0, 0);
        }

        /* Keep PSA initialized, later tests in this process still use it. */
    }
    return ret;
}

/*
* ECDSA signature encoding test.
* TLS 1.3 (RFC 8446, section 4.2.3) requires ECDSA signatures in
* CertificateVerify to be DER encoded ECDSA-Sig-Value:
*     SEQUENCE { r INTEGER, s INTEGER }
* PSA's psa_sign_hash() produces the raw r || s form instead. Because the
* mbedtls verifier in picoquic makes the same assumption, the sign/verify
* self test above does not catch an encoding error. This test checks the
* encoding directly, then verifies the signature with mbedtls_pk_verify()
* against the public key in the certificate, which expects DER encoding
* for ECDSA, like other TLS stacks.
*/

/* Parse a DER length starting at der[*x]; returns -1 on error. */
static int test_ecdsa_der_parse_length(const uint8_t* der, size_t der_len, size_t* x, size_t* l)
{
    if (*x >= der_len) {
        return -1;
    }
    if ((der[*x] & 0x80) == 0) {
        *l = der[*x];
        *x += 1;
    }
    else {
        size_t nb_bytes = der[*x] & 0x7f;
        *x += 1;
        if (nb_bytes == 0 || nb_bytes > 2 || *x + nb_bytes > der_len) {
            return -1;
        }
        *l = 0;
        for (size_t i = 0; i < nb_bytes; i++) {
            *l = (*l << 8) | der[*x];
            *x += 1;
        }
        if (*l < 128) {
            /* Not minimal encoding */
            return -1;
        }
    }
    return (*x + *l <= der_len) ? 0 : -1;
}

/* Parse a DER INTEGER at der[*x], check that it is a positive, minimally
* encoded value of at most max_bytes significant bytes. */
static int test_ecdsa_der_parse_integer(const uint8_t* der, size_t der_len, size_t* x, size_t max_bytes)
{
    size_t l = 0;

    if (*x >= der_len || der[*x] != 0x02) {
        return -1;
    }
    *x += 1;
    if (test_ecdsa_der_parse_length(der, der_len, x, &l) != 0 || l == 0) {
        return -1;
    }
    if ((der[*x] & 0x80) != 0) {
        /* Negative value */
        return -1;
    }
    if (l > 1 && der[*x] == 0 && (der[*x + 1] & 0x80) == 0) {
        /* Not minimal encoding */
        return -1;
    }
    if (l > max_bytes + 1 || (l == max_bytes + 1 && der[*x] != 0)) {
        /* Larger than the curve order */
        return -1;
    }
    *x += l;
    return 0;
}

static int test_ecdsa_der_check_format(const uint8_t* sig, size_t sig_len, size_t curve_bytes)
{
    size_t x = 0;
    size_t l = 0;

    if (sig_len < 2 || sig[0] != 0x30) {
        return -1;
    }
    x = 1;
    if (test_ecdsa_der_parse_length(sig, sig_len, &x, &l) != 0 || x + l != sig_len) {
        return -1;
    }
    if (test_ecdsa_der_parse_integer(sig, sig_len, &x, curve_bytes) != 0 ||
        test_ecdsa_der_parse_integer(sig, sig_len, &x, curve_bytes) != 0) {
        return -1;
    }
    return (x == sig_len) ? 0 : -1;
}

static int test_ecdsa_der_one(char const* key_path_ref, char const* cert_path_ref,
    uint16_t expected_scheme, mbedtls_md_type_t md_type, psa_algorithm_t hash_alg, size_t curve_bytes)
{
    int ret = 0;
    char cert_path[512];
    char key_path[512];
    ptls_context_t ctx = { 0 };
    mbedtls_x509_crt crt;
    uint16_t selected_algorithm = 0;
    uint8_t signature_smallbuf[256];
    ptls_buffer_t signature;
    ptls_iovec_t input;

    input.base = (uint8_t*)test_sign_verify_message;
    input.len = test_sign_verify_message_size;
    mbedtls_x509_crt_init(&crt);
    ptls_buffer_init(&signature, signature_smallbuf, sizeof(signature_smallbuf));

    if ((ret = picoquic_get_input_path(cert_path, sizeof(cert_path), picoquic_solution_dir, cert_path_ref)) != 0 ||
        (ret = picoquic_get_input_path(key_path, sizeof(key_path), picoquic_solution_dir, key_path_ref)) != 0) {
        DBG_PRINTF("Cannot build path from %s or %s", cert_path_ref, key_path_ref);
    }
    else if ((ret = ptls_mbedtls_load_private_key(key_path, &ctx)) != 0) {
        DBG_PRINTF("Cannot load private key from: %s, ret = %d", key_path, ret);
    }
    else if ((ret = mbedtls_x509_crt_parse_file(&crt, cert_path)) != 0) {
        DBG_PRINTF("Cannot load certificate from: %s, ret = -0x%x", cert_path, (unsigned int)-ret);
    }
    else if ((ret = ctx.sign_certificate->cb(ctx.sign_certificate, NULL, NULL, &selected_algorithm, &signature, input,
        test_sign_signature_algorithms, num_test_sign_signature_algorithms)) != 0) {
        DBG_PRINTF("sign_certificate (%s) returns 0x%x (%d)", key_path, ret, ret);
    }
    else if (selected_algorithm != expected_scheme) {
        DBG_PRINTF("sign_certificate (%s) selected 0x%04x, expected 0x%04x", key_path, selected_algorithm, expected_scheme);
        ret = -1;
    }
    else if (test_ecdsa_der_check_format(signature.base, signature.off, curve_bytes) != 0) {
        DBG_PRINTF("Signature (%s, 0x%04x, %zu bytes) is not a DER encoded ECDSA-Sig-Value",
            key_path, selected_algorithm, signature.off);
        ret = -1;
    }
    else {
        unsigned char hash[PSA_HASH_MAX_SIZE];
        size_t hash_length = 0;

        if (psa_hash_compute(hash_alg, input.base, input.len, hash, sizeof(hash), &hash_length) != PSA_SUCCESS) {
            DBG_PRINTF("Cannot hash message for %s", key_path);
            ret = -1;
        }
        else if ((ret = mbedtls_pk_verify(&crt.pk, md_type, hash, hash_length,
            signature.base, signature.off)) != 0) {
            DBG_PRINTF("mbedtls_pk_verify (%s, 0x%04x) returns -0x%x", cert_path, selected_algorithm, (unsigned int)-ret);
            ret = -1;
        }
    }

    ptls_buffer_dispose(&signature);
    mbedtls_x509_crt_free(&crt);
    if (ctx.sign_certificate != NULL) {
        ptls_mbedtls_dispose_sign_certificate(ctx.sign_certificate);
        free(ctx.sign_certificate);
    }
    return ret;
}

int mbedtls_ecdsa_der_test(void)
{
    int ret = 0;

    if ((ret = ptls_mbedtls_init()) != 0) {
        DBG_PRINTF("%s", "psa_crypto_init fails.");
    }
    else {
        if (ret == 0) {
            ret = test_ecdsa_der_one(ASSET_SECP256R1_KEY, ASSET_SECP256R1_CERT,
                PTLS_SIGNATURE_ECDSA_SECP256R1_SHA256, MBEDTLS_MD_SHA256, PSA_ALG_SHA_256, 32);
        }

        if (ret == 0) {
            ret = test_ecdsa_der_one(ASSET_SECP384R1_KEY, ASSET_SECP384R1_CERT,
                PTLS_SIGNATURE_ECDSA_SECP384R1_SHA384, MBEDTLS_MD_SHA384, PSA_ALG_SHA_384, 48);
        }

        if (ret == 0) {
            ret = test_ecdsa_der_one(ASSET_SECP521R1_KEY, ASSET_SECP521R1_CERT,
                PTLS_SIGNATURE_ECDSA_SECP521R1_SHA512, MBEDTLS_MD_SHA512, PSA_ALG_SHA_512, 66);
        }

        if (ret == 0) {
            ret = test_ecdsa_der_one(ASSET_SECP256R1_PKCS8_KEY, ASSET_SECP256R1_PKCS8_CERT,
                PTLS_SIGNATURE_ECDSA_SECP256R1_SHA256, MBEDTLS_MD_SHA256, PSA_ALG_SHA_256, 32);
        }

        /* Keep PSA initialized, later tests in this process still use it. */
    }
    return ret;
}

/*
* ECDSA verification test.
* Check that the mbedtls verifier accepts DER encoded ECDSA signatures,
* as sent by other TLS stacks, and rejects anything else -- in particular
* the raw r || s form.
* The P-256 signature is produced by the minicrypto signer, which shares no
* code with the mbedtls backend. The P-384 and P-521 signatures are produced
* by the mbedtls signer, whose encoding is verified independently by
* mbedtls_ecdsa_der_test.
*/

/* Verify one signature on the client side, and check that it is accepted
* or rejected as expected. Returns 0 if the expectation is met. */
static int test_ecdsa_verify_expect(ptls_context_t* client_ctx, ptls_context_t* server_ctx, char const* server_name,
    uint16_t algo, ptls_iovec_t input, const uint8_t* sig_bytes, size_t sig_len, int expect_accept, char const* label)
{
    int ret = 0;
    int verify_ret = 0;
    ptls_t* client_tls = ptls_new(client_ctx, 0);
    int (*verify_cb)(void* verify_ctx, uint16_t algo, ptls_iovec_t data, ptls_iovec_t signature) = NULL;
    void* verify_ctx = NULL;

    if (client_tls == NULL) {
        DBG_PRINTF("ptls_new (client, %s) returns NULL", server_name);
        return -1;
    }
    /* The verify context is released after each use, so the certificate
    * must be verified again for each signature. */
    ret = client_ctx->verify_certificate->cb(client_ctx->verify_certificate, client_tls, server_name,
        &verify_cb, &verify_ctx, server_ctx->certificates.list, server_ctx->certificates.count);
    if (ret != 0) {
        DBG_PRINTF("verify_certificate (%s) returns 0x%x (%d)", server_name, ret, ret);
        if (verify_cb != NULL) {
            ptls_iovec_t empty = { NULL, 0 };
            (void)verify_cb(verify_ctx, 0, empty, empty);
        }
        ret = -1;
    }
    else {
        ptls_iovec_t sig;
        sig.base = (uint8_t*)sig_bytes;
        sig.len = sig_len;
        verify_ret = verify_cb(verify_ctx, algo, input, sig);
        if ((verify_ret == 0) != (expect_accept != 0)) {
            DBG_PRINTF("%s signature (%s, 0x%04x, %zu bytes): expected %s, got 0x%x",
                label, server_name, algo, sig_len, (expect_accept) ? "accept" : "reject", verify_ret);
            ret = -1;
        }
    }
    ptls_free(client_tls);
    return ret;
}

static int test_ecdsa_verify_one(char const* key_path_ref, char const* cert_path_ref, char const* server_name,
    int server_config, uint16_t expected_scheme, psa_algorithm_t hash_alg)
{
    int ret = 0;
    char cert_path[512];
    char key_path[512];
    char trusted_path[512];
    ptls_context_t* server_ctx = NULL;
    ptls_context_t* client_ctx = NULL;
    ptls_t* server_tls = NULL;
    uint16_t selected_algorithm = 0;
    uint8_t signature_smallbuf[256];
    ptls_buffer_t signature;
    uint8_t mutated[256];
    ptls_iovec_t input;

    input.base = (uint8_t*)test_sign_verify_message;
    input.len = test_sign_verify_message_size;
    ptls_buffer_init(&signature, signature_smallbuf, sizeof(signature_smallbuf));

    if ((ret = picoquic_get_input_path(cert_path, sizeof(cert_path), picoquic_solution_dir, cert_path_ref)) != 0 ||
        (ret = picoquic_get_input_path(key_path, sizeof(key_path), picoquic_solution_dir, key_path_ref)) != 0 ||
        (ret = picoquic_get_input_path(trusted_path, sizeof(trusted_path), picoquic_solution_dir, ASSET_TEST_CA)) != 0) {
        DBG_PRINTF("Cannot build path from %s or %s", cert_path_ref, key_path_ref);
    }
    else if ((server_ctx = test_sign_set_ptls_context(key_path, cert_path, trusted_path, 1, server_config)) == NULL ||
        (client_ctx = test_sign_set_ptls_context(key_path, cert_path, trusted_path, 0, 0)) == NULL ||
        (server_tls = ptls_new(server_ctx, 1)) == NULL) {
        DBG_PRINTF("Cannot create contexts for %s", key_path);
        ret = -1;
    }
    else if ((ret = server_ctx->sign_certificate->cb(server_ctx->sign_certificate, server_tls, NULL,
        &selected_algorithm, &signature, input,
        test_sign_signature_algorithms, num_test_sign_signature_algorithms)) != 0) {
        DBG_PRINTF("sign_certificate (%s) returns 0x%x (%d)", key_path, ret, ret);
    }
    else if (selected_algorithm != expected_scheme || signature.off < 8 || signature.off + 2 > sizeof(mutated)) {
        DBG_PRINTF("Unexpected signature (%s), scheme 0x%04x, %zu bytes", key_path, selected_algorithm, signature.off);
        ret = -1;
    }
    else {
        const uint8_t* der = signature.base;
        size_t der_len = signature.off;

        /* The valid DER signature must be accepted */
        ret = test_ecdsa_verify_expect(client_ctx, server_ctx, server_name, selected_algorithm, input,
            der, der_len, 1, "Valid DER");
        /* Trailing data after the signature */
        if (ret == 0) {
            memcpy(mutated, der, der_len);
            mutated[der_len] = 0;
            ret = test_ecdsa_verify_expect(client_ctx, server_ctx, server_name, selected_algorithm, input,
                mutated, der_len + 1, 0, "Trailing byte");
        }
        /* Wrong SEQUENCE tag */
        if (ret == 0) {
            memcpy(mutated, der, der_len);
            mutated[0] = 0x31;
            ret = test_ecdsa_verify_expect(client_ctx, server_ctx, server_name, selected_algorithm, input,
                mutated, der_len, 0, "SET tag");
        }
        /* Truncated signature */
        if (ret == 0) {
            ret = test_ecdsa_verify_expect(client_ctx, server_ctx, server_name, selected_algorithm, input,
                der, der_len - 1, 0, "Truncated");
        }
        /* Corrupted value of s */
        if (ret == 0) {
            memcpy(mutated, der, der_len);
            mutated[der_len - 1] ^= 1;
            ret = test_ecdsa_verify_expect(client_ctx, server_ctx, server_name, selected_algorithm, input,
                mutated, der_len, 0, "Corrupted");
        }
        /* Non minimal encoding of r, with an extra leading zero. Only tested
        * when the lengths are in short form, i.e., not for P-521. */
        if (ret == 0 && der[1] < 0x7f && der[2] == 0x02 && der[3] < 0x7f) {
            mutated[0] = 0x30;
            mutated[1] = der[1] + 1;
            mutated[2] = 0x02;
            mutated[3] = der[3] + 1;
            mutated[4] = 0;
            memcpy(mutated + 5, der + 4, der_len - 4);
            ret = test_ecdsa_verify_expect(client_ctx, server_ctx, server_name, selected_algorithm, input,
                mutated, der_len + 1, 0, "Non minimal DER");
        }
        /* The raw r || s form produced by PSA must be rejected. This requires
        * access to the private key, so it is only tested with mbedtls. */
        if (ret == 0 && server_config == 0) {
            ptls_mbedtls_sign_certificate_t* signer = (ptls_mbedtls_sign_certificate_t*)
                (((unsigned char*)server_ctx->sign_certificate) - offsetof(struct st_ptls_mbedtls_sign_certificate_t, super));
            uint8_t hash[PSA_HASH_MAX_SIZE];
            size_t hash_length = 0;
            size_t raw_length = 0;

            if (psa_hash_compute(hash_alg, input.base, input.len, hash, sizeof(hash), &hash_length) != PSA_SUCCESS ||
                psa_sign_hash(signer->key_id, psa_get_key_algorithm(&signer->attributes), hash, hash_length,
                    mutated, sizeof(mutated), &raw_length) != PSA_SUCCESS) {
                DBG_PRINTF("Cannot compute raw signature (%s)", key_path);
                ret = -1;
            }
            else {
                ret = test_ecdsa_verify_expect(client_ctx, server_ctx, server_name, selected_algorithm, input,
                    mutated, raw_length, 0, "Raw r || s");
            }
        }
    }

    ptls_buffer_dispose(&signature);
    if (server_tls != NULL) {
        ptls_free(server_tls);
    }
    test_sign_free_context(server_ctx, server_config);
    test_sign_free_context(client_ctx, 0);
    return ret;
}

int mbedtls_ecdsa_verify_test(void)
{
    int ret = 0;

    if ((ret = ptls_mbedtls_init()) != 0) {
        DBG_PRINTF("%s", "psa_crypto_init fails.");
    }
    else {
        /* P-256 signature produced by minicrypto */
        if (ret == 0) {
            ret = test_ecdsa_verify_one(ASSET_SECP256R1_PKCS8_KEY, ASSET_SECP256R1_PKCS8_CERT, ASSET_SECP256R1_PKCS8_NAME,
                1, PTLS_SIGNATURE_ECDSA_SECP256R1_SHA256, PSA_ALG_SHA_256);
        }

        if (ret == 0) {
            ret = test_ecdsa_verify_one(ASSET_SECP256R1_KEY, ASSET_SECP256R1_CERT, ASSET_SECP256R1_NAME,
                0, PTLS_SIGNATURE_ECDSA_SECP256R1_SHA256, PSA_ALG_SHA_256);
        }

        if (ret == 0) {
            ret = test_ecdsa_verify_one(ASSET_SECP384R1_KEY, ASSET_SECP384R1_CERT, ASSET_SECP384R1_NAME,
                0, PTLS_SIGNATURE_ECDSA_SECP384R1_SHA384, PSA_ALG_SHA_384);
        }

        if (ret == 0) {
            ret = test_ecdsa_verify_one(ASSET_SECP521R1_KEY, ASSET_SECP521R1_CERT, ASSET_SECP521R1_NAME,
                0, PTLS_SIGNATURE_ECDSA_SECP521R1_SHA512, PSA_ALG_SHA_512);
        }

        /* Keep PSA initialized, later tests in this process still use it. */
    }
    return ret;
}

int mbedtls_configure_test(void)
{
    int ret = 0;
    int cipher_suite_match = 0;
    int key_exchange_max = 0;
    ptls_cipher_suite_t* targets[3] = {
        &ptls_mbedtls_aes128gcmsha256,
        &ptls_mbedtls_aes256gcmsha384,
        &ptls_mbedtls_chacha20poly1305sha256
    };
    ptls_key_exchange_algorithm_t* exchange[3] = {
        &ptls_mbedtls_secp256r1, &ptls_mbedtls_x25519 };

    /* Cleanup previous initiation of the TLS API and do it cleanly. */
    picoquic_tls_api_reset(TLS_API_INIT_FLAGS_NO_OPENSSL |
        TLS_API_INIT_FLAGS_NO_FUSION);
    /* Verify that the negotiated parameters have the expected value */
    for (int i = 0; i < PICOQUIC_CIPHER_SUITES_NB_MAX; i++) {
        for (int j = 0; j < 3; j++) {
            if (targets[j] == picoquic_cipher_suites[i]) {
                cipher_suite_match |= (1 << j);
            }
        }
        if (cipher_suite_match == 0x7) {
            break;
        }
    }
    if (cipher_suite_match != 0x7) {
        DBG_PRINTF("Suites registration test fails, expected 0x%x, got 0x%x",
            7, cipher_suite_match);
        ret = -1;
    }

    for (int i = 0; picoquic_key_exchanges[i] != NULL; i++) {
        if (picoquic_key_exchanges[i]->id == PTLS_GROUP_SECP256R1) {
            if (picoquic_key_exchanges[i] != &ptls_mbedtls_secp256r1) {
                DBG_PRINTF("%s", "key_exchange_secp256r1 does not match");
                ret = -1;
            }
            break;
        }
    }

    for (int i = 0; i < PICOQUIC_KEY_EXCHANGES_NB_MAX; i++) {
        for (int j = 0; j < 2; j++) {
            if (exchange[j] == picoquic_key_exchanges[i]) {
                key_exchange_max |= (1 << j);
            }
            if (key_exchange_max == 0x3) {
                break;
            }
        }
    }

    if (key_exchange_max != 0x3) {
        DBG_PRINTF("Exchange registration test fails, expected 0x%x, got 0x%x",
            7, key_exchange_max);
        ret = -1;
    }

    if (picoquic_set_private_key_from_file_fn != ptls_mbedtls_load_private_key ||
        picoquic_dispose_sign_certificate_fn != ptls_mbedtls_dispose_sign_certificate ||
        picoquic_get_certs_from_file_fn != picoquic_mbedtls_get_certs_from_file) {
        DBG_PRINTF("%s", "At least one private key function does not match mbedtls");
        ret = -1;
    }

    if (picoquic_get_certificate_verifier_fn != picoquic_mbedtls_get_certificate_verifier ||
        picoquic_dispose_certificate_verifier_fn != ptls_mbedtls_dispose_verify_certificate) {
        DBG_PRINTF("%s", "At least one verify certs function does not match mbedtls");
        ret = -1;
    }

    if (picoquic_crypto_random_provider_fn != ptls_mbedtls_random_bytes) {
        DBG_PRINTF("%s", "Crypto random provider does not match mbedtls");
        ret = -1;
    }

    /* Reset configuration to default after test */
    picoquic_tls_api_reset(0);

    return ret;
}


#endif
