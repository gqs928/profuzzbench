/*
* Author: Christian Huitema
* Copyright (c) 2020, Private Octopus, Inc.
* All rights reserved.
*
* Permission to use, copy, modify, and distribute this software for any
* purpose with or without fee is hereby granted, provided that the above
* copyright notice and this permission notice appear in all copies.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL Private Octopus, Inc. BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <stdlib.h>
#include <string.h>
#include "picoquic.h"
#include "picoquic_internal.h"
#include "picoquictest_internal.h"
#include "tls_api.h"
#include "picoquic_bbr.h"
#include "picoquic_qlog.h"
#include "picoquic_unified_log.h"

/* Add the additional links for multipath scenario */
int multipath_test_add_links(picoquic_test_tls_api_ctx_t* test_ctx, int mtu_drop)
{
    int ret = 0;
    /* Initialize the second client address */
    test_ctx->client_addr_2 = test_ctx->client_addr;
    test_ctx->client_addr_2.sin_port += 17;
    /* register the links */
    test_ctx->c_to_s_link_2 = picoquictest_sim_link_create(0.01, 10000, NULL, 20000, 0);
    test_ctx->s_to_c_link_2 = picoquictest_sim_link_create(0.01, 10000, NULL, 20000, 0);

    if (test_ctx->c_to_s_link_2 == NULL || test_ctx->s_to_c_link_2 == NULL) {
        ret = -1;
    }
    else if (mtu_drop) {
        test_ctx->c_to_s_link_2->path_mtu = (PICOQUIC_INITIAL_MTU_IPV4 + test_ctx->c_to_s_link->path_mtu) / 2;
        test_ctx->s_to_c_link_2->path_mtu = (PICOQUIC_INITIAL_MTU_IPV4 + test_ctx->s_to_c_link->path_mtu) / 2;
    }

    return ret;
}

/* Manage  the additional links for multipath scenario */
static void multipath_test_kill_links(picoquic_test_tls_api_ctx_t* test_ctx, int link_id)
{
    /* Make sure that nothing gets sent on the old links */
    if (link_id == 0) {
        test_ctx->c_to_s_link->next_send_time = UINT64_MAX;
        test_ctx->c_to_s_link->is_switched_off = 1;
        test_ctx->s_to_c_link->next_send_time = UINT64_MAX;
        test_ctx->s_to_c_link->is_switched_off = 1;
    }
    else {
        test_ctx->c_to_s_link_2->next_send_time = UINT64_MAX;
        test_ctx->c_to_s_link_2->is_switched_off = 1;
        test_ctx->s_to_c_link_2->next_send_time = UINT64_MAX;
        test_ctx->s_to_c_link_2->is_switched_off = 1;
    }
}


static void multipath_test_kill_server_links(picoquic_test_tls_api_ctx_t* test_ctx, int link_id)
{
    /* Make sure that nothing gets sent on the old links */
    if (link_id == 0) {
        test_ctx->s_to_c_link->next_send_time = UINT64_MAX;
        test_ctx->s_to_c_link->is_switched_off = 1;
    }
    else {
        test_ctx->s_to_c_link_2->next_send_time = UINT64_MAX;
        test_ctx->s_to_c_link_2->is_switched_off = 1;
    }
}

static void multipath_test_kill_client_links(picoquic_test_tls_api_ctx_t* test_ctx, int link_id)
{
    /* Make sure that nothing sent by the client gets through on that link */
    if (link_id == 0) {
        test_ctx->c_to_s_link->next_send_time = UINT64_MAX;
        test_ctx->c_to_s_link->is_switched_off = 1;
    }
    else {
        test_ctx->c_to_s_link_2->next_send_time = UINT64_MAX;
        test_ctx->c_to_s_link_2->is_switched_off = 1;
    }
}

static void multipath_test_set_unreachable(picoquic_test_tls_api_ctx_t* test_ctx, int link_id)
{
    if (link_id == 0) {
        test_ctx->c_to_s_link->is_unreachable = 1;
        test_ctx->s_to_c_link->is_unreachable = 1;
    }
    else {
        test_ctx->c_to_s_link_2->is_unreachable = 1;
        test_ctx->s_to_c_link_2->is_unreachable = 1;
    }
}

static void multipath_test_set_reachable(picoquic_test_tls_api_ctx_t* test_ctx, int link_id)
{
    if (link_id == 0) {
        test_ctx->c_to_s_link->is_unreachable = 0;
        test_ctx->s_to_c_link->is_unreachable = 0;
    }
    else {
        test_ctx->c_to_s_link_2->is_unreachable = 0;
        test_ctx->s_to_c_link_2->is_unreachable = 0;
    }
}

static void multipath_test_unkill_links(picoquic_test_tls_api_ctx_t* test_ctx, int link_id, uint64_t current_time)
{
    /* Make sure that nothing gets sent on the old links */
    if (link_id == 0) {
        test_ctx->c_to_s_link->next_send_time = current_time;
        test_ctx->c_to_s_link->is_switched_off = 0;
        test_ctx->s_to_c_link->next_send_time = current_time;
        test_ctx->s_to_c_link->is_switched_off = 1;
    }
    else {
        test_ctx->c_to_s_link_2->next_send_time = current_time;
        test_ctx->c_to_s_link_2->is_switched_off = 0;
        test_ctx->s_to_c_link_2->next_send_time = current_time;
        test_ctx->s_to_c_link_2->is_switched_off = 0;
    }
}

/* Add the additional links for multipath scenario */
static void multipath_test_sat_links(picoquic_test_tls_api_ctx_t* test_ctx, int link_id)
{
    if (link_id == 0) {
        /* Use low throughput for terrestrial link. */
        test_ctx->c_to_s_link->picosec_per_byte = 8000000ull; /* Simulate 1 Mbps */
        test_ctx->s_to_c_link->picosec_per_byte = 8000000ull; /* Simulate 1 Mbps */
    }
    else {
        /* Use higher latency for satellite link */
        const uint64_t sat_latency = 300000;

        test_ctx->c_to_s_link_2->microsec_latency = sat_latency;
        test_ctx->s_to_c_link_2->microsec_latency = sat_latency;
        test_ctx->c_to_s_link_2->queue_delay_max = 2*sat_latency;
        test_ctx->s_to_c_link_2->queue_delay_max = 2*sat_latency;
    }
}

/* Use higher data rate for multipath perf scenario */
static void multipath_test_perf_links(picoquic_test_tls_api_ctx_t* test_ctx, int link_id)
{
    const uint64_t wifi_latency = 15000;
    const uint64_t lte_latency = 30000;
    const uint64_t wifi_picosec = 8000000ull / 50;
    const uint64_t lte_picosec = 8000000ull / 40;

    if (link_id == 0) {
        test_ctx->c_to_s_link->microsec_latency = wifi_latency;
        test_ctx->s_to_c_link->microsec_latency = wifi_latency;
        test_ctx->c_to_s_link->queue_delay_max = 2 * wifi_latency;
        test_ctx->s_to_c_link->queue_delay_max = 2 * wifi_latency;
        test_ctx->c_to_s_link->picosec_per_byte = wifi_picosec;
        test_ctx->s_to_c_link->picosec_per_byte = wifi_picosec;
    }
    else {
        test_ctx->c_to_s_link_2->microsec_latency = lte_latency;
        test_ctx->s_to_c_link_2->microsec_latency = lte_latency;
        test_ctx->c_to_s_link_2->queue_delay_max = 2 * lte_latency;
        test_ctx->s_to_c_link_2->queue_delay_max = 2 * lte_latency;
        test_ctx->c_to_s_link_2->picosec_per_byte = lte_picosec;
        test_ctx->s_to_c_link_2->picosec_per_byte = lte_picosec;
    }
}

/* wait until the migration completes */
int wait_client_migration_done(picoquic_test_tls_api_ctx_t* test_ctx,
    uint64_t* simulated_time)
{
    int ret = 0;
    uint64_t time_out = *simulated_time + 4000000;
    int nb_trials = 0;
    int nb_inactive = 0;
    int was_active = 0;
    struct sockaddr_storage old_srce;
    struct sockaddr_storage old_dest;

    /* Check the selected path */
    picoquic_store_addr(&old_srce, (struct sockaddr*)&test_ctx->cnx_client->path[0]->first_tuple->local_addr);
    picoquic_store_addr(&old_dest, (struct sockaddr*) & test_ctx->cnx_client->path[0]->first_tuple->peer_addr);


    while (*simulated_time < time_out &&
        test_ctx->cnx_client->cnx_state == picoquic_state_ready &&
        nb_trials < 1024 &&
        nb_inactive < 64 &&
        ret == 0 && (
            (picoquic_compare_addr((struct sockaddr *) & old_srce, (struct sockaddr*) & test_ctx->cnx_client->path[0]->first_tuple->local_addr) == 0 &&
                picoquic_compare_addr((struct sockaddr*) & old_dest, (struct sockaddr*) & test_ctx->cnx_client->path[0]->first_tuple->peer_addr) == 0)
            ||
            (picoquic_compare_addr((struct sockaddr *) & old_srce, (struct sockaddr*) & test_ctx->cnx_server->path[0]->first_tuple->peer_addr) == 0 &&
                picoquic_compare_addr((struct sockaddr*) & old_dest, (struct sockaddr*) & test_ctx->cnx_server->path[0]->first_tuple->local_addr) == 0))){
        was_active = 0;
        nb_trials++;

        ret = tls_api_one_sim_round(test_ctx, simulated_time, time_out, &was_active);

        if (was_active) {
            nb_inactive = 0;
        }
        else {
            nb_inactive++;
        }
    }

    if (ret != 0 || (test_ctx->cnx_client->cnx_state != picoquic_state_ready ||
        (picoquic_compare_addr((struct sockaddr*) & old_srce, (struct sockaddr*) & test_ctx->cnx_client->path[0]->first_tuple->local_addr) == 0 &&
            picoquic_compare_addr((struct sockaddr*) & old_dest, (struct sockaddr*) & test_ctx->cnx_client->path[0]->first_tuple->peer_addr) == 0))
        ||
        (picoquic_compare_addr((struct sockaddr *) & old_srce, (struct sockaddr*) & test_ctx->cnx_server->path[0]->first_tuple->peer_addr) == 0 &&
            picoquic_compare_addr((struct sockaddr*) & old_dest, (struct sockaddr*) & test_ctx->cnx_server->path[0]->first_tuple->local_addr) == 0)){
        DBG_PRINTF("Could not complete migration, client state = %d\n",
            test_ctx->cnx_client->cnx_state);
        ret = -1;
    }

    return ret;
}


/* Controlled migration test.
 * Create a basic connection.
 * Run until the handshake is done.
 * Start a migration.
 * Verify that the transfer completes */

#define MIGRATION_TRACE_BIN "migration_trace.bin"


static test_api_stream_desc_t test_scenario_multipath[] = {
    { 4, 0, 257, 1000000 },
    { 8, 4, 257, 1000000 }
};

/* Same total data as test_scenario_multipath, but stream 8 does not depend on
 * stream 4 completing first: both are ready in parallel from the start. Used
 * to verify that pinning stream 4's affinity to a backup path does not let
 * stream 8 (unpinned) piggyback onto that path too.
 */
static test_api_stream_desc_t test_scenario_multipath_af_backup[] = {
    { 4, 0, 257, 1000000 },
    { 8, 0, 257, 1000000 }
};

static test_api_stream_desc_t test_scenario_multipath_long[] = {
    { 4, 0, 257, 1000000 },
    { 8, 0, 257, 1000000 },
    { 12, 0, 257, 1000000 },
    { 16, 0, 257, 1000000 },
    { 20, 0, 257, 1000000 },
    { 24, 0, 257, 1000000 },
    { 28, 0, 257, 1000000 },
    { 32, 0, 257, 1000000 },
    { 36, 0, 257, 1000000 },
    { 40, 0, 257, 1000000 }
};

int migration_test_one(int mtu_drop, int is_new_ip)
{
    uint64_t simulated_time = 0;
    uint64_t loss_mask = 0;
    uint64_t max_completion_microsec = 2100000;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    picoquic_connection_id_t initial_cid = { {0x1a, 0x10, 0xc0, 4, 5, 6, 7, 8}, 8 };
    int ret;

    if (mtu_drop) {
        initial_cid.id[2] = 0xcd;
    }
    if (is_new_ip) {
        initial_cid.id[2] = 0xe1;
    }
    
    ret = tls_api_init_ctx_ex(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1,
        PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, NULL, NULL, 0, 0, 0, &initial_cid);

    if (mtu_drop) {
        /* The MTU drop test is specifically orientated towards verifying retransmissions,
         * which requires simulating losses */
        loss_mask |= (((uint64_t)1) << 31);
    }

    if (ret == 0 && test_ctx == NULL) {
        ret = -1;
    }
    else {
        picoquic_set_qlog(test_ctx->qserver, ".");
        test_ctx->qserver->use_long_log = 1;
    }

    /* establish the connection*/
    if (ret == 0) {
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 0, &simulated_time);
    }

    /* Prepare to send data */
    if (ret == 0) {
        ret = test_api_init_send_recv_scenario(test_ctx, test_scenario_multipath, sizeof(test_scenario_multipath));

        if (ret != 0)
        {
            DBG_PRINTF("Init send receive scenario returns %d\n", ret);
        }
    }

    /* wait until the client (and thus the server) is ready */
    if (ret == 0) {
        ret = wait_client_connection_ready(test_ctx, &simulated_time);
    }

    /* Add the second links and initiate the migration */
    if (ret == 0) {
        ret = multipath_test_add_links(test_ctx, mtu_drop);
    }

    if (ret == 0 && is_new_ip) {
        /* Change the IP address, not just the port, so that CC and RTT are reset */
        ((uint8_t*)&test_ctx->client_addr_2.sin_addr)[3] ^= 0x10;
    }

    if (ret == 0) {
        ret = picoquic_probe_new_path(test_ctx->cnx_client, (struct sockaddr*) & test_ctx->server_addr,
            (struct sockaddr*) & test_ctx->client_addr_2, simulated_time);
    }

    /* Check that the migration succeeds */
    if (ret == 0) {
        ret = wait_client_migration_done(test_ctx, &simulated_time);
    }

    /* A new IP address resets CC on both sides, a port change does not */
    if (ret == 0) {
        int client_reset = test_ctx->cnx_client->path[0]->cc_reset_pn != 0;
        int server_reset = test_ctx->cnx_server != NULL && test_ctx->cnx_server->path[0]->cc_reset_pn != 0;
        if (client_reset != is_new_ip || server_reset != is_new_ip) {
            DBG_PRINTF("Expected CC reset %d, client %d, server %d", is_new_ip, client_reset, server_reset);
            ret = -1;
        }
    }

    /* Kill the old links, so nothing more can be sent there */
    if (ret == 0) {
        multipath_test_kill_links(test_ctx, 0);
    }

    /* Perform a data sending loop */
    if (ret == 0) {
        ret = tls_api_data_sending_loop(test_ctx, &loss_mask, &simulated_time, 0);

        if (ret != 0)
        {
            DBG_PRINTF("Data sending loop returns %d\n", ret);
        }
    }

    /* Check that the transmission succeeded */
    if (ret == 0) {
        ret = tls_api_one_scenario_body_verify(test_ctx, &simulated_time, max_completion_microsec);
    }

    /* Check that the default client address on the server was migrated,
     * as well as the default source address on the client */
    if (ret == 0 && test_ctx->cnx_server == NULL) {
        /* No server connection! */
        ret = -1;
    }

    if (ret == 0) {
        struct sockaddr* c_addr_at_server = NULL;
        struct sockaddr* c_addr_at_client = NULL;
        picoquic_get_peer_addr(test_ctx->cnx_server, &c_addr_at_server);
        picoquic_get_local_addr(test_ctx->cnx_client, &c_addr_at_client);

        if (picoquic_compare_addr((struct sockaddr*) & test_ctx->client_addr_2, c_addr_at_server) != 0 ||
            picoquic_compare_addr((struct sockaddr*) & test_ctx->client_addr_2, c_addr_at_client) != 0) {
            /* Migration was not completed */
            ret = -1;
        }
    }

    /* Delete the context */
    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
    }

    return ret;
}

int migration_controlled_test(void)
{
    return migration_test_one(0, 0);
}

int migration_mtu_drop_test(void)
{
    return migration_test_one(1, 0);
}

int migration_new_ip_test(void)
{
    return migration_test_one(0, 1);
}

/* Non-multipath migration: the client's PATH_RESPONSE is lost, then the client
 * retires the CID of the old tuple in a packet sent on the new tuple, before
 * the server has promoted that tuple. The server must accept the retirement. */
int migration_retire_old_cid_test(void)
{
    uint64_t simulated_time = 0;
    uint64_t loss_mask = 0;
    uint64_t drop_mask = 1;
    uint64_t time_out = 0;
    uint64_t nb_dropped = 0;
    int was_active = 0;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    picoquic_connection_id_t initial_cid = { {0x1a, 0x10, 0xce, 4, 5, 6, 7, 8}, 8 };
    int ret = tls_api_init_ctx_ex(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1,
        PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, NULL, NULL, 0, 0, 0, &initial_cid);

    if (ret == 0 && test_ctx == NULL) {
        ret = -1;
    }
    else if (ret == 0) {
        picoquic_set_qlog(test_ctx->qserver, ".");
        test_ctx->qserver->use_long_log = 1;
    }

    if (ret == 0) {
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 0, &simulated_time);
    }

    if (ret == 0) {
        ret = wait_client_connection_ready(test_ctx, &simulated_time);
    }

    if (ret == 0) {
        ret = multipath_test_add_links(test_ctx, 0);
    }

    if (ret == 0) {
        ret = picoquic_probe_new_path(test_ctx->cnx_client, (struct sockaddr*)&test_ctx->server_addr,
            (struct sockaddr*)&test_ctx->client_addr_2, simulated_time);
    }

    /* Run until the client promotes the new tuple */
    time_out = simulated_time + 1000000;
    while (ret == 0 && simulated_time < time_out &&
        picoquic_compare_addr((struct sockaddr*)&test_ctx->client_addr_2,
            (struct sockaddr*)&test_ctx->cnx_client->path[0]->first_tuple->local_addr) != 0) {
        ret = tls_api_one_sim_round(test_ctx, &simulated_time, time_out, &was_active);
    }
    if (ret == 0 && picoquic_compare_addr((struct sockaddr*)&test_ctx->client_addr_2,
        (struct sockaddr*)&test_ctx->cnx_client->path[0]->first_tuple->local_addr) != 0) {
        DBG_PRINTF("%s", "Client did not promote the new tuple");
        ret = -1;
    }

    /* Drop the next client packet on the new tuple, which carries the PATH_RESPONSE */
    if (ret == 0) {
        nb_dropped = test_ctx->c_to_s_link_2->packets_dropped;
        test_ctx->c_to_s_link_2->loss_mask = &drop_mask;
        time_out = simulated_time + 1000000;
        while (ret == 0 && simulated_time < time_out &&
            test_ctx->c_to_s_link_2->packets_dropped == nb_dropped) {
            ret = tls_api_one_sim_round(test_ctx, &simulated_time, time_out, &was_active);
        }
        test_ctx->c_to_s_link_2->loss_mask = NULL;
        if (ret == 0 && test_ctx->c_to_s_link_2->packets_dropped == nb_dropped) {
            DBG_PRINTF("%s", "No client packet dropped on the new tuple");
            ret = -1;
        }
        else if (ret == 0 && picoquic_compare_addr((struct sockaddr*)&test_ctx->client_addr,
            (struct sockaddr*)&test_ctx->cnx_server->path[0]->first_tuple->peer_addr) != 0) {
            DBG_PRINTF("%s", "Server promoted the new tuple too early for the test");
            ret = -1;
        }
    }

    /* Client deletes the old tuple, which queues a RETIRE_CONNECTION_ID for its CID */
    if (ret == 0) {
        picoquic_tuple_t* old_tuple = test_ctx->cnx_client->path[0]->first_tuple->next_tuple;

        if (old_tuple == NULL || picoquic_compare_addr((struct sockaddr*)&test_ctx->client_addr,
            (struct sockaddr*)&old_tuple->local_addr) != 0) {
            DBG_PRINTF("%s", "Old tuple not found on the client");
            ret = -1;
        }
        else {
            picoquic_delete_tuple(test_ctx->cnx_client->path[0], old_tuple, 0);
        }
    }

    /* The server must accept the retirement and complete the migration */
    time_out = simulated_time + 2000000;
    while (ret == 0 && simulated_time < time_out &&
        test_ctx->cnx_server != NULL && test_ctx->cnx_server->cnx_state == picoquic_state_ready &&
        picoquic_compare_addr((struct sockaddr*)&test_ctx->client_addr_2,
            (struct sockaddr*)&test_ctx->cnx_server->path[0]->first_tuple->peer_addr) != 0) {
        ret = tls_api_one_sim_round(test_ctx, &simulated_time, time_out, &was_active);
    }

    if (ret == 0 && (test_ctx->cnx_server == NULL || test_ctx->cnx_server->cnx_state != picoquic_state_ready)) {
        DBG_PRINTF("Server connection failed, error 0x%" PRIx64 ", reason: %s",
            (test_ctx->cnx_server == NULL) ? 0 : test_ctx->cnx_server->local_error,
            (test_ctx->cnx_server == NULL || test_ctx->cnx_server->local_error_reason == NULL) ? "none" :
            test_ctx->cnx_server->local_error_reason);
        ret = -1;
    }
    else if (ret == 0 && picoquic_compare_addr((struct sockaddr*)&test_ctx->client_addr_2,
        (struct sockaddr*)&test_ctx->cnx_server->path[0]->first_tuple->peer_addr) != 0) {
        DBG_PRINTF("%s", "Server did not migrate to the new tuple");
        ret = -1;
    }

    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
    }

    return ret;
}

/*
 * Test of actual multipath, by opposition to only migration.
 */

void multipath_init_params(picoquic_tp_t *test_parameters, int enable_time_stamp)
{
    memset(test_parameters, 0, sizeof(picoquic_tp_t));

    picoquic_init_transport_parameters(test_parameters);
    test_parameters->initial_max_path_id = 2;
    test_parameters->enable_time_stamp = 3* enable_time_stamp;
}

/* wait until the migration completes */
int wait_multipath_ready(picoquic_test_tls_api_ctx_t* test_ctx,
    uint64_t* simulated_time)
{
    int ret = 0;
    uint64_t time_out = *simulated_time + 4000000;
    int nb_trials = 0;
    int nb_inactive = 0;
    int was_active = 0;
    struct sockaddr_storage old_srce;
    struct sockaddr_storage old_dest;

    /* Check the selected path */
    picoquic_store_addr(&old_srce, (struct sockaddr*) & test_ctx->cnx_client->path[0]->first_tuple->local_addr);
    picoquic_store_addr(&old_dest, (struct sockaddr*) & test_ctx->cnx_client->path[0]->first_tuple->peer_addr);

    while (*simulated_time < time_out &&
        ret == 0 &&
        test_ctx->cnx_client->cnx_state == picoquic_state_ready &&
        nb_trials < 5000 &&
        nb_inactive < 64 &&
        (test_ctx->cnx_client->nb_paths != 2 ||
        !test_ctx->cnx_client->path[1]->first_tuple->challenge_verified ||
        (test_ctx->cnx_server == NULL || (test_ctx->cnx_server->nb_paths != 2 ||
        !test_ctx->cnx_server->path[1]->first_tuple->challenge_verified)))){
        nb_trials++;

        ret = tls_api_one_sim_round(test_ctx, simulated_time, time_out, &was_active);

        if (was_active) {
            nb_inactive = 0;
        }
        else {
            nb_inactive++;
        }
    }

    if (ret == 0 && (test_ctx->cnx_client->cnx_state != picoquic_state_ready ||
        (test_ctx->cnx_client->nb_paths != 2 ||
            !test_ctx->cnx_client->path[1]->first_tuple->challenge_verified) ||
            (test_ctx->cnx_server == NULL || (test_ctx->cnx_server->nb_paths != 2 ||
                !test_ctx->cnx_server->path[1]->first_tuple->challenge_verified)))) {
        DBG_PRINTF("Could not establish multipath, client state = %d\n",
            test_ctx->cnx_client->cnx_state);
        ret = -1;
    }

    return ret;
}

typedef enum {
    multipath_test_basic = 0,
    multipath_test_drop_first,
    multipath_test_drop_second,
    multipath_test_sat_plus,
    multipath_test_renew,
    multipath_test_rotation,
    multipath_test_nat,
    multipath_test_nat_challenge,
    multipath_test_break1,
    multipath_test_break2,
    multipath_test_break3,
    multipath_test_back0,
    multipath_test_back1,
    multipath_test_perf,
    multipath_test_callback,
    multipath_test_quality,
    multipath_test_quality_server,
    multipath_test_stream_af,
    multipath_test_abandon,
    multipath_test_datagram,
    multipath_test_dg_af,
    multipath_test_backup,
    multipath_test_stream_af_backup,
    multipath_test_standup,
    multipath_test_tunnel,
    multipath_test_fail,
    multipath_test_ab1,
    multipath_test_discovery,
    multipath_test_keep_alive,
    multipath_test_just_one,
    multipath_test_break_both,
    multipath_test_drop_first_c2s,
    multipath_test_drop_first_s2c,
} multipath_test_enum_t;

#ifdef _WINDOWS
#define PATH_CALLBACK_TEST_REF "picoquictest\\path_callback_ref.txt"
#define PATH_QUALITY_TEST_REF "picoquictest\\path_quality_ref.txt"
#define PATH_QUALITY_SERVER_REF "picoquictest\\path_quality_server_ref.txt"
#else
#define PATH_CALLBACK_TEST_REF "picoquictest/path_callback_ref.txt"
#define PATH_QUALITY_TEST_REF "picoquictest/path_quality_ref.txt"
#define PATH_QUALITY_SERVER_REF "picoquictest/path_quality_server_ref.txt"
#endif
#define PATH_CALLBACK_CSV "path_callback.csv"
#define PATH_QUALITY_CSV "path_quality.csv"
#define PATH_QUALITY_SERVER "path_quality_server.csv"

int multipath_init_callbacks(picoquic_test_tls_api_ctx_t* test_ctx, multipath_test_enum_t test_id)
{
    int ret = 0;
    char const* filename = (test_id == multipath_test_callback) ? PATH_CALLBACK_CSV :
        ((test_id == multipath_test_quality) ? PATH_QUALITY_CSV : PATH_QUALITY_SERVER);
    /* Open a file to log bandwidth updates and document it in context */
    test_ctx->path_events = picoquic_file_open(filename, "w");
    if (test_ctx->path_events == NULL) {
        DBG_PRINTF("Could not write file <%s>", filename);
        ret = -1;
    }
    else {
        if (test_id == multipath_test_quality_server) {
            picoquic_enable_path_callbacks_default(test_ctx->qserver, 1);
            picoquic_default_quality_update(test_ctx->qserver, 50000, 5000);
        }
        else {
            picoquic_enable_path_callbacks(test_ctx->cnx_client, 1);
            if (test_id == multipath_test_quality) {
                picoquic_subscribe_to_quality_update(test_ctx->cnx_client, 50000, 5000);
                ret = picoquic_subscribe_to_quality_update_per_path(test_ctx->cnx_client, 0, 50000, 5000);
            }
            if (test_id == multipath_test_callback) {
                int is_already_allowed = 0;
                ret = picoquic_subscribe_new_path_allowed(test_ctx->cnx_client, &is_already_allowed);
            }
        }
        if (test_id == multipath_test_callback) {
            fprintf(test_ctx->path_events, "Time, Path-ID, Event,\n");
        }
        else {
            fprintf(test_ctx->path_events, "Time, Path-ID, Event, Pacing_rate, Receive Rate, CWIN, RTT\n");
        }
    }
    return ret;
}

int multipath_verify_callbacks(multipath_test_enum_t test_id)
{
    int ret = 0;
    char file_ref[512];
    char const* filename = (test_id == multipath_test_callback) ? PATH_CALLBACK_CSV : 
        ((test_id == multipath_test_quality)?PATH_QUALITY_CSV:PATH_QUALITY_SERVER);
    char const* ref_name = (test_id == multipath_test_callback) ? PATH_CALLBACK_TEST_REF : 
        ((test_id == multipath_test_quality)?PATH_QUALITY_TEST_REF:PATH_QUALITY_SERVER_REF);

    ret = picoquic_get_input_path(file_ref, sizeof(file_ref), picoquic_solution_dir, ref_name);

    if (ret != 0) {
        DBG_PRINTF("Cannot set the reference file name for test id: %s.\n", (int)test_id);
    }
    else {
        ret = picoquic_test_compare_text_files(filename, file_ref);
    }
    return ret;
}

static int multipath_test_abandon_cycle(picoquic_test_tls_api_ctx_t* test_ctx, uint64_t* simulated_time)
{
    int ret = 0;
    uint64_t deleted_id = UINT64_MAX;
    picoquic_local_cnxid_list_t* local_cnxid_list = test_ctx->cnx_client->first_local_cnxid_list;

    while (local_cnxid_list != NULL) {
        if (!local_cnxid_list->is_demoted &&
            local_cnxid_list->unique_path_id != 0 &&
            local_cnxid_list->unique_path_id < deleted_id) {
            deleted_id = local_cnxid_list->unique_path_id;
        }
        local_cnxid_list = local_cnxid_list->next_list;
    }
    if (deleted_id == UINT64_MAX) {
        ret = -1;
    }
    else {
        ret = picoquic_abandon_path(test_ctx->cnx_client, deleted_id, 0, *simulated_time);
        if (ret != 0) {
            DBG_PRINTF("Could not abandon path %" PRIu64 ", ret=%d", deleted_id, ret);
        }
        else {
            /* wait about 250ms for the abandon to be noticed at both ends. */
            ret = tls_api_wait_for_timeout(test_ctx, simulated_time, 250000);
            if (ret != 0) {
                DBG_PRINTF("Issue after abandon path %" PRIu64 ", ret = %d", deleted_id, ret);
            }
        }
    }
    /* Verify that the deleted ID is gone. */
    if (ret == 0) {
        picoquic_local_cnxid_list_t* local_cnxid_list = test_ctx->cnx_client->first_local_cnxid_list;

        while (local_cnxid_list != NULL) {
            if (local_cnxid_list->unique_path_id == deleted_id) {
                DBG_PRINTF("Deleted ID %" PRIu64 " is still present", deleted_id);
                ret = -1;
                break;
            }
            local_cnxid_list = local_cnxid_list->next_list;
        }
    }
    if (ret == 0) {
        int stash_count = 0;
        /* Verify that we have enough remote path ID to continue. */
        for (int i = 0; i <= 10 && ret == 0; i++) {
            picoquic_remote_cnxid_stash_t* remote_cnxid_stash = test_ctx->cnx_client->first_remote_cnxid_stash;

            stash_count = 0;
            while (remote_cnxid_stash != NULL) {
                stash_count++;
                remote_cnxid_stash = remote_cnxid_stash->next_stash;
            }

            if (stash_count >= 2) {
                break;
            }
            else if (i < 10 && stash_count < 2) {
                ret = tls_api_wait_for_timeout(test_ctx, simulated_time, 100000);
            }
        }
        if (stash_count < 2) {
            DBG_PRINTF("Only %d stashes of CID available", stash_count);
            ret = -1;
        }
    }

    return ret;
}

void multipath_init_datagram_ctx(picoquic_test_tls_api_ctx_t* test_ctx, test_datagram_send_recv_ctx_t * dg_ctx)
{
    /* Initialize the datagram targets as a function of the test id */
    memset(dg_ctx, 0, sizeof(test_datagram_send_recv_ctx_t));
    dg_ctx->dg_max_size = PICOQUIC_MAX_PACKET_SIZE;
    dg_ctx->dg_target[0] = 100;
    dg_ctx->dg_target[1] = 100;
    dg_ctx->send_delay = 3000;
    /* Set the test contexts for sending and receiving datagrams */
    test_ctx->datagram_ctx = dg_ctx;
    test_ctx->datagram_recv_fn = test_datagram_recv;
    test_ctx->datagram_send_fn = test_datagram_send;
    test_ctx->datagram_ack_fn = test_datagram_ack;
    /* Enable multipath callbacks */
    picoquic_enable_path_callbacks_default(test_ctx->qserver, 1);
    picoquic_enable_path_callbacks(test_ctx->cnx_client, 1);
    /* Use the extended datagram API */
    dg_ctx->use_extended_provider_api = 1;
}

int multipath_set_datagram_ready(picoquic_test_tls_api_ctx_t* test_ctx, test_datagram_send_recv_ctx_t* dg_ctx, multipath_test_enum_t test_id)
{
    int ret = 0;
    /* Mark datagram ready, start to send. */
    if (test_id == multipath_test_datagram) {
        /* sending on any path */
        ret = picoquic_mark_datagram_ready(test_ctx->cnx_client, 1);
        if (ret == 0) {
            ret = picoquic_mark_datagram_ready(test_ctx->cnx_server, 1);
        }
    }
    else {
        /* Only wake up path 0 */
        dg_ctx->test_affinity = 1;
        ret = picoquic_mark_datagram_ready_path(test_ctx->cnx_client, 0, 1);
        if (ret == 0) {
            ret = picoquic_mark_datagram_ready_path(test_ctx->cnx_server, 0, 1);
        }
    }
    return ret;
}

int multipath_verify_datagram_sent(test_datagram_send_recv_ctx_t* dg_ctx, multipath_test_enum_t test_id)
{
    int ret = 0;

    /* Verify datagrams have been received -- 3/4 will be enough */
    if (4*dg_ctx->dg_recv[0] < 3*dg_ctx->dg_target[1] ||
        4*dg_ctx->dg_recv[1] < 3*dg_ctx->dg_target[0]) {
        DBG_PRINTF("%s", "Did not receive expected datagrams: ");
        for (int i = 0; i < 2; i++) {
            DBG_PRINTF("dg_target[%d]=%d, dg_sent[%d]=%d, dg_recv[%d]=%d",
                i, dg_ctx->dg_target[i], i, dg_ctx->dg_sent[i], 1 - i, dg_ctx->dg_recv[1 - i]);
            ret = -1;
        }
    }
    if (ret == 0) {
        if (test_id == multipath_test_datagram) {
            for (int i = 0; ret == 0 && i < 2; i++) {
                int min_expected = dg_ctx->dg_recv[i] / 8;

                if (dg_ctx->nb_recv_path_0[i] < min_expected ||
                    dg_ctx->nb_recv_path_other[i] < min_expected) {
                    DBG_PRINTF("Datagram not balanced, %s received %d on path 0, %d on others",
                        (i) ? "client" : "server", dg_ctx->nb_recv_path_0[i], dg_ctx->nb_recv_path_other[i]);
                    ret = -1;
                }
            }
        }
        else if (test_id == multipath_test_dg_af) {
            for (int i = 0; ret == 0 && i < 2; i++) {
                if (dg_ctx->nb_recv_path_other[i] > 0) {
                    DBG_PRINTF("Datagram affinity fails, %s received %d on path 0, %d on others",
                        (i) ? "client" : "server", dg_ctx->nb_recv_path_0[i], dg_ctx->nb_recv_path_other[i]);
                    ret = -1;
                }
            }
        }
    }
    return ret;
}

static int multipath_verify_all_cid_available(picoquic_cnx_t* cnx)
{
    int ret = 0;
    uint64_t unique_id_max = 0;
    picoquic_remote_cnxid_stash_t* stash = cnx->first_remote_cnxid_stash;

    while (stash != NULL) {
        if (stash->unique_path_id > unique_id_max) {
            unique_id_max = stash->unique_path_id;
        }
        stash = stash->next_stash;
    }
    if (unique_id_max < cnx->max_path_id_local && unique_id_max < cnx->max_path_id_remote) {
        ret = -1;
    }
    return ret;
}

int multipath_datagram_send_loop(picoquic_test_tls_api_ctx_t* test_ctx,
    test_datagram_send_recv_ctx_t* dg_ctx, uint64_t* loss_mask, uint64_t* simulated_time)
{
    int ret = 0;
    int nb_trials = 0;
    int nb_inactive = 0;

    test_ctx->c_to_s_link->loss_mask = loss_mask;
    test_ctx->s_to_c_link->loss_mask = loss_mask;

    while (ret == 0 && nb_trials < 16000 && nb_inactive < 512 && TEST_CLIENT_READY && TEST_SERVER_READY) {
        int was_active = 0;
        uint64_t time_out = test_datagram_next_time_ready(dg_ctx);
        nb_trials++;

        ret = tls_api_one_sim_round(test_ctx, simulated_time, time_out, &was_active);

        if (ret < 0) {
            break;
        }

        if (was_active) {
            nb_inactive = 0;
        } else {
            nb_inactive++;
        }

        /* Simulate wake up when data is ready for real time operation */
        for (int i = 0; i < 2; i++) {
            picoquic_cnx_t* cnx = (i == 0) ? test_ctx->cnx_server : test_ctx->cnx_client;
            if (!dg_ctx->is_ready[i] && test_datagram_check_ready(dg_ctx, i, *simulated_time)) {
                if (dg_ctx->test_affinity) {
                    picoquic_mark_datagram_ready_path(cnx, 0, 1);
                }
                else {
                    picoquic_mark_datagram_ready(cnx, 1);
                }
            }
        }

        if (test_ctx->test_finished) {
            if (test_ctx->immediate_exit ||
                (picoquic_is_cnx_backlog_empty(test_ctx->cnx_client) && picoquic_is_cnx_backlog_empty(test_ctx->cnx_server))) {
                break;
            }
        }
    }

    return ret;
}

int multipath_test_do_keep_alive(picoquic_test_tls_api_ctx_t* test_ctx, uint64_t * simulated_time)
{
    int ret = 0;
    uint8_t ping_frame[1] = { (uint8_t)picoquic_frame_type_ping };
    int nat_test_needed = 1;
    int rounds_without_nat = 0;

    while (ret == 0 && *simulated_time < 200000000) {
        uint64_t previous_time = *simulated_time;

        if (nat_test_needed) {
            if (rounds_without_nat > 3) {
                /* do a nat rebinding */
                test_ctx->client_addr_natted = test_ctx->client_addr;
                test_ctx->client_addr_natted.sin_port += 7;
                test_ctx->client_use_nat = 1;
                nat_test_needed = 0;
            }
            else {
                rounds_without_nat++;
            }
        }

        if (ret == 0) {
            ret = picoquic_queue_misc_frame(test_ctx->cnx_client, ping_frame, sizeof(ping_frame), 0, picoquic_packet_context_application);
            if (ret != 0) {
                DBG_PRINTF("Cannot queue ping frame, ret = 0x%x", ret);
                break;
            }
        }

        ret = tls_api_wait_for_timeout(test_ctx, simulated_time, 10000000);
        if (ret != 0) {
            DBG_PRINTF("Cannot wait 10 seconds, ret = 0x%x", ret);
            break;
        }

        if (!(TEST_CLIENT_READY && TEST_SERVER_READY) || *simulated_time < previous_time + 1000000) {
            DBG_PRINTF("Connection stalled at t=%" PRIu64, *simulated_time);
            ret = -1;
            break;
        }
    }
    if (ret != 0) {
        DBG_PRINTF("Keep alive test fails at t=%" PRIu64 ", ret = 0x%x", *simulated_time, ret);
    }
    return ret;
}

int multipath_test_one(uint64_t max_completion_microsec, multipath_test_enum_t test_id)
{
    uint64_t simulated_time = 0;
    uint64_t loss_mask = 0;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    test_datagram_send_recv_ctx_t dg_ctx = { 0 };
    picoquic_connection_id_t initial_cid = { {0x1b, 0x11, 0xc0, 4, 5, 6, 7, 8}, 8 };
    picoquic_tp_t server_parameters;
    uint64_t original_r_cid_sequence = 0;
    size_t send_buffer_size = 0;
    int ret;

    initial_cid.id[2] = (int)test_id;

    if (test_id == multipath_test_perf) {
        send_buffer_size = 65536;
    }

    /* Create the context but delay initialization, so the multipath option can be set */
    ret = tls_api_init_ctx_ex2(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1,
        PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, NULL, NULL, 0, 1, 0, &initial_cid,
        8, 0, send_buffer_size, 0);

    if (ret == 0 && test_ctx == NULL) {
        ret = -1;
    }

    if (ret == 0) {
        int is_sat_test = (test_id == multipath_test_sat_plus);
        if (is_sat_test || test_id == multipath_test_break1 || test_id == multipath_test_break2 || test_id == multipath_test_back1) {
            /* Reduce the throughput of path #0 to 1 mbps.
             * This is used to simulate an asymmetric "satellite and landline" scenario,
             * or to simulate a long transfer and test broken path detection or repair */
            multipath_test_sat_links(test_ctx, 0);
        }
        else if (test_id == multipath_test_perf) {
            multipath_test_perf_links(test_ctx, 0);
            picoquic_set_default_congestion_algorithm(test_ctx->qserver, picoquic_bbr_algorithm);
        }
        test_ctx->c_to_s_link->queue_delay_max = 2 * test_ctx->c_to_s_link->microsec_latency;
        test_ctx->s_to_c_link->queue_delay_max = 2 * test_ctx->s_to_c_link->microsec_latency;

        if (test_id == multipath_test_rotation) {
            picoquic_set_default_crypto_epoch_length(test_ctx->qserver, 200);
        }

        if (test_id == multipath_test_callback || test_id == multipath_test_quality || test_id == multipath_test_quality_server || test_id == multipath_test_stream_af) {
            multipath_init_callbacks(test_ctx, test_id);
        }

        if (test_id == multipath_test_datagram || test_id == multipath_test_dg_af) {
            multipath_init_datagram_ctx(test_ctx, &dg_ctx);
        }

        picoquic_set_qlog(test_ctx->qserver, ".");
        test_ctx->qserver->use_long_log = 1;
        /* set the binary log on the client side */
        picoquic_set_qlog(test_ctx->qclient, ".");
        test_ctx->qclient->use_long_log = 1;
        /* Set the multipath option at both client and server */
        multipath_init_params(&server_parameters, is_sat_test);
        if (test_id == multipath_test_datagram || test_id == multipath_test_dg_af) {
            server_parameters.max_datagram_frame_size = 1536;
            test_ctx->cnx_client->local_parameters.max_datagram_frame_size = 1536;
        }
        if (test_id == multipath_test_discovery) {
            server_parameters.address_discovery_mode = 1;
            test_ctx->cnx_client->local_parameters.address_discovery_mode = 3;
        }
        if (test_id == multipath_test_just_one) {
            server_parameters.initial_max_path_id = 1;
        }

        picoquic_set_default_tp(test_ctx->qserver, &server_parameters);
        test_ctx->cnx_client->local_parameters.enable_time_stamp = 3;

        test_ctx->cnx_client->local_parameters.initial_max_path_id = 3;
    }

    /* establish the connection */
    if (ret == 0) {
        /* Initialize the client connection */
        picoquic_start_client_cnx(test_ctx->cnx_client);
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 2 * test_ctx->s_to_c_link->microsec_latency, &simulated_time);
    }
    /* verify that multipath is negotiated on both sides */
    if (ret == 0 && (!test_ctx->cnx_client->is_multipath_enabled || !test_ctx->cnx_server->is_multipath_enabled)) {
        DBG_PRINTF("Multipath not fully negotiated (c=%d, s=%d)",
            test_ctx->cnx_client->is_multipath_enabled, test_ctx->cnx_server->is_multipath_enabled);
        ret = -1;
    }
    /* verify that both sides have the same vision of max path id*/
    if (ret == 0 && (test_ctx->cnx_client->max_path_id_local != test_ctx->cnx_server->max_path_id_remote ||
        test_ctx->cnx_client->max_path_id_remote != test_ctx->cnx_server->max_path_id_local)) {
        DBG_PRINTF("No agreement on max path if (c=%u/%u, s=%u/%u)",
            (uint32_t)test_ctx->cnx_client->max_path_id_local, (uint32_t)test_ctx->cnx_client->max_path_id_remote,
            (uint32_t)test_ctx->cnx_server->max_path_id_local, (uint32_t)test_ctx->cnx_server->max_path_id_remote);
        ret = -1;
    }

    /* wait until the client (and thus the server) is ready */
    if (ret == 0) {
        ret = wait_client_connection_ready(test_ctx, &simulated_time);
    }

    if (ret == 0 && test_id == multipath_test_ab1) {
        for (int i = 0; ret == 0 && i < 7; i++) {
            ret = multipath_test_abandon_cycle(test_ctx, &simulated_time);
        }
    }

    /* Prepare to send data */
    if (ret == 0) {
        if (test_id == multipath_test_sat_plus || test_id == multipath_test_perf) {
            ret = test_api_init_send_recv_scenario(test_ctx, test_scenario_multipath_long, sizeof(test_scenario_multipath_long));
        } else if (test_id == multipath_test_stream_af_backup) {
            ret = test_api_init_send_recv_scenario(test_ctx, test_scenario_multipath_af_backup, sizeof(test_scenario_multipath_af_backup));
        } else {
            ret = test_api_init_send_recv_scenario(test_ctx, test_scenario_multipath, sizeof(test_scenario_multipath));
        }

        if (ret != 0)
        {
            DBG_PRINTF("Init send receive scenario returns %d\n", ret);
        }
    }

    /* Add the multipath links and initiate the path creation */
    if (ret == 0) {
        ret = multipath_test_add_links(test_ctx, 0);
        if (ret == 0) {
            if (test_id == multipath_test_sat_plus) {
                /* Simulate an asymmetric "satellite and landline" scenario */
                multipath_test_sat_links(test_ctx, 1);
            }
            else if (test_id == multipath_test_perf) {
                multipath_test_perf_links(test_ctx, 1);
            }
            else if (test_id == multipath_test_fail) {
                /* Kill link #1 in server to client direction. This will cause path challenges to fail */
                multipath_test_kill_server_links(test_ctx, 1);
            }
        }
    }

    if (ret == 0) {
        ret = picoquic_probe_new_path(test_ctx->cnx_client, (struct sockaddr*) & test_ctx->server_addr,
            (struct sockaddr*) & test_ctx->client_addr_2, simulated_time);
    }

    /* Check that the two paths are established */
    if (ret == 0 && test_id != multipath_test_fail) {
        ret = wait_multipath_ready(test_ctx, &simulated_time);
    }
     if (ret == 0){
        if (test_id == multipath_test_stream_af) {
            ret = picoquic_set_stream_path_affinity(test_ctx->cnx_server, 4, 0);
            if (ret != 0) {
                DBG_PRINTF("Cannot set stream affinity, ret = %d", ret);
            }
        }
        else if (test_id == multipath_test_backup ||
            test_id == multipath_test_standup) {
            ret = picoquic_set_path_status(test_ctx->cnx_client, 1, picoquic_path_status_backup);
        }
        else if (test_id == multipath_test_stream_af_backup) {
            /* Path 1 is marked backup, but stream 4's affinity is pinned to it anyway.
             * Affinity should win: the stream's data must still go out on path 1. */
            ret = picoquic_set_path_status(test_ctx->cnx_client, 1, picoquic_path_status_backup);
            if (ret == 0) {
                ret = picoquic_set_stream_path_affinity(test_ctx->cnx_server, 4, 1);
            }
            if (ret != 0) {
                DBG_PRINTF("Cannot set backup path and stream affinity, ret = %d", ret);
            }
        }
    }

    if (ret == 0 && (test_id == multipath_test_drop_first || test_id == multipath_test_drop_second ||
        test_id == multipath_test_renew || test_id == multipath_test_nat || test_id == multipath_test_nat_challenge ||
        test_id == multipath_test_break1 || test_id == multipath_test_break2 || test_id == multipath_test_break3 ||
        test_id == multipath_test_back0 || test_id == multipath_test_back1 || test_id == multipath_test_standup ||
        test_id == multipath_test_abandon || test_id == multipath_test_tunnel || test_id == multipath_test_break_both ||
        test_id == multipath_test_drop_first_c2s || test_id == multipath_test_drop_first_s2c)) {
        /* If testing a final link drop before completion, perform a 
         * partial sending loop and then kill the initial link.
         * For the tunnel scenario, do the same but kill both links.
         */
        if (ret == 0) {
            uint64_t timeout = 640000;

            ret = tls_api_wait_for_timeout(test_ctx, &simulated_time, timeout);

            if (ret != 0)
            {
                DBG_PRINTF("Wait for %" PRIu64 "us returns %d\n", timeout, ret);
            }
        }
        if (ret == 0) {
            if (test_id == multipath_test_renew) {
                ret = picoquic_renew_connection_id(test_ctx->cnx_client, 1);
            }
            else if (test_id == multipath_test_nat || test_id == multipath_test_nat_challenge) {
                /* Change the client address */
                test_ctx->client_addr_natted = test_ctx->client_addr;
                test_ctx->client_addr_natted.sin_port += 7;
                test_ctx->client_use_nat = 1;
                if (test_id == multipath_test_nat_challenge) {
                    test_ctx->cnx_client->path[0]->first_tuple->challenge_required = 1;
                }
            }
            else if (test_id == multipath_test_abandon) {
                /* Client abandons the path, causes it to be demoted. Server should follow suit. */
                picoquic_abandon_path(test_ctx->cnx_client, 0, 0,
                    simulated_time);
            }
            else if (test_id == multipath_test_break2) {
                /* Trigger "destination unreachable" error on next socket call to link 1 */
                multipath_test_set_unreachable(test_ctx, 1);
            }
            else if (test_id == multipath_test_back0 || test_id == multipath_test_break3) {
                /* Trigger "destination unreachable" error on next socket call to link 0 */
                multipath_test_set_unreachable(test_ctx, 0);
            }
            else if (test_id == multipath_test_tunnel) {
                /* Break both links */
                multipath_test_kill_links(test_ctx, 0);
                multipath_test_kill_links(test_ctx, 1);
            }
            else if (test_id == multipath_test_break_both) {
                /* Break both paths, program them to return socket errors */
                multipath_test_set_unreachable(test_ctx, 0);
                multipath_test_set_unreachable(test_ctx, 1);
            }
            else if (test_id == multipath_test_drop_first_c2s) {
                /* Only the client to server direction of path 0 fails */
                multipath_test_kill_client_links(test_ctx, 0);
            }
            else if (test_id == multipath_test_drop_first_s2c) {
                /* Only the server to client direction of path 0 fails */
                multipath_test_kill_server_links(test_ctx, 0);
            } else {
                multipath_test_kill_links(test_ctx, 
                    (test_id == multipath_test_drop_first ||
                        test_id == multipath_test_standup) ? 0 : 1);
            }
        }
    }
    /* For the "backup scenario", wait a small interval, then bring the path # 1 back up
     * For the "tunnel" scenario, do the same but wait 5 seconds and then restore both links.
     */
    if (ret == 0 && (test_id == multipath_test_back0 || test_id == multipath_test_back1 || test_id == multipath_test_tunnel)) {
        uint64_t timeout = (test_id == multipath_test_tunnel)?5000000:1000000;

        ret = tls_api_wait_for_timeout(test_ctx, &simulated_time, timeout);

        if (ret != 0)
        {
            DBG_PRINTF("Wait for %" PRIu64 "us returns %d\n", timeout, ret);
        }
        else if (test_id == multipath_test_back0) {
            multipath_test_set_reachable(test_ctx, 0);
            
            ret = picoquic_probe_new_path(test_ctx->cnx_client, (struct sockaddr*)&test_ctx->server_addr,
                    (struct sockaddr*)&test_ctx->client_addr, simulated_time);
            if (ret != 0) {
                DBG_PRINTF("Create path on default address returns %d\n", ret);
            }
        }
        else {
            if (test_id == multipath_test_tunnel) {
                multipath_test_unkill_links(test_ctx, 0, simulated_time);
            }
            multipath_test_unkill_links(test_ctx, 1, simulated_time);
        }
    }
    /* In the "abandon" scenario, allow for a bit more than 1 second of delay for clearing of paths */
    if (ret == 0 && test_id == multipath_test_abandon) {
        uint64_t timeout = 1100000;

        ret = tls_api_wait_for_timeout(test_ctx, &simulated_time, timeout);

        if (ret != 0)
        {
            DBG_PRINTF("Wait for %" PRIu64 "us returns %d\n", timeout, ret);
        }
    }

    /* In the datagram scenarios, trigger the datagram transmission */
    if (ret == 0 && (test_id == multipath_test_datagram || test_id == multipath_test_dg_af)) {
        ret = multipath_set_datagram_ready(test_ctx, &dg_ctx, test_id);
    }

    /* Perform a final data sending loop, this time to completion  */
    if (ret == 0) { 
        if (test_id == multipath_test_datagram || test_id == multipath_test_dg_af) {
            ret = multipath_datagram_send_loop(test_ctx, &dg_ctx, &loss_mask, &simulated_time);
        }
        else if (!test_ctx->test_finished ||
            !picoquic_is_cnx_backlog_empty(test_ctx->cnx_client) ||
            !picoquic_is_cnx_backlog_empty(test_ctx->cnx_server)){
            ret = tls_api_data_sending_loop(test_ctx, &loss_mask, &simulated_time, 0);
        }

        if (ret != 0)
        {
            DBG_PRINTF("Data sending loop returns %d\n", ret);
        }
    }

    /* In the "socket error on path 0" scenario, the failing path is only removed after the
     * path challenge fails and the demotion delay expires. The transfer may well complete
     * before that, so allow for some delay for the clearing of paths. */
    if (ret == 0 && test_id == multipath_test_break3) {
        uint64_t timeout = 1100000;

        ret = tls_api_wait_for_timeout(test_ctx, &simulated_time, timeout);

        if (ret != 0)
        {
            DBG_PRINTF("Wait for %" PRIu64 "us returns %d\n", timeout, ret);
        }
    }

    if (ret == 0 && test_id == multipath_test_keep_alive) {
        ret = multipath_test_do_keep_alive(test_ctx, &simulated_time);
    }

    /* Check that the transmission succeeded */
    if (ret == 0) {
        ret = tls_api_one_scenario_body_verify(test_ctx, &simulated_time, max_completion_microsec);
    }

    if (ret == 0 && (test_id == multipath_test_basic || test_id == multipath_test_just_one)) {
        if ((ret = multipath_verify_all_cid_available(test_ctx->cnx_client)) != 0) {
            DBG_PRINTF("%s", "Not received all CID from server");
        }
        else if ((ret = multipath_verify_all_cid_available(test_ctx->cnx_server)) != 0) {
            DBG_PRINTF("%s", "Not received all CID from client");
        }
    }

    if (ret == 0 && test_id == multipath_test_fail) {
        if (test_ctx->cnx_client->nb_paths != 1 ||
            (test_ctx->cnx_server != NULL && test_ctx->cnx_server->nb_paths != 1)) {
            DBG_PRINTF("Delete failing path failed, client = %d paths, server = %d paths\n",
                test_ctx->cnx_client->nb_paths,
                (test_ctx->cnx_server == NULL) ? 0 : test_ctx->cnx_server->nb_paths);
            ret = -1;
        }
    }

    if (ret == 0 && test_id == multipath_test_renew) {
        if (test_ctx->cnx_client->path[1]->first_tuple->p_remote_cnxid->sequence == original_r_cid_sequence) {
            DBG_PRINTF("Remote CID on client path 1 is still %" PRIu64 "\n", original_r_cid_sequence);
            ret = -1;
        } else if (test_ctx->cnx_server->path[1]->first_tuple->p_remote_cnxid->sequence == original_r_cid_sequence) {
            DBG_PRINTF("Remote CID on server path 1 is still %" PRIu64 "\n", original_r_cid_sequence);
            ret = -1;
        }
        else if (test_ctx->cnx_server->path[1]->first_tuple->p_local_cnxid->sequence == original_r_cid_sequence) {
            DBG_PRINTF("Local CID on server path 1 is still %" PRIu64 "\n", original_r_cid_sequence);
            ret = -1;
        }
    }

    if (ret == 0 && test_id == multipath_test_rotation) {
        if (test_ctx->cnx_server->nb_crypto_key_rotations == 0) {
            DBG_PRINTF("%s", "No key rotation observed.\n");
            ret = -1;
        }
    }

    if (ret == 0) {
        uint64_t mask = 0;
        for (int i = 0; ret == 0 && i < test_ctx->cnx_client->nb_paths; i++) {
            if (test_ctx->cnx_client->path[i]->unique_path_id > 63) {
                DBG_PRINTF("Path ID[%d] = %" PRIu64 ", too big!", i, test_ctx->cnx_client->path[i]->unique_path_id);
                ret = -1;
            }
            else if ((mask & (1ull << test_ctx->cnx_client->path[i]->unique_path_id)) != 0) {
                DBG_PRINTF("Path ID[%d] = %" PRIu64 ", reuse!", i, test_ctx->cnx_client->path[i]->unique_path_id);
                ret = -1;
            }
            else if (test_ctx->cnx_client->path[i]->first_tuple->p_local_cnxid != NULL && test_ctx->cnx_client->path[i]->unique_path_id !=
                test_ctx->cnx_client->path[i]->first_tuple->p_local_cnxid->path_id) {
                DBG_PRINTF("Path ID[%d] = %" PRIu64 ", vs. local CID path id: %" PRIu64,
                    i, test_ctx->cnx_client->path[i]->unique_path_id,
                    i, test_ctx->cnx_client->path[i]->first_tuple->p_local_cnxid->path_id);
                ret = -1;
            }
        }
    }


    if (ret == 0 && (test_id == multipath_test_nat || test_id == multipath_test_nat_challenge)) {
        /* Check that the path 0 has the new address */
        if (test_ctx->cnx_server->nb_paths < 2 ||
            test_ctx->cnx_client->nb_paths < 2 ||
            test_ctx->cnx_server->path[0]->unique_path_id != 0 ||
            test_ctx->cnx_client->path[0]->unique_path_id != 0 ||
            picoquic_compare_addr((struct sockaddr*)&test_ctx->cnx_server->path[0]->first_tuple->peer_addr,
                (struct sockaddr*)&test_ctx->client_addr_natted) != 0) {
            DBG_PRINTF("%s", "NAT traversal looks wrong.\n");
            ret = -1;
        }
    }

    if (ret == 0 && (test_id == multipath_test_break1 || test_id == multipath_test_break2 || test_id == multipath_test_break3 || test_id == multipath_test_abandon)) {
        if (test_ctx->cnx_server->nb_paths != 1) {
            DBG_PRINTF("After break, %d paths on server connection.\n", test_ctx->cnx_server->nb_paths);
            ret = -1;
        } else if (test_ctx->cnx_client->nb_paths != 1) {
            DBG_PRINTF("After break, %d paths on client connection.\n", test_ctx->cnx_client->nb_paths);
            ret = -1;
        }
    }

    if (ret == 0 && (test_id == multipath_test_back0 || test_id == multipath_test_back1)) {
        if (test_ctx->cnx_server->nb_paths != 2) {
            DBG_PRINTF("After break and back, %d paths on server connection.\n", test_ctx->cnx_server->nb_paths);
            ret = -1;
        }
        else if (test_ctx->cnx_client->nb_paths != 2) {
            DBG_PRINTF("After break and back, %d paths on client connection.\n", test_ctx->cnx_client->nb_paths);
            ret = -1;
        }
    }

    if (ret == 0 && test_id == multipath_test_stream_af) {
        if (test_ctx->cnx_server->nb_paths != 2) {
            DBG_PRINTF("After break and back, %d paths on server connection.\n", test_ctx->cnx_server->nb_paths);
            ret = -1;
        }
        else if (test_ctx->cnx_server->path[0]->delivered < 1400000) {
            DBG_PRINTF("Not enough data delivered on server path 0 (%" PRIu64 ").\n", test_ctx->cnx_server->path[0]->delivered);
            ret = -1;
        }
        else if (test_ctx->cnx_server->path[1]->delivered > 600000) {
            DBG_PRINTF("Too much data delivered on server path 1 (%" PRIu64 ").\n",
                test_ctx->cnx_server->path[1]->delivered);
            ret = -1;
        }
    }

    /* In the datagram scenarios, verify the datagram transmission */
    if (ret == 0 && (test_id == multipath_test_datagram || test_id == multipath_test_dg_af)) {
        ret = multipath_verify_datagram_sent(&dg_ctx, test_id);
    }

    /* In the backup scenario, verify that the flag is set
    * correctly at the server, and that not too much data is
    * sent on backup path.
    */
    if (ret == 0 && (test_id == multipath_test_backup)) {
        if (!test_ctx->cnx_server->path[1]->path_is_backup) {
            DBG_PRINTF("Backup not set on server path 1 (%d).\n", test_ctx->cnx_server->path[1]->path_is_backup);
            ret = -1;
        }
        else if (test_ctx->cnx_server->path[1]->delivered > 50000) {
            DBG_PRINTF("Too much data delivered on server path 1 (%" PRIu64 ").\n", test_ctx->cnx_server->path[1]->delivered);
            ret = -1;
        }
    }

    /* In the stream-affinity-on-backup-path scenario, verify that the path
     * is indeed marked backup, but that stream 4's affinity still routed its
     * data there -- i.e. affinity overrides the backup exclusion instead of
     * the stream stalling forever.
     */
    if (ret == 0 && test_id == multipath_test_stream_af_backup) {
        if (!test_ctx->cnx_server->path[1]->path_is_backup) {
            DBG_PRINTF("Backup not set on server path 1 (%d).\n", test_ctx->cnx_server->path[1]->path_is_backup);
            ret = -1;
        }
        else if (test_ctx->cnx_server->path[1]->delivered < 900000) {
            DBG_PRINTF("Not enough data delivered on backup-but-affinity server path 1 (%" PRIu64 ").\n",
                test_ctx->cnx_server->path[1]->delivered);
            ret = -1;
        }
        else if (test_ctx->cnx_server->path[1]->delivered > 1100000) {
            /* Stream 4 (affinity-pinned) carries ~1MB. Stream 8 is NOT pinned and should
             * stay off the backup path entirely -- if it leaked onto path 1 too, delivered
             * would be closer to 2MB than 1MB. */
            DBG_PRINTF("Too much data delivered on backup-but-affinity server path 1 (%" PRIu64 "), non-affinity stream may have leaked onto it.\n",
                test_ctx->cnx_server->path[1]->delivered);
            ret = -1;
        }
    }

    if (ret == 0 && test_id == multipath_test_discovery) {
        if (test_ctx->nb_address_observed < 2) {
            DBG_PRINTF("Got % addresses observed", test_ctx->nb_address_observed);
            ret = -1;
        }
        for (int p = 0; p < 2; p++) {
            if (picoquic_compare_addr(
                (struct sockaddr*)&test_ctx->cnx_client->path[p]->first_tuple->local_addr,
                (struct sockaddr*)&test_ctx->cnx_client->path[p]->first_tuple->observed_addr) != 0) {
                char text1[256];
                char text2[256];

                DBG_PRINTF("Path %d, Local: %s, observed: %s", p,
                    picoquic_addr_text((struct sockaddr*)&test_ctx->cnx_client->path[p]->first_tuple->local_addr, text1, sizeof(text1)),
                    picoquic_addr_text((struct sockaddr*)&test_ctx->cnx_client->path[p]->first_tuple->observed_addr, text2, sizeof(text2)));
                ret = -1;
            }
        }
    }

    if (test_id == multipath_test_break_both) {
        /* exception: this test is supposed to fail, because both links
        * are unreachable. */
        if (ret == 0) {
            ret = -1;
        }
        else {
            ret = 0;
        }
    }
    /* Delete the context */
    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
    }

    /* Check the multipath event logs if collected. */
    if (ret == 0 && (test_id == multipath_test_callback || test_id == multipath_test_quality || test_id == multipath_test_quality_server)) {
        ret = multipath_verify_callbacks(test_id);
    }

    return ret;
}

/* Basic multipath test. Set up two links in parallel, verify that both are used and that
 * the overall transmission is shorter than if only one link was used.
 */

int multipath_basic_test(void)
{
    uint64_t max_completion_microsec = 1060000;

    return multipath_test_one(max_completion_microsec, multipath_test_basic);
}

/* Multipath fail test. Same as basic, but the multipath setup is expected to fail.
*/

int multipath_fail_test(void)
{
    uint64_t max_completion_microsec = 2000000;

    return multipath_test_one(max_completion_microsec, multipath_test_fail);
}

/* Multipath abandon path 1. Same as basic, but abandon a path before it is
* even established. And then repeat a cycle of abandon path / wait for
* new CID to make sure that the peer properly provisions new CID. And then
* create a path for real and use it.
*/

int multipath_ab1_test(void)
{
    uint64_t max_completion_microsec = 3000000;

    return multipath_test_one(max_completion_microsec, multipath_test_ab1);
}

/* Drop first multipath test. Set up two links in parallel, start using them, then
 * drop the first one of them. Check that the transmission succeeds.
 */

int multipath_drop_first_test(void)
{
    uint64_t max_completion_microsec = 1490000;

    return multipath_test_one(max_completion_microsec, multipath_test_drop_first);
}

/* Drop second multipath test. Set up two links in parallel, start using them, then
 * drop the second one of them. Check that the transmission succeeds.
 */

int multipath_drop_second_test(void)
{
    uint64_t max_completion_microsec = 1350000;

    return multipath_test_one(max_completion_microsec, multipath_test_drop_second);
}

/* Same as drop first, but only the client to server direction of path 0 fails. */
int multipath_drop_first_c2s_test(void)
{
    uint64_t max_completion_microsec = 1060000;

    return multipath_test_one(max_completion_microsec, multipath_test_drop_first_c2s);
}

/* Same as drop first, but only the server to client direction of path 0 fails. */
int multipath_drop_first_s2c_test(void)
{
    uint64_t max_completion_microsec = 1300000;

    return multipath_test_one(max_completion_microsec, multipath_test_drop_first_s2c);
}

/* Simulate the combination of a satellite link and a low latency low bandwidth
 * terrestrial link
 */
int multipath_sat_plus_test(void)
{
    uint64_t max_completion_microsec = 10000000;

    return  multipath_test_one(max_completion_microsec, multipath_test_sat_plus);
}

/* Test the renewal of the connection ID on a path
 */
int multipath_renew_test(void)
{
    uint64_t max_completion_microsec = 3000000;

    return  multipath_test_one(max_completion_microsec, multipath_test_renew);
}

/* Test key rotation in a multipath setup
 */
int multipath_rotation_test(void)
{
    uint64_t max_completion_microsec = 3000000;

    return  multipath_test_one(max_completion_microsec, multipath_test_rotation);
}

/* Test nat traversal in a multipath setup */
int multipath_nat_test(void)
{
    uint64_t max_completion_microsec = 3000000;

    return  multipath_test_one(max_completion_microsec, multipath_test_nat);
}

int multipath_nat_challenge_test(void)
{
    uint64_t max_completion_microsec = 3000000;

    return  multipath_test_one(max_completion_microsec, multipath_test_nat_challenge);
}


/* Test that breaking paths are removed after some time
 */
int multipath_break1_test(void)
{
    uint64_t max_completion_microsec = 10800000;

    return  multipath_test_one(max_completion_microsec, multipath_test_break1);
}

/* Test reaction to socket error on second path
 */
int multipath_socket_error_test(void)
{
    uint64_t max_completion_microsec = 11100000;

    return  multipath_test_one(max_completion_microsec, multipath_test_break2);
}

/* Test reaction to socket error on first path
 */
int multipath_socket0_error_test(void)
{
    uint64_t max_completion_microsec = 10900000;

    return  multipath_test_one(max_completion_microsec, multipath_test_break3);
}

/* Test that abandoned paths are removed after some time
 */
int multipath_abandon_test(void)
{
    uint64_t max_completion_microsec = 3800000;

    return  multipath_test_one(max_completion_microsec, multipath_test_abandon);
}

/* 
 * Verify that abandoning the last valid path will fail.
 *
 * This test drives the connection into that state and checks the
 * double abandon directly, by calling picoquic_delete_abandoned_paths()
 * the way a live connection would before preparing its next packet
 * -- so a still-broken tree fails this test cleanly
 * instead of crashing the test binary.
 */
int multipath_abandon_last_test(void)
{
    uint64_t simulated_time = 0;
    uint64_t loss_mask = 0;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    picoquic_tp_t server_parameters;
    int ret = tls_api_init_ctx(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1,
        PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, NULL, NULL, 0, 1, 0);

    if (ret == 0 && test_ctx == NULL) {
        ret = -1;
    }

    if (ret == 0) {
        test_ctx->c_to_s_link->queue_delay_max = 2 * test_ctx->c_to_s_link->microsec_latency;
        test_ctx->s_to_c_link->queue_delay_max = 2 * test_ctx->s_to_c_link->microsec_latency;
        /* Set the multipath option at both client and server */
        multipath_init_params(&server_parameters, 0);
        picoquic_set_default_tp(test_ctx->qserver, &server_parameters);
        test_ctx->cnx_client->local_parameters.initial_max_path_id = 3;
        (void)picoquic_start_client_cnx(test_ctx->cnx_client);
    }

    /* establish the connection */
    if (ret == 0) {
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 2 * test_ctx->s_to_c_link->microsec_latency, &simulated_time);
    }

    if (ret == 0 && (!test_ctx->cnx_client->is_multipath_enabled || !test_ctx->cnx_server->is_multipath_enabled)) {
        DBG_PRINTF("Multipath not fully negotiated (c=%d, s=%d)",
            test_ctx->cnx_client->is_multipath_enabled, test_ctx->cnx_server->is_multipath_enabled);
        ret = -1;
    }

    if (ret == 0) {
        ret = wait_client_connection_ready(test_ctx, &simulated_time);
    }

    /* Add a second path, and wait until both sides have validated it. */
    if (ret == 0) {
        ret = multipath_test_add_links(test_ctx, 0);
    }
    if (ret == 0) {
        ret = picoquic_probe_new_path(test_ctx->cnx_client, (struct sockaddr*)&test_ctx->server_addr,
            (struct sockaddr*)&test_ctx->client_addr_2, simulated_time);
    }
    if (ret == 0) {
        ret = wait_multipath_ready(test_ctx, &simulated_time);
    }

    if (ret == 0 && test_ctx->cnx_client->nb_paths != 2) {
        DBG_PRINTF("Expected 2 paths on the client, got %d", test_ctx->cnx_client->nb_paths);
        ret = -1;
    }

    /* Abandon path 1. This is normal, supported usage: more than one path is
     * available, so the call succeeds and path 1 is marked for demotion. */
    if (ret == 0) {
        ret = picoquic_abandon_path(test_ctx->cnx_client, 1, 0, simulated_time);
        if (ret != 0) {
            DBG_PRINTF("Could not abandon path 1, ret=%d", ret);
        }
    }

    /* Abandon path 0 as well -- the last path not yet marked for demotion.
     * This call should be rejected. */
    if (ret == 0) {
        int abandon_ret = picoquic_abandon_path(test_ctx->cnx_client, 0, 0, simulated_time);

        if (abandon_ret == PICOQUIC_ERROR_PATH_LAST_REMAINING) {
            /* Expected: abandoning the last non-demoted path is refused. */
            ret = 0;
        }
        else if (abandon_ret != 0) {
            DBG_PRINTF("Abandoning the last non-demoted path returned %d, expected PICOQUIC_ERROR_PATH_LAST_REMAINING.", abandon_ret);
            ret = -1;
        }
        else {
            uint64_t next_wake_time = simulated_time;
            uint64_t future_time = simulated_time + 10000000;

            DBG_PRINTF("%s", "Abandoning the last non-demoted path wrongly succeeded.");

            /* Let both demotion timers expire, then run the path cleanup
             * that a live connection performs before sending. */
            picoquic_delete_abandoned_paths(test_ctx->cnx_client, future_time, &next_wake_time);

            if (test_ctx->cnx_client->nb_paths == 0 || test_ctx->cnx_client->path[0] == NULL) {
                DBG_PRINTF("Client left with %d paths, path[0] = %p.",
                    test_ctx->cnx_client->nb_paths,
                    (void*)test_ctx->cnx_client->path[0]);
            }
            ret = -1;
        }
    }

    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
    }

    return ret;
}

/* Verify that receiving a PATH_ABANDON frame for the last remaining path
 * closes the connection, instead of marking the path demoted while still
 * using it for every subsequent packet.
 */
int multipath_abandon_last_by_peer_test(void)
{
    uint64_t simulated_time = 0;
    uint64_t loss_mask = 0;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    picoquic_tp_t server_parameters;
    int ret = tls_api_init_ctx(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1,
        PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, NULL, NULL, 0, 1, 0);

    if (ret == 0 && test_ctx == NULL) {
        ret = -1;
    }

    if (ret == 0) {
        test_ctx->c_to_s_link->queue_delay_max = 2 * test_ctx->c_to_s_link->microsec_latency;
        test_ctx->s_to_c_link->queue_delay_max = 2 * test_ctx->s_to_c_link->microsec_latency;
        /* Set the multipath option at both client and server */
        multipath_init_params(&server_parameters, 0);
        picoquic_set_default_tp(test_ctx->qserver, &server_parameters);
        test_ctx->cnx_client->local_parameters.initial_max_path_id = 3;
        (void)picoquic_start_client_cnx(test_ctx->cnx_client);
    }

    /* establish the connection, with a single path on each side */
    if (ret == 0) {
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 2 * test_ctx->s_to_c_link->microsec_latency, &simulated_time);
    }

    if (ret == 0 && (!test_ctx->cnx_client->is_multipath_enabled || !test_ctx->cnx_server->is_multipath_enabled)) {
        DBG_PRINTF("Multipath not fully negotiated (c=%d, s=%d)",
            test_ctx->cnx_client->is_multipath_enabled, test_ctx->cnx_server->is_multipath_enabled);
        ret = -1;
    }

    if (ret == 0) {
        ret = wait_client_connection_ready(test_ctx, &simulated_time);
    }

    if (ret == 0 && test_ctx->cnx_client->nb_paths != 1) {
        DBG_PRINTF("Expected 1 path on the client, got %d", test_ctx->cnx_client->nb_paths);
        ret = -1;
    }

    /* Simulate the peer sending a PATH_ABANDON frame for path 0, the
     * client's only path. Build just the frame payload -- path ID and
     * reason -- since picoquic_decode_path_abandon_frame() expects the
     * frame type to already be consumed by the caller. */
    if (ret == 0) {
        uint8_t frame_bytes[16];
        uint8_t* bytes_max = frame_bytes + sizeof(frame_bytes);
        uint8_t* bytes_next = picoquic_frames_varint_encode(frame_bytes, bytes_max, 0);

        bytes_next = picoquic_frames_varint_encode(bytes_next, bytes_max, PICOQUIC_TRANSPORT_APPLICATION_ABANDON);

        if (bytes_next == NULL ||
            picoquic_decode_path_abandon_frame(frame_bytes, bytes_next, test_ctx->cnx_client, simulated_time) == NULL) {
            DBG_PRINTF("%s", "Could not build or decode the injected PATH_ABANDON frame.");
            ret = -1;
        }
    }

    if (ret == 0 && test_ctx->cnx_client->cnx_state < picoquic_state_disconnecting) {
        DBG_PRINTF("Client cnx_state is %d after losing its only path to a peer abandon; the connection should be closing.",
            test_ctx->cnx_client->cnx_state);
        ret = -1;
    }

    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
    }

    return ret;
}

/* Verify that picoquic_delete_abandoned_paths() cannot leave path[0] with a
 * NULL remote CID while the connection is still picoquic_state_ready -- doing
 * that could lead to a crash if the code reference a partially deleted version
 * of path[0]. 
 */
int multipath_demoted_path0_null_cnxid_test(void)
{
    uint64_t simulated_time = 0;
    uint64_t loss_mask = 0;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    picoquic_tp_t server_parameters;
    int ret = tls_api_init_ctx(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1,
        PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, NULL, NULL, 0, 1, 0);

    if (ret == 0 && test_ctx == NULL) {
        ret = -1;
    }

    if (ret == 0) {
        test_ctx->c_to_s_link->queue_delay_max = 2 * test_ctx->c_to_s_link->microsec_latency;
        test_ctx->s_to_c_link->queue_delay_max = 2 * test_ctx->s_to_c_link->microsec_latency;
        /* Set the multipath option at both client and server */
        multipath_init_params(&server_parameters, 0);
        picoquic_set_default_tp(test_ctx->qserver, &server_parameters);
        test_ctx->cnx_client->local_parameters.initial_max_path_id = 3;
        (void)picoquic_start_client_cnx(test_ctx->cnx_client);
    }

    /* establish the connection */
    if (ret == 0) {
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 2 * test_ctx->s_to_c_link->microsec_latency, &simulated_time);
    }

    if (ret == 0 && (!test_ctx->cnx_client->is_multipath_enabled || !test_ctx->cnx_server->is_multipath_enabled)) {
        DBG_PRINTF("Multipath not fully negotiated (c=%d, s=%d)",
            test_ctx->cnx_client->is_multipath_enabled, test_ctx->cnx_server->is_multipath_enabled);
        ret = -1;
    }

    if (ret == 0) {
        ret = wait_client_connection_ready(test_ctx, &simulated_time);
    }

    /* Add a second path, and wait until both sides have validated it. */
    if (ret == 0) {
        ret = multipath_test_add_links(test_ctx, 0);
    }
    if (ret == 0) {
        ret = picoquic_probe_new_path(test_ctx->cnx_client, (struct sockaddr*)&test_ctx->server_addr,
            (struct sockaddr*)&test_ctx->client_addr_2, simulated_time);
    }
    if (ret == 0) {
        ret = wait_multipath_ready(test_ctx, &simulated_time);
    }

    if (ret == 0 && test_ctx->cnx_client->nb_paths != 2) {
        DBG_PRINTF("Expected 2 paths on the client, got %d", test_ctx->cnx_client->nb_paths);
        ret = -1;
    }

    /* Demote path 1, with a long retransmit timer so its demotion is far in
     * the future. This is normal, supported usage: two paths are available,
     * so the call succeeds, path 1's remote CID is released right away, and
     * path 1 itself stays in the path array until its demotion timer
     * expires. */
    if (ret == 0) {
        test_ctx->cnx_client->path[1]->retransmit_timer = 10000000;
        ret = picoquic_abandon_path(test_ctx->cnx_client, 1, 0, simulated_time);
        if (ret != 0) {
            DBG_PRINTF("Could not abandon path 1, ret=%d", ret);
        }
        else if (!test_ctx->cnx_client->path[1]->path_is_demoted ||
            test_ctx->cnx_client->path[1]->first_tuple->p_remote_cnxid != NULL) {
            DBG_PRINTF("%s", "Demoting path 1 did not release its remote CID as expected.");
            ret = -1;
        }
    }

    /* Path 0 is now the only path not yet marked for demotion. Simulate its
     * challenge having failed -- the state picoquic_prepare_tuple_challenge_frames()
     * (paths.c) reaches on its own after PICOQUIC_CHALLENGE_REPEAT_MAX
     * unanswered challenges -- with a short retransmit timer, then run the
     * same cleanup a live connection performs before sending. This exercises
     * picoquic_delete_abandoned_paths()'s own direct call into
     * picoquic_demote_path(), not the guarded picoquic_abandon_path() path.
     * Since path 1 already released its CID, picoquic_demote_path() has no
     * path left to swap into slot 0: it must close the connection rather
     * than mark path 0 demoted while leaving it in slot 0 with a valid CID. */
    if (ret == 0) {
        uint64_t next_wake_time = simulated_time;

        test_ctx->cnx_client->path[0]->retransmit_timer = 1000;
        test_ctx->cnx_client->path[0]->first_tuple->challenge_failed = 1;

        picoquic_delete_abandoned_paths(test_ctx->cnx_client, simulated_time, &next_wake_time);

        if (test_ctx->cnx_client->cnx_state < picoquic_state_disconnecting) {
            DBG_PRINTF("Client cnx_state is %d after path 0 could not be demoted; the connection should be closing.",
                test_ctx->cnx_client->cnx_state);
            ret = -1;
        }
        else if (test_ctx->cnx_client->nb_paths != 2 || test_ctx->cnx_client->path[0] == NULL) {
            DBG_PRINTF("Client left with %d paths, path[0] = %p.",
                test_ctx->cnx_client->nb_paths, (void*)test_ctx->cnx_client->path[0]);
            ret = -1;
        }
        else if (test_ctx->cnx_client->path[0]->path_is_demoted ||
            test_ctx->cnx_client->path[0]->first_tuple->p_remote_cnxid == NULL) {
            DBG_PRINTF("%s", "Path 0 should have been left alone -- not demoted, CID still valid -- "
                "when the connection closed instead.");
            ret = -1;
        }
    }

    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
    }

    return ret;
}

typedef struct st_multipath_close_test_ctx_t {
    int close_received;
} multipath_close_test_ctx_t;

static int multipath_close_test_callback(picoquic_cnx_t* UNUSED(cnx),
    uint64_t UNUSED(stream_id), uint8_t* UNUSED(bytes), size_t UNUSED(length),
    picoquic_call_back_event_t fin_or_event, void* callback_ctx, void* UNUSED(v_stream_ctx))
{
    if (fin_or_event == picoquic_callback_close) {
        ((multipath_close_test_ctx_t*)callback_ctx)->close_received = 1;
    }
    return 0;
}

/* Verify that when the only path of a connection cannot be validated, the
 * connection is closed locally -- there is no peer to send a CONNECTION_CLOSE
 * to, so this mirrors the abrupt local close already used for idle timeout
 * (picoquic_check_idle_timer), not the protocol-level close used when the
 * peer itself asks to abandon the last path.
 *
 * The test also checks that the code path that discovers the failure --
 * preparing a packet -- runs to completion without crashing, that it
 * notifies the application via picoquic_callback_close, and that calling
 * it again afterwards, as the application's event loop naturally would,
 * remains safe.
 */
int multipath_last_path_validation_fails_test(void)
{
    uint64_t simulated_time = 0;
    uint64_t loss_mask = 0;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    picoquic_tp_t server_parameters;
    multipath_close_test_ctx_t close_ctx = { 0 };
    int ret = tls_api_init_ctx(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1,
        PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, NULL, NULL, 0, 1, 0);

    if (ret == 0 && test_ctx == NULL) {
        ret = -1;
    }

    if (ret == 0) {
        test_ctx->c_to_s_link->queue_delay_max = 2 * test_ctx->c_to_s_link->microsec_latency;
        test_ctx->s_to_c_link->queue_delay_max = 2 * test_ctx->s_to_c_link->microsec_latency;
        /* Set the multipath option at both client and server */
        multipath_init_params(&server_parameters, 0);
        picoquic_set_default_tp(test_ctx->qserver, &server_parameters);
        test_ctx->cnx_client->local_parameters.initial_max_path_id = 3;
        (void)picoquic_start_client_cnx(test_ctx->cnx_client);
    }

    /* establish the connection, with a single path on each side */
    if (ret == 0) {
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 2 * test_ctx->s_to_c_link->microsec_latency, &simulated_time);
    }

    if (ret == 0 && (!test_ctx->cnx_client->is_multipath_enabled || !test_ctx->cnx_server->is_multipath_enabled)) {
        DBG_PRINTF("Multipath not fully negotiated (c=%d, s=%d)",
            test_ctx->cnx_client->is_multipath_enabled, test_ctx->cnx_server->is_multipath_enabled);
        ret = -1;
    }

    if (ret == 0) {
        ret = wait_client_connection_ready(test_ctx, &simulated_time);
    }

    if (ret == 0 && test_ctx->cnx_client->nb_paths != 1) {
        DBG_PRINTF("Expected 1 path on the client, got %d", test_ctx->cnx_client->nb_paths);
        ret = -1;
    }

    /* From this point on, watch for the close callback instead of running
     * the default test scenario. */
    if (ret == 0) {
        picoquic_set_callback(test_ctx->cnx_client, multipath_close_test_callback, &close_ctx);

        /* Simulate exhausted PATH_CHALLENGE retries on the client's only
         * path: this is the state picoquic_prepare_tuple_challenge_frames()
         * (paths.c) reaches on its own after PICOQUIC_CHALLENGE_REPEAT_MAX
         * unanswered challenges. */
        test_ctx->cnx_client->path[0]->first_tuple->challenge_failed = 1;
    }

    /* Preparing a packet is exactly the call chain of the reported crash
     * (picoquic_prepare_packet_ex -> ... -> picoquic_handle_send_paths ->
     * picoquic_select_next_path_tuple). It must run to completion, without
     * touching a path or tuple that no longer makes sense once the
     * connection is closed mid-call. */
    if (ret == 0) {
        size_t send_length = 0;
        size_t send_msg_size = 0;
        struct sockaddr_storage addr_to = { 0 };
        struct sockaddr_storage addr_from = { 0 };
        int if_index = 0;
        int prepare_ret = picoquic_prepare_packet_ex(test_ctx->cnx_client, simulated_time,
            test_ctx->send_buffer, test_ctx->send_buffer_size, &send_length,
            &addr_to, &addr_from, &if_index, &send_msg_size);

        if (prepare_ret != PICOQUIC_ERROR_DISCONNECTED) {
            DBG_PRINTF("First prepare_packet after last-path validation failure returned %d, expected PICOQUIC_ERROR_DISCONNECTED.",
                prepare_ret);
            ret = -1;
        }
    }

    if (ret == 0 && test_ctx->cnx_client->cnx_state != picoquic_state_disconnected) {
        DBG_PRINTF("Client cnx_state is %d after its only path failed validation; the connection should be disconnected.",
            test_ctx->cnx_client->cnx_state);
        ret = -1;
    }

    if (ret == 0 && !close_ctx.close_received) {
        DBG_PRINTF("%s", "The application was not notified with picoquic_callback_close.");
        ret = -1;
    }

    /* The application's event loop will keep calling into the connection
     * after it learns about the close, e.g. because other connections
     * still need service. That must also stay safe. */
    if (ret == 0) {
        size_t send_length = 0;
        size_t send_msg_size = 0;
        struct sockaddr_storage addr_to = { 0 };
        struct sockaddr_storage addr_from = { 0 };
        int if_index = 0;
        int prepare_ret = picoquic_prepare_packet_ex(test_ctx->cnx_client, simulated_time + 1000,
            test_ctx->send_buffer, test_ctx->send_buffer_size, &send_length,
            &addr_to, &addr_from, &if_index, &send_msg_size);

        if (prepare_ret != PICOQUIC_ERROR_DISCONNECTED || send_length != 0) {
            DBG_PRINTF("Second prepare_packet after disconnection returned %d, send_length %zu.",
                prepare_ret, send_length);
            ret = -1;
        }
    }

    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
    }

    return ret;
}

/* Test that after breaking path 0 we can establish a new path on the
* same link when it comes back up.
 */
int multipath_back0_test(void)
{
    uint64_t max_completion_microsec = 3300000;

    return  multipath_test_one(max_completion_microsec, multipath_test_back0);
}

/* Test that breaking paths can come back up after some time
 */
int multipath_back1_test(void)
{
    /* TODO: investigate why 3.5 instead of 3.05 with prior implementation of multipath */
    uint64_t max_completion_microsec = 3500000;

    return  multipath_test_one(max_completion_microsec, multipath_test_back1);
}

/* Test that a typical wifi+lte scenario provides good performance */
int multipath_perf_test(void)
{
    uint64_t max_completion_microsec = 1650000;

    return  multipath_test_one(max_completion_microsec, multipath_test_perf);
}

#if defined(_WINDOWS) && !defined(_WINDOWS64)
int multipath_callback_test(void)
{
    /* we do not run this test on Win32 builds */
    return 0;
}
#else
int multipath_callback_test(void)
{
    uint64_t max_completion_microsec = 1000000;

    return multipath_test_one(max_completion_microsec, multipath_test_callback);
}
#endif

#if defined(_WINDOWS) && !defined(_WINDOWS64)
int multipath_quality_test(void)
{
    /* we do not run this test on Win32 builds */
    return 0;
}
#else
int multipath_quality_test(void)
{
    uint64_t max_completion_microsec = 1000000;

    return multipath_test_one(max_completion_microsec, multipath_test_quality);
}
#endif

int multipath_stream_af_test(void)
{
    uint64_t max_completion_microsec = 1500000;

    return multipath_test_one(max_completion_microsec, multipath_test_stream_af);
}

int multipath_datagram_test(void)
{
    /* TODO: investigate why 1.15 instead of 1.12 with prior implementation of multipath */
    uint64_t max_completion_microsec = 1150000;

    return multipath_test_one(max_completion_microsec, multipath_test_datagram);
}

int multipath_dg_af_test(void)
{
    uint64_t max_completion_microsec = 1100000;

    return multipath_test_one(max_completion_microsec, multipath_test_dg_af);
}

int multipath_backup_test(void)
{
    uint64_t max_completion_microsec = 2000000;

    return multipath_test_one(max_completion_microsec, multipath_test_backup);
}

int multipath_stream_af_backup_test(void)
{
    uint64_t max_completion_microsec = 3500000;

    return multipath_test_one(max_completion_microsec, multipath_test_stream_af_backup);
}

int multipath_standup_test(void)
{
    uint64_t max_completion_microsec = 7200000;

    return multipath_test_one(max_completion_microsec, multipath_test_standup);
}

int multipath_discovery_test(void)
{
    uint64_t max_completion_microsec = 2000000;

    return multipath_test_one(max_completion_microsec, multipath_test_discovery);
}

int multipath_keep_alive_test(void)
{
    uint64_t max_completion_microsec = 210000000;

    return multipath_test_one(max_completion_microsec, multipath_test_keep_alive);
}

/* Setting the initial max patht ID to 1 should allow two paths to be created */
int multipath_just_one_test(void)
{
    uint64_t max_completion_microsec = 1060000;

    return multipath_test_one(max_completion_microsec, multipath_test_just_one);
}

/* Breaking both links at the same time. Expect the connection to break,
 * without crashing. */
int multipath_break_both_test(void)
{
    uint64_t max_completion_microsec = 1060000;

    return multipath_test_one(max_completion_microsec, multipath_test_break_both);
}

/* Monopath tests:
 * Enable the multipath option, but use only a single path. The goal of the tests is to verify that
 * these "monopath" scenarios perform just as well as if multipath was not enabled.
 */

typedef enum {
    monopath_test_basic = 0,
    monopath_test_hole,
    monopath_test_rotation,
    monopath_keep_alive
} monopath_test_enum_t;

/* Basic connection with the multicast option enabled. */
int monopath_test_one(monopath_test_enum_t test_case)
{
    uint64_t max_completion_microsec = 2200000;
    uint64_t simulated_time = 0;
    const uint64_t latency = 10000;
    picoquic_tp_t client_parameters;
    picoquic_tp_t server_parameters;
    picoquic_connection_id_t initial_cid = { {0xba, 0xba, 1, 0, 0, 0, 0, 0}, 8 };
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    int ret = 0;

    initial_cid.id[7] = (uint8_t)test_case;

    multipath_init_params(&client_parameters, 0);
    multipath_init_params(&server_parameters, 0);

    ret = tls_api_one_scenario_init_ex(&test_ctx, &simulated_time, PICOQUIC_INTERNAL_TEST_VERSION_1, &client_parameters, &server_parameters, &initial_cid);

    if (ret == 0 && test_ctx == NULL) {
        ret = -1;
    }

    /* Simulate satellite links: 250 mbps, 300ms delay in each direction */
    /* Set the congestion algorithm to specified value. Also, request a packet trace */
    if (ret == 0) {
        /* set the delay estimate, then launch the test */
        test_ctx->c_to_s_link->microsec_latency = latency;
        test_ctx->s_to_c_link->microsec_latency = latency;

        picoquic_set_qlog(test_ctx->qserver, ".");
        test_ctx->qserver->use_long_log = 1;
        /* set the binary log on the client side */
        picoquic_set_qlog(test_ctx->qclient, ".");
        test_ctx->qclient->use_long_log = 1;

        if (test_case == monopath_test_hole) {
            /* set the optimistic ack policy, to trigger hole insertion at the server */
            picoquic_set_optimistic_ack_policy(test_ctx->qserver, PICOQUIC_DEFAULT_HOLE_PERIOD);
            /* Reset the uniform random test */
            picoquic_public_random_seed_64(RANDOM_PUBLIC_TEST_SEED, 1);
        }

        if (test_case == monopath_test_rotation) {
            picoquic_set_default_crypto_epoch_length(test_ctx->qserver, 200);
        }

        if (ret == 0) {
            ret = tls_api_one_scenario_body_connect(test_ctx, &simulated_time, 0, 0);
            if (ret != 0)
            {
                DBG_PRINTF("Connect loop returns %d\n", ret);
            }
        }

        /* Prepare to send data */
        if (ret == 0) {
            ret = test_api_init_send_recv_scenario(test_ctx, test_scenario_multipath,
                sizeof(test_scenario_multipath));

            if (ret != 0)
            {
                DBG_PRINTF("Init send receive scenario returns %d\n", ret);
            }
        }

        if (ret == 0) {
            ret = tls_api_data_sending_loop(test_ctx, &test_ctx->loss_mask_default, &simulated_time, 0);

            if (ret != 0)
            {
                DBG_PRINTF("Data sending loop returns %d\n", ret);
            }
        }
    }

    if (ret == 0 && test_case == monopath_keep_alive) {
        max_completion_microsec = 202000000;
        ret = multipath_test_do_keep_alive(test_ctx, &simulated_time);
    }

    if (ret == 0) {
        ret = tls_api_one_scenario_body_verify(test_ctx, &simulated_time, max_completion_microsec);
    }

    if (ret == 0){
        if (test_case == monopath_test_hole) {
            if (test_ctx->cnx_server->nb_packet_holes_inserted == 0) {
                DBG_PRINTF("%s", "No holes inserted\n");
                ret = -1;
            }
        }
        else if (test_case == monopath_test_rotation) {
            if (test_ctx->cnx_server->nb_crypto_key_rotations == 0) {
                DBG_PRINTF("%s", "No key rotation observed.\n");
                ret = -1;
            }
        } 
    }

    /* Free the resource, which will close the log file.
     */

    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
        test_ctx = NULL;
    }

    return ret;
}

/* Basic connection with the multicast option enabled. */
int monopath_basic_test(void)
{
    return monopath_test_one(monopath_test_basic);
}

/* Testing the defense against opportunistic acks. */
int monopath_hole_test(void)
{
    return monopath_test_one(monopath_test_hole);
}

/* test that a single path connection can be kept alive */
int monopath_keep_alive_test(void)
{
    return monopath_test_one(monopath_keep_alive);
}

/* Testing key rotation in monopath context. */
int monopath_rotation_test(void)
{
    return monopath_test_one(monopath_test_rotation);
}


/* The zero RTT test uses the unipath code, with a special parameter.
 * Test both regular 0RTT set up, and case of losses.
 */

int monopath_0rtt_test(void)
{
    zero_rtt_test_t zrt = { 0 };
    zrt.do_multipath = 1;
    return zero_rtt_test_one(&zrt);
}

int monopath_0rtt_loss_test(void)
{
    int ret = 0;

    for (unsigned int i = 1; ret == 0 && i < 16; i++) {
        zero_rtt_test_t zrt = { 0 };
        zrt.early_loss = 1ull << i;
        zrt.do_multipath = 1;
        ret = zero_rtt_test_one(&zrt);
        if (ret != 0) {
            DBG_PRINTF("Monopath 0 RTT test fails when packet #%d is lost.\n", i);
        }
    }

    return ret;
}

/*
 * Test the multipath variant of AEAD encrypt and decrypt.
 */
int multipath_aead_test(void)
{
    int ret = 0;
    const uint8_t mp_aead_secret[32] = {
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
        16, 17, 18, 19, 20, 21, 22, 23, 24, 35, 26, 27, 28, 29, 30, 31
    };
    /* Create AEAD contexts for encryption and decryption */
    void* aead_encrypt = picoquic_setup_test_aead_context(1, mp_aead_secret, PICOQUIC_LABEL_QUIC_V1_KEY_BASE);
    void* aead_decrypt = picoquic_setup_test_aead_context(0, mp_aead_secret, PICOQUIC_LABEL_QUIC_V1_KEY_BASE);

    if (aead_encrypt == NULL || aead_decrypt == NULL) {
        DBG_PRINTF("%s", "Could not create the AEAD contexts.\n");
        ret = -1;
    }
    else {
        /* For a series of path_id, verify that encryption and decryption works */
        const uint64_t path_id_test[] = { 0, 1, 2, 0x0123456789abcdefull };
        const size_t nb_paths = sizeof(path_id_test) / sizeof(uint64_t);
        uint64_t sequence = 12345;
        const char* aad_str = "This is a test";
        const size_t aad_len = strlen(aad_str);
        const uint8_t* aad = (const uint8_t*)aad_str;
        const char* test_input_str = "The quick brown fox jumps over the lazy dog";
        const size_t test_input_len = strlen(test_input_str);
        const uint8_t* test_input = (const uint8_t*)test_input_str;
        uint8_t encrypted[256];
        uint8_t decrypted[256];
        size_t encrypted_length;
        size_t decrypted_length;

        for (size_t i = 0; ret == 0 &&  i < nb_paths; i++) {
            encrypted_length = picoquic_aead_encrypt_mp(encrypted, test_input, test_input_len,
                path_id_test[i], sequence, aad, aad_len, aead_encrypt);
            for (size_t j = 0; ret == 0 && j < nb_paths; j++) {
                decrypted_length = picoquic_aead_decrypt_mp(decrypted, encrypted, encrypted_length,
                    path_id_test[j], sequence, aad, aad_len, aead_decrypt);
                if (i != j) {
                    if (decrypted_length <= encrypted_length) {
                        DBG_PRINTF("Unexpected success, path id encode 0x%" PRIx64 ", decode 0x%"PRIx64"\n",
                            path_id_test[i], path_id_test[j]);
                        ret = -1;
                    }
                }
                else if (decrypted_length > encrypted_length) {
                    DBG_PRINTF("Unexpected error, path id 0x%" PRIx64 "\n", path_id_test[i]);
                    ret = -1;
                }
                else if (decrypted_length != test_input_len) {
                    DBG_PRINTF("Length don't match, path id 0x%" PRIx64 ", in: %zu, out %zu\n",
                        path_id_test[i], test_input_len, decrypted_length);
                    ret = -1;
                }
                else if (memcmp(decrypted, test_input, test_input_len) != 0) {
                    DBG_PRINTF("Decoded doesn't match encoded, path id 0x%" PRIx64 "\n", path_id_test[i]);
                    ret = -1;
                }
            }
        }
    }

    if (aead_encrypt != NULL) {
        picoquic_aead_free(aead_encrypt);
    }
    if (aead_decrypt != NULL) {
        picoquic_aead_free(aead_decrypt);
    }

    return ret;
}

/* Test the log of multipath connections
 */

#define MULTIPATH_TRACE_QLOG  "0807060504030201.server.qlog"
#define MULTIPATH_QLOG "multipath_qlog_test.qlog"
#ifdef _WINDOWS
#define MULTIPATH_QLOG_REF "picoquictest\\multipath_qlog_ref.txt"
#else
#define MULTIPATH_QLOG_REF "picoquictest/multipath_qlog_ref.txt"
#endif

static test_api_stream_desc_t test_scenario_multipath_qlog[] = {
    { 4, 0, 257, 10000 },
    { 8, 4, 257, 10000 }
};

static const picoquic_connection_id_t qlog_multipath_initial_cid = { {8, 7, 6, 5, 4, 3, 2, 1}, 8 };

int multipath_trace_test_one(void)
{
    uint64_t simulated_time = 0;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    int ret = tls_api_init_ctx(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1, PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, NULL, NULL, 0, 1, 0);
    
    picoquic_connection_id_t cnxfn_data_client = { {1, 1, 1, 1, 1, 1, 1, 1}, 8 };
    picoquic_connection_id_t cnxfn_data_server = { {2, 2, 2, 2, 2, 2, 2, 2}, 8 };
    uint8_t reset_seed_client[PICOQUIC_RESET_SECRET_SIZE] = { 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25 };
    uint8_t reset_seed_server[PICOQUIC_RESET_SECRET_SIZE] = { 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35 };
    picoquic_tp_t server_parameters;
    picoquic_tp_t client_parameters;
    uint64_t loss_mask = 0;
    
    if (ret == 0 && test_ctx == NULL) {
        ret = -1;
    }

    /* Set the logging policy on the server side, to store data in the
     * current working directory, and run a basic test scenario */
    if (ret == 0) {
        picoquic_set_qlog(test_ctx->qserver, ".");
        (void)picoquic_set_default_spinbit_policy(test_ctx->qserver, picoquic_spinbit_on);
        (void)picoquic_set_default_spinbit_policy(test_ctx->qclient, picoquic_spinbit_on);
        picoquic_set_default_lossbit_policy(test_ctx->qserver, picoquic_lossbit_send_receive);
        picoquic_set_default_lossbit_policy(test_ctx->qclient, picoquic_lossbit_send_receive);
        test_ctx->qserver->cnx_id_callback_ctx = (void*)&cnxfn_data_server;
        test_ctx->qserver->cnx_id_callback_fn = qlog_trace_cid_fn;
        test_ctx->qclient->cnx_id_callback_ctx = (void*)&cnxfn_data_client;
        test_ctx->qclient->cnx_id_callback_fn = qlog_trace_cid_fn;
        memcpy(test_ctx->qclient->reset_seed, reset_seed_client, PICOQUIC_RESET_SECRET_SIZE);
        memcpy(test_ctx->qserver->reset_seed, reset_seed_server, PICOQUIC_RESET_SECRET_SIZE);
        test_ctx->qserver->use_constant_challenges = 1;
        test_ctx->qclient->use_constant_challenges = 1;
        /* Fix the buffer sizes in the simulation */
        test_ctx->c_to_s_link->queue_delay_max = 2 * test_ctx->c_to_s_link->microsec_latency;
        test_ctx->s_to_c_link->queue_delay_max = 2 * test_ctx->s_to_c_link->microsec_latency;
        /* Set the multipath option at both client and server */
        multipath_init_params(&server_parameters, 1);
        picoquic_set_default_tp(test_ctx->qserver, &server_parameters);
        multipath_init_params(&client_parameters, 1);
        picoquic_set_default_tp(test_ctx->qclient, &server_parameters);
        test_ctx->qclient->use_predictable_random = 1;
        test_ctx->qserver->use_predictable_random = 1;

        /* Force ciphersuite to AES128, so Client Hello has a constant format */
        if (picoquic_set_cipher_suite(test_ctx->qclient, PICOQUIC_AES_128_GCM_SHA256) != 0) {
            DBG_PRINTF("Could not set ciphersuite to 0x%04x", PICOQUIC_AES_128_GCM_SHA256);
        }
        if (picoquic_set_key_exchange(test_ctx->qclient, PICOQUIC_GROUP_SECP256R1) != 0) {
            DBG_PRINTF("Could not set key exchange to %d", PICOQUIC_GROUP_SECP256R1);
        }
        /* Delete the old connection */
        picoquic_delete_cnx(test_ctx->cnx_client);
        /* Reset the uniform random test */
        picoquic_public_random_seed_64(RANDOM_PUBLIC_TEST_SEED, 1);
        /* re-create a client connection, this time picking up the required connection ID */
        test_ctx->cnx_client = picoquic_create_cnx(test_ctx->qclient, qlog_multipath_initial_cid, picoquic_null_connection_id,
            (struct sockaddr*) & test_ctx->server_addr, 0,
            PICOQUIC_INTERNAL_TEST_VERSION_1, PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, 1);
        if (test_ctx->cnx_client == NULL) {
            DBG_PRINTF("%s", "Could not create the new client connection");
            ret = -1;
        }
        else {
            /* Initialize the client connection */
            picoquic_start_client_cnx(test_ctx->cnx_client);
        }
    }

    /* establish the connection */
    if (ret == 0) {
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 2 * test_ctx->s_to_c_link->microsec_latency, &simulated_time);
    }

    /* wait until the client (and thus the server) is ready */
    if (ret == 0) {
        ret = wait_client_connection_ready(test_ctx, &simulated_time);
    }

    /* Prepare to send data */
    if (ret == 0) {
        ret = test_api_init_send_recv_scenario(test_ctx, test_scenario_multipath_qlog, sizeof(test_scenario_multipath_qlog));

        if (ret != 0)
        {
            DBG_PRINTF("Init send receive scenario returns %d\n", ret);
        }
    }

    /* Add the multipath links and initiate the migration */
    if (ret == 0) {
        ret = multipath_test_add_links(test_ctx, 0);
    }

    if (ret == 0) {
        ret = picoquic_probe_new_path(test_ctx->cnx_client, (struct sockaddr*) & test_ctx->server_addr,
            (struct sockaddr*) & test_ctx->client_addr_2, simulated_time);
    }

    /* Check that the two paths are established */
    if (ret == 0) {
        ret = wait_multipath_ready(test_ctx, &simulated_time);
    }

    /* Perform a final data sending loop, this time to completion  */
    if (ret == 0) {
        ret = tls_api_data_sending_loop(test_ctx, &loss_mask, &simulated_time, 0);

        if (ret != 0)
        {
            DBG_PRINTF("Data sending loop returns %d\n", ret);
        }
    }

    /* Abandon path 1 so we can check the log of abandon path */
    if (ret == 0) {
        ret = picoquic_abandon_path(test_ctx->cnx_server, 1, 0, simulated_time);
        if (ret != 0) {
            DBG_PRINTF("Could not abandon path %" PRIu64 ", ret=%d", 1, ret);
        }
        else {
            /* fake a packet loss just after demoting the path */
            picoquic_log_packet_lost(test_ctx->cnx_server,
                test_ctx->cnx_server->path[1], picoquic_packet_1rtt_protected,
                12345, "test", NULL,
                1234, simulated_time);

            /* wait about 250ms for the abandon to be noticed at both ends. */
            ret = tls_api_wait_for_timeout(test_ctx, &simulated_time, 250000);
            if (ret != 0) {
                DBG_PRINTF("Issue after abandon path %" PRIu64 ", ret = %d", 1, ret);
            }
        }
    }

    /* Check that the transmission succeeded */
    if (ret == 0) {
        ret = tls_api_one_scenario_body_verify(test_ctx, &simulated_time, 2000000);
    }


    /* Add a gratuitous bad packet to test "packet dropped" log */
    if (ret == 0 && test_ctx->cnx_server != NULL) {
        uint8_t p[256];

        memset(p, 0, sizeof(p));
        memcpy(p + 1, test_ctx->cnx_server->path[0]->first_tuple->p_local_cnxid->cnx_id.id, test_ctx->cnx_server->path[0]->first_tuple->p_local_cnxid->cnx_id.id_len);
        p[0] |= 64;
        (void)picoquic_incoming_packet(test_ctx->qserver, p, sizeof(p), (struct sockaddr*) & test_ctx->cnx_server->path[0]->first_tuple->peer_addr,
            (struct sockaddr*) & test_ctx->cnx_server->path[0]->first_tuple->local_addr, 0, test_ctx->recv_ecn_server, simulated_time);
    }

    /* Delete the context, which will close the log file. */
    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
    }

    return ret;
}

int multipath_qlog_test(void)
{
    int ret = 0;

    (void)picoquic_file_delete(MULTIPATH_TRACE_QLOG, NULL);

    ret = multipath_trace_test_one();

    /* compare the log file to the expected value */
    if (ret == 0)
    {
        char qlog_trace_test_ref[512];

        ret = picoquic_get_input_path(qlog_trace_test_ref, sizeof(qlog_trace_test_ref),
            picoquic_solution_dir, MULTIPATH_QLOG_REF);

        if (ret != 0) {
            DBG_PRINTF("%s", "Cannot set the qlog trace test ref file name.\n");
        }
        else {
            ret = picoquic_test_compare_text_files(MULTIPATH_TRACE_QLOG, qlog_trace_test_ref);
        }
    }

    return ret;
}

int multipath_tunnel_test(void)
{
    uint64_t max_completion_microsec = 12000000;

    return multipath_test_one(max_completion_microsec, multipath_test_tunnel);
}

/* CID retire */
int multipath_cid_retire_test(void)
{
    int ret = 0;
    picoquic_cnx_t* cnx;
    picoquic_quic_t* quic;
    struct sockaddr_storage peer = { 0 };

    if (picoquic_test_set_minimal_cnx(&quic, &cnx) != 0) {
        return -1;
    }
    cnx->local_parameters.initial_max_path_id = 1;
    cnx->max_path_id_local = 2;
    cnx->max_path_id_remote = 2;
    cnx->is_multipath_enabled = 1;
    (void) picoquic_create_path(cnx, 0,
        NULL, (struct sockaddr*)&peer, 0, 1);
    if (ret == 0) {
        (void) picoquic_find_or_create_remote_cnxid_stash(cnx, 1, 1);
        (void) picoquic_remove_not_before_cid(cnx, 1, 1, 0);
    }

    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return(ret);
}

/* Verify that the CID and CID stash is freed after abandoning a path, and will not
* be recreated by a NeW CID arriving after the abandon. */
#define MULTIPATH_ABANDON_STASH_ROUNDS 100

static int multipath_abandon_stash_frame(picoquic_cnx_t* cnx, int is_abandon, uint64_t path_id, uint64_t current_time)
{
    int ret = 0;
    uint8_t frame[64];
    uint8_t* bytes = frame;
    uint8_t* bytes_max = frame + sizeof(frame);
    const uint8_t* decoded = NULL;

    if (is_abandon) {
        if ((bytes = picoquic_frames_varint_encode(bytes, bytes_max, path_id)) == NULL ||
            (bytes = picoquic_frames_varint_encode(bytes, bytes_max, 0)) == NULL) {
            ret = -1;
        }
        else {
            decoded = picoquic_decode_path_abandon_frame(frame, bytes, cnx, current_time);
        }
    }
    else if ((bytes = picoquic_frames_varint_encode(bytes, bytes_max, picoquic_frame_type_path_new_connection_id)) == NULL ||
        (bytes = picoquic_frames_varint_encode(bytes, bytes_max, path_id)) == NULL ||
        (bytes = picoquic_frames_varint_encode(bytes, bytes_max, 0)) == NULL ||
        (bytes = picoquic_frames_varint_encode(bytes, bytes_max, 0)) == NULL ||
        bytes + 1 + 8 + PICOQUIC_RESET_SECRET_SIZE > bytes_max) {
        ret = -1;
    }
    else {
        *bytes++ = 8;
        memset(bytes, 0, 8 + PICOQUIC_RESET_SECRET_SIZE);
        picoformat_64(bytes, path_id + 1);
        picoformat_64(bytes + 8, path_id + 1);
        bytes += 8 + PICOQUIC_RESET_SECRET_SIZE;
        decoded = picoquic_decode_new_connection_id_frame(cnx, frame, bytes, current_time, 1);
    }
    if (ret == 0 && (decoded != bytes || cnx->local_error != 0)) {
        DBG_PRINTF("%s on path %" PRIu64 " failed, error 0x%" PRIx64, (is_abandon) ? "Abandon" : "New CID", path_id, cnx->local_error);
        ret = -1;
    }
    return ret;
}

static void multipath_abandon_stash_config(picoquic_cnx_t* cnx)
{
    cnx->is_multipath_enabled = 1;
    cnx->local_parameters.initial_max_path_id = 2;
    cnx->max_path_id_local = 2;
    cnx->max_path_id_remote = 1000;
    /* The peer must not use null length CIDs, or PATH_NEW_CONNECTION_ID is a protocol violation. */
    cnx->path[0]->first_tuple->p_remote_cnxid->cnx_id.id_len = 8;
}

/* Create the local CID lists for the next path IDs, as when preparing a packet. */
static void multipath_abandon_stash_refill(picoquic_cnx_t* cnx, uint64_t current_time)
{
    uint8_t buffer[PICOQUIC_MAX_PACKET_SIZE];
    uint64_t next_wake_time = UINT64_MAX;
    int more_data = 0;
    int is_pure_ack = 1;

    (void)picoquic_format_new_local_id_as_needed(cnx, buffer, buffer + sizeof(buffer), current_time,
        &next_wake_time, &more_data, &is_pure_ack);
}

static uint64_t multipath_abandon_stash_count(picoquic_cnx_t* cnx)
{
    uint64_t nb_stashes = 0;

    for (picoquic_remote_cnxid_stash_t* stash = cnx->first_remote_cnxid_stash; stash != NULL; stash = stash->next_stash) {
        nb_stashes++;
    }
    return nb_stashes;
}

int multipath_abandon_stash_test(void)
{
    uint64_t simulated_time = 0;
    uint64_t nb_stashes = 0;
    picoquic_cnx_t* cnx = NULL;
    picoquic_quic_t* quic = NULL;
    int ret = picoquic_test_set_minimal_cnx_with_time(&quic, &cnx, &simulated_time);

    if (ret == 0) {
        multipath_abandon_stash_config(cnx);
    }

    /* Each round, the local CID lists are refilled and the newest unused path ID is abandoned. */
    for (int i = 0; ret == 0 && i < MULTIPATH_ABANDON_STASH_ROUNDS; i++) {
        simulated_time += 1000;
        multipath_abandon_stash_refill(cnx, simulated_time);
        ret = multipath_abandon_stash_frame(cnx, 1, cnx->next_path_id_in_lists - 1, simulated_time);
    }
    if (ret == 0 && cnx->max_path_id_local < MULTIPATH_ABANDON_STASH_ROUNDS) {
        DBG_PRINTF("Max path ID only grew to %" PRIu64, cnx->max_path_id_local);
        ret = -1;
    }
    for (uint64_t path_id = 1; ret == 0 && path_id <= cnx->max_path_id_local; path_id++) {
        ret = multipath_abandon_stash_frame(cnx, 0, path_id, simulated_time);
    }
    if (ret == 0 && (nb_stashes = multipath_abandon_stash_count(cnx)) > cnx->local_parameters.initial_max_path_id + 1) {
        DBG_PRINTF("%" PRIu64 " stashes for max path ID %" PRIu64, nb_stashes, cnx->max_path_id_local);
        ret = -1;
    }

    if (cnx != NULL) {
        picoquic_test_delete_minimal_cnx(&quic, &cnx);
    }
    return ret;
}

/* A stash created before the abandon is deleted by it, and a later new CID does not recreate it. */
int multipath_abandon_stash_reverse_test(void)
{
    uint64_t simulated_time = 0;
    uint64_t nb_stashes = 0;
    picoquic_cnx_t* cnx = NULL;
    picoquic_quic_t* quic = NULL;
    int ret = picoquic_test_set_minimal_cnx_with_time(&quic, &cnx, &simulated_time);

    if (ret == 0) {
        multipath_abandon_stash_config(cnx);
    }

    for (int i = 0; ret == 0 && i < MULTIPATH_ABANDON_STASH_ROUNDS; i++) {
        uint64_t path_id = 0;

        simulated_time += 1000;
        multipath_abandon_stash_refill(cnx, simulated_time);
        path_id = cnx->next_path_id_in_lists - 1;
        if ((ret = multipath_abandon_stash_frame(cnx, 0, path_id, simulated_time)) == 0 &&
            picoquic_find_or_create_remote_cnxid_stash(cnx, path_id, 0) == NULL) {
            DBG_PRINTF("No stash created for path %" PRIu64, path_id);
            ret = -1;
        }
        if (ret == 0 && (ret = multipath_abandon_stash_frame(cnx, 1, path_id, simulated_time)) == 0 &&
            picoquic_find_or_create_remote_cnxid_stash(cnx, path_id, 0) != NULL) {
            DBG_PRINTF("Stash of path %" PRIu64 " not deleted by the abandon", path_id);
            ret = -1;
        }
        if (ret == 0 && (ret = multipath_abandon_stash_frame(cnx, 0, path_id, simulated_time)) == 0 &&
            picoquic_find_or_create_remote_cnxid_stash(cnx, path_id, 0) != NULL) {
            DBG_PRINTF("Stash of path %" PRIu64 " recreated after the abandon", path_id);
            ret = -1;
        }
    }
    if (ret == 0 && (nb_stashes = multipath_abandon_stash_count(cnx)) > cnx->local_parameters.initial_max_path_id + 1) {
        DBG_PRINTF("%" PRIu64 " stashes for max path ID %" PRIu64, nb_stashes, cnx->max_path_id_local);
        ret = -1;
    }

    if (cnx != NULL) {
        picoquic_test_delete_minimal_cnx(&quic, &cnx);
    }
    return ret;
}

static void multipath_abandon_stash_addr(struct sockaddr_in* addr, uint16_t port)
{
    memset(addr, 0, sizeof(struct sockaddr_in));
    addr->sin_family = AF_INET;
    addr->sin_port = htons(port);
}

/* Deleting a path deletes the stash of its path ID, unless another path entry still uses that ID. */
int multipath_delete_path_stash_test(void)
{
    uint64_t simulated_time = 0;
    uint64_t path_id = 1;
    int path_index = -1;
    int twin_index = -1;
    struct sockaddr_in addr_local;
    struct sockaddr_in addr_peer;
    picoquic_cnx_t* cnx = NULL;
    picoquic_quic_t* quic = NULL;
    int ret = picoquic_test_set_minimal_cnx_with_time(&quic, &cnx, &simulated_time);

    if (ret == 0) {
        multipath_abandon_stash_config(cnx);
    }

    multipath_abandon_stash_addr(&addr_local, 1234);
    multipath_abandon_stash_addr(&addr_peer, 4321);
    if (ret == 0) {
        multipath_abandon_stash_refill(cnx, simulated_time);
        if ((path_index = picoquic_create_path(cnx, simulated_time, (struct sockaddr*)&addr_local,
            (struct sockaddr*)&addr_peer, 0, path_id)) < 0 ||
            (twin_index = picoquic_create_path(cnx, simulated_time, (struct sockaddr*)&addr_local,
            (struct sockaddr*)&addr_peer, 0, path_id)) < 0) {
            DBG_PRINTF("Cannot create two paths with ID %" PRIu64, path_id);
            ret = -1;
        }
    }
    if (ret == 0 && (ret = multipath_abandon_stash_frame(cnx, 0, path_id, simulated_time)) == 0 &&
        picoquic_find_or_create_remote_cnxid_stash(cnx, path_id, 0) == NULL) {
        DBG_PRINTF("No stash created for path %" PRIu64, path_id);
        ret = -1;
    }
    if (ret == 0) {
        picoquic_dereference_stashed_cnxid(cnx, cnx->path[twin_index], 0);
        picoquic_delete_path(cnx, twin_index);
        if (picoquic_find_or_create_remote_cnxid_stash(cnx, path_id, 0) == NULL) {
            DBG_PRINTF("Stash of path %" PRIu64 " deleted while still in use", path_id);
            ret = -1;
        }
    }
    if (ret == 0) {
        picoquic_dereference_stashed_cnxid(cnx, cnx->path[path_index], 0);
        picoquic_delete_path(cnx, path_index);
        if (picoquic_find_or_create_remote_cnxid_stash(cnx, path_id, 0) != NULL) {
            DBG_PRINTF("Stash of path %" PRIu64 " not deleted with the path", path_id);
            ret = -1;
        }
    }

    if (cnx != NULL) {
        picoquic_test_delete_minimal_cnx(&quic, &cnx);
    }
    return ret;
}

/* The ACK of MAX_PATH_ID, PATHS_BLOCKED and PATH_CID_BLOCKED must consume the whole frame.
 * If the value 25 is left, it is read as RETIRE_CONNECTION_ID, and the CID of path 0 is freed. */
#define MULTIPATH_FLOW_FRAMES_ACK_VALUE 25

int multipath_flow_frames_ack_test(void)
{
    int ret = 0;
    picoquic_cnx_t* cnx = NULL;
    picoquic_quic_t* quic = NULL;
    picoquic_packet_t* packet = NULL;
    const uint64_t frame_types[3] = { picoquic_frame_type_max_path_id,
        picoquic_frame_type_paths_blocked, picoquic_frame_type_path_cid_blocked };

    if (picoquic_test_set_minimal_cnx(&quic, &cnx) != 0) {
        ret = -1;
    }
    else if ((packet = picoquic_create_packet(quic)) == NULL) {
        ret = -1;
    }
    else {
        multipath_abandon_stash_config(cnx);
        packet->ptype = picoquic_packet_1rtt_protected;
        packet->pc = picoquic_packet_context_application;
        packet->offset = 0;
        packet->length = 32;
    }

    for (int i = 0; ret == 0 && i < 3; i++) {
        uint8_t* bytes = packet->bytes;
        uint8_t* bytes_max = packet->bytes + packet->length;
        picoquic_remote_cnxid_stash_t* stash = NULL;

        cnx->path[0]->sending_path_cid_blocked_frame = 1;
        /* The frame, then padding. PATH_CID_BLOCKED has the path ID before the value. */
        if ((bytes = picoquic_frames_varint_encode(bytes, bytes_max, frame_types[i])) == NULL ||
            (frame_types[i] == picoquic_frame_type_path_cid_blocked &&
                (bytes = picoquic_frames_varint_encode(bytes, bytes_max, 0)) == NULL) ||
            (bytes = picoquic_frames_varint_encode(bytes, bytes_max, MULTIPATH_FLOW_FRAMES_ACK_VALUE)) == NULL) {
            ret = -1;
        }
        else {
            memset(bytes, 0, bytes_max - bytes);
            picoquic_process_ack_of_frames(cnx, packet, 0);
            stash = picoquic_find_or_create_remote_cnxid_stash(cnx, 0, 0);

            if (stash == NULL || stash->cnxid_stash_first == NULL ||
                stash->cnxid_stash_first != cnx->path[0]->first_tuple->p_remote_cnxid) {
                DBG_PRINTF("ACK of frame 0x%" PRIx64 " removed the CID used by path 0", frame_types[i]);
                /* The CID was freed. Do not read it when deleting the connection */
                cnx->path[0]->first_tuple->p_remote_cnxid = NULL;
                ret = -1;
            }
            else if (frame_types[i] == picoquic_frame_type_max_path_id &&
                cnx->max_path_id_acknowledged != MULTIPATH_FLOW_FRAMES_ACK_VALUE) {
                DBG_PRINTF("Max path ID acknowledged: %" PRIu64, cnx->max_path_id_acknowledged);
                ret = -1;
            }
            else if (frame_types[i] == picoquic_frame_type_paths_blocked &&
                cnx->paths_blocked_acknowledged != MULTIPATH_FLOW_FRAMES_ACK_VALUE) {
                DBG_PRINTF("Paths blocked acknowledged: %" PRIu64, cnx->paths_blocked_acknowledged);
                ret = -1;
            }
            else if (frame_types[i] == picoquic_frame_type_path_cid_blocked &&
                cnx->path[0]->sending_path_cid_blocked_frame) {
                DBG_PRINTF("%s", "Path CID blocked frame not marked as acknowledged");
                ret = -1;
            }
        }
    }

    if (packet != NULL) {
        picoquic_recycle_packet(quic, packet);
    }
    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return ret;
}

/* A new path never gets an ID already used by another path, even when no other ID is allowed. */
int multipath_unique_path_id_test(void)
{
    uint64_t simulated_time = 0;
    uint64_t unique_path_id = 0;
    struct sockaddr_in addr_local;
    struct sockaddr_in addr_peer;
    picoquic_cnx_t* cnx = NULL;
    picoquic_quic_t* quic = NULL;
    int ret = picoquic_test_set_minimal_cnx_with_time(&quic, &cnx, &simulated_time);

    if (ret == 0) {
        multipath_abandon_stash_config(cnx);
    }

    multipath_abandon_stash_addr(&addr_local, 1234);
    multipath_abandon_stash_addr(&addr_peer, 4321);
    if (ret == 0) {
        /* Path IDs are only usable once their local CID list holds CIDs. */
        cnx->remote_parameters.active_connection_id_limit = 2;
        multipath_abandon_stash_refill(cnx, simulated_time);
        /* Path ID 1 is taken, for example by a path the peer started, and the peer allows no higher ID. */
        if (picoquic_create_path(cnx, simulated_time, (struct sockaddr*)&addr_local, (struct sockaddr*)&addr_peer, 0, 1) < 0) {
            DBG_PRINTF("%s", "Cannot create the path with ID 1");
            ret = -1;
        }
        cnx->unique_path_id_next = 1;
        cnx->max_path_id_remote = 1;
    }
    if (ret == 0 && (unique_path_id = picoquic_find_avalaible_unique_path_id(cnx, UINT64_MAX)) != UINT64_MAX) {
        DBG_PRINTF("Path ID %" PRIu64 " returned, but all allowed IDs are in use", unique_path_id);
        ret = -1;
    }
    if (ret == 0) {
        /* Once the peer allows ID 2, it is the next one. */
        cnx->max_path_id_remote = 2;
        if ((unique_path_id = picoquic_find_avalaible_unique_path_id(cnx, UINT64_MAX)) != 2 ||
            cnx->unique_path_id_next != 3) {
            DBG_PRINTF("Path ID %" PRIu64 ", next %" PRIu64 ", expected 2 and 3", unique_path_id, cnx->unique_path_id_next);
            ret = -1;
        }
    }

    if (cnx != NULL) {
        picoquic_test_delete_minimal_cnx(&quic, &cnx);
    }
    return ret;
}

/* The PATH_ACK ack delay is the time since the largest packet was received on that path. */
int multipath_ack_delay_test(void)
{
    int ret = 0;
    picoquic_cnx_t* cnx = NULL;
    picoquic_quic_t* quic = NULL;
    uint8_t bytes[256];
    uint8_t* bytes_next = NULL;
    int more_data = 0;
    uint64_t num_block = 0;
    uint64_t path_id = UINT64_MAX;
    uint64_t largest = 0;
    uint64_t ack_delay = 0;
    size_t consumed = 0;
    const uint64_t largest_time = 20000;
    const uint64_t expected_delay = 5000;

    if (picoquic_test_set_minimal_cnx(&quic, &cnx) != 0) {
        ret = -1;
    }
    else {
        cnx->is_multipath_enabled = 1;
        for (uint64_t pn = 0; ret == 0 && pn < 4; pn++) {
            ret = picoquic_record_pn_received(cnx, picoquic_packet_context_application, NULL, pn,
                (pn < 3) ? 10000 : largest_time);
        }
        if (ret == 0) {
            bytes_next = picoquic_format_ack_frame(cnx, bytes, bytes + sizeof(bytes), &more_data,
                largest_time + expected_delay, picoquic_packet_context_application, 0);
            if (bytes_next == NULL || bytes_next == bytes || bytes[0] != picoquic_frame_type_path_ack) {
                DBG_PRINTF("%s", "No PATH_ACK frame formatted");
                ret = -1;
            }
            else if (picoquic_parse_ack_header(bytes, bytes_next - bytes, &num_block, &path_id, &largest,
                &ack_delay, &consumed, cnx->local_parameters.ack_delay_exponent) != 0) {
                DBG_PRINTF("%s", "Cannot parse PATH_ACK frame");
                ret = -1;
            }
            else if (path_id != 0 || largest != 3 || ack_delay != expected_delay) {
                DBG_PRINTF("PATH_ACK path %" PRIu64 ", largest %" PRIu64 ", ack delay %" PRIu64 ", expected 0, 3, %" PRIu64,
                    path_id, largest, ack_delay, expected_delay);
                ret = -1;
            }
        }
        picoquic_test_delete_minimal_cnx(&quic, &cnx);
    }
    return ret;
}

/* A path is stalled if the peer is active but our oldest unacknowledged packet is older than 2 RTT plus ack delay.
 * When pure ACKs are ignored, only an old ack-eliciting packet makes the path stalled. */
int multipath_ack_path_stalled_test(void)
{
    int ret = 0;
    uint64_t simulated_time = 1000000;
    picoquic_cnx_t* cnx = NULL;
    picoquic_quic_t* quic = NULL;
    picoquic_packet_t* oldest = (picoquic_packet_t*)calloc(1, sizeof(picoquic_packet_t));

    if (oldest == NULL || picoquic_test_set_minimal_cnx_with_time(&quic, &cnx, &simulated_time) != 0) {
        ret = -1;
    }
    else {
        picoquic_path_t* path_x = cnx->path[0];
        uint64_t delay;
        struct {
            uint64_t sent_ago;
            uint64_t received_ago;
            int has_pending;
            int is_ack_eliciting;
            int ignore_pure_ack;
            int expected;
        } cases[] = { { 0, 0, 0, 0, 0, 0 }, { 60000, 5000, 1, 0, 0, 0 }, { 70000, 5000, 1, 0, 0, 1 }, { 70000, 30000, 1, 0, 0, 0 },
            { 70000, 5000, 1, 0, 1, 0 }, { 70000, 5000, 1, 1, 1, 1 } };

        cnx->is_multipath_enabled = 1;
        path_x->smoothed_rtt = 20000;
        cnx->remote_parameters.max_ack_delay = 25000;
        delay = 2 * path_x->smoothed_rtt + cnx->remote_parameters.max_ack_delay;
        for (size_t i = 0; ret == 0 && i < sizeof(cases) / sizeof(cases[0]); i++) {
            int stalled;
            oldest->send_time = simulated_time - cases[i].sent_ago;
            oldest->is_evaluated = 1;
            oldest->is_ack_eliciting = cases[i].is_ack_eliciting;
            path_x->pkt_ctx.pending_first = (cases[i].has_pending) ? oldest : NULL;
            cnx->latest_receive_time = simulated_time - cases[i].received_ago;
            stalled = picoquic_is_ack_path_stalled(cnx, path_x, simulated_time, cases[i].ignore_pure_ack);
            if (stalled != cases[i].expected) {
                DBG_PRINTF("Case %zu: stalled %d, expected %d (threshold %" PRIu64 ")", i, stalled, cases[i].expected, delay);
                ret = -1;
            }
        }
        path_x->pkt_ctx.pending_first = NULL;
        picoquic_test_delete_minimal_cnx(&quic, &cnx);
    }
    if (oldest != NULL) {
        free(oldest);
    }
    return ret;
}

static int multipath_nominal_ack_path_index(picoquic_cnx_t* cnx, uint64_t current_time, picoquic_path_t** next_path)
{
    int nominal = -1;
    uint64_t next_wake_time = UINT64_MAX;
    picoquic_tuple_t* next_tuple = NULL;

    picoquic_select_next_path_tuple(cnx, current_time, &next_wake_time, next_path, &next_tuple);
    for (int i = 0; i < cnx->nb_paths; i++) {
        if (cnx->path[i]->is_nominal_ack_path) {
            nominal = i;
        }
    }
    return nominal;
}

/* The nominal ack path is sticky: it only changes if it stalls, or if a healthy path has a clearly lower RTT.
 * If the only available path stalls with an ack-eliciting packet, ACKs go on a healthy backup path, which stays backup. */
int multipath_nominal_ack_path_test(void)
{
    int ret = 0;
    uint64_t simulated_time = 1000000;
    picoquic_cnx_t* cnx = NULL;
    picoquic_quic_t* quic = NULL;
    struct sockaddr_storage peer = { 0 };
    picoquic_packet_t* oldest = (picoquic_packet_t*)calloc(1, sizeof(picoquic_packet_t));

    if (oldest == NULL || picoquic_test_set_minimal_cnx_with_time(&quic, &cnx, &simulated_time) != 0) {
        ret = -1;
    }
    else {
        picoquic_path_t* next_path = NULL;
        int nominal;

        cnx->is_multipath_enabled = 1;
        cnx->cnx_state = picoquic_state_ready;
        cnx->remote_parameters.max_ack_delay = 25000;
        cnx->latest_receive_time = simulated_time;
        if (picoquic_create_path(cnx, simulated_time, NULL, (struct sockaddr*)&peer, 0, 1) < 0 || cnx->nb_paths != 2) {
            DBG_PRINTF("%s", "Cannot create the second path");
            ret = -1;
        }
        for (int i = 0; ret == 0 && i < 2; i++) {
            cnx->path[i]->first_tuple->challenge_verified = 1;
            cnx->path[i]->first_tuple->challenge_required = 0;
            cnx->path[i]->smoothed_rtt = 20000;
            cnx->path[i]->rtt_min = 20000;
        }
        if (ret == 0) {
            /* Lowest rtt_min wins at first */
            cnx->path[1]->rtt_min = 21000;
            if ((nominal = multipath_nominal_ack_path_index(cnx, simulated_time, &next_path)) != 0) {
                DBG_PRINTF("Initial nominal path %d, expected 0", nominal);
                ret = -1;
            }
        }
        if (ret == 0) {
            /* A slightly lower RTT does not move the nominal path */
            cnx->path[1]->rtt_min = 19000;
            if ((nominal = multipath_nominal_ack_path_index(cnx, simulated_time, &next_path)) != 0) {
                DBG_PRINTF("Nominal path %d after small RTT change, expected 0", nominal);
                ret = -1;
            }
        }
        if (ret == 0) {
            /* A clearly lower RTT does */
            cnx->path[1]->rtt_min = 15000;
            if ((nominal = multipath_nominal_ack_path_index(cnx, simulated_time, &next_path)) != 1) {
                DBG_PRINTF("Nominal path %d after large RTT change, expected 1", nominal);
                ret = -1;
            }
        }
        if (ret == 0) {
            /* A stalled path is abandoned */
            oldest->send_time = simulated_time - 100000;
            oldest->is_evaluated = 1;
            oldest->is_ack_eliciting = 1;
            cnx->path[1]->pkt_ctx.pending_first = oldest;
            nominal = multipath_nominal_ack_path_index(cnx, simulated_time, &next_path);
            cnx->path[1]->pkt_ctx.pending_first = NULL;
            if (nominal != 0) {
                DBG_PRINTF("Nominal path %d after stall of path 1, expected 0", nominal);
                ret = -1;
            }
        }
        if (ret == 0) {
            /* Only path 0 is available, and only an old pure ACK is pending: ACKs stay on path 0 */
            cnx->path[1]->path_is_backup = 1;
            oldest->is_evaluated = 1;
            oldest->is_ack_eliciting = 0;
            cnx->path[0]->pkt_ctx.pending_first = oldest;
            picoquic_set_ack_needed(cnx, simulated_time, picoquic_packet_context_application, cnx->path[0], 1);
            nominal = multipath_nominal_ack_path_index(cnx, simulated_time, &next_path);
            cnx->path[0]->pkt_ctx.pending_first = NULL;
            if (nominal != 0 || next_path != cnx->path[0]) {
                DBG_PRINTF("Pure ACK pending on path 0: nominal %d, selected path %d, expected 0, 0", nominal,
                    (next_path == cnx->path[1]) ? 1 : 0);
                ret = -1;
            }
        }
        if (ret == 0) {
            /* Only path 0 is available and it stalls: the ACK goes on backup path 1, which remains backup */
            oldest->is_ack_eliciting = 1;
            cnx->path[0]->pkt_ctx.pending_first = oldest;
            picoquic_set_ack_needed(cnx, simulated_time, picoquic_packet_context_application, cnx->path[0], 1);
            nominal = multipath_nominal_ack_path_index(cnx, simulated_time, &next_path);
            cnx->path[0]->pkt_ctx.pending_first = NULL;
            if (nominal != 1 || next_path != cnx->path[1] || !cnx->path[1]->path_is_backup) {
                DBG_PRINTF("Stalled path 0: nominal %d, selected path %d, backup %d, expected 1, 1, 1", nominal,
                    (next_path == cnx->path[1]) ? 1 : 0, cnx->path[1]->path_is_backup);
                ret = -1;
            }
        }
        picoquic_test_delete_minimal_cnx(&quic, &cnx);
    }
    if (oldest != NULL) {
        free(oldest);
    }
    return ret;
}

/* The smoothed RTT must keep updating when the first sample came before any packet on the path was acknowledged,
 * as happens for the handshake on path 0 or the challenge on a new path. */
int multipath_srtt_update_test(void)
{
    int ret = 0;
    uint64_t simulated_time = 1000000;
    picoquic_cnx_t* cnx = NULL;
    picoquic_quic_t* quic = NULL;

    if (picoquic_test_set_minimal_cnx_with_time(&quic, &cnx, &simulated_time) != 0) {
        ret = -1;
    }
    else {
        picoquic_path_t* path_x = cnx->path[0];
        uint64_t initial_srtt;

        cnx->is_multipath_enabled = 1;
        cnx->cnx_state = picoquic_state_ready;
        /* First sample from the challenge, before any acknowledgement on the path */
        path_x->pkt_ctx.highest_acknowledged = UINT64_MAX;
        picoquic_update_path_rtt(cnx, path_x, -1, simulated_time - 600000, simulated_time, 0, 0);
        initial_srtt = path_x->smoothed_rtt;
        /* Then acknowledged samples of 300 ms, spaced by more than RTT/4 */
        for (uint64_t pn = 1; pn <= 4; pn++) {
            simulated_time += 200000;
            path_x->pkt_ctx.highest_acknowledged = pn;
            picoquic_update_path_rtt(cnx, path_x, picoquic_epoch_1rtt, simulated_time - 300000, simulated_time, 0, 0);
        }
        if (initial_srtt != 600000 || path_x->smoothed_rtt >= initial_srtt) {
            DBG_PRINTF("Smoothed RTT %" PRIu64 " after samples of 300 ms, initial %" PRIu64,
                path_x->smoothed_rtt, initial_srtt);
            ret = -1;
        }
        picoquic_test_delete_minimal_cnx(&quic, &cnx);
    }
    return ret;
}

/* CID rotation after idle periods, with two paths. After each idle period, the client
 * rotates its CIDs, and the server renews its own CID for each path, retiring the old one.
 * Path 0 becomes much slower just after the idle period, as a radio waking up would, so the
 * server's RTT estimate is stale: it declares path 0 packets lost too early and repeats
 * their frames on path 1. The retirement can then reach the client before packets sent
 * with the old CID on path 0. The client must not answer them with stateless resets. */
#define MULTIPATH_IDLE_ROTATION_CYCLES 6

static int multipath_idle_rotation_wait_stream(picoquic_test_tls_api_ctx_t* test_ctx, uint64_t* simulated_time, size_t stream_index)
{
    int ret = 0;
    int was_active = 0;
    int nb_trials = 0;
    uint64_t time_out = *simulated_time + 10000000;

    while (ret == 0 && test_ctx->test_stream[stream_index].r_received == 0 &&
        test_ctx->cnx_client->cnx_state == picoquic_state_ready && test_ctx->cnx_server->cnx_state == picoquic_state_ready) {
        if (++nb_trials > 100000 || *simulated_time > time_out) {
            DBG_PRINTF("Stream %zu not completed at time %" PRIu64, stream_index, *simulated_time);
            ret = -1;
        }
        else {
            ret = tls_api_one_sim_round(test_ctx, simulated_time, time_out, &was_active);
        }
    }
    return ret;
}

#define MULTIPATH_IDLE_ROTATION_LATENCY 10000

static void multipath_idle_rotation_set_latency_0(picoquic_test_tls_api_ctx_t* test_ctx, uint64_t latency)
{
    test_ctx->c_to_s_link->microsec_latency = latency;
    test_ctx->s_to_c_link->microsec_latency = latency;
}

static int multipath_idle_rotation_test_one(uint8_t test_id, uint64_t wake_latency_0, size_t q_len, size_t r_len)
{
    uint64_t simulated_time = 0;
    uint64_t loss_mask = 0;
    picoquic_test_tls_api_ctx_t* test_ctx = NULL;
    picoquic_connection_id_t initial_cid = { {0x1b, 0x11, 0x1d, 0x1e, test_id, 6, 7, 8}, 8 };
    picoquic_tp_t server_parameters;
    test_api_stream_desc_t test_scenario_multipath_idle_rotation[MULTIPATH_IDLE_ROTATION_CYCLES];
    int ret = tls_api_init_ctx_ex2(&test_ctx, PICOQUIC_INTERNAL_TEST_VERSION_1,
        PICOQUIC_TEST_SNI, PICOQUIC_TEST_ALPN, &simulated_time, NULL, NULL, 0, 1, 0, &initial_cid,
        8, 0, 0, 0);

    /* One stream per cycle; streams after the first are only started by the test, after an idle period. */
    for (size_t i = 0; i < MULTIPATH_IDLE_ROTATION_CYCLES; i++) {
        test_scenario_multipath_idle_rotation[i].stream_id = 4 * (i + 1);
        test_scenario_multipath_idle_rotation[i].previous_stream_id = (i == 0) ? 0 : 10000 + i;
        test_scenario_multipath_idle_rotation[i].q_len = q_len;
        test_scenario_multipath_idle_rotation[i].r_len = r_len;
    }

    if (ret == 0 && test_ctx == NULL) {
        ret = -1;
    }
    if (ret == 0) {
        /* Path 1 (created later) keeps the default 10 ms latency. */
        multipath_idle_rotation_set_latency_0(test_ctx, MULTIPATH_IDLE_ROTATION_LATENCY);
        picoquic_set_qlog(test_ctx->qserver, ".");
        picoquic_set_qlog(test_ctx->qclient, ".");
        multipath_init_params(&server_parameters, 0);
        picoquic_set_default_tp(test_ctx->qserver, &server_parameters);
        test_ctx->cnx_client->local_parameters.initial_max_path_id = 3;
        picoquic_start_client_cnx(test_ctx->cnx_client);
        ret = tls_api_connection_loop(test_ctx, &loss_mask, 2 * test_ctx->s_to_c_link->microsec_latency, &simulated_time);
    }
    if (ret == 0 && (!test_ctx->cnx_client->is_multipath_enabled || !test_ctx->cnx_server->is_multipath_enabled)) {
        DBG_PRINTF("%s", "Multipath not negotiated");
        ret = -1;
    }
    if (ret == 0) {
        ret = wait_client_connection_ready(test_ctx, &simulated_time);
    }
    if (ret == 0) {
        ret = test_api_init_send_recv_scenario(test_ctx, test_scenario_multipath_idle_rotation, sizeof(test_scenario_multipath_idle_rotation));
    }
    if (ret == 0 && (ret = multipath_test_add_links(test_ctx, 0)) == 0) {
        ret = picoquic_probe_new_path(test_ctx->cnx_client, (struct sockaddr*)&test_ctx->server_addr,
            (struct sockaddr*)&test_ctx->client_addr_2, simulated_time);
    }
    if (ret == 0) {
        ret = wait_multipath_ready(test_ctx, &simulated_time);
    }

    /* Each cycle: complete the exchange, stay idle long enough to trigger the CID rotation, start the next one. */
    for (size_t i = 0; ret == 0 && i < MULTIPATH_IDLE_ROTATION_CYCLES; i++) {
        if (i > 0) {
            /* Path 0 is slow just after the idle period. */
            multipath_idle_rotation_set_latency_0(test_ctx, wake_latency_0);
            ret = test_api_queue_initial_queries(test_ctx, 10000 + i);
        }
        if (ret == 0) {
            ret = multipath_idle_rotation_wait_stream(test_ctx, &simulated_time, i);
        }
        multipath_idle_rotation_set_latency_0(test_ctx, MULTIPATH_IDLE_ROTATION_LATENCY);
        if (ret == 0 && i + 1 < MULTIPATH_IDLE_ROTATION_CYCLES) {
            ret = tls_api_wait_for_timeout(test_ctx, &simulated_time, 11000000);
        }
        if (ret == 0 && (test_ctx->reset_received || test_ctx->cnx_server->cnx_state != picoquic_state_ready ||
            test_ctx->cnx_client->cnx_state != picoquic_state_ready)) {
            DBG_PRINTF("Cycle %zu: reset received %d, client state %d, server state %d", i, test_ctx->reset_received,
                test_ctx->cnx_client->cnx_state, test_ctx->cnx_server->cnx_state);
            ret = -1;
        }
    }

    if (test_ctx != NULL) {
        tls_api_delete_ctx(test_ctx);
    }
    return ret;
}

int multipath_idle_rotation_test(void)
{
    /* Path 0 goes from 10 ms to 160 ms after each idle period: server sends the data, then client sends the data. */
    int ret = multipath_idle_rotation_test_one(0, 160000, 257, 100000);

    if (ret == 0) {
        ret = multipath_idle_rotation_test_one(1, 160000, 100000, 257);
    }
    return ret;
}

/*
 * TODO: Unit test of path selection.
 * The input to path selections include the state of the path,
 * the status set by the peer, the presence of losses, etc.
 * Each test set up a connection context and two path contexts,
 * with stated values for the key variables, then verify that
 * the path selection is as expected.
 * 
 * Key values include:
 * cnx->path[i]->status_set_by_peer
 * cnx->path[i]->path_is_demoted
 * cnx->path[i]->first_tuple->challenge_failed (leads to demotion)
 * cnx->path[i]->first_tuple->response_required (set challenge path)
 * cnx->path[i]->first_tuple->challenge_verified (and next challenge time)
 * cnx->path[i]->challenge_repeat_count
 * cnx->path[i]->nb_retransmit
 * cnx->path[i]->rtt_min
 * picoquic_is_sending_authorized_by_pacing
 * affinity path for the next stream, or is_datagram_ready per path/cnx
 * cnx->path[i]->bytes_in_transit < cnx->path[i]->cwin, cnx->quic->cwin_max
 * then the selection:
 * 1) challenge path;
 * 2) if is_ack_needed, min rtt path for ACK
 * 3) affinity_path, if cwin_ok
 * 4) data path, if cwin ok
 * 5) data path with pacing OK
 * 6) path 0, after setting the timers.
 * 
 * TODO: break that into parts that can be verified!
 */
