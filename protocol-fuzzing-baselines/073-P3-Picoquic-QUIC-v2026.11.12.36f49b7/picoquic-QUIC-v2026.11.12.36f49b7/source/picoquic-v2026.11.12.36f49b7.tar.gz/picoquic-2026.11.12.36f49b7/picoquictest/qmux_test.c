/*
* Author: Christian Huitema
* Copyright (c) 2026, Private Octopus, Inc.
* All rights reserved.
*
* Permission to use, copy, modify, and distribute this software for any
* purpose with or without fee is hereby granted, provided that the above
* copyright notice and this permission notice appear in all copies.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL Private Octopus, Inc. BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
* Testing the implementation of Qmux in picoquic.
*
* - test of the send function. Verify that QMUX can format a packet.
* - test of the receive function. Test that QMUX can parse the frames in a packet.
* - raw connection. Verify that the server can create a QMUX connection.
* - back-to-back test. Do a qmux loop with pack to back sender/receiver. Try an end to end scenario.
* - back-to-back with TLS.
* - back-to-back with simulated network connection.
*
* The final step would of course be to implement a TCP extension to the socket loop.
*/


#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>
#include "picoquic.h"
#include "picoquic_utils.h"
#include "picoquictest_internal.h"
#include "picoquic_qlog.h"
#include "picoquic_packet_loop.h"
#include "picosocks.h"
#include "picoqmux.h"

/*
* Network simulation tests.
* The simulations have to use an interface between the picoquic stack and the
* network. This is logically split between:
* - socket loop functions that wait for new TCP and new TCP data
*   or permission to send.
* - Qmux function that accumulate a segment of data per connection.
* We assume that the Qmux function are implemented as a Qmux extension to the
* picoquic_quic_t context. We need functions to:
* - create a Qmux context: extension of picoquic_quic_t with new API.
* - create a Qmux connection: chained to the Qmux context, create a
*   tcp socket through an asynchronous call to the socket loop.
* - receive data from a socket.
* - request permission to write on a socket.
* - get polled for writing on the socket if data is granted.
* - ask the socket loop to close a socket.
* - get notified that a socket is closed.
*/

typedef  struct st_qmux_msg_t {
    uint8_t* buffer;
    size_t buffer_size;
    size_t length;
    int target_index;
    uint64_t delivery_time;
    struct st_qmux_msg_t* next;
} qmux_msg_t;

typedef struct st_qmux_sim_ctx_t {
    uint64_t simulated_time;
    int is_cleartext;
    int test_idle;
    int test_close;
    int should_close_tcp;
    uint64_t idle_timeout;
    picoquic_quic_t* quic[2];
    picoquic_cnx_t* cnx[2];
    qmux_msg_t* msg_queue;
    qmux_msg_t* msg_last;
    /* scenario handling */
    int received_stream_0;
    size_t stream_0_length_received;
    int stream0_fin_received;
    int stream0_data_matches;
    int test_datagram;
    int datagram_received;
    size_t datagram_length;
    int datagram_data_matches;
} qmux_sim_ctx_t;

typedef struct st_qmux_sim_spec_t {
    int test_idle;
    int is_cleartext;
    int test_close;
    uint64_t idle_timeout;
    uint64_t expected_time;
} qmux_sim_spec_t;

#define QMUX_FIRST_DATA 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F
uint8_t qmux_test_data[] = { QMUX_FIRST_DATA };
uint8_t qmux_test_packet[] = { 0x12, 0x0b, 0x0, 0x0f, QMUX_FIRST_DATA };
uint8_t qmux_test_packet_l2[] = { 0x40, 0x12, 0x0b, 0x0, 0x0f, QMUX_FIRST_DATA };
uint8_t qmux_test_packet_x2[] = { 0x03, 0, 0, 0, 0x12, 0x0b, 0x0, 0x0f, QMUX_FIRST_DATA };

void qmux_test_simulate_remote(picoquic_cnx_t* cnx) {
    cnx->remote_parameters.initial_max_data = 0x10000;
    cnx->maxdata_remote = cnx->remote_parameters.initial_max_data;
    cnx->remote_parameters.initial_max_stream_data_bidi_local = 0x10000;
    cnx->remote_parameters.initial_max_stream_data_bidi_remote = 0x10000;
    cnx->remote_parameters.initial_max_streams_bidi = 100;
    cnx->remote_parameters.initial_max_streams_uni = 100;
    cnx->max_streams_bidir_local = cnx->local_parameters.initial_max_streams_bidi;
    cnx->max_streams_bidir_remote = cnx->remote_parameters.initial_max_streams_bidi;
    cnx->max_streams_unidir_local = cnx->local_parameters.initial_max_streams_uni;
    cnx->max_streams_unidir_remote = cnx->remote_parameters.initial_max_streams_uni;
}

int qmux_send_test(void)
{
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    uint8_t buffer[1536];
    size_t send_length = 0;
    int ret = picoquic_test_set_minimal_cnx(&quic, &cnx);

    picoqmux_init(cnx, 1);

    if (ret == 0) {
        /* simulate that TP has been sent and received. */
        picoqmux_update_state_on_tp_sent(cnx);
        picoqmux_update_state_on_tp_received(cnx);
        /* simulate flow control open. */
        qmux_test_simulate_remote(cnx);
        /* add test data to stream zero. */
        ret = picoquic_add_to_stream(cnx, 0, qmux_test_data, sizeof(qmux_test_data), 1);
    }
    if (ret == 0) {
        /* prepare the packet */
        ret = picoqmux_prepare_cnx_packets(cnx, 0, buffer, sizeof(buffer), &send_length);

        if (send_length != sizeof(qmux_test_packet) ||
            memcmp(buffer, qmux_test_packet, send_length) != 0) {
            ret = -1;
        }
    }
    picoquic_test_delete_minimal_cnx(&quic, &cnx);

    return ret;
}

/* ALPN list function -- need to set one? */

int qmux_test_callback(picoquic_cnx_t* cnx,
    uint64_t stream_id, uint8_t* bytes, size_t length,
    picoquic_call_back_event_t fin_or_event, void* callback_ctx, void* UNUSED(v_stream_ctx))
{

    int ret = 0;
    qmux_sim_ctx_t* sim_ctx = (qmux_sim_ctx_t*)callback_ctx;

    if (ret == 0) {
        switch (fin_or_event) {
        case picoquic_callback_stream_data:
        case picoquic_callback_stream_fin:
            if (stream_id == 0) {
                sim_ctx->received_stream_0 = 1;
                sim_ctx->stream_0_length_received = length;
                if (length == sizeof(qmux_test_data) &&
                    memcmp(bytes, qmux_test_data, length) == 0) {
                    sim_ctx->stream0_data_matches = 1;
                }
                if (fin_or_event == picoquic_callback_stream_fin) {
                    sim_ctx->stream0_fin_received = 1;
                    if (sim_ctx->test_close) {
                        sim_ctx->should_close_tcp = 1;
                        picoquic_connection_disconnect(cnx);
                    }
                    else if (!sim_ctx->test_idle) {
                        picoquic_close_ex(cnx, 0, "data received.");
                    }
                }
            }
            break;
        case picoquic_callback_datagram:
            if (sim_ctx->test_datagram) {
                sim_ctx->datagram_received = 1;
                sim_ctx->datagram_length = length;
                sim_ctx->datagram_data_matches = (length == sizeof(qmux_test_data) &&
                    memcmp(bytes, qmux_test_data, length) == 0);
            }
            else {
                ret = -1;
            }
            break;
        case picoquic_callback_prepare_to_send:
        case picoquic_callback_prepare_datagram:
            /* not expected */
            ret = -1;
            break;
        case picoquic_callback_stream_reset: /* Client reset stream #x */
        case picoquic_callback_stop_sending: /* Client asks server to reset stream #x */
            /* TODO: react to abandon stream, etc. */
            break;
        case picoquic_callback_stateless_reset: /* Received an error message */
        case picoquic_callback_close: /* Received connection close */
        case picoquic_callback_application_close: /* Received application close */
            /* Remove the connection from the context, and then delete it */
            picoquic_set_callback(cnx, NULL, NULL);
            break;
        case picoquic_callback_version_negotiation:
            /* The server should never receive a version negotiation response */
            break;
        case picoquic_callback_almost_ready:
            break;
        case picoquic_callback_ready:
            /* should mark the first stream as ready, create it if necessary */
            if (cnx->client_mode) {
                picoquic_add_to_stream(cnx, 0, qmux_test_data, sizeof(qmux_test_data), 1);
            }
            break;
        case picoquic_callback_request_alpn_list:
            /* qmux_test_set_alpn_list((void*)bytes); */
            break;
        case picoquic_callback_set_alpn:
            break;
        case picoquic_callback_datagram_acked:
            /* Ack for packet carrying datagram-object received from peer */
        case picoquic_callback_datagram_lost:
            /* Packet carrying datagram-object probably lost */
        case picoquic_callback_datagram_spurious:
            /* Packet carrying datagram-object was not really lost */
            break;
        case picoquic_callback_pacing_changed:
            /* Notification of rate change from congestion controller */
            break;
        default:
            /* unexpected */
            break;
        }
    }

    return ret;
}

uint8_t qmux_test_tp_packet[] = {
    0x30, 0xff, 0x51, 0x53, 0x30, 0x0d, 0x0a, 0x0d, 0x0a,
    0x40, 0x26, 0x05, 0x04, 0x80, 0x20, 0x00, 0x00,
    0x04, 0x04, 0x80, 0x10, 0x00, 0x00, 0x08, 0x02,
    0x42, 0x00, 0x01, 0x04, 0x80, 0x00, 0x75, 0x30,
    0x09, 0x02, 0x42, 0x00, 0x06, 0x04, 0x80, 0x01,
    0x00, 0x63, 0x07, 0x04, 0x80, 0x00, 0xff, 0xff };

static size_t qmux_format_tp_test_packet(uint8_t* buffer, size_t buffer_size,
    uint64_t tp_type, const uint8_t* tp_value, size_t tp_value_length)
{
    uint8_t* bytes = buffer + 1;
    uint8_t* tp_length = NULL;
    uint8_t* tp_start = NULL;

    if (buffer_size < 2 ||
        (bytes = picoquic_frames_varint_encode(bytes, buffer + buffer_size, FRAME_TYPE_QX_TRANSPORT_PARAMETERS)) == NULL ||
        bytes >= buffer + buffer_size) {
        return 0;
    }

    tp_length = bytes++;
    tp_start = bytes;
    if ((bytes = picoquic_frames_varint_encode(bytes, buffer + buffer_size, tp_type)) == NULL ||
        (bytes = picoquic_frames_varint_encode(bytes, buffer + buffer_size, tp_value_length)) == NULL ||
        bytes + tp_value_length > buffer + buffer_size ||
        bytes - tp_start >= 64 ||
        bytes + tp_value_length - buffer - 1 >= 64) {
        return 0;
    }

    if (tp_value_length > 0) {
        memcpy(bytes, tp_value, tp_value_length);
    }
    bytes += tp_value_length;
    buffer[0] = (uint8_t)(bytes - buffer - 1);
    *tp_length = (uint8_t)(bytes - tp_start);
    return (size_t)(bytes - buffer);
}

static size_t qmux_format_frame_record(uint8_t* buffer, size_t buffer_size,
    const uint8_t* frame, size_t frame_length)
{
    uint8_t* bytes = picoquic_frames_varint_encode(buffer, buffer + buffer_size, frame_length);

    if (bytes == NULL || bytes + frame_length > buffer + buffer_size) {
        return 0;
    }
    memcpy(bytes, frame, frame_length);
    return (size_t)(bytes + frame_length - buffer);
}



int qmux_send_tp_test(void)
{
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    uint8_t buffer[2048];
    size_t send_length = 0;
    int ret = picoquic_test_set_minimal_cnx(&quic, &cnx);
    picoqmux_init(cnx, 1);

    if (ret == 0) {
        /* prepare the packet */
        ret = picoqmux_prepare_cnx_packets(cnx, 0, buffer, sizeof(buffer), &send_length);

        if (send_length != sizeof(qmux_test_tp_packet) ||
            memcmp(buffer, qmux_test_tp_packet, send_length) != 0) {
            ret = -1;
        }
    }

    if (ret == 0 && cnx->cnx_state != picoquic_state_client_ready_start) {
        ret = -1;
    }
    picoquic_test_delete_minimal_cnx(&quic, &cnx);

    return ret;
}

typedef int (*qmux_test_check_fn)(picoquic_cnx_t* cnx, uint64_t expected_error);

int qmux_receive_test_one(int client_mode, int is_tp_received, int is_tp_sent,
    uint8_t* msg, size_t length, uint64_t expected, qmux_test_check_fn post_check_fn)
{
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    qmux_sim_ctx_t qtc = { 0 };
    int ret = picoquic_test_set_minimal_cnx(&quic, &cnx);

    cnx->client_mode = client_mode; /* as required for the test */
    picoqmux_init(cnx, 1);
    if (is_tp_received) {
        picoqmux_update_state_on_tp_received(cnx); /* simulate that TP has been received. */
    }
    if (is_tp_sent) {
        picoqmux_update_state_on_tp_sent(cnx); /* simulate that TP has been sent. */
    }

    picoquic_set_callback(cnx, qmux_test_callback, &qtc);
    if (ret == 0) {
        /* process a packet */
#if 0
        int ret = picoqmux_incoming_cnx_bytes(cnx, 12345, msg, length);
#else
        int r_ret = picoqmux_incoming_cnx_packet(cnx, 12345, msg, length);
#endif

        if (r_ret == 0) {
            if (expected != 0) {
                ret = -1;
            }
        }
        else if (expected == 0) {
            ret = -1;
        }

        if (ret == 0 && post_check_fn != NULL) {
            ret = post_check_fn(cnx, expected);
        }
    }
    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return ret;
}

int qmux_receive_tp_check(picoquic_cnx_t* cnx, uint64_t UNUSED(expected))
{
    int ret = 0;

    qmux_sim_ctx_t* qtc = (qmux_sim_ctx_t*)picoquic_get_callback_context(cnx);

    if (qtc == NULL || !(
        qtc->received_stream_0 &&
        qtc->stream_0_length_received == sizeof(qmux_test_data) &&
        qtc->stream0_fin_received &&
        qtc->stream0_data_matches)) {
        ret = -1;
    }
    return ret;
}

int qmux_receive_test(void)
{
    int ret = qmux_receive_test_one(0, 1, 0, qmux_test_packet, sizeof(qmux_test_packet),
        0, qmux_receive_tp_check);

    return ret;
}

int qmux_receive_no_error_check(picoquic_cnx_t* cnx, uint64_t UNUSED(expected))
{
    return (cnx->local_error == 0 &&
        cnx->cnx_state != picoquic_state_disconnecting &&
        cnx->cnx_state != picoquic_state_handshake_failure) ? 0 : -1;
}

int qmux_receive_tp_test_check(picoquic_cnx_t* cnx, uint64_t UNUSED(expected))
{
    int ret = 0;
    if (cnx->cnx_state != picoquic_state_server_false_start) {
        ret = -1;
    }
    return ret;
}

int qmux_receive_tp_test(void)
{
    int ret = qmux_receive_test_one(0, 0, 0, qmux_test_tp_packet, sizeof(qmux_test_tp_packet),
        0, qmux_receive_tp_test_check);

    return ret;
}

uint8_t qmux_qx_ping_packet[] = {
    0x09, 0xF4, 0x8c, 0x67, 0x52, 0x9e, 0xf8, 0xc7, 0xbd, 0
};

uint8_t qmux_qx_ping_r_packet[] = {
    0x09, 0xF4, 0x8c, 0x67, 0x52, 0x9e, 0xf8, 0xc7, 0xbe, 0
};

int qmux_receive_error_one(int set_tp_received, int set_tp_sent,
    uint8_t* message, size_t length, uint64_t expected);

int qmux_receive_qx_ping_test_check(picoquic_cnx_t* cnx, uint64_t UNUSED(expected))
{
    int ret = 0;
    if (cnx->cnx_state != picoquic_state_ready ||
        cnx->qx_query_ack != UINT64_MAX ||
        cnx->qx_query_last != 0) {
        ret = -1;
    }
    return ret;
}

int qmux_receive_qx_ping_test(void)
{
    int ret = qmux_receive_test_one(0, 1, 1, qmux_qx_ping_packet, sizeof(qmux_qx_ping_packet),
        0, qmux_receive_qx_ping_test_check);

    return ret;
}

static void qmux_format_double_qx_ping(uint8_t* packet, uint8_t second_sequence)
{
    size_t frame_length = sizeof(qmux_qx_ping_packet) - 1;

    packet[0] = (uint8_t)(2 * frame_length);
    memcpy(packet + 1, qmux_qx_ping_packet + 1, frame_length);
    memcpy(packet + 1 + frame_length, qmux_qx_ping_packet + 1, frame_length);
    packet[2 * frame_length] = second_sequence;
}

int qmux_receive_qx_ping_order_test(void)
{
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    uint8_t packet[32];
    uint8_t expected_response[sizeof(qmux_qx_ping_r_packet)];
    uint8_t buffer[2048];
    size_t send_length = 0;
    int ret = picoquic_test_set_minimal_cnx(&quic, &cnx);

    picoqmux_init(cnx, 1);
    picoqmux_update_state_on_tp_sent(cnx);
    picoqmux_update_state_on_tp_received(cnx);
    qmux_format_double_qx_ping(packet, 1);

    if (ret == 0) {
        ret = picoqmux_incoming_cnx_packet(cnx, 12345, packet, 1 + 2 * (sizeof(qmux_qx_ping_packet) - 1));
    }
    if (ret == 0) {
        memcpy(expected_response, qmux_qx_ping_r_packet, sizeof(expected_response));
        expected_response[sizeof(expected_response) - 1] = 1;
        ret = picoqmux_prepare_cnx_packets(cnx, 0, buffer, sizeof(buffer), &send_length);
        if (send_length != sizeof(expected_response) ||
            memcmp(buffer, expected_response, send_length) != 0 ||
            cnx->qx_query_last != 1 ||
            cnx->qx_query_ack != 1) {
            ret = -1;
        }
    }

    picoquic_test_delete_minimal_cnx(&quic, &cnx);

    if (ret == 0) {
        qmux_format_double_qx_ping(packet, 0);
        ret = qmux_receive_error_one(1, 1, packet, 1 + 2 * (sizeof(qmux_qx_ping_packet) - 1),
            PICOQUIC_TRANSPORT_PROTOCOL_VIOLATION);
    }
    return ret;
}


/* tests of closing frame */

uint8_t qmux_cnx_close_packet[] = {
    0x10,
    picoquic_frame_type_connection_close,
    0x80, 0x00, 0xCF, 0xFF, 0,
    9,
    '1', '2', '3', '4', '5', '6', '7', '8', '9'
};

uint8_t qmux_app_close_packet[] = {
    0x03,
    picoquic_frame_type_application_close,
    0,
    0
};


int qmux_receive_close_check(picoquic_cnx_t* cnx, uint64_t UNUSED(expected))
{
    int ret = 0;
    if (cnx->cnx_state != picoquic_state_disconnected &&
        cnx->cnx_state != picoquic_state_closing_received) {
        ret = -1;
    }
    return ret;
}

int qmux_receive_cnx_close_test(void)
{
    int ret = qmux_receive_test_one(0, 1, 1,
        qmux_cnx_close_packet, sizeof(qmux_cnx_close_packet),
        0, qmux_receive_close_check);

    return ret;
}

int qmux_receive_app_close_test(void)
{
    int ret = qmux_receive_test_one(0, 1, 1,
        qmux_app_close_packet, sizeof(qmux_app_close_packet),
        0, qmux_receive_close_check);

    return ret;
}

int qmux_receive_error_test_check(picoquic_cnx_t* cnx, uint64_t UNUSED(expected))
{
    int ret = 0;

    if (cnx->cnx_state != picoquic_state_disconnecting &&
        cnx->cnx_state != picoquic_state_handshake_failure) {
        ret = -1;
    }
    else if (ret == 0 && cnx->local_error != expected) {
        ret = -1;
    }
    return ret;
}

int qmux_receive_error_one(int set_tp_received, int set_tp_sent,
    uint8_t * message, size_t length, uint64_t expected)
{
    int ret = qmux_receive_test_one(0, set_tp_received, set_tp_sent, message, length,
        expected, qmux_receive_error_test_check);
    return ret;
}

int qmux_receive_errors_test(void)
{
    uint8_t qmux_retire_cid_packet[] = { 0x02, picoquic_frame_type_retire_connection_id, 0 };
    uint8_t qmux_bad_tp_packet[64];
    uint8_t ack_delay_exponent[] = { 3 };
    size_t qmux_bad_tp_packet_length = qmux_format_tp_test_packet(qmux_bad_tp_packet,
        sizeof(qmux_bad_tp_packet), picoquic_tp_ack_delay_exponent,
        ack_delay_exponent, sizeof(ack_delay_exponent));
    int ret = 0;

    if (qmux_bad_tp_packet_length == 0) {
        ret = -1;
    }
    if (ret == 0) {
        /* TP not received, but message is not TP */
        ret = qmux_receive_error_one(0, 0, qmux_test_data, sizeof(qmux_test_data),
            PICOQUIC_TRANSPORT_PARAMETER_ERROR);
    }
    if (ret == 0) {
        /* TP received, but message is a duplicate TP */;
        ret = qmux_receive_error_one(1, 1, qmux_test_tp_packet, sizeof(qmux_test_tp_packet),
            PICOQUIC_TRANSPORT_PARAMETER_ERROR);
    }
    if (ret == 0) {
        /* Prohibited QUIC v1 transport parameter in QMUX. */
        ret = qmux_receive_error_one(0, 0, qmux_bad_tp_packet, qmux_bad_tp_packet_length,
            PICOQUIC_TRANSPORT_PARAMETER_ERROR);
    }
    if (ret == 0) {
        /* Prohibited QUIC v1 frame in QMUX. */
        ret = qmux_receive_error_one(1, 1, qmux_retire_cid_packet, sizeof(qmux_retire_cid_packet),
            PICOQUIC_TRANSPORT_FRAME_FORMAT_ERROR);
    }
    if (ret == 0) {
        /* Receive qx_ping response when no qx_ping query has been sent */
        ret = qmux_receive_error_one(1, 1, qmux_qx_ping_r_packet, sizeof(qmux_qx_ping_r_packet),
            PICOQUIC_TRANSPORT_PROTOCOL_VIOLATION);
    }
    return ret;
}

int qmux_receive_prohibited_frames_test(void)
{
    uint8_t packet[16];
    uint64_t prohibited_frames[] = {
        picoquic_frame_type_ping,
        picoquic_frame_type_ack,
        picoquic_frame_type_ack_ecn,
        picoquic_frame_type_crypto_hs,
        picoquic_frame_type_new_token,
        picoquic_frame_type_new_connection_id,
        picoquic_frame_type_retire_connection_id,
        picoquic_frame_type_path_challenge,
        picoquic_frame_type_path_response,
        picoquic_frame_type_handshake_done
    };
    int ret = 0;

    for (size_t i = 0; ret == 0 && i < sizeof(prohibited_frames) / sizeof(prohibited_frames[0]); i++) {
        uint8_t frame[8];
        uint8_t* bytes = picoquic_frames_varint_encode(frame, frame + sizeof(frame), prohibited_frames[i]);
        size_t packet_length = (bytes == NULL) ? 0 :
            qmux_format_frame_record(packet, sizeof(packet), frame, (size_t)(bytes - frame));

        ret = (packet_length == 0) ? -1 : qmux_receive_error_one(1, 1, packet,
            packet_length, PICOQUIC_TRANSPORT_FRAME_FORMAT_ERROR);
    }
    return ret;
}

static int qmux_receive_allowed_frame_one(const uint8_t* frame, size_t frame_length)
{
    uint8_t packet[64];
    size_t packet_length = qmux_format_frame_record(packet, sizeof(packet), frame, frame_length);

    return (packet_length == 0) ? -1 :
        qmux_receive_test_one(0, 1, 1, packet, packet_length, 0, qmux_receive_no_error_check);
}

int qmux_receive_allowed_frames_test(void)
{
    uint8_t padding[] = { picoquic_frame_type_padding };
    uint8_t reset_stream[] = { picoquic_frame_type_reset_stream, 0, 0, 0 };
    uint8_t stop_sending[] = { picoquic_frame_type_stop_sending, 0, 0 };
    uint8_t max_data[] = { picoquic_frame_type_max_data, 1 };
    uint8_t max_stream_data[] = { picoquic_frame_type_max_stream_data, 0, 1 };
    uint8_t max_streams_bidi[] = { picoquic_frame_type_max_streams_bidir, 1 };
    uint8_t max_streams_uni[] = { picoquic_frame_type_max_streams_unidir, 1 };
    uint8_t data_blocked[] = { picoquic_frame_type_data_blocked, 1 };
    uint8_t stream_data_blocked[] = { picoquic_frame_type_stream_data_blocked, 0, 1 };
    uint8_t streams_blocked_bidi[] = { picoquic_frame_type_streams_blocked_bidir, 1 };
    uint8_t streams_blocked_uni[] = { picoquic_frame_type_streams_blocked_unidir, 1 };
    struct st_qmux_allowed_frame_t {
        uint8_t* frame;
        size_t frame_length;
    } frames[] = {
        { padding, sizeof(padding) },
        { reset_stream, sizeof(reset_stream) },
        { stop_sending, sizeof(stop_sending) },
        { max_data, sizeof(max_data) },
        { max_stream_data, sizeof(max_stream_data) },
        { max_streams_bidi, sizeof(max_streams_bidi) },
        { max_streams_uni, sizeof(max_streams_uni) },
        { data_blocked, sizeof(data_blocked) },
        { stream_data_blocked, sizeof(stream_data_blocked) },
        { streams_blocked_bidi, sizeof(streams_blocked_bidi) },
        { streams_blocked_uni, sizeof(streams_blocked_uni) }
    };
    int ret = 0;

    for (size_t i = 0; ret == 0 && i < sizeof(frames) / sizeof(frames[0]); i++) {
        ret = qmux_receive_allowed_frame_one(frames[i].frame, frames[i].frame_length);
    }
    return ret;
}

int qmux_receive_extension_tp_ignore_test_check(picoquic_cnx_t* cnx, uint64_t UNUSED(expected))
{
    return cnx->remote_parameters.enable_loss_bit ? -1 : 0;
}

int qmux_receive_extension_tp_ignore_test(void)
{
    uint8_t packet[64];
    size_t packet_length = qmux_format_tp_test_packet(packet, sizeof(packet),
        picoquic_tp_enable_loss_bit, NULL, 0);
    int ret = (packet_length == 0) ? -1 : 0;

    if (ret == 0) {
        ret = qmux_receive_test_one(0, 0, 0, packet, packet_length,
            0, qmux_receive_extension_tp_ignore_test_check);
    }
    return ret;
}

int qmux_datagram_test(void)
{
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    qmux_sim_ctx_t qtc = { 0 };
    uint8_t frame[32];
    uint8_t packet[64];
    uint8_t buffer[2048];
    uint8_t* bytes = frame;
    size_t packet_length = 0;
    size_t send_length = 0;
    int ret = picoquic_test_set_minimal_cnx(&quic, &cnx);

    picoqmux_init(cnx, 1);
    picoqmux_update_state_on_tp_sent(cnx);
    picoqmux_update_state_on_tp_received(cnx);
    cnx->local_parameters.max_datagram_frame_size = PICOQUIC_MAX_PACKET_SIZE;
    picoquic_set_callback(cnx, qmux_test_callback, &qtc);
    qtc.test_datagram = 1;

    if (ret == 0) {
        *bytes++ = picoquic_frame_type_datagram_l;
        bytes = picoquic_frames_varint_encode(bytes, frame + sizeof(frame), sizeof(qmux_test_data));
        if (bytes != NULL) {
            memcpy(bytes, qmux_test_data, sizeof(qmux_test_data));
            bytes += sizeof(qmux_test_data);
        }
        packet_length = (bytes == NULL) ? 0 :
            qmux_format_frame_record(packet, sizeof(packet), frame, (size_t)(bytes - frame));
        ret = (packet_length == 0) ? -1 :
            picoqmux_incoming_cnx_packet(cnx, 12345, packet, packet_length);
    }

    if (ret == 0 && (!qtc.datagram_received ||
        qtc.datagram_length != sizeof(qmux_test_data) ||
        !qtc.datagram_data_matches)) {
        ret = -1;
    }

    if (ret == 0) {
        qtc.datagram_received = 0;
        cnx->remote_parameters.max_datagram_frame_size = PICOQUIC_MAX_PACKET_SIZE;
        ret = picoquic_queue_datagram_frame(cnx, sizeof(qmux_test_data), qmux_test_data);
    }

    if (ret == 0) {
        ret = picoqmux_prepare_cnx_packets(cnx, 12346, buffer, sizeof(buffer), &send_length);
        if (send_length != packet_length || memcmp(buffer, packet, send_length) != 0) {
            ret = -1;
        }
    }

    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return ret;
}

int qmux_receive_stream_order_test(void)
{
    uint8_t qmux_stream_gap_packet[] = {
        0x05, picoquic_frame_type_stream_range_min | 6, 0, 1, 1, 0xaa
    };

    return qmux_receive_error_one(1, 1, qmux_stream_gap_packet,
        sizeof(qmux_stream_gap_packet), PICOQUIC_TRANSPORT_PROTOCOL_VIOLATION);
}

int qmux_receive_stream_order_edges_test(void)
{
    uint8_t qmux_stream_interleave_packet[] = {
        0x0d,
        picoquic_frame_type_stream_range_min | 2, 0, 1, 0xaa,
        picoquic_frame_type_stream_range_min | 2, 4, 1, 0xbb,
        picoquic_frame_type_stream_range_min | 6, 0, 1, 1, 0xcc
    };
    uint8_t qmux_stream_duplicate_packet[] = {
        0x08,
        picoquic_frame_type_stream_range_min | 2, 0, 1, 0xaa,
        picoquic_frame_type_stream_range_min | 2, 0, 1, 0xbb
    };
    uint8_t qmux_stream_late_gap_packet[] = {
        0x09,
        picoquic_frame_type_stream_range_min | 2, 0, 1, 0xaa,
        picoquic_frame_type_stream_range_min | 6, 0, 2, 1, 0xbb
    };
    int ret = qmux_receive_test_one(0, 1, 1, qmux_stream_interleave_packet,
        sizeof(qmux_stream_interleave_packet), 0, NULL);

    if (ret == 0) {
        ret = qmux_receive_error_one(1, 1, qmux_stream_duplicate_packet,
            sizeof(qmux_stream_duplicate_packet), PICOQUIC_TRANSPORT_PROTOCOL_VIOLATION);
    }
    if (ret == 0) {
        ret = qmux_receive_error_one(1, 1, qmux_stream_late_gap_packet,
            sizeof(qmux_stream_late_gap_packet), PICOQUIC_TRANSPORT_PROTOCOL_VIOLATION);
    }
    return ret;
}


int qmux_receive_record_errors_test(void)
{
    uint8_t qmux_truncated_record[] = { 0x06, 0x0b, 0x0, 0x0f, 01, 02, 03 }; 
    uint8_t qmux_oversized_record[] = { 0x7f, 0xff };
    int ret = qmux_receive_error_one(1, 1, qmux_truncated_record, sizeof(qmux_truncated_record),
        PICOQUIC_TRANSPORT_FRAME_FORMAT_ERROR);

    if (ret == 0) {
        ret = qmux_receive_error_one(1, 1, qmux_oversized_record, sizeof(qmux_oversized_record),
            PICOQUIC_TRANSPORT_FRAME_FORMAT_ERROR);
    }
    return ret;
}

int qmux_receive_empty_record_test(void)
{
    uint8_t qmux_empty_record[] = { 0 };

    return qmux_receive_error_one(1, 1, qmux_empty_record, sizeof(qmux_empty_record),
        PICOQUIC_TRANSPORT_FRAME_FORMAT_ERROR);
}

int qmux_receive_split_record_test_one(uint8_t * test_packet, size_t length, size_t split)
{
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    qmux_sim_ctx_t qtc = { 0 };
    int ret = picoquic_test_set_minimal_cnx(&quic, &cnx);

    cnx->client_mode = 0;
    picoqmux_init(cnx, 1);
    picoqmux_update_state_on_tp_received(cnx);
    picoquic_set_callback(cnx, qmux_test_callback, &qtc);

    if (ret == 0) {
        ret = picoqmux_incoming_packets(cnx, 12345, test_packet, split, 0);
    }

    if (ret == 0 && qtc.received_stream_0) {
        ret = -1;
    }

    if (ret == 0) {
        ret = picoqmux_incoming_packets(cnx, 12346, test_packet + split,
            length - split, 0);
    }

    if (ret == 0) {
        ret = qmux_receive_tp_check(cnx, 0);
    }

    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return ret;
}

int qmux_receive_split_record_test(void)
{
    /* Test interesting split values:
    * - Just one byte, splitting the length
    * - 2 bytes, splitting length from content
    * - L-1 bytes, leaving just one byte for the next packet
    * 
    * Do that with two test packets:
    * - first one has length encoded on 1 byte
    * - second one has length encoded on 2 bytes
    */
    int ret = qmux_receive_split_record_test_one(qmux_test_packet, sizeof(qmux_test_packet), 1);

    if (ret == 0) {
        ret = qmux_receive_split_record_test_one(qmux_test_packet, sizeof(qmux_test_packet), 2);
    }

    if (ret == 0) {
        ret = qmux_receive_split_record_test_one(qmux_test_packet_l2, sizeof(qmux_test_packet_l2), 1);
    }

    if (ret == 0) {
        ret = qmux_receive_split_record_test_one(qmux_test_packet_l2, sizeof(qmux_test_packet_l2), 2);
    }

    if (ret == 0) {
        ret = qmux_receive_split_record_test_one(qmux_test_packet_l2, sizeof(qmux_test_packet_l2), 3);
    }

    if (ret == 0) {
        ret = qmux_receive_split_record_test_one(qmux_test_packet_l2, sizeof(qmux_test_packet_l2),
            sizeof(qmux_test_packet_l2) - 1);
    }

    if (ret == 0) {
        ret = qmux_receive_split_record_test_one(qmux_test_packet_x2, sizeof(qmux_test_packet_x2), 3);
    }

    if (ret == 0) {
        ret = qmux_receive_split_record_test_one(qmux_test_packet_x2, sizeof(qmux_test_packet_x2),
            sizeof(qmux_test_packet_l2) - 1);
    }
    return ret;
}

int qmux_send_qx_ping_r_append_test(void)
{
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    uint8_t buffer[2048];
    uint8_t expected[2048];
    size_t send_length = 0;
    size_t expected_length = sizeof(qmux_test_tp_packet) + sizeof(qmux_qx_ping_r_packet) - 1;
    int ret = picoquic_test_set_minimal_cnx(&quic, &cnx);
    picoqmux_init(cnx, 1);

    cnx->qx_query_last = 0;

    if (ret == 0) {
        picoqmux_update_state_on_tp_received(cnx);
        expected[0] = (uint8_t)(expected_length - 1);
        memcpy(expected + 1, qmux_test_tp_packet + 1, sizeof(qmux_test_tp_packet) - 1);
        memcpy(expected + sizeof(qmux_test_tp_packet),
            qmux_qx_ping_r_packet + 1, sizeof(qmux_qx_ping_r_packet) - 1);

        ret = picoqmux_prepare_cnx_packets(cnx, 0, buffer, sizeof(buffer), &send_length);
        if (send_length != expected_length ||
            memcmp(buffer, expected, send_length) != 0 ||
            cnx->qx_query_ack != cnx->qx_query_last) {
            ret = -1;
        }
    }

    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return ret;
}

int qmux_send_qx_ping_r_test(void)
{
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    uint8_t buffer[2048];
    size_t send_length = 0;
    int ret = picoquic_test_set_minimal_cnx(&quic, &cnx);
    picoqmux_init(cnx, 1);

    /* Simulate QX Ping received 
     */
    cnx->qx_query_last = 0;

    if (ret == 0) {
        /* simulate that TP has been sent and received. */
        picoqmux_update_state_on_tp_sent(cnx);
        picoqmux_update_state_on_tp_received(cnx);
        /* prepare the packet */
        ret = picoqmux_prepare_cnx_packets(cnx, 0, buffer, sizeof(buffer), &send_length);

        if (send_length != sizeof(qmux_qx_ping_r_packet) ||
            memcmp(buffer, qmux_qx_ping_r_packet, send_length) != 0) {
            ret = -1;
        }
    }

    picoquic_test_delete_minimal_cnx(&quic, &cnx);

    return ret;
}

int qmux_send_cnx_close_test(void)
{
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    uint8_t buffer[2048];
    size_t send_length = 0;
    int ret = picoquic_test_set_minimal_cnx(&quic, &cnx);
    picoqmux_init(cnx, 1);

    if (ret == 0) {
        /* simulate that TP has been sent and received. */
        picoqmux_update_state_on_tp_sent(cnx);
        picoqmux_update_state_on_tp_received(cnx);
        /* Simulate that the local application requests disconnect */
        picoquic_close(cnx, 0);
        /* prepare the packet */
        ret = picoqmux_prepare_cnx_packets(cnx, 0, buffer, sizeof(buffer), &send_length);

        if (send_length != sizeof(qmux_app_close_packet) ||
            memcmp(buffer, qmux_app_close_packet, send_length) != 0 ||
            cnx->cnx_state != picoquic_state_disconnected) {
            ret = -1;
        }
    }

    picoquic_test_delete_minimal_cnx(&quic, &cnx);

    return ret;
}

int qmux_test_init(qmux_sim_ctx_t* sim_ctx, qmux_sim_spec_t* spec)
{
    int ret = 0;
    char test_server_cert_file[512];
    char test_server_key_file[512];
    char test_server_cert_store_file[512];

    memset(sim_ctx, 0, sizeof(qmux_sim_ctx_t));

    sim_ctx->is_cleartext = spec->is_cleartext;

    ret = picoquic_get_input_path(test_server_cert_file, sizeof(test_server_cert_file), picoquic_solution_dir,
        PICOQUIC_TEST_FILE_SERVER_CERT);

    if (ret == 0) {
        ret = picoquic_get_input_path(test_server_key_file, sizeof(test_server_key_file), picoquic_solution_dir,
            PICOQUIC_TEST_FILE_SERVER_KEY);
    }

    if (ret == 0) {
        ret = picoquic_get_input_path(test_server_cert_store_file, sizeof(test_server_cert_store_file), picoquic_solution_dir,
            PICOQUIC_TEST_FILE_CERT_STORE);
    }

    if (ret != 0) {
        DBG_PRINTF("%s", "Cannot set key file names.");
    }
    else {
        /* Test the creation of the client and server contexts */
        sim_ctx->quic[0] = picoqmux_create(8, NULL, NULL, test_server_cert_store_file,
            NULL, qmux_test_callback, sim_ctx, NULL, sim_ctx->simulated_time,
            &sim_ctx->simulated_time, NULL, NULL, 0);

        sim_ctx->quic[1] = picoqmux_create(8,
            test_server_cert_file, test_server_key_file, NULL, "qmux_test",
            qmux_test_callback, sim_ctx, NULL,
            sim_ctx->simulated_time, &sim_ctx->simulated_time, NULL, NULL, 0);

        if (sim_ctx->quic[0] == NULL || sim_ctx->quic[1] == NULL) {
            ret = -1;
        }
        else {
            for (int i = 0; i < 2; i++) {
                /* set the default idle timeout to the specified value */
                picoquic_set_default_idle_timeout(sim_ctx->quic[i], spec->idle_timeout);
            }
            /* Classic client groups only, so PQ capable servers do not send HRR */
            ret = picoquic_set_key_exchange(sim_ctx->quic[0], PICOQUIC_GROUP_SECP256R1);
            sim_ctx->test_idle = spec->test_idle;
            sim_ctx->test_close = spec->test_close;
            sim_ctx->idle_timeout = spec->idle_timeout;
        }
    }
    return ret;
}

void qmux_test_release(qmux_sim_ctx_t* sim_ctx)
{
    while (sim_ctx->msg_queue != NULL) {
        qmux_msg_t* to_delete = sim_ctx->msg_queue;
        sim_ctx->msg_queue = sim_ctx->msg_queue->next;
        free(to_delete);
    }

    for (int i = 0; i < 2; i++) {
        if (sim_ctx->cnx[i] != NULL) {
            picoquic_delete_cnx(sim_ctx->cnx[i]);
            sim_ctx->cnx[i] = NULL;
        }
    }
    for (int i = 0; i < 2; i++) {
        if (sim_ctx->quic[i] != NULL) {
            picoquic_free(sim_ctx->quic[i]);
            sim_ctx->quic[i] = NULL;
        }
    }
}

int qmux_socket_accept_test(void)
{
#ifdef _WINDOWS
    return 0;
#else
    qmux_sim_ctx_t sim_ctx;
    qmux_sim_spec_t spec;
    picoqmux_socket_ctx_t* sqmux_ctx[2] = { 0 };
    SOCKET_TYPE client_socket = INVALID_SOCKET;
    struct sockaddr_in server_addr;
    int nb_qmux_sockets = 0;
    int ret = 0;

    memset(&spec, 0, sizeof(qmux_sim_spec_t));
    spec.is_cleartext = 1;
    spec.idle_timeout = 1000000;
    ret = qmux_test_init(&sim_ctx, &spec);

    if (ret == 0) {
        sqmux_ctx[0] = picoquic_packet_loop_open_qmux_socket(AF_INET, 0, 1, 1);
        if (sqmux_ctx[0] == NULL || sqmux_ctx[0]->af != AF_INET || sqmux_ctx[0]->port == 0) {
            ret = -1;
        }
        else {
            nb_qmux_sockets = 1;
        }
    }

    if (ret == 0) {
        client_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        memset(&server_addr, 0, sizeof(server_addr));
        server_addr.sin_family = AF_INET;
        server_addr.sin_addr.s_addr = htonl(0x7f000001);
        server_addr.sin_port = htons(sqmux_ctx[0]->port);
        if (client_socket == INVALID_SOCKET ||
            connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) != 0) {
            ret = -1;
        }
    }

    if (ret == 0) {
        /* sleep a short time so the "connect" can arrive before calling accept */
        usleep(10000);
        ret = picoquic_packet_loop_do_tcp_accept(sim_ctx.quic[1], sqmux_ctx,
            &nb_qmux_sockets, 2, 0, sim_ctx.simulated_time);
    }

    if (ret == 0 && (nb_qmux_sockets != 2 ||
        sqmux_ctx[1] == NULL ||
        sqmux_ctx[1]->fd == INVALID_SOCKET ||
        sqmux_ctx[1]->cnx == NULL ||
        sqmux_ctx[1]->af != AF_INET ||
        sqmux_ctx[1]->port != sqmux_ctx[0]->port ||
        sqmux_ctx[1]->local_addr.ss_family != AF_INET ||
        sqmux_ctx[1]->remote_addr.ss_family != AF_INET)) {
#if 1
        DBG_PRINTF("error detected, nb_sockets: %d, sqmux_ctx[1]: %x", nb_qmux_sockets, sqmux_ctx[1]);
        if (nb_qmux_sockets == 2 && sqmux_ctx[1] != NULL) {
             DBG_PRINTF("fd: %d, cnx: %x, af: %d, port: %d/%d, local_af: %d/%d",
                 sqmux_ctx[1]->fd,
                 sqmux_ctx[1]->cnx,
                 sqmux_ctx[1]->af,
                 sqmux_ctx[1]->port,
                 sqmux_ctx[0]->port,
                 sqmux_ctx[1]->local_addr.ss_family,
                 sqmux_ctx[1]->remote_addr.ss_family);
        } 
#endif
        ret = -1;
    }

    if (client_socket != INVALID_SOCKET) {
        SOCKET_CLOSE(client_socket);
    }
    for (int i = 0; i < nb_qmux_sockets && i < 2; i++) {
        picoquic_packet_loop_free_qmux_socket(sqmux_ctx[i]);
    }
    qmux_test_release(&sim_ctx);
    return ret;
#endif
}

int qmux_socket_close_on_receive_test(void)
{
#ifdef _WINDOWS
    return 0;
#else
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    picoqmux_socket_ctx_t* sqmux_ctx[1] = { 0 };
    int sockets[2] = { INVALID_SOCKET, INVALID_SOCKET };
    uint8_t buffer[128];
    int ret = picoquic_test_set_minimal_cnx(&quic, &cnx);
    int socket_was_closed = -1;

    if (ret == 0 && socketpair(AF_UNIX, SOCK_STREAM, 0, sockets) != 0) {
        ret = -1;
    }
    if (ret == 0) {
        sqmux_ctx[0] = (picoqmux_socket_ctx_t*)malloc(sizeof(picoqmux_socket_ctx_t));
        if (sqmux_ctx[0] == NULL) {
            ret = -1;
        }
        else {
            memset(sqmux_ctx[0], 0, sizeof(picoqmux_socket_ctx_t));
            sqmux_ctx[0]->fd = sockets[1];
            sqmux_ctx[0]->cnx = cnx;
            picoqmux_init(cnx, 1);
            picoqmux_update_state_on_tp_sent(cnx);
            picoqmux_update_state_on_tp_received(cnx);
        }
    }
    if (ret == 0 && send(sockets[0], (const char*)qmux_app_close_packet,
        (int)sizeof(qmux_app_close_packet), 0) != sizeof(qmux_app_close_packet)) {
        ret = -1;
    }
    if (ret == 0) {
        ret = picoquic_packet_loop_do_tcp_read(sqmux_ctx,  &socket_was_closed, 0, 12345, buffer, sizeof(buffer));
        if (ret != 0 || sqmux_ctx[0]->fd != INVALID_SOCKET || sqmux_ctx[0]->cnx != NULL ||
            cnx->cnx_state != picoquic_state_disconnected) {
            ret = -1;
        }
    }

    if (sockets[0] != INVALID_SOCKET) {
        SOCKET_CLOSE(sockets[0]);
    }
    if (sqmux_ctx[0] != NULL) {
        picoquic_packet_loop_free_qmux_socket(sqmux_ctx[0]);
    }
    else if (sockets[1] != INVALID_SOCKET) {
        SOCKET_CLOSE(sockets[1]);
    }
    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return ret;
#endif
}


int qmux_loop_deliver_message(qmux_sim_ctx_t* sim_ctx)
{
    int ret = 0;
    qmux_msg_t* msg = sim_ctx->msg_queue;
    sim_ctx->msg_queue = msg->next;
    if (msg->next == NULL) {
        sim_ctx->msg_last = NULL;
    }

    if (sim_ctx->cnx[msg->target_index] == NULL) {
        /* submit message to connection */
        if (sim_ctx->quic[msg->target_index] != NULL) {
            /* submit to quic context and obtain the connection pointer */
            sim_ctx->cnx[msg->target_index] = picoqmux_create_qmux_cnx(
                sim_ctx->quic[msg->target_index], sim_ctx->simulated_time, 0, 
                sim_ctx->is_cleartext, PICOQUIC_TEST_SNI, "qmux_test", NULL);
        }
    }

    if (sim_ctx->cnx[msg->target_index] == NULL) {
        ret = -1;
    }
    else {
        ret = picoqmux_incoming_packets(sim_ctx->cnx[msg->target_index],
            sim_ctx->simulated_time,
            msg->buffer, msg->length, 0);
        if (sim_ctx->should_close_tcp) {
            /* simulate that the TCP connection is closed */
            ret = picoqmux_incoming_packets(sim_ctx->cnx[msg->target_index],
                sim_ctx->simulated_time,
                NULL, 0, 1);
        }
    }
    free(msg);
    return ret;
}

int qmux_loop_poll_connection(qmux_sim_ctx_t* sim_ctx, int cnx_index)
{
    int ret = 0;
    size_t msg_alloc = sizeof(qmux_msg_t) + 0x4000;
    qmux_msg_t* msg = (qmux_msg_t*)malloc(msg_alloc);
    if (msg == NULL) {
        ret = -1;
    }
    else {
        memset(msg, 0, sizeof(qmux_msg_t));
        msg->buffer = (uint8_t*)msg + sizeof(qmux_msg_t);
        msg->buffer_size = 0x4000;

        ret = picoqmux_prepare_packets(sim_ctx->cnx[cnx_index],
            sim_ctx->simulated_time, msg->buffer, msg->buffer_size, &msg->length);

        if (msg->length > 0) {
            msg->target_index = 1 - cnx_index;
            msg->delivery_time = sim_ctx->simulated_time + sim_ctx->idle_timeout;
            if (sim_ctx->msg_last == NULL) {
                sim_ctx->msg_last = msg;
                sim_ctx->msg_queue = msg;
            }
            else {
                sim_ctx->msg_last->next = msg;
                sim_ctx->msg_last = msg;
            }
        }
        else {
            free(msg);
        }
    }
    return ret;
}

int qmux_loop_iterate(qmux_sim_ctx_t* sim_ctx)
{
    int ret = 0;
    int next_cnx = -1;
    int has_msg = 0;
    int should_close = 0;
    uint64_t next_sim_time = UINT64_MAX;

    for (int i = 0; i < 2; i++) {
        if (sim_ctx->cnx[i] != NULL &&
            sim_ctx->cnx[i]->cnx_state != picoquic_state_disconnected &&
            sim_ctx->cnx[i]->next_wake_time < next_sim_time) {
            next_sim_time = sim_ctx->cnx[i]->next_wake_time;
            next_cnx = i;
        }
    }
    if (sim_ctx->msg_queue != NULL &&
        sim_ctx->msg_queue->delivery_time <= next_sim_time) {
        next_sim_time = sim_ctx->msg_queue->delivery_time;
        has_msg = 1;
    }
    if (sim_ctx->should_close_tcp) {
        for (int i = 0; i < 2; i++) {
            if (sim_ctx->cnx[i] != NULL &&
                sim_ctx->cnx[i]->cnx_state != picoquic_state_disconnected) {
                next_sim_time = sim_ctx->simulated_time;
                next_cnx = i;
                should_close = 1;
                break;
            }
        }
    }
    if (next_sim_time > sim_ctx->simulated_time) {
        sim_ctx->simulated_time = next_sim_time;
    }
    if (should_close) {
        /* simulate that the TCP connection is closed */
        ret = picoqmux_incoming_packets(sim_ctx->cnx[next_cnx],
            sim_ctx->simulated_time,
            NULL, 0, 1);
    }
    else if (has_msg){
        /* deliver the message */
        ret = qmux_loop_deliver_message(sim_ctx);
    }
    else if (next_cnx >= 0) {
        /* get the next message from the specifed connection */
        ret = qmux_loop_poll_connection(sim_ctx, next_cnx);
    }
    else {
        ret = -1; /* Simulation is finished. */
    }
    return ret;
}

int qmux_loop_one(qmux_sim_spec_t * spec)
{
    int ret = 0;
    qmux_sim_ctx_t sim_ctx;

    ret = qmux_test_init(&sim_ctx, spec);

    /* Start the loop by creating a client connection */
    if (ret == 0 &&
        (sim_ctx.cnx[0] = picoqmux_create_qmux_cnx(sim_ctx.quic[0],
            sim_ctx.simulated_time, 1, spec->is_cleartext, PICOQUIC_TEST_SNI, "qmux_test", NULL)) == NULL) {
        ret = -1;
    }

    /* Do a connection loop */
    while (ret == 0) {
        /* Do an iteration of the loop */
        /* if both client and server have received enough data, exit */
        if ((ret = qmux_loop_iterate(&sim_ctx)) == 0 &&
            sim_ctx.cnx[0]->cnx_state == picoquic_state_disconnected) {
            break;
        }
    }
    /* Check the result */
    if (ret == 0) {
        if (sim_ctx.cnx[1] == NULL) {
            ret = -1;
        }
        else if (sim_ctx.simulated_time > spec->expected_time) {
            ret = -1;
        }
    }
       
    /* release everything. */
    qmux_test_release(&sim_ctx);
    return ret;
}

int qmux_loop_test(void)
{
    qmux_sim_spec_t spec = { 0 };
    spec.is_cleartext = 1;

    return qmux_loop_one(&spec);
}

int qmux_loop_delay_test(void)
{
    qmux_sim_spec_t spec = { 0 };
    spec.is_cleartext = 1;
    spec.idle_timeout = 15000;
    spec.expected_time = 60000;

    return qmux_loop_one(&spec);
}

int qmux_loop_idle_test(void)
{
    qmux_sim_spec_t spec = { 0 };
    spec.is_cleartext = 1;
    spec.idle_timeout = 15000;
    spec.test_idle = 1;
    spec.expected_time = 30030000;

    return qmux_loop_one(&spec);
}

int qmux_tls_client_alpn_required_test(void)
{
    qmux_sim_ctx_t sim_ctx;
    qmux_sim_spec_t spec = { 0 };
    int ret;

    spec.is_cleartext = 0;
    spec.idle_timeout = 15000;
    ret = qmux_test_init(&sim_ctx, &spec);

    if (ret == 0) {
        sim_ctx.cnx[0] = picoqmux_create_qmux_cnx(sim_ctx.quic[0],
            sim_ctx.simulated_time, 1, 0, PICOQUIC_TEST_SNI, NULL, NULL);
        if (sim_ctx.cnx[0] != NULL) {
            ret = -1;
        }
    }

    qmux_test_release(&sim_ctx);
    return ret;
}

/* A client whose TLS handshake gets no answer must be disconnected by the idle timer. */
int qmux_tls_handshake_idle_timeout_test(void)
{
    qmux_sim_ctx_t sim_ctx;
    qmux_sim_spec_t spec = { 0 };
    uint8_t buffer[4096];
    size_t send_length = 0;
    int ret;

    spec.is_cleartext = 0;
    spec.idle_timeout = 15000;
    ret = qmux_test_init(&sim_ctx, &spec);

    if (ret == 0 &&
        (sim_ctx.cnx[0] = picoqmux_create_qmux_cnx(sim_ctx.quic[0],
            sim_ctx.simulated_time, 1, 0, PICOQUIC_TEST_SNI, "qmux_test", NULL)) == NULL) {
        ret = -1;
    }
    /* The first call sends the ClientHello, which is never answered. */
    if (ret == 0 &&
        (picoqmux_prepare_packets(sim_ctx.cnx[0], sim_ctx.simulated_time, buffer, sizeof(buffer), &send_length) != 0 ||
            send_length == 0)) {
        DBG_PRINTF("%s", "Cannot send the ClientHello");
        ret = -1;
    }
    if (ret == 0) {
        int prepare_ret = 0;

        sim_ctx.simulated_time += (uint64_t)spec.idle_timeout * 1000 + 1;
        for (int i = 0; i < 4 && prepare_ret == 0; i++) {
            prepare_ret = picoqmux_prepare_packets(sim_ctx.cnx[0], sim_ctx.simulated_time, buffer, sizeof(buffer), &send_length);
        }
        if (prepare_ret == 0 || sim_ctx.cnx[0]->cnx_state != picoquic_state_disconnected) {
            DBG_PRINTF("After idle timeout, prepare returns 0x%x, state %d", prepare_ret, (int)sim_ctx.cnx[0]->cnx_state);
            ret = -1;
        }
    }

    qmux_test_release(&sim_ctx);
    return ret;
}

/* When a QMUX connection times out before TLS completes, the packet loop timer check must close
 * that socket and return 0, so the loop keeps serving the other QMUX sockets. */
int qmux_tls_handshake_idle_timeout_loop_test(void)
{
    qmux_sim_ctx_t sim_ctx;
    qmux_sim_spec_t spec = { 0 };
    picoquic_cnx_t* cnx_other = NULL;
    picoqmux_socket_ctx_t* sqmux_ctx[2] = { NULL, NULL };
    uint8_t buffer[4096];
    size_t send_length = 0;
    int socket_was_closed = -1;
    int ret;
#ifdef _WINDOWS
    WSADATA wsaData = { 0 };
#endif

    spec.is_cleartext = 0;
    spec.idle_timeout = 15000;
    ret = qmux_test_init(&sim_ctx, &spec);
#ifdef _WINDOWS
    /* The test opens sockets directly, without the packet loop that would initialize Winsock. */
    if (ret == 0) {
        ret = WSA_START(MAKEWORD(2, 2), &wsaData);
    }
#endif
    if (ret == 0 &&
        ((sim_ctx.cnx[0] = picoqmux_create_qmux_cnx(sim_ctx.quic[0],
            sim_ctx.simulated_time, 1, 0, PICOQUIC_TEST_SNI, "qmux_test", NULL)) == NULL ||
        (sqmux_ctx[0] = picoquic_packet_loop_open_qmux_socket(AF_INET, 0, 0, 0)) == NULL ||
        (sqmux_ctx[1] = picoquic_packet_loop_open_qmux_socket(AF_INET, 0, 0, 0)) == NULL)) {
        ret = -1;
    }
    /* The first connection sends a ClientHello, which is never answered. */
    if (ret == 0 &&
        (picoqmux_prepare_packets(sim_ctx.cnx[0], sim_ctx.simulated_time, buffer, sizeof(buffer), &send_length) != 0 ||
            send_length == 0)) {
        DBG_PRINTF("%s", "Cannot send the ClientHello");
        ret = -1;
    }
    /* After its idle timeout, a second connection starts; it is not yet due for sending. */
    if (ret == 0) {
        sim_ctx.simulated_time += (uint64_t)spec.idle_timeout * 1000 + 1;
        if ((cnx_other = picoqmux_create_qmux_cnx(sim_ctx.quic[0],
            sim_ctx.simulated_time, 1, 0, PICOQUIC_TEST_SNI, "qmux_test", NULL)) == NULL) {
            ret = -1;
        }
        else {
            cnx_other->next_wake_time = sim_ctx.simulated_time + 1000000;
            sqmux_ctx[0]->cnx = sim_ctx.cnx[0];
            sqmux_ctx[1]->cnx = cnx_other;
        }
    }
    for (int i = 0; ret == 0 && i < 4 && sqmux_ctx[0]->fd != INVALID_SOCKET; i++) {
        if (picoquic_packet_loop_check_qmux_timers(sqmux_ctx, 2, &socket_was_closed, sim_ctx.simulated_time,
            buffer, sizeof(buffer)) != 0) {
            DBG_PRINTF("Timer check %d returns an error, which would stop the packet loop", i);
            ret = -1;
        }
    }
    if (ret == 0 && (sqmux_ctx[0]->fd != INVALID_SOCKET || socket_was_closed != 0 ||
        sqmux_ctx[1]->fd == INVALID_SOCKET || sqmux_ctx[1]->cnx != cnx_other)) {
        DBG_PRINTF("Socket 0 open: %d, closed rank: %d, socket 1 open: %d", sqmux_ctx[0]->fd != INVALID_SOCKET,
            socket_was_closed, sqmux_ctx[1]->fd != INVALID_SOCKET);
        ret = -1;
    }

    picoquic_packet_loop_free_qmux_socket(sqmux_ctx[0]);
    picoquic_packet_loop_free_qmux_socket(sqmux_ctx[1]);
    qmux_test_release(&sim_ctx);
    return ret;
}

int qmux_loop_tls_test(void)
{
    qmux_sim_spec_t spec = { 0 };
    spec.is_cleartext = 0;
    spec.idle_timeout = 15000;
    spec.expected_time = 90000;

    return qmux_loop_one(&spec);
}

int qmux_loop_tls_close_test(void)
{
    qmux_sim_spec_t spec = { 0 };
    spec.is_cleartext = 0;
    spec.test_close = 1;
    spec.idle_timeout = 15000;
    spec.expected_time = 90000;

    return qmux_loop_one(&spec);
}

/* Direct-call tests for the qmux.c frame-level parse/format/decode/skip functions --
 * these never got the same direct malformed-input testing as their frames.c equivalents,
 * since every existing qmux test above exercises them only indirectly through a full
 * end-to-end connection simulation (qmux_loop_one et al.), which only ever produces
 * well-formed frames in normal order. */
const uint8_t* picoquic_skip_qx_ping_frame(const uint8_t* bytes, const uint8_t* bytes_max);
const uint8_t* picoquic_parse_qx_ping_frame(const uint8_t* bytes, const uint8_t* bytes_max, uint64_t* sequence);
const uint8_t* picoquic_decode_qx_ping_frame(picoquic_cnx_t* cnx, const uint8_t* bytes, const uint8_t* bytes_max,
    uint64_t frame_type, uint64_t current_time);
uint8_t* picoquic_format_qx_ping_frame(picoquic_cnx_t* cnx, uint8_t* bytes, uint8_t* bytes_max, int is_response, int* more_data);
uint8_t* picoquic_format_qmux_tp_frame(picoquic_cnx_t* cnx, uint8_t* bytes, uint8_t* bytes_max);
const uint8_t* picoquic_decode_qmux_tp_frame(picoquic_cnx_t* cnx, const uint8_t* bytes, const uint8_t* bytes_max);

/* picoquic_skip_qx_ping_frame is never reached by any existing test: the skip-frame
 * dispatch path is only used for frames the receiver is choosing to ignore, and no qmux
 * test ever does that. */
int qmux_skip_qx_ping_frame_test(void)
{
    int ret = 0;
    uint8_t valid[] = { 42 };
    uint8_t truncated[] = { 0x40 }; /* 2-byte varint prefix with no second byte */
    const uint8_t* result;

    result = picoquic_skip_qx_ping_frame(valid, valid + sizeof(valid));
    if (result != valid + sizeof(valid)) {
        ret = -1;
    }
    if (ret == 0) {
        result = picoquic_skip_qx_ping_frame(truncated, truncated + sizeof(truncated));
        if (result != NULL) {
            ret = -1;
        }
    }
    return ret;
}

/* picoquic_parse_qx_ping_frame's truncated-input path was never exercised directly. */
int qmux_parse_qx_ping_frame_test(void)
{
    int ret = 0;
    uint8_t valid[] = { 42 };
    uint8_t truncated[] = { 0x40 };
    uint64_t sequence = 0;
    const uint8_t* result;

    result = picoquic_parse_qx_ping_frame(valid, valid + sizeof(valid), &sequence);
    if (result != valid + sizeof(valid) || sequence != 42) {
        ret = -1;
    }
    if (ret == 0) {
        sequence = 12345;
        result = picoquic_parse_qx_ping_frame(truncated, truncated + sizeof(truncated), &sequence);
        if (result != NULL) {
            ret = -1;
        }
    }
    return ret;
}

/* picoquic_decode_qx_ping_frame: the "not a QMux connection" guard, and the "response
 * sequence exactly matches the last sent query" (delta == 0, a normal acknowledgement)
 * branch, were never exercised -- the full end-to-end tests above only ever generate
 * out-of-order or strictly-in-order exchanges on a real QMux connection. */
int qmux_decode_qx_ping_frame_test(void)
{
    int ret = 0;
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    uint8_t query_bytes[] = { 5 };
    uint8_t response_bytes[] = { 5 };
    const uint8_t* result;

    if (picoquic_test_set_minimal_cnx(&quic, &cnx) != 0) {
        ret = -1;
    }
    else {
        cnx->is_qmux = 0;
        result = picoquic_decode_qx_ping_frame(cnx, query_bytes, query_bytes + sizeof(query_bytes),
            FRAME_TYPE_QX_PING, 0);
        if (result != NULL) {
            ret = -1;
        }

        if (ret == 0) {
            cnx->is_qmux = 1;
            cnx->qx_sent_last = 5;
            cnx->qx_acked_last = 0;
            result = picoquic_decode_qx_ping_frame(cnx, response_bytes, response_bytes + sizeof(response_bytes),
                FRAME_TYPE_QX_PING_R, 0);
            if (result == NULL || cnx->qx_acked_last != 5) {
                ret = -1;
            }
        }
    }
    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return ret;
}

/* picoquic_format_qx_ping_frame's buffer-too-small path was never exercised -- every
 * existing test formats into a full-size packet buffer. */
int qmux_format_qx_ping_frame_test(void)
{
    int ret = 0;
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    uint8_t buffer[1];
    int more_data = 0;
    uint8_t* result;

    if (picoquic_test_set_minimal_cnx(&quic, &cnx) != 0) {
        ret = -1;
    }
    else {
        cnx->qx_sent_last = 5;
        result = picoquic_format_qx_ping_frame(cnx, buffer, buffer + sizeof(buffer), 0, &more_data);
        if (result != buffer || more_data != 1) {
            ret = -1;
        }
    }
    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return ret;
}

/* picoquic_format_qmux_tp_frame's two failure paths -- not enough room even for the frame
 * type and length prefix, and enough room for those but not for the actual transport
 * parameters -- were never exercised, since every existing test formats into a full-size
 * buffer. */
int qmux_format_qmux_tp_frame_too_small_test(void)
{
    int ret = 0;
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    uint8_t tiny_buffer[2];
    uint8_t small_buffer[10];
    uint8_t* result;

    if (picoquic_test_set_minimal_cnx(&quic, &cnx) != 0) {
        ret = -1;
    }
    else {
        result = picoquic_format_qmux_tp_frame(cnx, tiny_buffer, tiny_buffer + sizeof(tiny_buffer));
        if (result != NULL) {
            ret = -1;
        }
        if (ret == 0) {
            result = picoquic_format_qmux_tp_frame(cnx, small_buffer, small_buffer + sizeof(small_buffer));
            if (result != NULL) {
                ret = -1;
            }
        }
    }
    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return ret;
}

/* picoquic_decode_qmux_tp_frame rejects a declared length that overruns the buffer --
 * never exercised, since every existing test decodes a well-formed frame produced by
 * picoquic_format_qmux_tp_frame itself. */
int qmux_decode_qmux_tp_frame_too_long_test(void)
{
    int ret = 0;
    picoquic_quic_t* quic = NULL;
    picoquic_cnx_t* cnx = NULL;
    uint8_t bytes[] = { 0x7F, 0xFF }; /* declares a 2-byte-varint length of 0x3FFF, far more than available */
    const uint8_t* result;

    if (picoquic_test_set_minimal_cnx(&quic, &cnx) != 0) {
        ret = -1;
    }
    else {
        result = picoquic_decode_qmux_tp_frame(cnx, bytes, bytes + sizeof(bytes));
        if (result != NULL) {
            ret = -1;
        }
    }
    picoquic_test_delete_minimal_cnx(&quic, &cnx);
    return ret;
}

