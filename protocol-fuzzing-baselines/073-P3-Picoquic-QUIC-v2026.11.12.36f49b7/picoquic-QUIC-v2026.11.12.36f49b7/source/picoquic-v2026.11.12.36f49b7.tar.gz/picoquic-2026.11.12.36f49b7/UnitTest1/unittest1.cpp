/*
* Author: Christian Huitema
* Copyright (c) 2017, Private Octopus, Inc.
* All rights reserved.
*
* Permission to use, copy, modify, and distribute this software for any
* purpose with or without fee is hereby granted, provided that the above
* copyright notice and this permission notice appear in all copies.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL Private Octopus, Inc. BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "CppUnitTest.h"
#include "picoquictest/picoquictest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{
	TEST_CLASS(UnitTest1)
	{
	public:
        TEST_CLASS_INITIALIZE(setup) {
            // avoid large debug spew that slows down the console.
            debug_printf_suspend();
        }

	    TEST_METHOD(picohash)
	    {
            int ret = picohash_test();

            Assert::AreEqual(ret, 0);
	    }

        TEST_METHOD(picohash_embedded)
        {
            int ret = picohash_embedded_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picohash_bytes)
        {
            int ret = picohash_bytes_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(siphash)
        {
            int ret = siphash_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picolog_basic)
        {
            int ret = picolog_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(logger_textlog_malformed_frame)
        {
            int ret = logger_textlog_malformed_frame_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(perflog_param_name)
        {
            int ret = perflog_param_name_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(perflog_file_is_empty)
        {
            int ret = perflog_file_is_empty_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(perflog_multi_cnx)
        {
            int ret = perflog_multi_cnx_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bytestream)
        {
            int ret = bytestream_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(connection_id_print)
        {
            int ret = util_connection_id_print_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(connection_id_parse)
        {
            int ret = util_connection_id_parse_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(connection_id_decode)
        {
            int ret = util_connection_id_decode_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(error_name)
        {
            int ret = error_name_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(util_sprintf)
        {
            int ret = util_sprintf_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(util_debug_print)
        {
            int ret = util_debug_print_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(util_debug_pop_stream)
        {
            int ret = util_debug_pop_stream_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(util_addr_text)
        {
            int ret = util_addr_text_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(util_uint8_to_str)
        {
            int ret = util_uint8_to_str_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(memcmp)
        {
            int ret = util_memcmp_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(threading)
        {
            int ret = util_threading_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wait_thread)
        {
            int ret = util_wait_thread_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(is_path_sane)
        {
            int ret = util_is_path_sane_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(set_addr_port)
        {
            int ret = util_set_addr_port_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(random_tester)
        {
            int ret = random_tester_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(random_gauss)
        {
            int ret = random_gauss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(random_public_tester)
        {
            int ret = random_public_tester_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_basic)
        {
            int ret = sockloop_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_time_check_stop)
        {
            int ret = sockloop_time_check_stop_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_eio)
        {
            int ret = sockloop_eio_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_errsock)
        {
            int ret = sockloop_errsock_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_ipv4)
        {
            int ret = sockloop_ipv4_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_send_err)
        {
            int ret = sockloop_send_err_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_bind_addr)
        {
            int ret = sockloop_bind_addr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_migration)
        {
            int ret = sockloop_migration_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_nat)
        {
            int ret = sockloop_nat_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_send_source)
        {
            int ret = sockloop_send_source_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_delete_thread_allocated_param)
        {
            int ret = sockloop_delete_thread_allocated_param_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_server_set_context)
        {
            int ret = sockloop_server_set_context_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_start_server_threads)
        {
            int ret = sockloop_start_server_threads_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_system_call_duration)
        {
            int ret = sockloop_system_call_duration_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_thread)
        {
            int ret = sockloop_thread_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_thread_name)
        {
            int ret = sockloop_thread_name_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_thread_null_callback)
        {
            int ret = sockloop_thread_null_callback_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_qmux)
        {
            int ret = sockloop_qmux_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_qmux_badp)
        {
            int ret = sockloop_qmux_badp_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_qmux_win_recv)
        {
            int ret = sockloop_qmux_win_recv_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_qmux_win_accept)
        {
            int ret = sockloop_qmux_win_accept_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_qmux_win_reset)
        {
            int ret = sockloop_qmux_win_reset_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_qmux_cnx_sockets_limit)
        {
            int ret = sockloop_qmux_cnx_sockets_limit_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_qmux_close)
        {
            int ret = sockloop_qmux_close_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_qmux_send_reset)
        {
            int ret = sockloop_qmux_send_reset_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sockloop_eintr)
        {
            int ret = sockloop_eintr_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(splay)
        {
            int ret = splay_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(rbtree)
        {
            int ret = rbtree_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(create_cnx)
        {
            int ret = create_cnx_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(create_quic)
        {
            int ret = create_quic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stateless_packet_queue_limit)
        {
            int ret = stateless_packet_queue_limit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(parse_header)
        {
            int ret = parseheadertest();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(incoming_initial)
        {
            int ret = incoming_initial_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(header_length)
        {
            int ret = header_length_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_pn2pn64)
        {
            int ret = pn2pn64test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_intformat)
        {
            int ret = intformattest();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(varints)
        {
            int ret = varint_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sqrt_for_test)
        {
            int ret = sqrt_for_test_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ack_sack)
        {
            int ret = sacktest();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(frames_skip)
        {
            int ret = skip_frame_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(frames_parse)
        {
            int ret = parse_frame_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(frames_repeat)
        {
            int ret = frames_repeat_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(frames_ackack_error)
        {
            int ret = frames_ackack_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(frames_ackof_error)
        {
            int ret = frames_ackof_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_stream_at_needs_repeat)
        {
            int ret = reset_stream_at_needs_repeat_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(crypto_hs_is_last)
        {
            int ret = crypto_hs_is_last_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(observed_address_ack_after_path_deleted)
        {
            int ret = observed_address_ack_after_path_deleted_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(process_ack_of_reset_stream_at)
        {
            int ret = process_ack_of_reset_stream_at_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stop_sending_needs_repeat)
        {
            int ret = stop_sending_needs_repeat_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_invalid_id)
        {
            int ret = stream_invalid_id_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_never_called_apis)
        {
            int ret = stream_never_called_apis_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(queue_multipath_blocked_frames)
        {
            int ret = queue_multipath_blocked_frames_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(skip_immediate_ack_frame)
        {
            int ret = skip_immediate_ack_frame_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_never_called_apis)
        {
            int ret = quicctx_never_called_apis_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(frames_format)
        {
            int ret = frames_format_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(flow_control_check_stream_offset)
        {
            int ret = flow_control_check_stream_offset_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(signal_stream_reset)
        {
            int ret = signal_stream_reset_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(null_callback_setters)
        {
            int ret = null_callback_setters_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_logger)
        {
            int ret = logger_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(binlog)
        {
            int ret = binlog_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(binlog_compare_mismatch)
        {
            int ret = binlog_compare_mismatch_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(unified_log_multi_backend)
        {
            int ret = unified_log_multi_backend_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qlog_frames)
        {
            int ret = qlog_frames_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(app_message_overflow)
        {
            int ret = app_message_overflow_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_TlsStreamFrame)
        {
            int ret = TlsStreamFrameTest();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_StreamZeroFrame)
        {
            int ret = StreamZeroFrameTest();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(stream_state_local_reuse)
        {
            int ret = stream_state_local_reuse_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_splay)
        {
            int ret = stream_splay_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_output)
        {
            int ret = stream_output_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(stream_retransmit_copy)
        {
            int ret = test_copy_for_retransmit();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(dataqueue_copy)
        {
            int ret = dataqueue_copy_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(dataqueue_packet)
        {
            int ret = dataqueue_packet_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(dataqueue_order)
        {
            int ret = dataqueue_order_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stateless_blowback) {
            int ret = test_stateless_blowback();

            Assert::AreEqual(ret, 0);
        }

		TEST_METHOD(ack_send)
		{
			int ret = sendacktest();

			Assert::AreEqual(ret, 0);
		}

        TEST_METHOD(ack_loop)
        {
            int ret = sendack_loop_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ack_range)
        {
            int ret = ackrange_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ack_disorder)
        {
            int ret = ack_disorder_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ack_horizon)
        {
            int ret = ack_horizon_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sack_list_unbounded_growth)
        {
            int ret = sack_list_unbounded_growth_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sack_list_stream_bytes_unbounded)
        {
            int ret = sack_list_stream_bytes_unbounded_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(sack_list_horizon_backward)
        {
            int ret = sack_list_horizon_backward_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ack_loss_since_sent)
        {
            int ret = ack_loss_since_sent_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ack_delay_per_path)
        {
            int ret = ack_delay_per_path_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ack_old_packets_loss)
        {
            int ret = ack_old_packets_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ack_of_ack)
        {
            int ret = ack_of_ack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ackfrq_basic)
        {
            int ret = ackfrq_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ackfrq_short)
        {
            int ret = ackfrq_short_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ackfrq_min_delay)
        {
            int ret = ackfrq_min_delay_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_sim_link)
        {
            int ret = sim_link_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cleartext_pn_enc)
        {
            int ret = cleartext_pn_enc_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cid_for_lb)
        {
            int ret = cid_for_lb_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cid_for_lb_cli)
        {
            int ret = cid_for_lb_cli_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retry_protection_vector)
        {
            int ret = retry_protection_vector_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retry_protection_v2)
        {
            int ret = retry_protection_v2_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(test_pn_enc_1rtt)
        {
            int ret = pn_enc_1rtt_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(not_decrypted_stash)
        {
            int ret = not_decrypted_stash_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(new_cnxid_stash)
        {
            int ret = cnxid_stash_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(new_cnxid)
        {
            int ret = new_cnxid_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(pacing)
        {
            int ret = pacing_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(pacing_repeat)
        {
            int ret = pacing_repeat_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(packet_names)
        {
            int ret = packet_names_test();

            Assert::AreEqual(ret, 0);
        }

		TEST_METHOD(test_tls_api)
		{
			int ret = tls_api_test();

			Assert::AreEqual(ret, 0);
		}

        TEST_METHOD(tls_handshake_pool_exhausted)
        {
            int ret = tls_handshake_pool_exhausted_test();

            Assert::AreEqual(ret, 0);
        }

#if 0
        /* The TLS API connect test is only useful when debugging issues step by step */
        TEST_METHOD(tls_api_connect)
        {
            int ret = tls_api_connect_test();

            Assert::AreEqual(ret, 0);
        }
#endif
        TEST_METHOD(tls_api_inject_hs_ack)
        {
            int ret = tls_api_inject_hs_ack_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(tls_exporter)
        {
            int ret = tls_exporter_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(null_sni)
        {
            int ret = null_sni_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(test_silence)
        {
            int ret = tls_api_silence_test();

            Assert::AreEqual(ret, 0);
        }

		TEST_METHOD(test_tls_api_first_loss)
		{
			int ret = tls_api_loss_test(1ull);

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(test_tls_api_second_loss)
		{
			int ret = tls_api_loss_test(2ull);

			Assert::AreEqual(ret, 0);
		}

        TEST_METHOD(test_server_first_loss)
        {
            int ret = tls_api_server_first_loss_test();

            Assert::AreEqual(ret, 0);
        }

		TEST_METHOD(test_tls_api_client_losses)
		{
			int ret = tls_api_client_losses_test();

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(test_tls_api_server_losses)
		{
			int ret = tls_api_server_losses_test();

			Assert::AreEqual(ret, 0);
		}

        TEST_METHOD(test_tls_api_many_losses)
        {
            int ret = tls_api_many_losses();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(initial_ping)
        {
            int ret = initial_ping_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(initial_ping_ack)
        {
            int ret = initial_ping_ack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram)
        {
            int ret = datagram_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram_rt)
        {
            int ret = datagram_rt_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram_rt_skip)
        {
            int ret = datagram_rt_skip_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram_rtnew_skip)
        {
            int ret = datagram_rtnew_skip_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram_loss)
        {
            int ret = datagram_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram_size)
        {
            int ret = datagram_size_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram_small)
        {
            int ret = datagram_small_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram_small_new)
        {
            int ret = datagram_small_new_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram_small_packet)
        {
            int ret = datagram_small_packet_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram_too_long)
        {
            int ret = datagram_too_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(datagram_wifi)
        {
            int ret = datagram_wifi_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ddos_amplification)
        {
            int ret = ddos_amplification_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ddos_amplification_0rtt)
        {
            int ret = ddos_amplification_0rtt_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ddos_amplification_8k)
        {
            int ret = ddos_amplification_8k_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(blackhole)
        {
            int ret = blackhole_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(no_ack_frequency)
        {
            int ret = no_ack_frequency_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(immediate_ack)
        {
            int ret = immediate_ack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(connection_drop)
        {
            int ret = connection_drop_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(code_version) {
            int ret = code_version_test();

            Assert::AreEqual(ret, 0);
        }

		TEST_METHOD(version_negotiation)
		{
			int ret = tls_api_version_negotiation_test();

			Assert::AreEqual(ret, 0);
		}

        TEST_METHOD(version_invariant)
        {
            int ret = tls_api_version_invariant_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(version_negotiation_spoof)
        {
            int ret = test_version_negotiation_spoof();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wrong_source_addr_initial)
        {
            int ret = wrong_source_addr_initial_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wrong_source_addr_vn)
        {
            int ret = wrong_source_addr_vn_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wrong_source_addr_retry)
        {
            int ret = wrong_source_addr_retry_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(vn_tp)
        {
            int ret = vn_tp_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(vn_compat)
        {
            int ret = vn_compat_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(vn_upgrade)
        {
            int ret = vn_upgrade_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(transport_param_default) {
            int ret = transport_param_default_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_rank)
        {
            int ret = stream_rank_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_id_limit)
        {
            int ret = stream_id_limit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(provide_stream_buffer)
        {
            int ret = provide_stream_buffer_test();

            Assert::AreEqual(ret, 0);
        }

		TEST_METHOD(transport_param)
		{
			int ret = transport_param_test();

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(test_tls_api_sni)
		{
			int ret = tls_api_sni_test();

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(test_tls_api_alpn)
		{
			int ret = tls_api_alpn_test();

			Assert::AreEqual(ret, 0);
		}

        TEST_METHOD(tls_x25519)
        {
            int ret = tls_x25519_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(tls_x25519mlkem)
        {
            int ret = tls_x25519mlkem_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(tls_api_dispose_certificate_verifier)
        {
            int ret = tls_api_dispose_certificate_verifier_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(tls_api_remove_ticket)
        {
            int ret = tls_api_remove_ticket_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(tls_api_null_arg_checks)
        {
            int ret = tls_api_null_arg_checks_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(tls_api_server_decrypt_short_token)
        {
            int ret = tls_api_server_decrypt_short_token_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(tls_api_set_key_exchange_no_master)
        {
            int ret = tls_api_set_key_exchange_no_master_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(tls_api_set_key_log_file_twice)
        {
            int ret = tls_api_set_key_log_file_twice_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(tls_api_verify_retry_protection_short)
        {
            int ret = tls_api_verify_retry_protection_short_test();

            Assert::AreEqual(ret, 0);
        }

		TEST_METHOD(test_tls_api_wrong_alpn)
		{
			int ret = tls_api_wrong_alpn_test();

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(test_one_way_stream)
		{
			int ret = tls_api_oneway_stream_test();

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(test_q_and_r_stream)
		{
			int ret = tls_api_q_and_r_stream_test();

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(test_q2_and_r2_stream)
		{
			int ret = tls_api_q2_and_r2_stream_test();

			Assert::AreEqual(ret, 0);
		}

        TEST_METHOD(implicit_ack)
        {
            int ret = implicit_ack_test();

            Assert::AreEqual(ret, 0);
        }

		TEST_METHOD(stateless_reset)
		{
			int ret = stateless_reset_test();

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(stateless_reset_bad)
		{
			int ret = stateless_reset_bad_test();

			Assert::AreEqual(ret, 0);
		}

        TEST_METHOD(stateless_reset_client)
        {
            int ret = stateless_reset_client_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stateless_reset_handshake)
        {
            int ret = stateless_reset_handshake_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(immediate_close)
        {
            int ret = immediate_close_test();

            Assert::AreEqual(ret, 0);
        }

		TEST_METHOD(test_very_long_stream)
		{
			int ret = tls_api_very_long_stream_test();

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(test_very_long_max)
		{
			int ret = tls_api_very_long_max_test();

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(test_very_long_with_err)
		{
			int ret = tls_api_very_long_with_err_test();

			Assert::AreEqual(ret, 0);
		}

		TEST_METHOD(test_very_long_congestion)
		{
			int ret = tls_api_very_long_congestion_test();

			Assert::AreEqual(ret, 0);
		}

        TEST_METHOD(retry)
        {
            int ret = tls_api_retry_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retry_large)
        {
            int ret = tls_api_retry_large_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retry_token)
        {
            int ret = tls_retry_token_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retry_token_valid)
        {
            int ret = tls_retry_token_valid_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(test_two_connections)
        {
            int ret = tls_api_two_connections_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_cleartext_aead)
        {
            int ret = cleartext_aead_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_multiple_versions)
        {
            int ret = tls_api_multiple_versions_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_keep_alive)
        {
          int ret = keep_alive_test();

          Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(keep_alive_idle)
        {
            int ret = keep_alive_idle_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(integrity_limit)
        {
            int ret = integrity_limit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(excess_repeat)
        {
            int ret = excess_repeat_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(netperf_basic)
        {
            int ret = netperf_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(netperf_bbr)
        {
            int ret = netperf_bbr_test();

            Assert::AreEqual(ret, 0);
        }

        /* test disabled because the results are not consistent. */
        TEST_METHOD(nat_attack)
        {
            int ret = nat_attack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_sockets)
        {
            int ret = socket_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_sockets_ecn)
        {
            int ret = socket_ecn_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_sockets_cloexec)
        {
            int ret = socket_cloexec_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(ticket_store)
        {
            int ret = ticket_store_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ticket_store_save_wrappers)
        {
            int ret = ticket_store_save_wrappers_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ticket_store_too_short)
        {
            int ret = ticket_store_too_short_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ticket_store_load_padded_record)
        {
            int ret = ticket_store_load_padded_record_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ticket_seed)
        {
            int ret = ticket_seed_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ticket_seed_from_bdp_frame)
        {
            int ret = ticket_seed_from_bdp_frame_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_store)
        {
            int ret = token_store_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_store_format_zero_ip)
        {
            int ret = token_store_format_zero_ip_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_store_serialize_too_small)
        {
            int ret = token_store_serialize_too_small_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_store_deserialize_short)
        {
            int ret = token_store_deserialize_short_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_store_store_invalid_params)
        {
            int ret = token_store_store_invalid_params_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_store_load_oversized_record)
        {
            int ret = token_store_load_oversized_record_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_store_load_record_size_overflow)
        {
            int ret = token_store_load_record_size_overflow_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_store_load_truncated)
        {
            int ret = token_store_load_truncated_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_store_load_padded_record)
        {
            int ret = token_store_load_padded_record_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_reuse_api)
        {
            int ret = token_reuse_api_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(token_reuse_cap)
        {
            int ret = token_reuse_cap_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_session_resume)
        {
            int ret = session_resume_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(zero_rtt)
        {
            int ret = zero_rtt_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(zero_rtt_loss)
        {
            int ret = zero_rtt_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stop_sending)
        {
            int ret = stop_sending_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stop_sending_loss)
        {
            int ret = stop_sending_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(discard_stream)
        {
            int ret = discard_stream_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_unidir)
        {
            int ret = unidir_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(many_short_loss)
        {
            int ret = many_short_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_discovery)
        {
            int ret = mtu_discovery_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_blocked)
        {
            int ret = mtu_blocked_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_delayed)
        {
            int ret = mtu_delayed_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_required)
        {
            int ret = mtu_required_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_max)
        {
            int ret = mtu_max_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_drop_bbr)
        {
            int ret = mtu_drop_bbr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_drop_cubic)
        {
            int ret = mtu_drop_cubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_drop_dcubic)
        {
            int ret = mtu_drop_dcubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_drop_fast)
        {
            int ret = mtu_drop_fast_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_drop_newreno)
        {
            int ret = mtu_drop_newreno_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mtu_drop_bbr1)
        {
            int ret = mtu_drop_bbr1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(red_bbr)
        {
            int ret = red_bbr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(red_cubic)
        {
            int ret = red_cubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(red_dcubic)
        {
            int ret = red_dcubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(red_fast)
        {
            int ret = red_fast_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(red_newreno)
        {
            int ret = red_newreno_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multi_segment)
        {
            int ret = multi_segment_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(pacing_bbr)
        {
            int ret = pacing_bbr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(pacing_cubic)
        {
            int ret = pacing_cubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(pacing_dcubic)
        {
            int ret = pacing_dcubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(pacing_fast)
        {
            int ret = pacing_fast_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(pacing_newreno)
        {
            int ret = pacing_newreno_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(heavy_loss)
        {
            int ret = heavy_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(heavy_loss_inter)
        {
            int ret = heavy_loss_inter_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(heavy_loss_total)
        {
            int ret = heavy_loss_total_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_spurious_retransmit)
        {
            int ret = spurious_retransmit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_pn_ctr)
        {
            int ret = pn_ctr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_tls_zero_share)
        {
            int ret = tls_zero_share_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(key_rotation_vector)
        {
            int ret = key_rotation_vector_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(keylog) {
            int ret = keylog_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(draft17_vector)
        {
            int ret = draft17_vector_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(dtn_basic)
        {
            int ret = dtn_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(dtn_data)
        {
            int ret = dtn_data_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(dtn_silence)
        {
            int ret = dtn_silence_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(dtn_twenty)
        {
            int ret = dtn_twenty_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_transport_param_log)
        {
            int ret = transport_param_log_test();

            Assert::AreEqual(ret, 0);
        }


        TEST_METHOD(client_cert_callback)
        {
            int ret = set_verify_certificate_callback_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(client_cert_verification_policy)
        {
            int ret = client_cert_verification_policy_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(client_auth)
        {
          int ret = request_client_authentication_test();

          Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(client_auth_25519)
        {
          int ret = request_client_authentication_25519_test();

          Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(virtual_time)
        {
            int ret = virtual_time_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_different_params)
        {
            int ret = tls_different_params_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_quant_params)
        {
            int ret = tls_quant_params_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_set_certificate_and_key)
        {
            int ret = set_certificate_and_key_test();

            Assert::AreEqual(ret, 0);
        }
    
        TEST_METHOD(test_bad_client_certificate)
        {
            int ret = bad_client_certificate_test();

            Assert::AreEqual(ret, 0);
        }
    
        TEST_METHOD(nat_rebinding)
        {
            int ret = nat_rebinding_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(nat_rebinding_loss)
        {
            int ret = nat_rebinding_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(nat_rebinding_zero)
        {
            int ret = nat_rebinding_zero_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(nat_rebinding_latency)
        {
            int ret = nat_rebinding_latency_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(nat_rebinding_fast)
        {
            int ret = fast_nat_rebinding_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(path_challenge_ack)
        {
            int ret = path_challenge_ack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(spinbit)
        {
            int ret = spinbit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(spinbit_bad)
        {
            int ret = spinbit_bad_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(spinbit_null)
        {
            int ret = spinbit_null_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(spinbit_random)
        {
            int ret = spinbit_random_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(spinbit_randclient)
        {
            int ret = spinbit_randclient_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(loss_bit)
        {
            int ret = loss_bit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_client_error)
        {
            int ret = client_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(client_only)
        {
            int ret = client_only_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_packet_enc_dec)
        {
            int ret = packet_enc_dec_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_pn_vector)
        {
            int ret = cleartext_pn_vector_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(zero_rtt_spurious)
        {
            int ret = zero_rtt_spurious_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(zero_rtt_bad_param)
        {
            int ret = zero_rtt_bad_param_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(zero_rtt_retry)
        {
            int ret = zero_rtt_retry_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(zero_rtt_no_coal)
        {
            int ret = zero_rtt_no_coal_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(zero_rtt_many_losses)
        {
            int ret = zero_rtt_many_losses_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(zero_rtt_long)
        {
            int ret = zero_rtt_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(zero_rtt_delay)
        {
            int ret = zero_rtt_delay_test();

            Assert::AreEqual(ret, 0);
        }
#if 0
        TEST_METHOD(zero_rtt_ech) {
            int ret = zero_rtt_ech_test();

            Assert::AreEqual(ret, 0);
        }
#endif
        TEST_METHOD(zero_rtt_refused) {
            int ret = zero_rtt_refused_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cnxid_transmit)
        {
            int ret = transmit_cnxid_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cnxid_transmit_disable)
        {
            int ret = transmit_cnxid_disable_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cnxid_transmit_r_before)
        {
            int ret = transmit_cnxid_retire_before_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cnxid_transmit_r_disable){
            int ret = transmit_cnxid_retire_disable_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cnxid_transmit_r_early){
            int ret = transmit_cnxid_retire_early_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_probe_api)
        {
            int ret = probe_api_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(memlog)
        {
            int ret= memlog_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(migration)
        {
            int ret = migration_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(migration_long)
        {
            int ret = migration_test_long();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(migration_loss)
        {
            int ret = migration_test_loss();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(migration_zero)
        {
            int ret = migration_zero_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(migration_fail)
        {
            int ret = migration_fail_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(preferred_address)
        {
            int ret = preferred_address_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(preferred_address_dis_mig)
        {
            int ret = preferred_address_dis_mig_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(preferred_address_zero)
        {
            int ret = preferred_address_zero_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(test_cnxid_renewal)
        {
            int ret = cnxid_renewal_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_late_packet)
        {
            int ret = retired_cnxid_late_packet_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_cap)
        {
            int ret = retired_cnxid_cap_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_arrival_kept)
        {
            int ret = retired_cnxid_arrival_kept_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_not_reused)
        {
            int ret = retired_cnxid_not_reused_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_path_deleted)
        {
            int ret = retired_cnxid_path_deleted_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_nat_rebinding)
        {
            int ret = retired_cnxid_nat_rebinding_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_no_renew)
        {
            int ret = retired_cnxid_no_renew_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_scone)
        {
            int ret = retired_cnxid_scone_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_bound)
        {
            int ret = retired_cnxid_bound_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_new_cid_no_repeat)
        {
            int ret = retired_cnxid_new_cid_no_repeat_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(retired_cnxid_expired_count)
        {
            int ret = retired_cnxid_expired_count_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_retire_cnxid)
        {
            int ret = retire_cnxid_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(not_before_cnxid)
        {
            int ret = not_before_cnxid_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(test_server_busy)
        {
            int ret = server_busy_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(initial_close)
        {
            int ret = initial_close_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(initial_server_close)
        {
            int ret = initial_server_close_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(new_rotated_key)
        {
            int ret = new_rotated_key_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(key_rotation)
        {
            int ret = key_rotation_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(key_rotation_server)
        {
            int ret = key_rotation_auto_server();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(key_rotation_client)
        {
            int ret = key_rotation_auto_client();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(key_rotation_stress)
        {
            int ret = key_rotation_stress_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(false_migration)
        {
            int ret = false_migration_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(nat_handshake)
        {
            int ret = nat_handshake_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(short_initial_cid)
        {
            int ret = short_initial_cid_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_id_max)
        {
            int ret = stream_id_max_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(padding)
        {
            int ret = padding_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(padding_null)
        {
            int ret = padding_null_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(padding_zero_min)
        {
            int ret = padding_zero_min_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(packet_trace)
        {
            int ret = packet_trace_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(log_packet_limit)
        {
            int ret = log_packet_limit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qlog_auto)
        {
            int ret = qlog_auto_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qlog_error)
        {
            int ret = qlog_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qlog_fns_trim_path_contexts)
        {
            int ret = qlog_fns_trim_path_contexts_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qlog_quic_fallback)
        {
            int ret = qlog_quic_fallback_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qlog_max_simultaneous_logs)
        {
            int ret = qlog_max_simultaneous_logs_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qlog_trace)
        {
            int ret = qlog_trace_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qlog_trace_ecn)
        {
            int ret = qlog_trace_ecn_test();

            Assert::AreEqual(ret, 0);
        }


        TEST_METHOD(qlog_trace_parallel)
        {
            int ret = qlog_trace_parallel_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qlog_fns)
        {
            int ret = qlog_fns_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qlog_fns_ecn)
        {
            int ret = qlog_fns_ecn_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive)
        {
            int ret = qmux_receive_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_send)
        {
            int ret = qmux_send_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_send_tp)
        {
            int ret = qmux_send_tp_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_tp)
        {
            int ret = qmux_receive_tp_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_app_close)
        {
            int ret = qmux_receive_app_close_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_cnx_close)
        {
            int ret = qmux_receive_cnx_close_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_errors)
        {
            int ret = qmux_receive_errors_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_prohibited_frames)
        {
            int ret = qmux_receive_prohibited_frames_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_allowed_frames)
        {
            int ret = qmux_receive_allowed_frames_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_extension_tp_ignore)
        {
            int ret = qmux_receive_extension_tp_ignore_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_datagram)
        {
            int ret = qmux_datagram_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_stream_order)
        {
            int ret = qmux_receive_stream_order_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_stream_order_edges)
        {
            int ret = qmux_receive_stream_order_edges_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_record_errors)
        {
            int ret = qmux_receive_record_errors_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_empty_record)
        {
            int ret = qmux_receive_empty_record_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_split_record)
        {
            int ret = qmux_receive_split_record_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_qx_ping)
        {
            int ret = qmux_receive_qx_ping_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_receive_qx_ping_order)
        {
            int ret = qmux_receive_qx_ping_order_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_send_qx_ping_r)
        {
            int ret = qmux_send_qx_ping_r_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_send_qx_ping_r_append)
        {
            int ret = qmux_send_qx_ping_r_append_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_send_cnx_close)
        {
            int ret = qmux_send_cnx_close_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_loop)
        {
            int ret = qmux_loop_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_loop_delay)
        {
            int ret = qmux_loop_delay_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_loop_idle)
        {
            int ret = qmux_loop_idle_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_socket_accept)
        {
            int ret = qmux_socket_accept_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_socket_close_on_receive)
        {
            int ret = qmux_socket_close_on_receive_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_loop_tls)
        {
            int ret = qmux_loop_tls_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_tls_client_alpn_required)
        {
            int ret = qmux_tls_client_alpn_required_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_tls_handshake_idle_timeout)
        {
            int ret = qmux_tls_handshake_idle_timeout_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_tls_handshake_idle_timeout_loop)
        {
            int ret = qmux_tls_handshake_idle_timeout_loop_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_loop_tls_close)
        {
            int ret = qmux_loop_tls_close_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_skip_qx_ping_frame)
        {
            int ret = qmux_skip_qx_ping_frame_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_parse_qx_ping_frame)
        {
            int ret = qmux_parse_qx_ping_frame_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_decode_qx_ping_frame)
        {
            int ret = qmux_decode_qx_ping_frame_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_format_qx_ping_frame)
        {
            int ret = qmux_format_qx_ping_frame_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_format_qmux_tp_frame_too_small)
        {
            int ret = qmux_format_qmux_tp_frame_too_small_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qmux_decode_qmux_tp_frame_too_long)
        {
            int ret = qmux_decode_qmux_tp_frame_too_long_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_context_from_epoch)
        {
            int ret = quicctx_context_from_epoch_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_adjust_max_connections)
        {
            int ret = quicctx_adjust_max_connections_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_set_default_address_discovery_mode)
        {
            int ret = quicctx_set_default_address_discovery_mode_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_is_local_cid)
        {
            int ret = quicctx_is_local_cid_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_get_path_addr)
        {
            int ret = quicctx_get_path_addr_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_set_stream_path_affinity)
        {
            int ret = quicctx_set_stream_path_affinity_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_verify_proposed_tuple_family_mismatch)
        {
            int ret = quicctx_verify_proposed_tuple_family_mismatch_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_probe_new_tuple_family_mismatch)
        {
            int ret = quicctx_probe_new_tuple_family_mismatch_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_remember_issued_ticket_oversized_addr)
        {
            int ret = quicctx_remember_issued_ticket_oversized_addr_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicctx_check_new_path_allowed_limit)
        {
            int ret = quicctx_check_new_path_allowed_limit_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(perflog)
        {
            int ret = perflog_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(nat_rebinding_stress)
        {
            int ret = rebinding_stress_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(nat_rebinding_stress_dead_tuple)
        {
            int ret = rebinding_stress_dead_tuple_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(nat_rebinding_stress_cid_exhaustion)
        {
            int ret = rebinding_stress_cid_exhaustion_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(random_padding)
        {
            int ret = random_padding_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ec00_zero)
        {
            int ret = ec00_zero_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ec2f_second_flight)
        {
            int ret = ec2f_second_flight_nack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(eccf_corrupted_fuzz)
        {
            int ret = eccf_corrupted_file_fuzz_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(eca1_amplification_loss)
        {
            int ret = eca1_amplification_loss_test();

            Assert::AreEqual(ret, 0);
        }


        TEST_METHOD(ecf1_final_loss)
        {
            int ret = ecf1_final_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ecdc_double_close)
        {
            int ret = ecdc_double_close_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ec5c_silly_cid)
        {
            int ret = ec5c_silly_cid_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ec9a_preemptive_amok)
        {
            int ret = ec9a_preemptive_amok_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ecb1_packet_too_big)
        {
            int ret = ec2b_packet_too_big_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(error_reason)
        {
            int ret = error_reason_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(idle_server)
        {
            int ret = idle_server_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(idle_timeout)
        {
            int ret = idle_timeout_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_ack_max)
        {
            int ret = reset_ack_max_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(reset_ack_reset)
        {
            int ret = reset_ack_reset_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_extra_max)
        {
            int ret = reset_extra_max_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_extra_reset)
        {
            int ret = reset_extra_reset_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(reset_extra_stop)
        {
            int ret = reset_extra_stop_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_need_max)
        {
            int ret = reset_need_max_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(reset_need_reset)
        {
            int ret = reset_need_reset_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_need_stop)
        {
            int ret = reset_need_stop_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_at_end)
        {
            int ret = reset_at_end_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_after_fin_received)
        {
            int ret = reset_after_fin_received_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_deleted)
        {
            int ret = reset_deleted_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_loop)
        {
            int ret = reset_loop_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_stream_at_basic) {
            int ret = reset_stream_at_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_stream_at_limit) {
            int ret = reset_stream_at_limit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(reset_stream_at_loss) {
            int ret = reset_stream_at_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_data_nodes) {
            int ret = stream_data_nodes_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_data_nodes_attack) {
            int ret = stream_data_nodes_attack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_data_nodes_window) {
            int ret = stream_data_nodes_window_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_data_nodes_limit) {
            int ret = stream_data_nodes_limit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(direct_receive_duplicate) {
            int ret = direct_receive_duplicate_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(direct_receive_flow_control) {
            int ret = direct_receive_flow_control_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(initial_pto)
        {
            int ret = initial_pto_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(initial_pto_srv)
        {
            int ret = initial_pto_srv_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ready_to_send)
        {
            int ret = ready_to_send_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(ready_to_skip)
        {
            int ret = ready_to_skip_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ready_to_zero)
        {
            int ret = ready_to_zero_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ready_to_zfin)
        {
            int ret= ready_to_zfin_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(crypto_hs_offset)
        {
            int ret = crypto_hs_offset_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cubic)
        {
            int ret = cubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cubic_jitter)
        {
            int ret = cubic_jitter_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(c4)
        {
            int ret = c4_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(c4_jitter)
        {
            int ret = c4_jitter_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_compete_cubic2)
        {
            int ret = cc_compete_cubic2_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_compete_c4c4)
        {
            int ret = cc_compete_c4c4_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_compete_prague2)
        {
            int ret = cc_compete_prague2_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_compete_d_cubic)
        {
            int ret = cc_compete_d_cubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_asym)
        {
            int ret = cc_ns_asym_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_blackhole)
        {
            int ret = cc_ns_blackhole_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_drop_and_back)
        {
            int ret = cc_ns_drop_and_back_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_low_and_up)
        {
            int ret = cc_ns_low_and_up_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_wifi_fade)
        {
            int ret = cc_ns_wifi_fade_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_wifi_suspension)
        {
            int ret = cc_ns_wifi_suspension_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_wifi_bad_cubic)
        {
            int ret = cc_ns_wifi_bad_cubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_wifi_bad_bbr)
        {
            int ret = cc_ns_wifi_bad_bbr_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(cc_ns_varylink)
        {
            int ret = cc_ns_varylink_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_satellite)
        {
            int ret = cc_ns_satellite_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_media)
        {
            int ret = cc_ns_media_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_media_repeat)
        {
            int ret = cc_ns_media_repeat_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_bad_scenario)
        {
            int ret = cc_ns_bad_scenario_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_no_connections)
        {
            int ret = cc_ns_no_connections_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_bad_link_scenario)
        {
            int ret = cc_ns_bad_link_scenario_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_bad_qperf_log)
        {
            int ret = cc_ns_bad_qperf_log_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_target_time_exceeded)
        {
            int ret = cc_ns_target_time_exceeded_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_connection_error)
        {
            int ret = cc_ns_connection_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_ns_varylink_zero_rate)
        {
            int ret = cc_ns_varylink_zero_rate_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(fastcc)
        {
            int ret = fastcc_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(fastcc_jitter)
        {
            int ret = fastcc_jitter_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(flow_control)
        {
            int ret = flow_control_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(flow_control_open_max)
        {
            int ret = flow_control_open_max_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_uni_blocked)
        {
            int ret = stream_uni_blocked_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(stream_uni_reactivate)
        {
            int ret = stream_uni_reactivate_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr)
        {
            int ret = bbr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr_jitter)
        {
            int ret = bbr_jitter_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr_long)
        {
            int ret = bbr_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(c4_long)
        {
            int ret = c4_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr_performance)
        {
            int ret = bbr_performance_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr_slow_long)
        {
            int ret = bbr_slow_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr_one_second)
        {
            int ret = bbr_one_second_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr_gbps)
        {
            int ret = gbps_performance_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr_asym100)
        {
            int ret = bbr_asym100_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr_asym100_nodelay)
        {
            int ret = bbr_asym100_nodelay_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr_asym400)
        {
            int ret = bbr_asym400_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_lost_feedback_ack_only)
        {
            int ret = cc_lost_feedback_ack_only_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cc_reset_gate)
        {
            int ret = cc_reset_gate_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr1)
        {
            int ret = bbr1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bbr1_long)
        {
            int ret = bbr1_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(l4s_reno)
        {
            int ret = l4s_reno_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(l4s_prague)
        {
            int ret = l4s_prague_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(l4s_prague_updown)
        {
            int ret = l4s_prague_updown_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(l4s_prague_shallow)
        {
            int ret = l4s_prague_shallow_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(l4s_prague_long_rtt)
        {
            int ret = l4s_prague_long_rtt_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(l4s_c4)
        {
            int ret = l4s_c4_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(l4s_bbr)
        {
            int ret = l4s_bbr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(l4s_bbr1)
        {
            int ret = l4s_bbr1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(l4s_bbr_updown)
        {
            int ret = l4s_bbr_updown_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(long_rtt)
        {
            int ret = long_rtt_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(high_latency_basic)
        {
            int ret = high_latency_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(high_latency_bbr)
        {
            int ret = high_latency_bbr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(high_latency_cubic)
        {
            int ret = high_latency_cubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(high_latency_probeRTT)
        {
            int ret = high_latency_probeRTT_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cid_length)
        {
            int ret = cid_length_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(optimistic_ack)
        {
            int ret = optimistic_ack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(optimistic_hole)
        {
            int ret = optimistic_hole_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bad_coalesce)
        {
            int ret = bad_coalesce_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bad_cnxid)
        {
            int ret = bad_cnxid_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(document_addresses)
        {
            int ret = document_addresses_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(migration_disabled)
        {
            int ret = migration_disabled_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(large_client_hello) {
            int ret = large_client_hello_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(limited_reno) {
            int ret = limited_reno_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(limited_batch) {
            int ret = limited_batch_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(limited_cubic) {
            int ret = limited_cubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(limited_bbr) {
            int ret = limited_bbr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(limited_safe) {
            int ret = limited_safe_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(send_stream_blocked) {
            int ret = send_stream_blocked_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_basic) {
            int ret = scone_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_client) {
            int ret = scone_client_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_loss) {
            int ret = scone_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_loss_client) {
            int ret = scone_loss_client_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_loss_server) {
            int ret = scone_loss_server_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_none) {
            int ret = scone_none_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_server) {
            int ret = scone_server_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_padding_short_length) {
            int ret = scone_padding_short_length_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_padding_indicator_already_sent) {
            int ret = scone_padding_indicator_already_sent_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_format_packet_too_small) {
            int ret = scone_format_packet_too_small_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_prepare_format_failure) {
            int ret = scone_prepare_format_failure_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(scone_report_guards) {
            int ret = scone_report_guards_test();

            Assert::AreEqual(ret, 0);
        }


        TEST_METHOD(stream_ack) {
            int ret = stream_ack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(queue_network_input) {
            int ret = queue_network_input_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(pacing_update) {
            int ret = pacing_update_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quality_update) {
            int ret = quality_update_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(direct_receive) {
            int ret = direct_receive_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(address_discovery) {
            int ret = address_discovery_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(af_undef) {
            int ret = af_undef_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(app_limit_cc) {
            int ret = app_limit_cc_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(app_limited_bbr) {
            int ret = app_limited_bbr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(app_limited_bbr1) {
            int ret = app_limited_bbr1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(app_limited_cubic) {
            int ret = app_limited_cubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(app_limited_reno) {
            int ret = app_limited_reno_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(app_limited_rpr) {
            int ret = app_limited_rpr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(app_limited_cubic_idle) {
            int ret = app_limited_cubic_idle_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cwin_max) {
            int ret = cwin_max_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(bbr1_seed_bdp) {
            int ret = bbr1_seed_bdp_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(bbr1_seed_startup) {
            int ret = bbr1_seed_startup_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(bbr1_ltbw) {
            int ret = bbr1_ltbw_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(bbr1_ltbw_edge) {
            int ret = bbr1_ltbw_edge_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(fastcc_notify) {
            int ret = fastcc_notify_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(c4_notify) {
            int ret = c4_notify_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(c4_seed_resuming) {
            int ret = c4_seed_resuming_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(prague_notify) {
            int ret = prague_notify_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(prague_ecn_recovery) {
            int ret = prague_ecn_recovery_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(cc_algo_reset) {
            int ret = cc_algo_reset_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(cc_common_slow_start_increase) {
            int ret = cc_common_slow_start_increase_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(initial_race) {
            int ret = initial_race_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(chacha20) {
            int ret = chacha20_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(aegis_cipher_suite) {
            int ret = aegis_cipher_suite_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(aegis_hp_vector) {
            int ret = aegis_hp_vector_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(aegis128l) {
            int ret = aegis128l_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(aegis256) {
            int ret = aegis256_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(aegis_fallback) {
            int ret = aegis_fallback_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(aegis_0rtt) {
            int ret = aegis_0rtt_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(aegis_retry) {
            int ret = aegis_retry_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(aegis_initial_aes) {
            int ret = aegis_initial_aes_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cnx_limit) {
            int ret = cnx_limit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cert_verify_bad_cert) {
            int ret = cert_verify_bad_cert_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cert_verify_bad_sni) {
            int ret = cert_verify_bad_sni_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cert_verify_null) {
            int ret = cert_verify_null_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cert_verify_null_sni) {
            int ret = cert_verify_null_sni_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cert_verify_rsa) {
            int ret = cert_verify_rsa_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cert_verify_invalid)
        {
            int ret = cert_verify_invalid_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cid_quiescence) {
            int ret = cid_quiescence_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_video) {
            int ret = mediatest_video_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_video_audio) {
            int ret = mediatest_video_audio_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_video_data_audio) {
            int ret = mediatest_video_data_audio_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_video2_down) {
            int ret = mediatest_video2_down_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_video2_back) {
            int ret = mediatest_video2_back_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_video2_probe) {
            int ret = mediatest_video2_probe_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_wifi) {
            int ret = mediatest_wifi_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_worst) {
            int ret = mediatest_worst_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_no_coal) {
            int ret = mediatest_no_coal_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_suspension) {
            int ret = mediatest_suspension_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(mediatest_suspension2) {
            int ret = mediatest_suspension2_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(warptest_video) {
            int ret = warptest_video_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(warptest_video_audio) {
            int ret = warptest_video_audio_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(warptest_video_data_audio) {
            int ret = warptest_video_data_audio_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(warptest_worst) {
            int ret = warptest_worst_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(warptest_param) {
            int ret = warptest_param_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_bbr) {
            int ret = wifi_bbr_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_bbr_hard) {
            int ret = wifi_bbr_hard_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_bbr_long) {
            int ret = wifi_bbr_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_bbr_many) {
            int ret = wifi_bbr_many_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_bbr_shadow) {
            int ret = wifi_bbr_shadow_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_bbr1)
        {
            int ret = wifi_bbr1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_bbr1_hard) {
            int ret = wifi_bbr1_hard_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_bbr1_long) {
            int ret = wifi_bbr1_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_cubic) {
            int ret = wifi_cubic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_cubic_hard) {
            int ret = wifi_cubic_hard_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_cubic_long) {
            int ret = wifi_cubic_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_reno) {
            int ret = wifi_reno_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_reno_hard) {
            int ret = wifi_reno_hard_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wifi_reno_long) {
            int ret = wifi_reno_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(openssl_cert) {
            int ret = openssl_cert_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(migration_controlled) {
            int ret = migration_controlled_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(migration_mtu_drop) {
            int ret = migration_mtu_drop_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(migration_new_ip) {
            int ret = migration_new_ip_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(migration_retire_old_cid) {
            int ret = migration_retire_old_cid_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(minicrypto) {
            int ret = minicrypto_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(minicrypto_is_last ){
            int ret = minicrypto_is_last_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(monopath_basic) {
            int ret = monopath_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(monopath_hole) {
            int ret= monopath_hole_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(monopath_keep_alive) {
            int ret = monopath_keep_alive_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(monopath_rotation) {
            int ret = monopath_rotation_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(monopath_0rtt) {
            int ret = monopath_0rtt_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(monopath_0rtt_loss) {
            int ret = monopath_0rtt_loss_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(multipath_aead) {
            int ret = multipath_aead_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_basic) {
            int ret = multipath_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_drop_first) {
            int ret = multipath_drop_first_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_drop_second) {
            int ret = multipath_drop_second_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_drop_first_c2s) {
            int ret = multipath_drop_first_c2s_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_drop_first_s2c) {
            int ret = multipath_drop_first_s2c_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_fail) {
            int ret = multipath_fail_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_ab1) {
            int ret = multipath_ab1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_sat_plus) {
            int ret = multipath_sat_plus_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_renew) {
            int ret = multipath_renew_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_rotation) {
            int ret = multipath_rotation_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_nat) {
            int ret = multipath_nat_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_nat_challenge) {
            int ret = multipath_nat_challenge_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_break1) {
            int ret = multipath_break1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_socket_error) {
            int ret = multipath_socket_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_socket0_error) {
            int ret = multipath_socket0_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_abandon) {
            int ret = multipath_abandon_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_abandon_last) {
            int ret = multipath_abandon_last_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_abandon_last_by_peer) {
            int ret = multipath_abandon_last_by_peer_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_last_path_validation_fails) {
            int ret = multipath_last_path_validation_fails_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_demoted_path0_null_cnxid) {
            int ret = multipath_demoted_path0_null_cnxid_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_back0) {
            int ret = multipath_back0_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_back1) {
            int ret = multipath_back1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_perf) {
            int ret = multipath_perf_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_callback) {
            int ret = multipath_callback_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_quality) {
            int ret = multipath_quality_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_stream_af) {
            int ret = multipath_stream_af_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_datagram) {
            int ret = multipath_datagram_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_dg_af) {
            int ret = multipath_dg_af_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_backup) {
            int ret = multipath_backup_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_stream_af_backup) {
            int ret = multipath_stream_af_backup_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_standup) {
            int ret = multipath_standup_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_discovery) {
            int ret = multipath_discovery_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_keep_alive) {
            int ret = multipath_keep_alive_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_just_one) {
            int ret = multipath_just_one_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_break_both) {
            int ret = multipath_break_both_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_qlog) {
            int ret = multipath_qlog_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_tunnel) {
            int ret = multipath_tunnel_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_cid_retire) {
            int ret = multipath_cid_retire_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_abandon_stash) {
            int ret = multipath_abandon_stash_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_abandon_stash_reverse) {
            int ret = multipath_abandon_stash_reverse_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_delete_path_stash) {
            int ret = multipath_delete_path_stash_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_flow_frames_ack) {
            int ret = multipath_flow_frames_ack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_unique_path_id) {
            int ret = multipath_unique_path_id_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_ack_delay) {
            int ret = multipath_ack_delay_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_ack_path_stalled) {
            int ret = multipath_ack_path_stalled_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_nominal_ack_path) {
            int ret = multipath_nominal_ack_path_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_srtt_update) {
            int ret = multipath_srtt_update_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(multipath_idle_rotation) {
            int ret = multipath_idle_rotation_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(config_option_letters) {
            int ret = config_option_letters_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(config_command_line_index) {
            int ret = config_command_line_index_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(config_option) {
            int ret = config_option_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(config_quic) {
            int ret = config_quic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(config_quic_context_edge) {
            int ret = config_quic_context_edge_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(config_qmux) {
            int ret = config_qmux_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(config_usage) {
            int ret= config_usage_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(config_preferred) {
            int ret = config_preferred_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(config_set_port) {
            int ret = config_set_port_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_integer) {
            int ret = h3zero_integer_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_varint_stream) {
            int ret = h3zero_varint_stream_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_incoming_unidir) {
            int ret = h3zero_incoming_unidir_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_unidir_error) {
            int ret = h3zero_unidir_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_setting_error) {
            int ret = h3zero_setting_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_remote_control_stream_singleton) {
            int ret = h3zero_remote_control_stream_singleton_test();
            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_capsule) {
            int ret = h3zero_capsule_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_client_data) {
            int ret = h3zero_client_data_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_client_data_repeat) {
            int ret = h3zero_client_data_repeat_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qpack_huffman) {
            int ret = qpack_huffman_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(qpack_huffman_base) {
            int ret = qpack_huffman_base_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_name_lookup) {
            int ret = h3zero_name_lookup_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_qpack_encode_error) {
            int ret = h3zero_qpack_encode_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_create_header_frame_error) {
            int ret = h3zero_create_header_frame_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_parse_duplicate_header_value_string) {
            int ret = h3zero_parse_duplicate_header_value_string_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_parse_duplicate_header) {
            int ret = h3zero_parse_duplicate_header_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_varint_decode_error) {
            int ret = h3zero_varint_decode_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_parse_qpack) {
            int ret = h3zero_parse_qpack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_prepare_qpack) {
            int ret = h3zero_prepare_qpack_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_user_agent) {
            int ret = h3zero_user_agent_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_uri) {
            int ret = h3zero_uri_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_url_template) {
            int ret = h3zero_url_template_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_null_sni) {
            int ret = h3zero_null_sni_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_qpack_fuzz) {
            int ret = h3zero_qpack_fuzz_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_stream) {
            int ret = h3zero_stream_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_stream_fuzz) {
            int ret = h3zero_stream_fuzz_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(parse_demo_scenario) {
            int ret = parse_demo_scenario_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(parse_demo_scenario_error) {
            int ret = parse_demo_scenario_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_prepare_stream_open_command_too_small) {
            int ret = h09_prepare_stream_open_command_too_small_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_server) {
            int ret = h3zero_server_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_migration_disabled)
        {
            int ret = h3zero_migration_disabled_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(h09_server) {
            int ret = h09_server_test();

            Assert::AreEqual(ret, 0);
        }
        
        TEST_METHOD(h09_header) {
            int ret = h09_header_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_parse_method) {
            int ret = h09_parse_method_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_parse_protocol) {
            int ret = h09_parse_protocol_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_parse_commandline) {
            int ret = h09_parse_commandline_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_stop_sending_reset) {
            int ret = h09_stop_sending_reset_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_server_parse_path) {
            int ret = h3zero_server_parse_path_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_server_prepare_to_send) {
            int ret = h3zero_server_prepare_to_send_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picohttp_find_path_item) {
            int ret = picohttp_find_path_item_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(generic_server) {
            int ret = generic_server_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_post) {
            int ret = h3zero_post_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_post) {
            int ret = h09_post_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(demo_alpn) {
            int ret = demo_alpn_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(demo_ticket) {
            int ret = demo_ticket_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(demo_error) {
            int ret = demo_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(demo_file_access) {
            int ret = demo_file_access_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(demo_server_file) {
            int ret = demo_server_file_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_satellite) {
            int ret = h3zero_satellite_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_satellite) {
            int ret = h09_satellite_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_lone_fin) {
            int ret = h09_lone_fin_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3_grease_client) {
            int ret = h3_grease_client_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3_grease_server) {
            int ret = h3_grease_server_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3_long_file_name) {
            int ret = h3_long_file_name_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_multi_file) {
            int ret = h09_multi_file_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_multi_file_loss) {
            int ret = h09_multi_file_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h09_multi_file_preemptive) {
            int ret = h09_multi_file_preemptive_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3_multi_file) {
            int ret = h3_multi_file_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3_multi_file_loss) {
            int ret = h3_multi_file_loss_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3_multi_file_preemptive) {
            int ret = h3_multi_file_preemptive_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_settings) {
            int ret = h3zero_settings_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_settings_components_decode) {
            int ret = h3zero_settings_components_decode_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(h3zero_settings_encode_too_short) {
            int ret = h3zero_settings_encode_too_short_test();

            Assert::AreEqual(ret, 0);
        }

	    TEST_METHOD(h3zero_get_content_type_by_path) {
            int ret = h3zero_get_content_type_by_path_test();

            Assert::AreEqual(ret, 0);
        }

	    TEST_METHOD(h3zero_find_path_item) {
            int ret = h3zero_find_path_item_test();

            Assert::AreEqual(ret, 0);
        }

	    TEST_METHOD(h3zero_process_request_frame) {
            int ret = h3zero_process_request_frame_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(http_drop) {
            int ret = http_drop_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(get_hash) {
            int ret = get_hash_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(get_tls_errors) {
            int ret = get_tls_errors_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(dualq_aqm) {
            int ret = dualq_aqm_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(ech_config) {
            int ret = ech_config_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_config_p) {
            int ret = ech_config_p_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_config_secp384r1) {
            int ret = ech_config_secp384r1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_config_pub_secp384r1) {
            int ret = ech_config_pub_secp384r1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_config_pub_x25519) {
            int ret = ech_config_pub_x25519_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_config_file) {
            int ret = ech_config_file_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_e2e) {
            int ret = ech_e2e_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_e2e_0rtt) {
            int ret = ech_e2e_0rtt_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_grease) {
            int ret = ech_grease_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_no_ech) {
            int ret = ech_no_ech_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_bad_config_empty) {
            int ret = ech_bad_config_empty_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_bad_config_whitespace) {
            int ret = ech_bad_config_whitespace_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_bad_config_too_short) {
            int ret = ech_bad_config_too_short_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_bad_config_missing_file) {
            int ret = ech_bad_config_missing_file_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_bad_config_invalid_base64) {
            int ret = ech_bad_config_invalid_base64_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_kem_lookup) {
            int ret = ech_kem_lookup_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_pubkey_asn1) {
            int ret = ech_pubkey_asn1_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_pubkey_missing_file) {
            int ret = ech_pubkey_missing_file_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(ech_registration_failure) {
            int ret = ech_registration_failure_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(getter) {
            int ret = getter_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(grease_quic_bit) {
            int ret = grease_quic_bit_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picomask_udp) {
            int ret = picomask_udp_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picomask_udp_path) {
            int ret = picomask_udp_path_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_basic) {
            int ret = picowt_baton_basic_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_error) {
            int ret = picowt_baton_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_long) {
            int ret = picowt_baton_long_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_multi) {
            int ret = picowt_baton_multi_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_random) {
            int ret = picowt_baton_random_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_reset) {
            int ret = picowt_baton_reset_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_stop_reset) {
            int ret = picowt_baton_stop_reset_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_url) {
            int ret = wt_interop_url_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_handshake) {
            int ret = wt_interop_handshake_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_uni_receive) {
            int ret = wt_interop_uni_receive_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_uni_send) {
            int ret = wt_interop_uni_send_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_bidi_receive) {
            int ret = wt_interop_bidi_receive_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_bidi_send) {
            int ret = wt_interop_bidi_send_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_datagram_receive) {
            int ret = wt_interop_datagram_receive_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_datagram_send) {
            int ret = wt_interop_datagram_send_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_missing_file) {
            int ret = wt_interop_missing_file_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_uni_missing_file) {
            int ret = wt_interop_uni_missing_file_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_datagram_missing_file) {
            int ret = wt_interop_datagram_missing_file_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_download_fail) {
            int ret = wt_interop_download_fail_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_datagram_large) {
            int ret = wt_interop_datagram_large_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_wildcard_post) {
            int ret = wt_interop_wildcard_post_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_datagram_loss_get) {
            int ret = wt_interop_datagram_loss_get_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_datagram_loss_push) {
            int ret = wt_interop_datagram_loss_push_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(wt_interop_datagram_loss_send) {
            int ret = wt_interop_datagram_loss_send_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_bad_params) {
            int ret = picowt_baton_bad_params_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_bad_params_syntax) {
            int ret = picowt_baton_bad_params_syntax_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_server_reject) {
            int ret = picowt_baton_server_reject_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_fin_before_baton) {
            int ret = picowt_baton_fin_before_baton_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_wrong_stream) {
            int ret = picowt_baton_wrong_stream_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_wildcard) {
            int ret = picowt_baton_wildcard_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_one_session) {
            int ret = picowt_one_session_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_one_session_baton_route) {
            int ret = picowt_one_session_baton_route_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_overflow) {
            int ret = picowt_baton_overflow_test();

            Assert::AreEqual(ret, 0);
        }
        TEST_METHOD(picowt_baton_krome) {
            int ret = picowt_baton_krome_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_uri) {
            int ret = picowt_baton_uri_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_baton_wrong) {
            int ret = picowt_baton_wrong_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_drain) {
            int ret = picowt_drain_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_reset_stream_remote_unidir) {
            int ret = picowt_reset_stream_remote_unidir_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_select_wt_protocol_whitespace) {
            int ret = picowt_select_wt_protocol_whitespace_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_webtransport_requirements_met) {
            int ret = picowt_webtransport_requirements_met_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_format_connect_frame) {
            int ret = picowt_format_connect_frame_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_send_close_session_already_closed) {
            int ret = picowt_send_close_session_already_closed_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(picowt_tp) {
            int ret = picowt_tp_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_parse) {
            int ret = quicperf_parse_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_scenario_error) {
            int ret = quicperf_scenario_error_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_batch) {
            int ret = quicperf_batch_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_infinite) {
            int ret = quicperf_infinite_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_batch_post) {
            int ret = quicperf_batch_post_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_server_timer_batch) {
            int ret = quicperf_server_timer_batch_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_batch_priority) {
            int ret = quicperf_batch_priority_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_client_media_stream) {
            int ret = quicperf_client_media_stream_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_client_media_datagram) {
            int ret = quicperf_client_media_datagram_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_datagram_too_large) {
            int ret = quicperf_datagram_too_large_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_datagram) {
            int ret = quicperf_datagram_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_datagram_multiflow) {
            int ret = quicperf_datagram_multiflow_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_media) {
            int ret = quicperf_media_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_ungrouped) {
            int ret = quicperf_ungrouped_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_group_remainder) {
            int ret = quicperf_group_remainder_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_datagram_vs_group) {
            int ret = quicperf_datagram_vs_group_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_server_timer_wakeup) {
            int ret = quicperf_server_timer_wakeup_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_receive_media_overrun) {
            int ret = quicperf_receive_media_overrun_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_server_timer_leak) {
            int ret = quicperf_server_timer_leak_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_chain) {
            int ret = quicperf_chain_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_print_report) {
            int ret = quicperf_print_report_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_multi) {
            int ret = quicperf_multi_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_overflow) {
            int ret = quicperf_overflow_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_multipath_settled) {
            int ret = quicperf_multipath_settled_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_multipath_race) {
            int ret = quicperf_multipath_race_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(quicperf_multipath_race_delayed) {
            int ret = quicperf_multipath_race_delayed_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(grease_quic_bit_one_way) {
            int ret = grease_quic_bit_one_way_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(bad_chello) {
            int ret = bad_chello_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(pn_random) {
            int ret = pn_random_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(port_blocked) {
            int ret = port_blocked_test();

            Assert::AreEqual(ret, 0);
        }

        TEST_METHOD(cplusplus) {
            int ret = cplusplustest();

            Assert::AreEqual(ret, 0);
        }
    };
}
