# Static sources
