// Package webrtc contains a WebRTC server.
package webrtc

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha1"
	"encoding/base64"
	"errors"
	"fmt"
	"net"
	"net/http"
	"reflect"
	"sort"
	"strconv"
	"sync"
	"time"

	"github.com/bluenviron/gortsplib/v5/pkg/readbuffer"
	"github.com/google/uuid"
	"github.com/pion/ice/v4"
	"github.com/pion/logging"
	pwebrtc "github.com/pion/webrtc/v4"

	"github.com/bluenviron/mediamtx/internal/auth"
	"github.com/bluenviron/mediamtx/internal/conf"
	"github.com/bluenviron/mediamtx/internal/defs"
	"github.com/bluenviron/mediamtx/internal/externalcmd"
	"github.com/bluenviron/mediamtx/internal/logger"
	"github.com/bluenviron/mediamtx/internal/protocols/webrtc"
	"github.com/bluenviron/mediamtx/internal/protocols/whip"
	"github.com/bluenviron/mediamtx/internal/restrictnetwork"
)

const (
	turnSecretExpiration = 24 * time.Hour
	maxInboundSDPSize    = 128 * 1024
)

// ErrSessionNotFound is returned when a session is not found.
var ErrSessionNotFound = errors.New("session not found")

func interfaceIsEmpty(i any) bool {
	return reflect.ValueOf(i).Kind() != reflect.Pointer || reflect.ValueOf(i).IsNil()
}

type nilWriter struct{}

func (nilWriter) Write(p []byte) (int, error) {
	return len(p), nil
}

var webrtcNilLogger = logging.NewDefaultLeveledLoggerForScope("", 0, &nilWriter{})

func randInt63() (int64, error) {
	var b [8]byte
	_, err := rand.Read(b[:])
	if err != nil {
		return 0, err
	}

	return int64(uint64(b[0]&0b01111111)<<56 | uint64(b[1])<<48 | uint64(b[2])<<40 | uint64(b[3])<<32 |
		uint64(b[4])<<24 | uint64(b[5])<<16 | uint64(b[6])<<8 | uint64(b[7])), nil
}

// https://cs.opensource.google/go/go/+/refs/tags/go1.20.4:src/math/rand/rand.go;l=119
func randInt63n(n int64) (int64, error) {
	if n&(n-1) == 0 { // n is power of two, can mask
		r, err := randInt63()
		if err != nil {
			return 0, err
		}
		return r & (n - 1), nil
	}

	maxVal := int64((1 << 63) - 1 - (1<<63)%uint64(n))

	v, err := randInt63()
	if err != nil {
		return 0, err
	}

	for v > maxVal {
		v, err = randInt63()
		if err != nil {
			return 0, err
		}
	}

	return v % n, nil
}

func randomTurnUser() (string, error) {
	const charset = "abcdefghijklmnopqrstuvwxyz1234567890"
	b := make([]byte, 20)
	for i := range b {
		j, err := randInt63n(int64(len(charset)))
		if err != nil {
			return "", err
		}

		b[i] = charset[int(j)]
	}

	return string(b), nil
}

type serverAPISessionsListRes struct {
	data *defs.APIWebRTCSessionList
	err  error
}

type serverAPISessionsListReq struct {
	res chan serverAPISessionsListRes
}

type serverAPISessionsGetRes struct {
	data *defs.APIWebRTCSession
	err  error
}

type serverAPISessionsGetReq struct {
	uuid uuid.UUID
	res  chan serverAPISessionsGetRes
}

type serverAPISessionsKickRes struct {
	err error
}

type serverAPISessionsKickReq struct {
	uuid uuid.UUID
	res  chan serverAPISessionsKickRes
}

type newSessionRes struct {
	sx            *session
	errStatusCode int
	err           error
}

type newSessionReq struct {
	remoteAddr  string
	pathName    string
	query       string
	userAgent   string
	credentials *auth.Credentials
	offer       []byte
	publish     bool
	res         chan newSessionRes
}

type addSessionCandidatesRes struct {
	sx     *session
	answer *whip.SDPFragment
	err    error
}

type addSessionCandidatesReq struct {
	secret   uuid.UUID
	fragment *whip.SDPFragment
	res      chan addSessionCandidatesRes
}

type deleteSessionRes struct {
	err error
}

type deleteSessionReq struct {
	secret uuid.UUID
	res    chan deleteSessionRes
}

type serverMetrics interface {
	SetWebRTCServer(defs.APIWebRTCServer)
}

type serverPathManager interface {
	FindPathConf(req defs.PathFindPathConfReq) (*defs.PathFindPathConfRes, error)
	AddPublisher(req defs.PathAddPublisherReq) (*defs.PathAddPublisherRes, error)
	AddReader(req defs.PathAddReaderReq) (*defs.PathAddReaderRes, error)
}

type serverParent interface {
	logger.Writer
	OnFatalError(context.Context, error)
}

// Server is a WebRTC server.
type Server struct {
	Address                      string
	DumpPackets                  bool
	Encryption                   bool
	ServerKey                    string
	ServerCert                   string
	AllowOrigins                 []string
	TrustedProxies               conf.IPNetworks
	ReadTimeout                  conf.Duration
	WriteTimeout                 conf.Duration
	UDPReadBufferSize            uint
	LocalUDPAddress              string
	LocalTCPAddress              string
	SupportsIPv6                 bool
	IPsFromInterfaces            bool
	IPsFromInterfacesList        []string
	IPsFromInterfacesExcludeList []string
	AdditionalHosts              []string
	ICEServers                   []conf.WebRTCICEServer
	STUNGatherTimeout            conf.Duration
	HandshakeTimeout             conf.Duration
	TrackGatherTimeout           conf.Duration
	ExternalCmdPool              *externalcmd.Pool
	Metrics                      serverMetrics
	PathManager                  serverPathManager
	Parent                       serverParent

	ctx              context.Context
	ctxCancel        func()
	httpServer       *httpServer
	udpMuxLn         net.PacketConn
	tcpMuxLn         net.Listener
	net              *webrtc.Net
	iceUDPMux        ice.UDPMux
	iceTCPMux        *webrtc.TCPMuxWrapper
	sessions         map[*session]struct{}
	sessionsBySecret map[uuid.UUID]*session

	// in
	chListenError          chan error
	chNewSession           chan newSessionReq
	chCloseSession         chan *session
	chAddSessionCandidates chan addSessionCandidatesReq
	chDeleteSession        chan deleteSessionReq
	chAPISessionsList      chan serverAPISessionsListReq
	chAPISessionsGet       chan serverAPISessionsGetReq
	chAPIConnsKick         chan serverAPISessionsKickReq

	// out
	done chan struct{}
}

// Initialize initializes the server.
func (s *Server) Initialize() error {
	ctx, ctxCancel := context.WithCancel(context.Background())

	s.ctx = ctx
	s.ctxCancel = ctxCancel
	s.sessions = make(map[*session]struct{})
	s.sessionsBySecret = make(map[uuid.UUID]*session)
	s.chListenError = make(chan error)
	s.chNewSession = make(chan newSessionReq)
	s.chCloseSession = make(chan *session)
	s.chAddSessionCandidates = make(chan addSessionCandidatesReq)
	s.chDeleteSession = make(chan deleteSessionReq)
	s.chAPISessionsList = make(chan serverAPISessionsListReq)
	s.chAPISessionsGet = make(chan serverAPISessionsGetReq)
	s.chAPIConnsKick = make(chan serverAPISessionsKickReq)
	s.done = make(chan struct{})

	s.httpServer = &httpServer{
		address:        s.Address,
		dumpPackets:    s.DumpPackets,
		encryption:     s.Encryption,
		serverKey:      s.ServerKey,
		serverCert:     s.ServerCert,
		allowOrigins:   s.AllowOrigins,
		trustedProxies: s.TrustedProxies,
		readTimeout:    s.ReadTimeout,
		writeTimeout:   s.WriteTimeout,
		pathManager:    s.PathManager,
		parent:         s,
	}
	err := s.httpServer.initialize()
	if err != nil {
		ctxCancel()
		return err
	}

	s.net = &webrtc.Net{UDPReadBufferSize: int(s.UDPReadBufferSize)}

	if s.LocalUDPAddress != "" {
		s.udpMuxLn, err = net.ListenPacket(restrictnetwork.Restrict("udp", s.LocalUDPAddress))
		if err != nil {
			s.httpServer.close()
			ctxCancel()
			return err
		}

		if s.UDPReadBufferSize != 0 {
			err = readbuffer.SetReadBuffer(s.udpMuxLn.(*net.UDPConn), int(s.UDPReadBufferSize))
			if err != nil {
				s.udpMuxLn.Close()
				s.httpServer.close()
				ctxCancel()
				return err
			}
		}

		s.iceUDPMux = ice.NewUDPMuxDefault(ice.UDPMuxParams{
			UDPConn: s.udpMuxLn,
			Logger:  webrtcNilLogger,
			Net:     s.net,
		})
	}

	if s.LocalTCPAddress != "" {
		s.tcpMuxLn, err = net.Listen(restrictnetwork.Restrict("tcp", s.LocalTCPAddress))
		if err != nil {
			if s.udpMuxLn != nil {
				s.udpMuxLn.Close()
			}
			s.httpServer.close()
			ctxCancel()
			return err
		}

		s.iceTCPMux = &webrtc.TCPMuxWrapper{
			Mux: pwebrtc.NewICETCPMux(webrtcNilLogger, s.tcpMuxLn, 8),
			Ln:  s.tcpMuxLn,
		}
	}

	str := "started with listeners on " + s.Address
	if !s.Encryption {
		str += " (TCP/HTTP)"
	} else {
		str += " (TCP/HTTPS)"
	}
	if s.udpMuxLn != nil {
		str += ", " + s.LocalUDPAddress + " (UDP/ICE)"
	}
	if s.tcpMuxLn != nil {
		str += ", " + s.LocalTCPAddress + " (TCP/ICE)"
	}
	s.Log(logger.Info, str)

	go s.run()

	if !interfaceIsEmpty(s.Metrics) {
		s.Metrics.SetWebRTCServer(s)
	}

	return nil
}

// Log implements logger.Writer.
func (s *Server) Log(level logger.Level, format string, args ...any) {
	s.Parent.Log(level, "[WebRTC] "+format, args...)
}

// Close closes the server.
func (s *Server) Close() {
	s.Log(logger.Info, "closing")

	if !interfaceIsEmpty(s.Metrics) {
		s.Metrics.SetWebRTCServer(nil)
	}

	s.ctxCancel()
	<-s.done

	s.Log(logger.Debug, "closed")
}

func (s *Server) run() {
	defer close(s.done)

	var wg sync.WaitGroup

outer:
	for {
		select {
		case err := <-s.chListenError:
			s.Log(logger.Error, "%s", err)
			s.Parent.OnFatalError(s.ctx, err)
			break outer

		case req := <-s.chNewSession:
			sx := &session{
				net:                          s.net,
				parentCtx:                    s.ctx,
				ipsFromInterfaces:            s.IPsFromInterfaces,
				ipsFromInterfacesList:        s.IPsFromInterfacesList,
				ipsFromInterfacesExcludeList: s.IPsFromInterfacesExcludeList,
				additionalHosts:              s.AdditionalHosts,
				iceUDPMux:                    s.iceUDPMux,
				iceTCPMux:                    s.iceTCPMux,
				supportsIPv6:                 s.SupportsIPv6,
				stunGatherTimeout:            s.STUNGatherTimeout,
				handshakeTimeout:             s.HandshakeTimeout,
				trackGatherTimeout:           s.TrackGatherTimeout,
				remoteAddr:                   req.remoteAddr,
				pathName:                     req.pathName,
				query:                        req.query,
				userAgent:                    req.userAgent,
				credentials:                  req.credentials,
				offer:                        req.offer,
				publish:                      req.publish,
				wg:                           &wg,
				externalCmdPool:              s.ExternalCmdPool,
				pathManager:                  s.PathManager,
				parent:                       s,
			}
			sx.initialize()
			s.sessions[sx] = struct{}{}
			s.sessionsBySecret[sx.secret] = sx
			req.res <- newSessionRes{sx: sx}

		case sx := <-s.chCloseSession:
			delete(s.sessions, sx)
			delete(s.sessionsBySecret, sx.secret)

		case req := <-s.chAddSessionCandidates:
			sx, ok := s.sessionsBySecret[req.secret]
			if !ok {
				req.res <- addSessionCandidatesRes{err: ErrSessionNotFound}
				continue
			}

			req.res <- addSessionCandidatesRes{sx: sx}

		case req := <-s.chDeleteSession:
			sx, ok := s.sessionsBySecret[req.secret]
			if !ok {
				req.res <- deleteSessionRes{err: ErrSessionNotFound}
				continue
			}

			delete(s.sessions, sx)
			delete(s.sessionsBySecret, sx.secret)
			sx.Close()

			req.res <- deleteSessionRes{}

		case req := <-s.chAPISessionsList:
			data := &defs.APIWebRTCSessionList{
				Items: []defs.APIWebRTCSession{},
			}

			for sx := range s.sessions {
				data.Items = append(data.Items, *sx.apiItem())
			}

			sort.Slice(data.Items, func(i, j int) bool {
				return data.Items[i].Created.Before(data.Items[j].Created)
			})

			req.res <- serverAPISessionsListRes{data: data}

		case req := <-s.chAPISessionsGet:
			sx := s.findSessionByUUID(req.uuid)
			if sx == nil {
				req.res <- serverAPISessionsGetRes{err: ErrSessionNotFound}
				continue
			}

			req.res <- serverAPISessionsGetRes{data: sx.apiItem()}

		case req := <-s.chAPIConnsKick:
			sx := s.findSessionByUUID(req.uuid)
			if sx == nil {
				req.res <- serverAPISessionsKickRes{err: ErrSessionNotFound}
				continue
			}

			delete(s.sessions, sx)
			delete(s.sessionsBySecret, sx.secret)
			sx.Close()

			req.res <- serverAPISessionsKickRes{}

		case <-s.ctx.Done():
			break outer
		}
	}

	s.ctxCancel()

	wg.Wait()

	s.httpServer.close()

	if s.udpMuxLn != nil {
		s.udpMuxLn.Close()
	}

	if s.tcpMuxLn != nil {
		s.tcpMuxLn.Close()
	}
}

func (s *Server) onListenError(ctx context.Context, err error) {
	select {
	case s.chListenError <- err:
	case <-ctx.Done():
	case <-s.ctx.Done():
	}
}

func (s *Server) findSessionByUUID(uuid uuid.UUID) *session {
	for sx := range s.sessions {
		if sx.uuid == uuid {
			return sx
		}
	}
	return nil
}

func (s *Server) generateICEServers(clientConfig bool) ([]pwebrtc.ICEServer, error) {
	ret := make([]pwebrtc.ICEServer, 0, len(s.ICEServers))

	for _, server := range s.ICEServers {
		if !server.ClientOnly || clientConfig {
			if server.Username == "AUTH_SECRET" {
				expireDate := time.Now().Add(turnSecretExpiration).Unix()

				user, err := randomTurnUser()
				if err != nil {
					return nil, err
				}

				server.Username = strconv.FormatInt(expireDate, 10) + ":" + user

				h := hmac.New(sha1.New, []byte(server.Password))
				h.Write([]byte(server.Username))

				server.Password = base64.StdEncoding.EncodeToString(h.Sum(nil))
			}

			ret = append(ret, pwebrtc.ICEServer{
				URLs:       []string{server.URL},
				Username:   server.Username,
				Credential: server.Password,
			})
		}
	}

	return ret, nil
}

// newSession is called by webRTCHTTPServer.
func (s *Server) newSession(req newSessionReq) newSessionRes {
	req.res = make(chan newSessionRes)

	select {
	case s.chNewSession <- req:
		return <-req.res

	case <-s.ctx.Done():
		return newSessionRes{
			errStatusCode: http.StatusInternalServerError,
			err:           fmt.Errorf("terminated"),
		}
	}
}

// closeSession is called by session.
func (s *Server) closeSession(sx *session) {
	select {
	case s.chCloseSession <- sx:
	case <-s.ctx.Done():
	}
}

// addSessionCandidates is called by webRTCHTTPServer.
func (s *Server) addSessionCandidates(
	req addSessionCandidatesReq,
) addSessionCandidatesRes {
	req.res = make(chan addSessionCandidatesRes)
	select {
	case s.chAddSessionCandidates <- req:
		res1 := <-req.res
		if res1.err != nil {
			return res1
		}

		return res1.sx.addCandidates(req)

	case <-s.ctx.Done():
		return addSessionCandidatesRes{err: fmt.Errorf("terminated")}
	}
}

// deleteSession is called by webRTCHTTPServer.
func (s *Server) deleteSession(req deleteSessionReq) error {
	req.res = make(chan deleteSessionRes)
	select {
	case s.chDeleteSession <- req:
		res := <-req.res
		return res.err

	case <-s.ctx.Done():
		return fmt.Errorf("terminated")
	}
}

// APISessionsList implements defs.APIWebRTCServer.
func (s *Server) APISessionsList() (*defs.APIWebRTCSessionList, error) {
	req := serverAPISessionsListReq{
		res: make(chan serverAPISessionsListRes),
	}

	select {
	case s.chAPISessionsList <- req:
		res := <-req.res
		return res.data, res.err

	case <-s.ctx.Done():
		return nil, fmt.Errorf("terminated")
	}
}

// APISessionsGet implements defs.APIWebRTCServer.
func (s *Server) APISessionsGet(uuid uuid.UUID) (*defs.APIWebRTCSession, error) {
	req := serverAPISessionsGetReq{
		uuid: uuid,
		res:  make(chan serverAPISessionsGetRes),
	}

	select {
	case s.chAPISessionsGet <- req:
		res := <-req.res
		return res.data, res.err

	case <-s.ctx.Done():
		return nil, fmt.Errorf("terminated")
	}
}

// APISessionsKick implements defs.APIWebRTCServer.
func (s *Server) APISessionsKick(uuid uuid.UUID) error {
	req := serverAPISessionsKickReq{
		uuid: uuid,
		res:  make(chan serverAPISessionsKickRes),
	}

	select {
	case s.chAPIConnsKick <- req:
		res := <-req.res
		return res.err

	case <-s.ctx.Done():
		return fmt.Errorf("terminated")
	}
}
