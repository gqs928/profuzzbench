package api //nolint:revive

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/stretchr/testify/require"

	"github.com/bluenviron/mediamtx/internal/auth"
	"github.com/bluenviron/mediamtx/internal/conf"
	"github.com/bluenviron/mediamtx/internal/defs"
	"github.com/bluenviron/mediamtx/internal/logger"
	"github.com/bluenviron/mediamtx/internal/test"
)

type testParent struct {
	log  func(_ logger.Level, _ string, _ ...any)
	conf *conf.Conf
	ids  []uuid.UUID
}

func TestMediaIdentityJSON(t *testing.T) {
	expiresAt := time.Date(2026, time.October, 20, 12, 0, 0, 0, time.UTC)
	for _, ca := range []struct {
		name string
		make func(*time.Time) any
	}{
		{"rtsp", func(exp *time.Time) any { return defs.APIRTSPSession{User: "somebody", ExpiresAt: exp} }},
		{"rtmp", func(exp *time.Time) any { return defs.APIRTMPConn{User: "somebody", ExpiresAt: exp} }},
		{"srt", func(exp *time.Time) any { return defs.APISRTConn{User: "somebody", ExpiresAt: exp} }},
		{"hls", func(exp *time.Time) any { return defs.APIHLSSession{User: "somebody", ExpiresAt: exp} }},
		{"webrtc", func(exp *time.Time) any { return defs.APIWebRTCSession{User: "somebody", ExpiresAt: exp} }},
		{"moq", func(exp *time.Time) any { return defs.APIMoQSession{User: "somebody", ExpiresAt: exp} }},
	} {
		t.Run(ca.name, func(t *testing.T) {
			for _, exp := range []*time.Time{nil, &expiresAt} {
				byts, err := json.Marshal(ca.make(exp))
				require.NoError(t, err)

				var fields map[string]json.RawMessage
				require.NoError(t, json.Unmarshal(byts, &fields))
				require.JSONEq(t, `"somebody"`, string(fields["user"]))
				if exp == nil {
					require.Equal(t, `null`, string(fields["expiresAt"]))
				} else {
					require.JSONEq(t, `"2026-10-20T12:00:00Z"`, string(fields["expiresAt"]))
				}
			}
		})
	}
}

func (p *testParent) Log(l logger.Level, s string, a ...any) {
	if p.log != nil {
		p.log(l, s, a...)
	}
}

func (p *testParent) OnFatalError(context.Context, error) {
}

func (p *testParent) APIConfigSnapshot() *conf.Conf { return p.conf }

func (p *testParent) APIConfigGlobalPatch(_ context.Context, in conf.OptionalGlobal) error {
	newConf := p.conf.Clone()

	err := newConf.PatchGlobal(&in)
	if err != nil {
		return err
	}

	p.conf = newConf
	return nil
}

func (p *testParent) APIConfigPathDefaultsPatch(_ context.Context, in conf.OptionalPath) error {
	newConf := p.conf.Clone()

	err := newConf.PatchPathDefaults(&in)
	if err != nil {
		return err
	}

	p.conf = newConf
	return nil
}

func (p *testParent) APIConfigPathsAdd(_ context.Context, name string, in conf.OptionalPath) error {
	newConf := p.conf.Clone()

	if err := newConf.AddPath(name, &in); err != nil {
		return err
	}

	p.conf = newConf
	return nil
}

func (p *testParent) APIConfigPathsPatch(_ context.Context, name string, in conf.OptionalPath) error {
	newConf := p.conf.Clone()

	err := newConf.PatchPath(name, &in)
	if err != nil {
		return err
	}

	p.conf = newConf
	return nil
}

func (p *testParent) APIConfigPathsReplace(_ context.Context, name string, in conf.OptionalPath) error {
	newConf := p.conf.Clone()

	err := newConf.ReplacePath(name, &in)
	if err != nil {
		return err
	}

	p.conf = newConf
	return nil
}

func (p *testParent) APIConfigPathsDelete(_ context.Context, name string) error {
	newConf := p.conf.Clone()

	err := newConf.RemovePath(name)
	if err != nil {
		return err
	}

	p.conf = newConf
	return nil
}

func (p *testParent) APIConfigInternalUsersSnapshot() ([]defs.APIInternalUser, error) {
	if len(p.ids) != len(p.conf.AuthInternalUsers) {
		p.ids = make([]uuid.UUID, len(p.conf.AuthInternalUsers))
		for i := range p.ids {
			p.ids[i] = uuid.New()
		}
	}
	c := conf.Redact(p.conf)
	items := make([]defs.APIInternalUser, len(c.AuthInternalUsers))
	for i, user := range c.AuthInternalUsers {
		items[i] = defs.APIInternalUser{
			ID:          p.ids[i],
			Pos:         i + 1,
			User:        user.User,
			Pass:        user.Pass,
			IPs:         user.IPs,
			Permissions: user.Permissions,
		}
	}
	return items, nil
}

func (p *testParent) APIConfigInternalUsersAdd(_ context.Context, user conf.AuthInternalUser) (uuid.UUID, error) {
	c := p.conf.Clone()

	err := c.AddInternalUser(&user)
	if err != nil {
		return uuid.Nil, err
	}

	id := uuid.New()
	p.ids = append(p.ids, id)
	p.conf = c
	return id, nil
}

func (p *testParent) APIConfigInternalUsersPatch(
	_ context.Context,
	id uuid.UUID,
	optional conf.OptionalAuthInternalUser,
) error {
	for i, existing := range p.ids {
		if existing == id {
			c := p.conf.Clone()

			err := c.PatchInternalUser(i, &optional)
			if err != nil {
				return err
			}

			p.conf = c
			return nil
		}
	}
	return conf.ErrAuthInternalUserNotFound
}

func (p *testParent) APIConfigInternalUsersReplace(_ context.Context, id uuid.UUID, user conf.AuthInternalUser) error {
	for i, existing := range p.ids {
		if existing == id {
			c := p.conf.Clone()
			if user.Pass == "<redacted>" {
				user.Pass = c.AuthInternalUsers[i].Pass
			}

			err := c.ReplaceInternalUser(i, &user)
			if err != nil {
				return err
			}

			p.conf = c
			return nil
		}
	}
	return conf.ErrAuthInternalUserNotFound
}

func (p *testParent) APIConfigInternalUsersDelete(_ context.Context, id uuid.UUID) error {
	for i, existing := range p.ids {
		if existing == id {
			c := p.conf.Clone()

			err := c.DeleteInternalUser(i)
			if err != nil {
				return err
			}

			p.ids = append(p.ids[:i], p.ids[i+1:]...)
			p.conf = c
			return nil
		}
	}
	return conf.ErrAuthInternalUserNotFound
}

func tempConf(t *testing.T, cnt string) *conf.Conf {
	t.Helper()

	fi := test.CreateTempFile(t, []byte(cnt))

	cnf, _, err := conf.Load(fi, nil, nil)
	require.NoError(t, err)

	return cnf
}

func httpRequest(t *testing.T, hc *http.Client, method string, ur string, in any, out any) {
	t.Helper()

	buf := func() io.Reader {
		if in == nil {
			return nil
		}

		byts, err := json.Marshal(in)
		require.NoError(t, err)

		return bytes.NewBuffer(byts)
	}()

	req, err := http.NewRequest(method, ur, buf)
	require.NoError(t, err)

	res, err := hc.Do(req)
	require.NoError(t, err)
	defer res.Body.Close()

	if res.StatusCode != http.StatusOK {
		t.Errorf("bad status code: %d", res.StatusCode)
	}

	if out == nil {
		checkOK(t, res.Body)
		return
	}

	err = json.NewDecoder(res.Body).Decode(out)
	require.NoError(t, err)
}

func checkError(t *testing.T, body io.Reader, msg string) {
	t.Helper()

	var raw map[string]any
	err := json.NewDecoder(body).Decode(&raw)
	require.NoError(t, err)
	require.Equal(t, map[string]any{"status": "error", "error": msg}, raw)
}

func checkOK(t *testing.T, body io.Reader) {
	t.Helper()

	var raw map[string]any
	err := json.NewDecoder(body).Decode(&raw)
	require.NoError(t, err)
	require.Equal(t, map[string]any{"status": "ok"}, raw)
}

func TestPreflightRequest(t *testing.T) {
	api := API{
		Address:      "localhost:9997",
		AllowOrigins: []string{"*"},
		ReadTimeout:  conf.Duration(10 * time.Second),
		WriteTimeout: conf.Duration(10 * time.Second),
		AuthManager:  test.NilAuthManager,
		Parent:       &testParent{},
	}
	err := api.Initialize()
	require.NoError(t, err)
	defer api.Close()

	tr := &http.Transport{}
	defer tr.CloseIdleConnections()
	hc := &http.Client{Transport: tr}

	req, err := http.NewRequest(http.MethodOptions, "http://localhost:9997", nil)
	require.NoError(t, err)

	req.Header.Add("Origin", "http://example.com")
	req.Header.Add("Access-Control-Request-Method", "GET")

	res, err := hc.Do(req)
	require.NoError(t, err)
	defer res.Body.Close()

	require.Equal(t, http.StatusNoContent, res.StatusCode)

	byts, err := io.ReadAll(res.Body)
	require.NoError(t, err)

	require.Equal(t, "http://example.com", res.Header.Get("Access-Control-Allow-Origin"))
	require.Equal(t, "OPTIONS, GET, POST, PATCH, DELETE", res.Header.Get("Access-Control-Allow-Methods"))
	require.Equal(t, "Authorization, Content-Type", res.Header.Get("Access-Control-Allow-Headers"))
	require.Equal(t, byts, []byte{})
}

func TestInfo(t *testing.T) {
	api := API{
		Version:      "v1.2.3",
		Started:      time.Date(2008, 11, 7, 11, 22, 0, 0, time.Local),
		Address:      "localhost:9997",
		ReadTimeout:  conf.Duration(10 * time.Second),
		WriteTimeout: conf.Duration(10 * time.Second),
		AuthManager:  test.NilAuthManager,
		Parent:       &testParent{},
	}
	err := api.Initialize()
	require.NoError(t, err)
	defer api.Close()

	tr := &http.Transport{}
	defer tr.CloseIdleConnections()
	hc := &http.Client{Transport: tr}

	var out map[string]any
	httpRequest(t, hc, http.MethodGet, "http://localhost:9997/v3/info", nil, &out)
	require.Equal(t, map[string]any{
		"started": time.Date(2008, 11, 7, 11, 22, 0, 0, time.Local).Format(time.RFC3339),
		"version": "v1.2.3",
	}, out)
}

func TestAuthJWKSRefresh(t *testing.T) {
	ok := false

	api := API{
		Address:      "localhost:9997",
		ReadTimeout:  conf.Duration(10 * time.Second),
		WriteTimeout: conf.Duration(10 * time.Second),
		AuthManager: &test.AuthManager{
			AuthenticateImpl: func(_ *auth.Request) (*auth.Result, *auth.Error) {
				return &auth.Result{}, nil
			},
			RefreshJWTJWKSImpl: func() {
				ok = true
			},
		},
		Parent: &testParent{},
	}
	err := api.Initialize()
	require.NoError(t, err)
	defer api.Close()

	tr := &http.Transport{}
	defer tr.CloseIdleConnections()
	hc := &http.Client{Transport: tr}

	u, err := url.Parse("http://localhost:9997/v3/auth/jwks/refresh")
	require.NoError(t, err)

	httpRequest(t, hc, http.MethodPost, u.String(), nil, nil)

	require.True(t, ok)
}

func TestAuthError(t *testing.T) {
	api := API{
		Address:      "localhost:9997",
		ReadTimeout:  conf.Duration(10 * time.Second),
		WriteTimeout: conf.Duration(10 * time.Second),
		AuthManager: &test.AuthManager{
			AuthenticateImpl: func(req *auth.Request) (*auth.Result, *auth.Error) {
				if req.Credentials.User == "" {
					return nil, &auth.Error{AskCredentials: true, Wrapped: fmt.Errorf("auth error")}
				}
				return nil, &auth.Error{Wrapped: fmt.Errorf("auth error")}
			},
		},
		Parent: &testParent{},
	}
	err := api.Initialize()
	require.NoError(t, err)
	defer api.Close()

	tr := &http.Transport{}
	defer tr.CloseIdleConnections()
	hc := &http.Client{Transport: tr}

	res, err := hc.Get("http://localhost:9997/v3/config/global/get")
	require.NoError(t, err)
	defer res.Body.Close()

	require.Equal(t, http.StatusUnauthorized, res.StatusCode)
	require.Equal(t, `Basic realm="mediamtx"`, res.Header.Get("WWW-Authenticate"))
	checkError(t, res.Body, "authentication error")

	res, err = hc.Get("http://myuser:mypass@localhost:9997/v3/config/global/get")
	require.NoError(t, err)
	defer res.Body.Close()

	require.Equal(t, http.StatusUnauthorized, res.StatusCode)
	require.Equal(t, ``, res.Header.Get("WWW-Authenticate"))
	checkError(t, res.Body, "authentication error")
}
