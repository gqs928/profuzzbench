// Copyright 2023 The BoringSSL Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef OPENSSL_HEADER_CRYPTO_FIPSMODULE_KECCAK_INTERNAL_H
#define OPENSSL_HEADER_CRYPTO_FIPSMODULE_KECCAK_INTERNAL_H

#include <openssl/base.h>

#include "../../internal.h"


BSSL_NAMESPACE_BEGIN

#define BITS_TO_BYTES(BITS) ((BITS) / 8)
#define SHA3_256_DIGEST_LENGTH BITS_TO_BYTES(256)
#define SHA3_384_DIGEST_LENGTH BITS_TO_BYTES(384)
#define SHA3_512_DIGEST_LENGTH BITS_TO_BYTES(512)
#define SHA3_BLOCK_SIZE(BITS) BITS_TO_BYTES(1600 - 2 * (BITS))
#define SHA3_256_CBLOCK SHA3_BLOCK_SIZE(256)
#define SHA3_384_CBLOCK SHA3_BLOCK_SIZE(384)
#define SHA3_512_CBLOCK SHA3_BLOCK_SIZE(512)
#define SHAKE256_CBLOCK SHA3_BLOCK_SIZE(256)

enum boringssl_keccak_config_t : int32_t {
  boringssl_sha3_256,
  boringssl_sha3_384,
  boringssl_sha3_512,
  boringssl_shake128,
  boringssl_shake256,
  boringssl_turboshake128,
  boringssl_turboshake256,
  boringssl_cshake128,
  boringssl_cshake256,
};

enum boringssl_keccak_phase_t : int32_t {
  boringssl_keccak_phase_absorb,
  boringssl_keccak_phase_squeeze,
};

struct BORINGSSL_keccak_st {
  // Note: the state with 64-bit integers comes first so that the size of this
  // struct is easy to compute on all architectures without padding surprises
  // due to alignment.
  uint64_t state[25];
  enum boringssl_keccak_config_t config;
  enum boringssl_keccak_phase_t phase;
  size_t required_out_len;
  size_t rate_bytes;
  size_t absorb_offset;
  size_t squeeze_offset;
};

// BORINGSSL_keccak hashes `in_len` bytes from `in` and writes `out_len` bytes
// of output to `out`. If the `config` specifies a fixed-output function, like
// SHA3-256, then `out_len` must be the correct length for that function. The
// cSHAKE configurations are only valid with the BORINGSSL_cshake functions.
OPENSSL_EXPORT void BORINGSSL_keccak(uint8_t *out, size_t out_len,
                                     const uint8_t *in, size_t in_len,
                                     enum boringssl_keccak_config_t config);

// BORINGSSL_keccak_init prepares `ctx` for absorbing. If the `config` specifies
// a fixed-output function, like SHA3-256, then the output must be squeezed in a
// single call to `BORINGSSL_keccak_squeeze`. In that case, it is recommended to
// use `BORINGSSL_keccak` if the input can be absorbed in a single call.
OPENSSL_EXPORT void BORINGSSL_keccak_init(
    struct BORINGSSL_keccak_st *ctx, enum boringssl_keccak_config_t config);

// BORINGSSL_cshake_init prepares `ctx` for cSHAKE, including absorbing the
// function-name and customization strings. `config` must be
// `boringssl_cshake128` or `boringssl_cshake256`. The message may then be
// absorbed and output squeezed with the usual Keccak functions.
OPENSSL_EXPORT void BORINGSSL_cshake_init(struct BORINGSSL_keccak_st *ctx,
                                          enum boringssl_keccak_config_t config,
                                          const uint8_t *function_name,
                                          size_t function_name_len,
                                          const uint8_t *customization,
                                          size_t customization_len);

// BORINGSSL_cshake is the one-shot form of BORINGSSL_cshake_init.
OPENSSL_EXPORT void BORINGSSL_cshake(uint8_t *out, size_t out_len,
                                     const uint8_t *in, size_t in_len,
                                     enum boringssl_keccak_config_t config,
                                     const uint8_t *function_name,
                                     size_t function_name_len,
                                     const uint8_t *customization,
                                     size_t customization_len);

// BORINGSSL_keccak_absorb absorbs `in_len` bytes from `in`.
OPENSSL_EXPORT void BORINGSSL_keccak_absorb(struct BORINGSSL_keccak_st *ctx,
                                            const uint8_t *in, size_t in_len);

// BORINGSSL_keccak_squeeze writes `out_len` bytes to `out` from `ctx`. If the
// configuration previously passed in `BORINGSSL_keccak_init` specifies a
// fixed-output function, then a single call to `BORINGSSL_keccak_squeeze` is
// allowed, where `out_len` must be the correct length for that function.
OPENSSL_EXPORT void BORINGSSL_keccak_squeeze(struct BORINGSSL_keccak_st *ctx,
                                             uint8_t *out, size_t out_len);

#if defined(__has_attribute)
#if __has_attribute(vector_size)

#define HAVE_KECCAK_X2

#if defined(OPENSSL_AARCH64)
#define HAVE_KECCAK_X4
#define KECCAK_X4_TARGET
#endif

#if defined(OPENSSL_X86_64)
#define HAVE_KECCAK_X4
#define KECCAK_X4_TARGET __attribute__((target("avx2")))
#endif

#endif  // vector_size
#endif  // __has_attribute

#if defined(HAVE_KECCAK_X2)
// BORINGSSL_keccak_squeeze_x2 performs BORINGSSL_keccak_squeeze in parallel
// with two same-length outputs. The contexts must be in equivalent state (i.e.
// same config, same amount of bytes absorbed and squeezed).
// This function is not compatible with cSHAKE nor TurboSHAKE.
OPENSSL_EXPORT void BORINGSSL_keccak_squeeze_x2(
    struct BORINGSSL_keccak_st ctx[2], uint8_t *outs[2], size_t out_len);

// BORINGSSL_keccak_short_x2 performs BORINGSSL_keccak in parallel on two
// same-length strings with same-length outputs. `in_len` must be less than 72
// (or actually `rate_bytes`).
// This function is not compatible with cSHAKE nor TurboSHAKE.
OPENSSL_EXPORT void BORINGSSL_keccak_short_x2(
    uint8_t *outs[2], size_t out_len, const uint8_t *ins[2], size_t in_len,
    enum boringssl_keccak_config_t config);
#endif

#if defined(HAVE_KECCAK_X4)
// BORINGSSL_have_keccak_x4 needs to return true before using any of the _x4
// variants here, as they may require additional CPU features.
// This function is not compatible with cSHAKE nor TurboSHAKE.
inline bool BORINGSSL_have_keccak_x4() {
#if defined(OPENSSL_X86_64)
  return CRYPTO_is_AVX2_capable();
#else
  return true;
#endif
}

// BORINGSSL_keccak_squeeze_x4 performs BORINGSSL_keccak_squeeze in parallel
// with four same-length outputs. The contexts must be in equivalent state (i.e.
// same config, same amount of bytes absorbed and squeezed).
// This function is not compatible with cSHAKE nor TurboSHAKE.
OPENSSL_EXPORT void BORINGSSL_keccak_squeeze_x4(
    struct BORINGSSL_keccak_st ctx[4], uint8_t *outs[4], size_t out_len);

// BORINGSSL_keccak_short_x4 performs BORINGSSL_keccak in parallel on four
// same-length strings with same-length outputs. in_len must be less than 72
// (or actually `rate_bytes`).
// This function is not compatible with cSHAKE nor TurboSHAKE.
OPENSSL_EXPORT void BORINGSSL_keccak_short_x4(
    uint8_t *outs[4], size_t out_len, const uint8_t *ins[4], size_t in_len,
    enum boringssl_keccak_config_t config);
#endif

BSSL_NAMESPACE_END

#endif  // OPENSSL_HEADER_CRYPTO_FIPSMODULE_KECCAK_INTERNAL_H
