// Copyright 2025 The BoringSSL Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <openssl/base.h>
#include <openssl/crypto.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/mem.h>

#include <benchmark/benchmark.h>

namespace {
void BM_SpeedSelfTest(benchmark::State &state) {
  for (auto _ : state) {
    if (!BORINGSSL_self_test()) {
      state.SkipWithError("BORINGSSL_self_test failed.");
      break;
    }
  }
}
BENCHMARK(BM_SpeedSelfTest);
}  // namespace
