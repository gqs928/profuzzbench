{
  dog = {
    tater.man = {
      type = {
        name = "pug",
      },
    },
  },
}
