{
  fruit = {
    apple = {
    },
    orange = {
    },
  },
  animal = {
  },
}
