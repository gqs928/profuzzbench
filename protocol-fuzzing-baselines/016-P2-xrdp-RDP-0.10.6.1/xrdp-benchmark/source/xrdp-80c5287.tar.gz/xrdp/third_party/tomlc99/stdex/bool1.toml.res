{
  bool1 = true,
  bool2 = false,
}
