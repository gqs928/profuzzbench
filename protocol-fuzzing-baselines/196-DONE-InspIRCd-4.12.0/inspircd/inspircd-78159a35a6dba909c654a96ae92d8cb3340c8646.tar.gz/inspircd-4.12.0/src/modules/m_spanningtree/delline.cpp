/*
 * InspIRCd -- Internet Relay Chat Daemon
 *
 *   Copyright (C) 2019 Matt Schatz <genius3000@g3k.solutions>
 *   Copyright (C) 2018, 2020, 2023 Sadie Powell <sadie@sadiepowell.dev>
 *   Copyright (C) 2013, 2015 Attila Molnar <attilamolnar@hush.com>
 *   Copyright (C) 2012 Robby <robby@chatbelgie.be>
 *   Copyright (C) 2009 Uli Schlachter <psychon@znc.in>
 *   Copyright (C) 2009 Daniel De Graaf <danieldg@inspircd.org>
 *   Copyright (C) 2008 Robin Burchell <robin+git@viroteck.net>
 *
 * This file is part of InspIRCd.  InspIRCd is free software: you can
 * redistribute it and/or modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation, version 2.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "inspircd.h"
#include "xline.h"

#include "commands.h"

CmdResult CommandDelLine::Handle(User* user, Params& params)
{
	const std::string& setter = user->nick;
	std::string reason;

	// XLineManager::DelLine() returns true if the xline existed, false if it didn't
	if (ServerInstance->XLines->DelLine(params[1], params[0], reason, user))
	{
		ServerInstance->SNO.WriteToSnoMask('X', "{} removed {}{} on {}: {}", setter,
			params[0], params[0].length() <= 2 ? "-line" : "", params[1], reason);
		return CmdResult::SUCCESS;
	}
	return CmdResult::FAILURE;
}
