/**
 * @file sn_common.c
 * @author Michal Vasko <mvasko@cesnet.cz>
 * @brief ietf-subscribed-notifications common functions
 *
 * @copyright
 * Copyright (c) 2023 Deutsche Telekom AG.
 * Copyright (c) 2023 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */

#define _GNU_SOURCE

#include "sn_common.h"

#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/uio.h>
#include <time.h>

#include <libyang/libyang.h>
#include <libyang/plugins_types.h>

#include "common.h"
#include "compat.h"
#include "log.h"
#include "ly_wrap.h"
#include "sysrepo.h"

static struct srsn_state snstate = {
    .sub_lock = PTHREAD_MUTEX_INITIALIZER,
    .dispatch_lock = PTHREAD_MUTEX_INITIALIZER,
};

static ATOMIC_T new_sub_id = 1;

uint32_t
srsn_new_id(void)
{
    return ATOMIC_INC_RELAXED(new_sub_id);
}

sr_error_info_t *
srsn_lock(void)
{
    sr_error_info_t *err_info = NULL;
    int r;

    if ((r = pthread_mutex_lock(&snstate.sub_lock))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Locking failed (%s: %s).", __func__, strerror(r));
    }

    return err_info;
}

void
srsn_unlock(void)
{
    sr_error_info_t *err_info = NULL;
    int r;

    if ((r = pthread_mutex_unlock(&snstate.sub_lock))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Unlocking a rwlock failed (%s: %s).", __func__, strerror(r));
        sr_errinfo_free(&err_info);
    }
}

sr_error_info_t *
srsn_sub_new(const char *xpath_filter, const struct timespec *stop_time, sr_subscription_ctx_t **sr_sub,
        sr_conn_ctx_t *conn, const char *nacm_user, struct srsn_sub **sub)
{
    sr_error_info_t *err_info = NULL;
    struct srsn_sub *s = NULL;
    int fds[2];

    /* create a pipe */
    if (pipe2(fds, O_CLOEXEC) == -1) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Failed to create pipes (%s).", strerror(errno));
        goto cleanup;
    }

    /* fill the subscription structure */
    s = calloc(1, sizeof *s);
    SR_CHECK_MEM_GOTO(!s, err_info, cleanup);
    s->id = srsn_new_id();
    s->rfd = fds[0];
    s->wfd = fds[1];
    if (sr_sub) {
        /* subscription will be returned to the caller */
        s->sr_sub = *sr_sub;
    } else {
        /* internal subscription, needs to be unsubscribed */
        s->unsub = 1;
    }
    s->xpath_filter = xpath_filter ? strdup(xpath_filter) : NULL;
    pthread_mutex_init(&s->stop_sntimer.lock, NULL);
    pthread_cond_init(&s->stop_sntimer.cond, NULL);
    if (stop_time) {
        s->stop_time = *stop_time;
    }
    s->conn = conn;
    if (nacm_user) {
        s->nacm_user = strdup(nacm_user);
    }

    *sub = s;

cleanup:
    return err_info;
}

void
srsn_sub_free_unsubscribe(struct srsn_sub *sub)
{
    uint32_t i;

    if (!sub) {
        return;
    }

    /* unsubscribe */
    if (sub->unsub) {
        sr_unsubscribe(sub->sr_sub);
        sub->sr_sub = NULL;
    } else {
        for (i = 0; i < sub->sr_sub_id_count; ++i) {
            sr_unsubscribe_sub(sub->sr_sub, sub->sr_sub_ids[i]);
        }
    }
    free(sub->sr_sub_ids);
    sub->sr_sub_ids = NULL;
    sub->sr_sub_id_count = 0;

    if (sub->type == SRSN_YANG_PUSH_PERIODIC) {
        srsn_update_timer(NULL, NULL, &sub->update_sntimer);
    }
    if (sub->type == SRSN_YANG_PUSH_ON_CHANGE) {
        srsn_update_timer(NULL, NULL, &sub->damp_sntimer);
    }
}

void
srsn_sub_free(struct srsn_sub *sub)
{
    sr_error_info_t *err_info = NULL;
    struct pollfd pfd = {0};
    struct timespec timeout_ts, cur_ts;
    uint32_t i;
    int r, dispatch_thread;

    if (!sub) {
        return;
    }

    /* unsubscribe */
    srsn_sub_free_unsubscribe(sub);

    /* free members */
    free(sub->xpath_filter);
    srsn_update_timer(NULL, NULL, &sub->stop_sntimer);
    if ((r = pthread_mutex_destroy(&sub->stop_sntimer.lock))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Destroying stop timer lock failed (%s).", strerror(r));
        sr_errinfo_free(&err_info);
    }
    pthread_cond_destroy(&sub->stop_sntimer.cond);
    free(sub->nacm_user);

    switch (sub->type) {
    case SRSN_SUB_NOTIF:
        free(sub->stream);
        for (i = 0; i < sub->rt_notif_count; ++i) {
            lyd_free_tree(sub->rt_notifs[i].notif);
        }
        free(sub->rt_notifs);
        break;
    case SRSN_YANG_PUSH_PERIODIC:
        if ((r = pthread_mutex_destroy(&sub->update_sntimer.lock))) {
            sr_errinfo_new(&err_info, SR_ERR_SYS, "Destroying update timer lock failed (%s).", strerror(r));
            sr_errinfo_free(&err_info);
        }
        pthread_cond_destroy(&sub->update_sntimer.cond);
        break;
    case SRSN_YANG_PUSH_ON_CHANGE:
        sr_release_data(sub->change_ntf);
        srsn_update_timer(NULL, NULL, &sub->damp_sntimer);
        if ((r = pthread_mutex_destroy(&sub->damp_sntimer.lock))) {
            sr_errinfo_new(&err_info, SR_ERR_SYS, "Destroying dampening timer lock failed (%s).", strerror(r));
            sr_errinfo_free(&err_info);
        }
        pthread_cond_destroy(&sub->damp_sntimer.cond);
        break;
    }

    /* close the pipe as last, poll can be waiting for it to signal the subscription fully terminated */
    if (sub->wfd > -1) {
        close(sub->wfd);

        /* DISPATCH LOCK */
        pthread_mutex_lock(&snstate.dispatch_lock);

        dispatch_thread = snstate.tid ? 1 : 0;

        /* DISPATCH UNLOCK */
        pthread_mutex_unlock(&snstate.dispatch_lock);

        if (dispatch_thread) {
            /* wait until the dispatch thread closes the read end */
            sr_timeouttime_get(&timeout_ts, SR_SN_READ_DISPATCH_CLOSE_TIMEOUT);
            pfd.fd = sub->rfd;
            while (1) {
                if (poll(&pfd, 1, 0) == -1) {
                    sr_errinfo_new(&err_info, SR_ERR_SYS, "Polling failed (%s).", strerror(errno));
                    sr_errinfo_free(&err_info);
                    break;
                } else if (!(pfd.revents & POLLHUP)) {
                    /* we expect POLLNVAL but the FD can have already been reused, but we know POLLHUP
                     * is returned before the read end is closed */
                    break;
                }

                /* check for timeout */
                sr_timeouttime_get(&cur_ts, 0);
                if (sr_time_cmp(&cur_ts, &timeout_ts) > 0) {
                    sr_errinfo_new(&err_info, SR_ERR_SYS, "Waiting for SN read dispatch thread close failed (timed out).");
                    sr_errinfo_free(&err_info);
                    break;
                }

                /* sleep */
                sr_msleep(20);
            }
        }
    }
    /* find it in the array */
    for (i = 0; i < snstate.count; ++i) {
        if (snstate.subs[i] == sub) {
            break;
        }
    }

    /* remove from the array, it may not be there yet */
    if (i < snstate.count) {
        if (i < snstate.count - 1) {
            snstate.subs[i] = snstate.subs[snstate.count - 1];
        }
        if (!--snstate.count) {
            free(snstate.subs);
            snstate.subs = NULL;
        }
    }

    free(sub);
}

/**
 * @brief Timer callback for stopping a subscriptions.
 */
static void
srsn_stop_timer_cb(void *arg, int *freed)
{
    struct srsn_sub *sub = arg;
    sr_error_info_t *err_info = NULL;

    /* TIMER UNLOCK */
    pthread_mutex_unlock(&sub->stop_sntimer.lock);

    if (sub->type == SRSN_SUB_NOTIF) {
        while (ATOMIC_LOAD_RELAXED(sub->replay_complete_count) < ATOMIC_LOAD_RELAXED(sub->sr_sub_id_count)) {
            /* wait until the replay is completed */
            sr_msleep(20);
        }
    }

    /* unsubscribe to prevent any more notifications to be sent */
    srsn_sub_free_unsubscribe(sub);

    /* send the subscription-terminated notification */
    if ((err_info = srsn_ntf_send_terminated(sub, "ietf-subscribed-notifications:no-such-subscription"))) {
        sr_errinfo_free(&err_info);
    }

    /* LOCK */
    err_info = srsn_lock();

    /* terminate the subscription */
    srsn_sub_free(sub);

    if (!err_info) {
        /* UNLOCK */
        srsn_unlock();
    } else {
        sr_errinfo_free(&err_info);
    }

    *freed = 1;
}

sr_error_info_t *
srsn_sub_schedule_stop(struct srsn_sub *sub)
{
    sr_error_info_t *err_info = NULL;

    if (!sub->stop_time.tv_sec) {
        return NULL;
    }

    /* schedule the stop */
    if ((err_info = srsn_create_timer(srsn_stop_timer_cb, sub, &sub->stop_time, NULL, &sub->stop_sntimer))) {
        goto cleanup;
    }

cleanup:
    return err_info;
}

sr_error_info_t *
srsn_sub_add(struct srsn_sub *sub)
{
    sr_error_info_t *err_info = NULL;
    void *mem;

    /* LOCK */
    if ((err_info = srsn_lock())) {
        return err_info;
    }

    mem = realloc(snstate.subs, (snstate.count + 1) * sizeof *snstate.subs);
    SR_CHECK_MEM_GOTO(!mem, err_info, cleanup);
    snstate.subs = mem;

    snstate.subs[snstate.count] = sub;
    ++snstate.count;

cleanup:
    /* UNLOCK */
    srsn_unlock();

    return NULL;
}

/**
 * @brief Get excluded-notifications count on a sysrepo subscription.
 *
 * @param[in] sr_sub SR subscription.
 * @param[in] sr_sub_ids SR subscription IDs.
 * @param[in] sr_sub_id_count Count of @p sr_sub_ids.
 * @param[in] type Subscription type.
 * @param[out] excluded Excluded notifications count.
 * @return Sysrepo error value.
 */
static int
srsn_state_collect_sr_sub_excluded(sr_subscription_ctx_t *sr_sub, uint32_t *sr_sub_ids, uint32_t sr_sub_id_count,
        srsn_sub_type_t type, uint32_t *excluded)
{
    int rc = SR_ERR_OK;
    uint32_t i, filtered_out;

    *excluded = 0;

    for (i = 0; i < sr_sub_id_count; ++i) {
        /* get filtered-out count for the subscription */
        switch (type) {
        case SRSN_SUB_NOTIF:
            rc = sr_notif_sub_get_info(sr_sub, sr_sub_ids[i], NULL, NULL, NULL, NULL, &filtered_out);
            break;
        case SRSN_YANG_PUSH_ON_CHANGE:
            rc = sr_module_change_sub_get_info(sr_sub, sr_sub_ids[i], NULL, NULL, NULL, &filtered_out);
            break;
        case SRSN_YANG_PUSH_PERIODIC:
            /* no subscriptions */
            assert(0);
            break;
        }
        if (rc) {
            return rc;
        }

        *excluded += filtered_out;
    }

    return rc;
}

sr_error_info_t *
srsn_state_collect_sub(const struct srsn_sub *s, srsn_state_sub_t *sub)
{
    sr_error_info_t *err_info = NULL;
    int r;

    sub->sub_id = s->id;
    sub->xpath_filter = s->xpath_filter ? strdup(s->xpath_filter) : NULL;
    sub->stop_time = s->stop_time;
    sub->sent_count = ATOMIC_LOAD_RELAXED(s->sent_count);
    if ((r = srsn_state_collect_sr_sub_excluded(s->sr_sub, s->sr_sub_ids,
            ATOMIC_LOAD_RELAXED(s->sr_sub_id_count), s->type, &sub->excluded_count))) {
        sr_errinfo_new(&err_info, r, "Failed to get the excluded-notification count.");
        return err_info;
    }

    switch (s->type) {
    case SRSN_SUB_NOTIF:
    case SRSN_YANG_PUSH_ON_CHANGE:
        assert(s->sr_sub_id_count);
        if ((r = sr_subscription_get_suspended(s->sr_sub, s->sr_sub_ids[0],
                &sub->suspended))) {
            sr_errinfo_new(&err_info, r, "Failed to learn whether a SR subscription is suspended.");
            return err_info;
        }
        break;
    case SRSN_YANG_PUSH_PERIODIC:
        sub->suspended = s->suspended;
        break;
    }

    sub->type = s->type;
    switch (s->type) {
    case SRSN_SUB_NOTIF:
        sub->sub_notif.stream = strdup(s->stream);
        sub->sub_notif.start_time = s->start_time;
        break;
    case SRSN_YANG_PUSH_PERIODIC:
        sub->yp_periodic.ds = s->ds;
        sub->yp_periodic.period = s->period_ms / 10;
        sub->yp_periodic.anchor_time = s->anchor_time;
        break;
    case SRSN_YANG_PUSH_ON_CHANGE:
        sub->yp_on_change.ds = s->ds;
        sub->yp_on_change.dampening_period = s->dampening_period_ms / 10;
        sub->yp_on_change.sync_on_start = s->sync_on_start;
        memcpy(sub->yp_on_change.excluded_change, s->excluded_changes,
                sizeof s->excluded_changes);

        sub->excluded_count += s->excluded_change_count;
        break;
    }

    return NULL;
}

sr_error_info_t *
srsn_state_collect(srsn_state_sub_t **subs, uint32_t *count)
{
    sr_error_info_t *err_info = NULL;
    uint32_t i;

    *subs = calloc(snstate.count, sizeof **subs);
    SR_CHECK_MEM_GOTO(!*subs, err_info, cleanup);
    *count = snstate.count;

    for (i = 0; i < snstate.count; ++i) {
        if ((err_info = srsn_state_collect_sub(snstate.subs[i], &(*subs)[i]))) {
            goto cleanup;
        }
    }

cleanup:
    if (err_info) {
        srsn_state_free(*subs, *count);
        *subs = NULL;
        *count = 0;
    }
    return err_info;
}

void
srsn_state_free(srsn_state_sub_t *subs, uint32_t count)
{
    uint32_t i;

    if (!subs) {
        return;
    }

    for (i = 0; i < count; ++i) {
        free(subs[i].xpath_filter);
        switch (subs[i].type) {
        case SRSN_SUB_NOTIF:
            free(subs[i].sub_notif.stream);
            break;
        case SRSN_YANG_PUSH_PERIODIC:
        case SRSN_YANG_PUSH_ON_CHANGE:
            break;
        }
    }
    free(subs);
}

struct srsn_sub *
srsn_find(uint32_t sub_id)
{
    struct srsn_sub *sub = NULL;
    uint32_t i;

    for (i = 0; i < snstate.count; ++i) {
        if (snstate.subs[i]->id == sub_id) {
            sub = snstate.subs[i];
            break;
        }
    }

    return sub;
}

/**
 * @brief Write a whole vector into an FD, completing any short writes.
 *
 * @param[in] fd File descriptor to write into.
 * @param[in,out] bufs Buffers to write, modified while completing short writes.
 * @param[in] buf_count Number of @p bufs.
 * @return err_info, NULL on success.
 */
static sr_error_info_t *
srsn_writev_all(int fd, struct iovec *bufs, int buf_count)
{
    sr_error_info_t *err_info = NULL;
    ssize_t w;
    int i = 0;

    while (i < buf_count) {
        w = writev(fd, &bufs[i], buf_count - i);
        if (w == -1) {
            if (errno == EINTR) {
                continue;
            }
            sr_errinfo_new(&err_info, SR_ERR_SYS, "Failed to write a notification (%s).", strerror(errno));
            return err_info;
        }

        /* skip the fully written buffers, adjust the partially written one */
        while ((i < buf_count) && ((size_t)w >= bufs[i].iov_len)) {
            w -= bufs[i].iov_len;
            ++i;
        }
        if (i < buf_count) {
            bufs[i].iov_base = ((char *)bufs[i].iov_base) + w;
            bufs[i].iov_len -= w;
        }
    }

    return NULL;
}

sr_error_info_t *
srsn_ntf_send(struct srsn_sub *sub, const struct timespec *timestamp, const struct lyd_node *ly_ntf)
{
    sr_error_info_t *err_info = NULL;
    struct iovec bufs[3];
    uint32_t size;
    char *ntf_lyb = NULL;

    /* 1) write the timestamp */
    bufs[0].iov_base = (void *)timestamp;
    bufs[0].iov_len = sizeof *timestamp;

    /* get the LYB notification data */
    if ((err_info = sr_lyd_print_data(ly_ntf, LYD_LYB, 0, -1, &ntf_lyb, &size))) {
        goto cleanup;
    }

    /* 2) write LYB size */
    bufs[1].iov_base = &size;
    bufs[1].iov_len = sizeof size;

    /* 3) write LYB data */
    bufs[2].iov_base = ntf_lyb;
    bufs[2].iov_len = size;

    /* vector write, atomic only up to PIPE_BUF so a short write must be completed manually */
    if ((err_info = srsn_writev_all(sub->wfd, bufs, 3))) {
        goto cleanup;
    }

    /* increase sent notification count */
    ATOMIC_INC_RELAXED(sub->sent_count);

cleanup:
    free(ntf_lyb);
    return err_info;
}

/**
 * @brief Timer thread function.
 */
static void *
srsn_timer_thread(void *arg)
{
    struct srsn_timer *sntimer = arg;
    struct timespec trigger;
    int r, freed = 0;
    uint32_t interval_ms;

    /* TIMER LOCK */
    pthread_mutex_lock(&sntimer->lock);

wait:
    do {
        /* wait until the trigger, allow its modification from another thread */
        trigger = sntimer->trigger;

        /* TIMER COND WAIT */
        r = pthread_cond_clockwait(&sntimer->cond, &sntimer->lock, CLOCK_REALTIME, &trigger);

        if (!sntimer->tid) {
            /* we should terminate */
            goto cleanup;
        }
    } while (!r);
    assert(r == ETIMEDOUT);

    /* call the callback */
    sntimer->cb(sntimer->arg, &freed);
    if (freed) {
        /* special case when the timer was unlocked and freed */
        return NULL;
    }

    /* prepare the next trigger after the callback */
    if (sntimer->interval.tv_sec || sntimer->interval.tv_nsec) {
        /* update the trigger to the current time */
        sr_realtime_get(&sntimer->trigger);

        interval_ms = sntimer->interval.tv_sec * 1000;
        interval_ms += sntimer->interval.tv_nsec / 1000000;

        /* add the interval */
        sntimer->trigger = sr_time_ts_add(&sntimer->trigger, interval_ms);

        /* wait until the next trigger */
        goto wait;
    }

cleanup:
    /* TIMER UNLOCK */
    pthread_mutex_unlock(&sntimer->lock);

    return NULL;
}

sr_error_info_t *
srsn_create_timer(void (*cb)(void *arg, int *freed), void *arg, const struct timespec *trigger,
        const struct timespec *interval, struct srsn_timer *sntimer)
{
    sr_error_info_t *err_info = NULL;
    int r;

    /* prepare argument */
    sntimer->cb = cb;
    sntimer->arg = arg;
    sntimer->trigger = *trigger;
    if (interval) {
        sntimer->interval = *interval;
    }

    /* create the timer thread */
    if ((r = pthread_create(&sntimer->tid, NULL, srsn_timer_thread, sntimer))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Failed to create a thread (%s).", strerror(r));
        return err_info;
    }

    return NULL;
}

void
srsn_update_timer(const struct timespec *trigger, const struct timespec *interval, struct srsn_timer *sntimer)
{
    sr_error_info_t *err_info = NULL;
    pthread_t tid = 0;
    int r;

    /* TIMER LOCK */
    pthread_mutex_lock(&sntimer->lock);

    /* timer must exist if it is not just a cleanup */
    assert(!trigger || sntimer->tid);

    if (!trigger) {
        if (sntimer->tid) {
            /* stop the timer, thread will terminate on its own */
            if (pthread_self() == sntimer->tid) {
                /* use detach because this is the timer thread itself */
                pthread_detach(sntimer->tid);
            } else {
                tid = sntimer->tid;
            }
            sntimer->tid = 0;
        }
    } else {
        /* update trigger and/or interval */
        sntimer->trigger = *trigger;
        if (interval) {
            sntimer->interval = *interval;
        } else {
            sntimer->interval.tv_sec = 0;
            sntimer->interval.tv_nsec = 0;
        }
    }

    /* COND SIGNAL */
    pthread_cond_signal(&sntimer->cond);

    /* TIMER UNLOCK */
    pthread_mutex_unlock(&sntimer->lock);

    if (tid) {
        /* wait until the thread finishes */
        if ((r = pthread_join(tid, NULL))) {
            sr_errinfo_new(&err_info, SR_ERR_SYS, "Failed to join a thread (%s).", strerror(r));
            sr_errinfo_free(&err_info);
        }
    }
}

sr_error_info_t *
srsn_ntf_send_terminated(struct srsn_sub *sub, const char *reason)
{
    sr_error_info_t *err_info = NULL;
    struct lyd_node *ly_ntf = NULL;
    sr_conn_ctx_t *conn;
    const struct ly_ctx *ly_ctx;
    char buf[26];
    struct timespec ts;

    conn = sub->conn;
    ly_ctx = sr_acquire_context(conn);

    sprintf(buf, "%" PRIu32, sub->id);
    if ((err_info = sr_lyd_new_path(NULL, ly_ctx, "/ietf-subscribed-notifications:subscription-terminated/id", buf, 0,
            &ly_ntf, NULL))) {
        goto cleanup;
    }
    if ((err_info = sr_lyd_new_path(ly_ntf, NULL, "reason", reason, 0, NULL, NULL))) {
        goto cleanup;
    }

    sr_realtime_get(&ts);
    if ((err_info = srsn_ntf_send(sub, &ts, ly_ntf))) {
        goto cleanup;
    }

cleanup:
    lyd_free_tree(ly_ntf);
    sr_release_context(conn);
    return err_info;
}

sr_error_info_t *
srsn_modify_xpath(struct srsn_sub *sub, const char *xpath_filter)
{
    sr_error_info_t *err_info = NULL;
    int rc = SR_ERR_OK;
    uint32_t i;

    if ((xpath_filter && !sub->xpath_filter) || (!xpath_filter && sub->xpath_filter) ||
            (xpath_filter && sub->xpath_filter && strcmp(xpath_filter, sub->xpath_filter))) {
        /* update the filter */
        for (i = 0; i < sub->sr_sub_id_count; ++i) {
            switch (sub->type) {
            case SRSN_SUB_NOTIF:
                rc = sr_notif_sub_modify_xpath(sub->sr_sub, sub->sr_sub_ids[i], xpath_filter);
                break;
            case SRSN_YANG_PUSH_ON_CHANGE:
                rc = sr_module_change_sub_modify_xpath(sub->sr_sub, sub->sr_sub_ids[i], xpath_filter);
                break;
            case SRSN_YANG_PUSH_PERIODIC:
                /* no subscriptions */
                break;
            }
            if (rc) {
                sr_errinfo_new(&err_info, rc, "Failed to modify XPath filter of a subscription.");
                goto cleanup;
            }
        }

        free(sub->xpath_filter);
        sub->xpath_filter = xpath_filter ? strdup(xpath_filter) : NULL;
    }

cleanup:
    return err_info;
}

sr_error_info_t *
srsn_modify_stop(struct srsn_sub *sub, const struct timespec *stop_time)
{
    sr_error_info_t *err_info = NULL;

    if ((!stop_time && sub->stop_time.tv_sec) || (stop_time && sr_time_cmp(&sub->stop_time, stop_time))) {
        if (!sub->stop_time.tv_sec) {
            /* create the stop timer */
            if ((err_info = srsn_create_timer(srsn_stop_timer_cb, sub, stop_time, NULL, &sub->stop_sntimer))) {
                goto cleanup;
            }
        } else {
            /* update/delete the stop timer */
            srsn_update_timer(stop_time, NULL, &sub->stop_sntimer);
        }

        /* update stored params */
        if (stop_time) {
            sub->stop_time = *stop_time;
        } else {
            sub->stop_time.tv_sec = 0;
            sub->stop_time.tv_nsec = 0;
        }
    }

cleanup:
    return err_info;
}

/**
 * @brief Add a notification duplicate into an array.
 *
 * @param[in] notif Notification to store.
 * @param[in] timestamp Notification timestamp.
 * @param[in,out] ntfs Notification array to add to.
 * @param[in,out] ntf_count Count of notifications in @p ntfs.
 */
static void
srsn_ntf_add_dup(const struct lyd_node *notif, const struct timespec *timestamp, struct srsn_rt_notif **ntfs,
        uint32_t *ntf_count)
{
    sr_error_info_t *err_info = NULL;
    void *mem;

    mem = realloc(*ntfs, (*ntf_count + 1) * sizeof **ntfs);
    if (!mem) {
        SR_ERRINFO_MEM(&err_info);
        sr_errinfo_free(&err_info);
        return;
    }
    *ntfs = mem;

    if ((err_info = sr_lyd_dup(notif, NULL, LYD_DUP_RECURSIVE | LYD_DUP_WITH_FLAGS, 0, &(*ntfs)[*ntf_count].notif))) {
        sr_errinfo_free(&err_info);
        return;
    }
    (*ntfs)[*ntf_count].timestamp = *timestamp;
    ++(*ntf_count);
}

/**
 * @brief New notification callback used for notifications received on subscription made by \<notif-subscribe\> RPC.
 */
static void
srsn_sn_rpc_subscribe_cb(sr_session_ctx_t *session, uint32_t UNUSED(sub_id), const sr_ev_notif_type_t notif_type,
        const struct lyd_node *notif, struct timespec *timestamp, void *private_data)
{
    struct srsn_sub *sub = private_data;
    sr_error_info_t *err_info = NULL;
    struct lyd_node *ly_ntf;
    const struct ly_ctx *ly_ctx;
    char buf[26];
    uint32_t i;

    /* context lock must be held */
    ly_ctx = sr_session_acquire_context(session);
    sr_session_release_context(session);

    if (notif) {
        /* find the top-level node */
        while (notif->parent) {
            notif = lyd_parent(notif);
        }
    }

    switch (notif_type) {
    case SR_EV_NOTIF_REPLAY_COMPLETE:
        if (ATOMIC_LOAD_RELAXED(sub->replay_complete_count) + 1 < ATOMIC_LOAD_RELAXED(sub->sr_sub_id_count)) {
            /* wait until all the SR subscriptions except for the last finish their replay */
            ATOMIC_INC_RELAXED(sub->replay_complete_count);
            break;
        }

        sprintf(buf, "%" PRIu32, sub->id);
        if (!(err_info = sr_lyd_new_path(NULL, ly_ctx, "/ietf-subscribed-notifications:replay-completed/id", buf, 0,
                &ly_ntf, NULL))) {
            if ((err_info = srsn_ntf_send(sub, timestamp, ly_ntf))) {
                sr_errinfo_free(&err_info);
            }
            lyd_free_tree(ly_ntf);
        } else {
            sr_errinfo_free(&err_info);
        }

        /* now send all the buffered notifications */
        for (i = 0; i < sub->rt_notif_count; ++i) {
            if ((err_info = srsn_ntf_send(sub, &sub->rt_notifs[i].timestamp, sub->rt_notifs[i].notif))) {
                sr_errinfo_free(&err_info);
            }
        }

        /* replay is completely finished (with all buffered notifications sent as well */
        ATOMIC_INC_RELAXED(sub->replay_complete_count);
        break;
    case SR_EV_NOTIF_REALTIME:
        assert(notif);
        if (ATOMIC_LOAD_RELAXED(sub->replay_complete_count) < ATOMIC_LOAD_RELAXED(sub->sr_sub_id_count)) {
            /* realtime notification received before replay has been completed, store in buffer */
            srsn_ntf_add_dup(notif, timestamp, &sub->rt_notifs, &sub->rt_notif_count);
        } else {
            /* send the realtime notification */
            if ((err_info = srsn_ntf_send(sub, timestamp, notif))) {
                sr_errinfo_free(&err_info);
            }
        }
        break;
    case SR_EV_NOTIF_REPLAY:
        assert(notif);

        /* send the replayed notification */
        if ((err_info = srsn_ntf_send(sub, timestamp, notif))) {
            sr_errinfo_free(&err_info);
        }
        break;
    case SR_EV_NOTIF_STOP_TIME:
        /* not generated */
        SR_ERRINFO_INT(&err_info);
        sr_errinfo_free(&err_info);
        break;
    case SR_EV_NOTIF_MODIFIED:
    case SR_EV_NOTIF_TERMINATED:
    case SR_EV_NOTIF_RESUMED:
    case SR_EV_NOTIF_SUSPENDED:
        /* handled elsewhere */
        break;
    }
}

sr_error_info_t *
srsn_sn_sr_subscribe(sr_session_ctx_t *sess, struct srsn_sub *sub, int sub_no_thread, struct timespec *replay_start)
{
    sr_error_info_t *err_info = NULL;
    const sr_error_info_t *tmp_err;
    const struct ly_ctx *ly_ctx;
    const struct lys_module *ly_mod;
    int rc = SR_ERR_OK;
    struct timespec earliest_notif, rpl_start;
    struct ly_set *mod_set = NULL;
    uint32_t idx;

    memset(replay_start, 0, sizeof *replay_start);
    ly_ctx = sr_session_acquire_context(sess);

    /* collect modules to subscribe to */
    if ((rc = srsn_stream_collect_mods(sub->stream, sub->xpath_filter, ly_ctx, &mod_set))) {
        sr_errinfo_new(&err_info, rc, "Failed to collect modules to subscribe to, invalid stream and/or XPath filter (%s).",
                sr_strerror(rc));
        goto error;
    }

    /* allocate all sub IDs */
    sub->sr_sub_ids = calloc(mod_set->count, sizeof *sub->sr_sub_ids);
    SR_CHECK_MEM_GOTO(!sub->sr_sub_ids, err_info, error);

    /* set subscription and replayed count */
    sub->sr_sub_id_count = mod_set->count;
    sub->replay_complete_count = sub->start_time.tv_sec ? 0 : mod_set->count;

    for (idx = 0; idx < mod_set->count; ++idx) {
        ly_mod = mod_set->objs[idx];

        /* learn replay start time */
        if ((rc = sr_get_module_replay_start(sr_session_get_connection(sess), ly_mod->name, &sub->start_time,
                &earliest_notif, &rpl_start))) {
            sr_errinfo_new(&err_info, rc, "Failed to learn the start of module \"%s\" replay (%s).", ly_mod->name,
                    sr_strerror(rc));
            goto error;
        }

        /* update the earliest replay start time, if:
         * 1) the module's replay is enabled, there is a notif stored after sub->start_time (time from which
         *    the user wants to receive notifications) and the replay was enabled prior to storing the earliest notif,
         * 2) the found notification is earlier than the current one (find minimum). */
        if (rpl_start.tv_sec && earliest_notif.tv_sec && (sr_time_cmp(&rpl_start, &earliest_notif) <= 0)) {
            if (!replay_start->tv_sec || (sr_time_cmp(replay_start, &rpl_start) > 0)) {
                *replay_start = rpl_start;
            }
        }

        /* subscribe to the module */
        if ((rc = sr_notif_subscribe_tree(sess, ly_mod->name, sub->xpath_filter,
                sub->start_time.tv_sec ? &sub->start_time : NULL, NULL, srsn_sn_rpc_subscribe_cb, sub,
                sub_no_thread ? SR_SUBSCR_NO_THREAD : 0, &sub->sr_sub))) {
            sr_session_get_error(sess, &tmp_err);
            sr_errinfo_new(&err_info, tmp_err->err[0].err_code, "%s", tmp_err->err[0].message);
            goto error;
        }

        /* add new sub ID */
        sub->sr_sub_ids[idx] = sr_subscription_get_last_sub_id(sub->sr_sub);
    }

    goto cleanup;

error:
    for (idx = 0; idx < sub->sr_sub_id_count; ++idx) {
        if (sub->sr_sub_ids[idx]) {
            sr_unsubscribe_sub(sub->sr_sub, sub->sr_sub_ids[idx]);
        }
    }
    free(sub->sr_sub_ids);
    sub->sr_sub_ids = NULL;
    sub->sr_sub_id_count = 0;

cleanup:
    sr_session_release_context(sess);
    ly_set_free(mod_set, NULL);
    return err_info;
}

sr_error_info_t *
srsn_dispatch_init(sr_conn_ctx_t *conn, srsn_notif_cb cb)
{
    sr_error_info_t *err_info = NULL;
    int r;

    /* DISPATCH LOCK */
    if ((r = pthread_mutex_lock(&snstate.dispatch_lock))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Locking failed (%s: %s).", __func__, strerror(r));
        return err_info;
    }

    snstate.conn = conn;
    snstate.cb = cb;

    /* DISPATCH UNLOCK */
    pthread_mutex_unlock(&snstate.dispatch_lock);

    return NULL;
}

/**
 * @brief Thread reading notifications from subscriptions.
 */
static void *
srsn_read_dispatch_thread(void *UNUSED(arg))
{
    sr_error_info_t *err_info = NULL;
    const struct ly_ctx *ly_ctx;
    struct timespec ts;
    struct lyd_node *notif = NULL;
    uint32_t i;
    int r, locked = 0;

    /* DISPATCH LOCK */
    if ((r = pthread_mutex_lock(&snstate.dispatch_lock))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Locking failed (%s: %s).", __func__, strerror(r));
        goto cleanup;
    }
    locked = 1;

    while (snstate.tid) {
        /* poll */
        if (snstate.valid_pfds) {
            r = poll(snstate.pfds, snstate.pfd_count, 10);
        } else {
            r = 0;
        }
        if (r == -1) {
            if (errno != EINTR) {
                sr_errinfo_new(&err_info, SR_ERR_SYS, "Poll failed (%s).", strerror(errno));
                sr_errinfo_free(&err_info);
                err_info = NULL;
            }

            /* never fatal, the thread is never restarted, retry after the sleep below */
            r = 0;
        }

        for (i = 0; (i < snstate.pfd_count) && r; ++i) {
            if (!snstate.pfds[i].revents) {
                /* no event */
                continue;
            }

            if (snstate.pfds[i].revents & POLLIN) {
                /* lock the context */
                ly_ctx = sr_acquire_context(snstate.conn);

                /* read all notifs and call the callback */
                while (!srsn_read_notif(snstate.pfds[i].fd, ly_ctx, &ts, &notif)) {
                    snstate.cb(notif, &ts, snstate.cb_data[i]);
                    lyd_free_tree(notif);
                }

                /* release the context */
                sr_release_context(snstate.conn);
            }

            if (snstate.pfds[i].revents & (POLLHUP | POLLERR)) {
                /* terminated or in an error state, either way it is done */
                close(snstate.pfds[i].fd);
                snstate.pfds[i].fd = -1;
                snstate.cb_data[i] = NULL;
                --snstate.valid_pfds;
            } else if (snstate.pfds[i].revents & POLLNVAL) {
                /* the FD was closed behind our back, just drop the item, closing again could affect
                 * an unrelated FD that reused the number */
                snstate.pfds[i].fd = -1;
                snstate.cb_data[i] = NULL;
                --snstate.valid_pfds;
            }

            /* processed */
            --r;
        }

        /* DISPATCH UNLOCK */
        pthread_mutex_unlock(&snstate.dispatch_lock);
        locked = 0;

        /* sleep, to yield the lock */
        sr_msleep(10);

        /* DISPATCH LOCK */
        if ((r = pthread_mutex_lock(&snstate.dispatch_lock))) {
            sr_errinfo_new(&err_info, SR_ERR_SYS, "Locking failed (%s: %s).", __func__, strerror(r));
            goto cleanup;
        }
        locked = 1;
    }

cleanup:
    if (locked) {
        /* DISPATCH UNLOCK */
        pthread_mutex_unlock(&snstate.dispatch_lock);
    }

    sr_errinfo_free(&err_info);
    return NULL;
}

sr_error_info_t *
srsn_dispatch_add(int fd, void *cb_data)
{
    sr_error_info_t *err_info = NULL;
    uint32_t i;
    void *mem;
    int r;

    /* DISPATCH LOCK */
    if ((r = pthread_mutex_lock(&snstate.dispatch_lock))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Locking failed (%s: %s).", __func__, strerror(r));
        return err_info;
    }

    if (!snstate.conn || !snstate.cb) {
        sr_errinfo_new(&err_info, SR_ERR_INVAL_ARG, "Subscribed-notifications read dispatch not initialized.");
        goto cleanup;
    }

    if (snstate.valid_pfds < snstate.pfd_count) {
        /* move the invalid PFDs and their cb_data, keep the order */
        i = 0;
        while (i < snstate.pfd_count) {
            if (snstate.pfds[i].fd == -1) {
                memmove(&snstate.pfds[i], &snstate.pfds[i + 1], (snstate.pfd_count - (i + 1)) * sizeof *snstate.pfds);
                memmove(&snstate.cb_data[i], &snstate.cb_data[i + 1], (snstate.pfd_count - (i + 1)) * sizeof *snstate.cb_data);

                --snstate.pfd_count;
            } else {
                ++i;
            }
        }
    }

    /* realloc arrays */
    mem = realloc(snstate.pfds, (snstate.valid_pfds + 1) * sizeof *snstate.pfds);
    SR_CHECK_MEM_GOTO(!mem, err_info, cleanup);
    snstate.pfds = mem;
    mem = realloc(snstate.cb_data, (snstate.valid_pfds + 1) * sizeof *snstate.cb_data);
    SR_CHECK_MEM_GOTO(!mem, err_info, cleanup);
    snstate.cb_data = mem;

    /* add the new items */
    snstate.pfds[snstate.valid_pfds].fd = fd;
    snstate.pfds[snstate.valid_pfds].events = POLLIN;
    snstate.cb_data[snstate.valid_pfds] = cb_data;

    ++snstate.valid_pfds;
    snstate.pfd_count = snstate.valid_pfds;

    if (!snstate.tid) {
        /* create the thread */
        if ((r = pthread_create(&snstate.tid, NULL, srsn_read_dispatch_thread, NULL))) {
            sr_errinfo_new(&err_info, SR_ERR_SYS, "Failed to create a thread (%s).", strerror(r));

            /* roll back the new item, on error the FD is not registered */
            --snstate.valid_pfds;
            snstate.pfd_count = snstate.valid_pfds;
            goto cleanup;
        }
    }

cleanup:
    /* DISPATCH UNLOCK */
    pthread_mutex_unlock(&snstate.dispatch_lock);

    return err_info;
}

sr_error_info_t *
srsn_dispatch_del(int fd)
{
    sr_error_info_t *err_info = NULL;
    uint32_t i;
    int r;

    /* DISPATCH LOCK, the dispatch thread holds it while calling the callback, so once acquired,
     * no callback is running nor can start before we are done */
    if ((r = pthread_mutex_lock(&snstate.dispatch_lock))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Locking failed (%s: %s).", __func__, strerror(r));
        return err_info;
    }

    for (i = 0; i < snstate.pfd_count; ++i) {
        if (snstate.pfds[i].fd != fd) {
            continue;
        }

        /* invalidate the item, it is removed from the arrays by the next add. Close the FD while still
         * holding the lock, the dispatch thread closes it on POLLHUP under the same lock but then there
         * is no valid item left to find here, so it is always closed exactly once. */
        close(snstate.pfds[i].fd);
        snstate.pfds[i].fd = -1;
        snstate.cb_data[i] = NULL;
        --snstate.valid_pfds;
        break;
    }

    /* DISPATCH UNLOCK */
    pthread_mutex_unlock(&snstate.dispatch_lock);

    return err_info;
}

uint32_t
srsn_dispatch_count(void)
{
    sr_error_info_t *err_info = NULL;
    int r;
    uint32_t count = 0;

    /* DISPATCH LOCK */
    if ((r = pthread_mutex_lock(&snstate.dispatch_lock))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Locking failed (%s: %s).", __func__, strerror(r));
        goto cleanup;
    }

    count = snstate.valid_pfds;

    /* DISPATCH UNLOCK */
    pthread_mutex_unlock(&snstate.dispatch_lock);

cleanup:
    sr_errinfo_free(&err_info);
    return count;
}

sr_error_info_t *
srsn_dispatch_destroy(void)
{
    sr_error_info_t *err_info = NULL;
    pthread_t tid;
    uint32_t i;
    int r;

    /* DISPATCH LOCK */
    if ((r = pthread_mutex_lock(&snstate.dispatch_lock))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Locking failed (%s: %s).", __func__, strerror(r));
        goto cleanup;
    }

    tid = snstate.tid;
    snstate.tid = 0;

    /* DISPATCH UNLOCK */
    pthread_mutex_unlock(&snstate.dispatch_lock);

    /* join the thread */
    if (tid && (r = pthread_join(tid, NULL))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Joining a thread failed (%s: %s).", __func__, strerror(r));
        goto cleanup;
    }

    /* DISPATCH LOCK */
    if ((r = pthread_mutex_lock(&snstate.dispatch_lock))) {
        sr_errinfo_new(&err_info, SR_ERR_SYS, "Locking failed (%s: %s).", __func__, strerror(r));
        goto cleanup;
    }

    /* free vars */
    for (i = 0; i < snstate.pfd_count; ++i) {
        if (snstate.pfds[i].fd > -1) {
            close(snstate.pfds[i].fd);
        }
    }
    free(snstate.pfds);
    snstate.pfds = NULL;
    free(snstate.cb_data);
    snstate.cb_data = NULL;
    snstate.pfd_count = 0;
    snstate.valid_pfds = 0;

    /* DISPATCH UNLOCK */
    pthread_mutex_unlock(&snstate.dispatch_lock);

cleanup:
    return err_info;
}
