/**
 * @file replay.h
 * @author Michal Vasko <mvasko@cesnet.cz>
 * @brief header for notification replay routines
 *
 * @copyright
 * Copyright (c) 2018 - 2025 Deutsche Telekom AG.
 * Copyright (c) 2018 - 2025 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */

#ifndef _REPLAY_H
#define _REPLAY_H

#include <time.h>

#include <libyang/libyang.h>

#include "sysrepo_types.h"

struct modsub_notifsub_s;

/**
 * @brief Store a notification for replay.
 *
 * @param[in] conn Connection to use.
 * @param[in] sess Session to use, if available.
 * @param[in] notif Notification to store.
 * @param[in] notif_ts Notification timestamp to store.
 * @return err_info, NULL on success.
 */
sr_error_info_t *sr_replay_store(sr_conn_ctx_t *conn, sr_session_ctx_t *sess, const struct lyd_node *notif,
        struct timespec notif_ts);

/**
 * @brief Notification buffer thread.
 *
 * @param[in] arg Pointer to the session.
 * @return Always NULL.
 */
void *sr_notif_buf_thread(void *arg);

/**
 * @brief Replay valid notifications.
 *
 * @param[in] notif_sub Notification subscription structure to use.
 * @param[in] mod_name Module name.
 * @return err_info, NULL on success.
 */
sr_error_info_t *sr_replay_notify(struct modsub_notifsub_s *notif_sub, const char *mod_name);

#endif
