/**
 * @file session.c
 * @author Michal Vasko <mvasko@cesnet.cz>
 * @brief libnetconf2 - general session functions
 *
 * @copyright
 * Copyright (c) 2015 - 2026 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */
#define _GNU_SOURCE

#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <libyang/libyang.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "compat.h"
#include "config.h"
#include "log_p.h"
#include "netconf.h"
#include "session_p.h"

#ifdef NC_ENABLED_SSH_TLS

#include "session_server_ssh_wrapper.h"
#include "session_wrapper.h"

#include <curl/curl.h>
#include <libssh/libssh.h>

#endif /* NC_ENABLED_SSH_TLS */

/* in seconds */
#define NC_CLIENT_HELLO_TIMEOUT 60
#define NC_SERVER_CH_HELLO_TIMEOUT 180

/* in milliseconds */
#define NC_CLOSE_REPLY_TIMEOUT 200

void
nc_timeouttime_get(struct timespec *ts, uint32_t add_ms)
{
    if (clock_gettime(COMPAT_CLOCK_ID, ts) == -1) {
        ERR(NULL, "clock_gettime() failed (%s).", strerror(errno));
        return;
    }

    if (!add_ms) {
        return;
    }

    assert((ts->tv_nsec >= 0) && (ts->tv_nsec < 1000000000L));

    ts->tv_sec += add_ms / 1000;
    ts->tv_nsec += (add_ms % 1000) * 1000000L;

    if (ts->tv_nsec >= 1000000000L) {
        ++ts->tv_sec;
        ts->tv_nsec -= 1000000000L;
    } else if (ts->tv_nsec < 0) {
        --ts->tv_sec;
        ts->tv_nsec += 1000000000L;
    }

    assert((ts->tv_nsec >= 0) && (ts->tv_nsec < 1000000000L));
}

int32_t
nc_time_diff(const struct timespec *ts1, const struct timespec *ts2)
{
    int64_t nsec_diff = 0;

    nsec_diff += (((int64_t)ts1->tv_sec) - ((int64_t)ts2->tv_sec)) * 1000000000L;
    nsec_diff += ((int64_t)ts1->tv_nsec) - ((int64_t)ts2->tv_nsec);

    return nsec_diff / 1000000L;
}

int32_t
nc_timeouttime_cur_diff(const struct timespec *ts)
{
    struct timespec cur;

    nc_timeouttime_get(&cur, 0);

    return nc_time_diff(ts, &cur);
}

void
nc_realtime_get(struct timespec *ts)
{
    if (clock_gettime(CLOCK_REALTIME, ts)) {
        ERR(NULL, "clock_gettime() failed (%s).", strerror(errno));
        return;
    }
}

int
nc_poll(struct pollfd *pfd, uint16_t pfd_count, int timeout_ms)
{
    int rc;
    struct timespec start_ts;

    if (timeout_ms > 0) {
        /* get current time */
        nc_timeouttime_get(&start_ts, 0);
    }

    do {
        /* poll */
        rc = poll(pfd, pfd_count, timeout_ms);

        if (timeout_ms > 0) {
            /* adjust the timeout by subtracting the elapsed time (relevant in case of EINTR) */
            timeout_ms += nc_timeouttime_cur_diff(&start_ts);
            if (timeout_ms < 0) {
                /* manual timeout */
                rc = 0;
                errno = 0;
                break;
            }
        }
    } while ((rc == -1) && (errno == EINTR));

    if (rc == -1) {
        ERR(NULL, "Poll failed (%s).", strerror(errno));
    }
    return rc;
}

#ifdef NC_ENABLED_SSH_TLS

void *
nc_base64der_to_cert(const char *data)
{
    char *buf = NULL;
    void *cert;

    NC_CHECK_ARG_RET(NULL, data, NULL);

    if (asprintf(&buf, "%s%s%s", "-----BEGIN CERTIFICATE-----\n", data, "\n-----END CERTIFICATE-----") == -1) {
        ERRMEM;
        return NULL;
    }

    cert = nc_tls_pem_to_cert_wrap(buf);
    free(buf);
    return cert;
}

const char *
nc_privkey_format_to_str(enum nc_privkey_format format)
{
    switch (format) {
    case NC_PRIVKEY_FORMAT_RSA:
        return " RSA ";
    case NC_PRIVKEY_FORMAT_EC:
        return " EC ";
    case NC_PRIVKEY_FORMAT_X509:
        return " ";
    case NC_PRIVKEY_FORMAT_OPENSSH:
        return " OPENSSH ";
    default:
        return NULL;
    }
}

int
nc_is_pk_subject_public_key_info(const char *b64)
{
    int ret = 0;
    long len;
    unsigned char *bin = NULL, *tmp;

    /* decode base64 */
    len = nc_base64_decode_wrap(b64, &bin);
    if (len == -1) {
        ret = -1;
        goto cleanup;
    }

    /* for deallocation later */
    tmp = bin;

    /* try to parse the supposed SubjectPublicKeyInfo binary data */
    if (nc_tls_is_der_subpubkey_wrap(tmp, len)) {
        /* success, it's most likely SubjectPublicKeyInfo */
        ret = 1;
    } else {
        /* it's most likely not SubjectPublicKeyInfo */
        ret = 0;
    }

cleanup:
    free(bin);
    return ret;
}

#endif /* NC_ENABLED_SSH_TLS */

int
nc_sock_configure_ka(int sock, const struct nc_keepalives *ka)
{
    int opt;

    opt = ka->enabled;
    if (setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &opt, sizeof opt) == -1) {
        ERR(NULL, "Failed to set SO_KEEPALIVE (%s).", strerror(errno));
        return -1;
    }

    if (!ka->enabled) {
        return 0;
    }

#ifdef TCP_KEEPIDLE
    opt = ka->idle_time;
    if (setsockopt(sock, IPPROTO_TCP, TCP_KEEPIDLE, &opt, sizeof opt) == -1) {
        ERR(NULL, "Failed to set TCP_KEEPIDLE (%s).", strerror(errno));
        return -1;
    }
#endif

#ifdef TCP_KEEPCNT
    opt = ka->max_probes;
    if (setsockopt(sock, IPPROTO_TCP, TCP_KEEPCNT, &opt, sizeof opt) == -1) {
        ERR(NULL, "Failed to set TCP_KEEPCNT (%s).", strerror(errno));
        return -1;
    }
#endif

#ifdef TCP_KEEPINTVL
    opt = ka->probe_interval;
    if (setsockopt(sock, IPPROTO_TCP, TCP_KEEPINTVL, &opt, sizeof opt) == -1) {
        ERR(NULL, "Failed to set TCP_KEEPINTVL (%s).", strerror(errno));
        return -1;
    }
#endif

    return 0;
}

struct nc_session *
nc_new_session(NC_SIDE side, int shared_ti)
{
    struct nc_session *sess;
    struct timespec ts_cur;

    sess = calloc(1, sizeof *sess);
    if (!sess) {
        return NULL;
    }

    sess->side = side;

    if (side == NC_SERVER) {
        pthread_mutex_init(&sess->opts.server.ntf_status_lock, NULL);
        pthread_mutex_init(&sess->opts.server.rpc_lock, NULL);
        pthread_cond_init(&sess->opts.server.rpc_cond, NULL);

        pthread_mutex_init(&sess->opts.server.ch_lock, NULL);
        pthread_cond_init(&sess->opts.server.ch_cond, NULL);

        /* initialize last_rpc for idle_timeout */
        nc_timeouttime_get(&ts_cur, 0);
        sess->opts.server.last_rpc = ts_cur.tv_sec;
    } else {
        pthread_mutex_init(&sess->opts.client.msgs_lock, NULL);
    }

    if (!shared_ti) {
        sess->io_rd_lock = malloc(sizeof *sess->io_rd_lock);
        if (!sess->io_rd_lock) {
            goto error;
        }
        pthread_mutex_init(sess->io_rd_lock, NULL);

        sess->io_wr_lock = malloc(sizeof *sess->io_wr_lock);
        if (!sess->io_wr_lock) {
            goto error;
        }
        pthread_mutex_init(sess->io_wr_lock, NULL);
    }

    return sess;

error:
    free(sess);
    return NULL;
}

/*
 * @return 1 - success
 *         0 - timeout
 *        -1 - error
 */
int
nc_session_rpc_lock(struct nc_session *session, int timeout, const char *func)
{
    int ret;
    struct timespec ts_timeout;

    if (session->side != NC_SERVER) {
        ERRINT;
        return -1;
    }

    if (timeout > 0) {
        nc_timeouttime_get(&ts_timeout, timeout);

        /* LOCK */
        ret = pthread_mutex_clocklock(&session->opts.server.rpc_lock, COMPAT_CLOCK_ID, &ts_timeout);
        if (!ret) {
            while (session->opts.server.rpc_inuse) {
                ret = pthread_cond_clockwait(&session->opts.server.rpc_cond, &session->opts.server.rpc_lock,
                        COMPAT_CLOCK_ID, &ts_timeout);
                if (ret) {
                    pthread_mutex_unlock(&session->opts.server.rpc_lock);
                    break;
                }
            }
        }
    } else if (!timeout) {
        /* LOCK */
        ret = pthread_mutex_trylock(&session->opts.server.rpc_lock);
        if (!ret) {
            if (session->opts.server.rpc_inuse) {
                pthread_mutex_unlock(&session->opts.server.rpc_lock);
                return 0;
            }
        }
    } else { /* timeout == -1 */
        /* LOCK */
        ret = pthread_mutex_lock(&session->opts.server.rpc_lock);
        if (!ret) {
            while (session->opts.server.rpc_inuse) {
                ret = pthread_cond_wait(&session->opts.server.rpc_cond, &session->opts.server.rpc_lock);
                if (ret) {
                    pthread_mutex_unlock(&session->opts.server.rpc_lock);
                    break;
                }
            }
        }
    }

    if (ret) {
        if ((ret == EBUSY) || (ret == ETIMEDOUT)) {
            /* timeout */
            return 0;
        }

        /* error */
        ERR(session, "%s: failed to RPC lock a session (%s).", func, strerror(ret));
        return -1;
    }

    /* ok */
    assert(session->opts.server.rpc_inuse == 0);
    session->opts.server.rpc_inuse = 1;

    /* UNLOCK */
    ret = pthread_mutex_unlock(&session->opts.server.rpc_lock);
    if (ret) {
        /* error */
        ERR(session, "%s: failed to RPC unlock a session (%s).", func, strerror(ret));
        return -1;
    }

    return 1;
}

int
nc_session_rpc_unlock(struct nc_session *session, int timeout, const char *func)
{
    int ret;
    struct timespec ts_timeout;

    if (session->side != NC_SERVER) {
        ERRINT;
        return -1;
    }

    assert(session->opts.server.rpc_inuse);

    if (timeout > 0) {
        nc_timeouttime_get(&ts_timeout, timeout);

        /* LOCK */
        ret = pthread_mutex_clocklock(&session->opts.server.rpc_lock, COMPAT_CLOCK_ID, &ts_timeout);
    } else if (!timeout) {
        /* LOCK */
        ret = pthread_mutex_trylock(&session->opts.server.rpc_lock);
    } else { /* timeout == -1 */
        /* LOCK */
        ret = pthread_mutex_lock(&session->opts.server.rpc_lock);
    }

    if (ret && (ret != EBUSY) && (ret != ETIMEDOUT)) {
        /* error */
        ERR(session, "%s: failed to RPC lock a session (%s).", func, strerror(ret));
        return -1;
    } else if (ret) {
        WRN(session, "%s: session RPC lock timeout, should not happen.", func);
    }

    session->opts.server.rpc_inuse = 0;
    pthread_cond_signal(&session->opts.server.rpc_cond);

    if (!ret) {
        /* UNLOCK */
        ret = pthread_mutex_unlock(&session->opts.server.rpc_lock);
        if (ret) {
            /* error */
            ERR(session, "%s: failed to RPC unlock a session (%s).", func, strerror(ret));
            return -1;
        }
    }

    return 1;
}

int
nc_rwlock_lock(pthread_rwlock_t *rwlock, enum nc_rwlock_mode mode, int timeout, const char *func_name)
{
    int ret;
    struct timespec ts_timeout;

    if (!rwlock || (mode == NC_RWLOCK_NONE)) {
        ERRINT;
        return -1;
    }

    if (timeout > 0) {
        /* get absolute time for timeout */
        nc_timeouttime_get(&ts_timeout, timeout);

        /* acquire lock with timeout based on mode */
        if (mode == NC_RWLOCK_READ) {
            ret = pthread_rwlock_clockrdlock(rwlock, COMPAT_CLOCK_ID, &ts_timeout);
        } else {
            ret = pthread_rwlock_clockwrlock(rwlock, COMPAT_CLOCK_ID, &ts_timeout);
        }
    } else if (!timeout) {
        /* try to acquire lock without waiting */
        if (mode == NC_RWLOCK_READ) {
            ret = pthread_rwlock_tryrdlock(rwlock);
        } else {
            ret = pthread_rwlock_trywrlock(rwlock);
        }
    } else {
        /* acquire lock without timeout */
        if (mode == NC_RWLOCK_READ) {
            ret = pthread_rwlock_rdlock(rwlock);
        } else {
            ret = pthread_rwlock_wrlock(rwlock);
        }
    }

    if (ret) {
        if ((ret == EBUSY) || (ret == ETIMEDOUT)) {
            /* timeout, a trylock (no timeout) being busy is a normal outcome, an expired deadline is not */
            if (timeout > 0) {
                ERR(NULL, "%s: timed out after %d ms waiting for the rwlock in %s mode.", func_name, timeout,
                        mode == NC_RWLOCK_READ ? "read" : "write");
            }
            return 0;
        }

        ERR(NULL, "%s: failed to lock rwlock in %s mode (%s).", func_name,
                mode == NC_RWLOCK_READ ? "read" : "write", strerror(ret));
        return -1;
    }

    return 1;
}

void
nc_rwlock_unlock(pthread_rwlock_t *rwlock, const char *func_name)
{
    int r;

    if (!rwlock) {
        ERRINT;
        return;
    }

    r = pthread_rwlock_unlock(rwlock);
    if (r) {
        ERR(NULL, "%s: failed to unlock rwlock (%s).", func_name, strerror(r));
    }
}

int
nc_mutex_clocklock(pthread_mutex_t *mutex, const struct timespec *ts_deadline, const char *func_name)
{
    int r;

    if (!mutex) {
        ERRINT;
        return -1;
    }

    if (ts_deadline) {
        /* acquire the lock until the deadline, an expired one still locks a free mutex */
        r = pthread_mutex_clocklock(mutex, COMPAT_CLOCK_ID, ts_deadline);
    } else {
        /* acquire the lock without any timeout */
        r = pthread_mutex_lock(mutex);
    }

    if (r) {
        if ((r == EBUSY) || (r == ETIMEDOUT)) {
            /* timeout, the caller knows what it asked for so it logs the details */
            return 0;
        }

        ERR(NULL, "%s: failed to lock mutex (%s).", func_name, strerror(r));
        return -1;
    }

    return 1;
}

int
nc_mutex_lock(pthread_mutex_t *mutex, int timeout, const char *func_name)
{
    int ret;
    struct timespec ts_timeout;

    if (!mutex) {
        ERRINT;
        return -1;
    }

    if (timeout > 0) {
        /* get absolute time for timeout */
        nc_timeouttime_get(&ts_timeout, timeout);

        /* acquire lock with timeout */
        ret = pthread_mutex_clocklock(mutex, COMPAT_CLOCK_ID, &ts_timeout);
    } else if (!timeout) {
        /* try to acquire lock without waiting */
        ret = pthread_mutex_trylock(mutex);
    } else {
        /* acquire lock without timeout */
        ret = pthread_mutex_lock(mutex);
    }

    if (ret) {
        if ((ret == EBUSY) || (ret == ETIMEDOUT)) {
            /* timeout, a trylock (no timeout) being busy is a normal outcome, an expired deadline is not */
            if (timeout > 0) {
                ERR(NULL, "%s: timed out after %d ms waiting for the mutex.", func_name, timeout);
            }
            return 0;
        }

        ERR(NULL, "%s: failed to lock mutex (%s).", func_name, strerror(ret));
        return -1;
    }

    return 1;
}

void
nc_mutex_unlock(pthread_mutex_t *mutex, const char *func_name)
{
    int r;

    if (!mutex) {
        ERRINT;
        return;
    }

    r = pthread_mutex_unlock(mutex);
    if (r) {
        ERR(NULL, "%s: failed to unlock mutex (%s).", func_name, strerror(r));
    }
}

API NC_STATUS
nc_session_get_status(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, NC_STATUS_ERR);

    return NC_SESSION_STATUS_GET(session);
}

API NC_SESSION_TERM_REASON
nc_session_get_term_reason(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, NC_SESSION_TERM_ERR);

    return NC_SESSION_TERM_REASON_GET(session);
}

API uint32_t
nc_session_get_killed_by(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, 0);

    return session->killed_by;
}

API uint32_t
nc_session_get_id(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, 0);

    return session->id;
}

API int
nc_session_get_version(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, -1);

    return session->version == NC_PROT_VERSION_10 ? 0 : 1;
}

API NC_TRANSPORT_IMPL
nc_session_get_ti(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, 0);

    return session->ti_type;
}

API const char *
nc_session_get_username(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, NULL);

    return session->username;
}

API const char *
nc_session_get_host(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, NULL);

    return session->host;
}

API const char *
nc_session_get_path(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, NULL);

    if (session->ti_type != NC_TI_UNIX) {
        return NULL;
    }

    return session->path;
}

API uint16_t
nc_session_get_port(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, 0);

    return session->port;
}

#ifdef NC_ENABLED_SSH_TLS

API const char *
nc_session_ssh_get_protocol_string(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(NULL, session, NULL);

    if (session->ti_type != NC_TI_SSH) {
        ERR(NULL, "Cannot get the SSH protocol string of a non-SSH session.");
        return NULL;
    }

    if (session->side == NC_SERVER) {
        return ssh_get_clientbanner(session->ti.libssh.session);
    } else {
        return ssh_get_serverbanner(session->ti.libssh.session);
    }
}

API const char *
nc_session_ssh_get_banner(const struct nc_session *session)
{
    return nc_session_ssh_get_protocol_string(session);
}

#endif

API const struct ly_ctx *
nc_session_get_ctx(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, NULL);

    return session->ctx;
}

API const char * const *
nc_session_get_cpblts(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, NULL);

    return (const char * const *)session->cpblts;
}

API const char *
nc_session_cpblt(const struct nc_session *session, const char *capab)
{
    int i, len;

    NC_CHECK_ARG_RET(session, session, capab, NULL);

    len = strlen(capab);
    for (i = 0; session->cpblts[i]; ++i) {
        if (!strncmp(session->cpblts[i], capab, len)) {
            return session->cpblts[i];
        }
    }

    return NULL;
}

API void
nc_session_set_data(struct nc_session *session, void *data)
{
    if (!session) {
        ERRARG(NULL, "session");
        return;
    }

    session->data = data;
}

API void *
nc_session_get_data(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, NULL);

    return session->data;
}

API int
nc_session_is_callhome(const struct nc_session *session)
{
    NC_CHECK_ARG_RET(session, session, 0);

    if (session->flags & NC_SESSION_CALLHOME) {
        return 1;
    }

    return 0;
}

/**
 * @brief Send a transport shutdown indication to the peer.
 *
 * Depending on the transport type, this may involve sending transport-specific
 * shutdown signaling so the peer can detect no more outgoing data are expected.
 *
 * @param[in] session Closing NETCONF session.
 */
static void
nc_session_free_send_transport_shutdown(struct nc_session *session)
{
    switch (session->ti_type) {
    case NC_TI_FD:
    case NC_TI_UNIX:
        /* nothing needed - the transport will be closed by caller */
        break;
#ifdef NC_ENABLED_SSH_TLS
    case NC_TI_SSH:
        if (session->ti.libssh.channel) {
            if (session->side == NC_SERVER) {
                /* send SSH channel close - we will not be reading nor writing anymore */
                ssh_channel_close(session->ti.libssh.channel);
            } else if (session->side == NC_CLIENT) {
                /* send SSH channel EOF - we can still receive data from the server, but not send.
                 * we will close the channel later, after receiving the server acknowledges our EOF,
                 * since we are the one initiating it */
                ssh_channel_send_eof(session->ti.libssh.channel);
            }
        }
        break;
    case NC_TI_TLS:
        /* send TLS close_notify alert - we can still receive data from the peer, but not send */
        if (session->ti.tls.session) {
            nc_tls_close_notify_wrap(session->ti.tls.session);
        }
        break;
#endif
    default:
        break;
    }
}

/**
 * @brief Send \<close-session\> to the peer.
 *
 * @param[in] session Closing NETCONF session.
 * @param[out] close_rpc The sent \<close-session\> RPC, caller must free.
 * @return 0 on success, 1 on failure (RPC not sent).
 */
static int
nc_session_free_send_close_session(struct nc_session *session, struct lyd_node **close_rpc)
{
    struct lys_module *ietfnc;
    struct lyd_node *rpc = NULL;
    NC_MSG_TYPE msg_type;

    *close_rpc = NULL;

    ietfnc = ly_ctx_get_module_implemented(session->ctx, "ietf-netconf");
    if (!ietfnc) {
        WRN(session, "Missing ietf-netconf module in context, unable to send <close-session>.");
        return 1;
    }
    if (lyd_new_inner(NULL, ietfnc, "close-session", 0, &rpc)) {
        WRN(session, "Failed to create <close-session> RPC.");
        return 1;
    }

    /* send the RPC */
    msg_type = nc_write_msg_io(session, NC_SESSION_FREE_LOCK_TIMEOUT, NC_MSG_RPC, rpc, NULL);
    if (msg_type != NC_MSG_RPC) {
        WRN(session, "Failed to send <close-session> RPC.");
        lyd_free_tree(rpc);
        return 1;
    } else {
        *close_rpc = rpc;
        return 0;
    }
}

/**
 * @brief Wait for the \<close-session\> reply from the server and process it.
 *
 * @note Waits for at most ::NC_CLOSE_REPLY_TIMEOUT ms.
 *
 * @param[in] session Closing NETCONF session.
 * @param[in] close_rpc The sent \<close-session\> RPC.
 */
static void
nc_session_free_wait_close_session_reply(struct nc_session *session, struct lyd_node *close_rpc)
{
    int32_t timeout;
    struct timespec ts_end;
    struct ly_in *msg = NULL;
    struct lyd_node *envp = NULL;

    nc_timeouttime_get(&ts_end, NC_CLOSE_REPLY_TIMEOUT);

read_msg:
    timeout = nc_timeouttime_cur_diff(&ts_end);
    if (timeout <= 0) {
        /* avoid waiting for the reply for long in case of notification flooding */
        WRN(session, "Timeout for receiving a reply to <close-session> elapsed.");
        return;
    }

    switch (nc_read_msg_poll_io(session, timeout, &msg)) {
    case 1:
        if (!strncmp(ly_in_memory(msg, NULL), "<notification", 13)) {
            /* ignore */
            ly_in_free(msg, 1);
            msg = NULL;
            goto read_msg;
        }
        if (lyd_parse_op(session->ctx, close_rpc, msg, LYD_XML, LYD_TYPE_REPLY_NETCONF, LYD_PARSE_STRICT, &envp, NULL)) {
            WRN(session, "Failed to parse <close-session> reply.");
        } else if (!lyd_child(envp) || strcmp(LYD_NAME(lyd_child(envp)), "ok")) {
            WRN(session, "Reply to <close-session> was not <ok> as expected.");
        }
        lyd_free_tree(envp);
        envp = NULL;
        ly_in_free(msg, 1);
        msg = NULL;
        break;
    case 0:
        WRN(session, "Timeout for receiving a reply to <close-session> elapsed.");
        break;
    case -1:
        ERR(session, "Failed to receive a reply to <close-session>.");
        break;
    default:
        /* cannot happen */
        break;
    }
}

/**
 * @brief Gracefully close a client session on NETCONF and transport levels.
 *
 * Sends the \<close-session\> RPC to close the NETCONF layer and then sends
 * a transport shutdown indication.
 *
 * @param[in] session Closing NETCONF session.
 */
static void
nc_session_free_client_close_graceful(struct nc_session *session)
{
    int r;
    struct ly_in *msg;
    struct lyd_node *close_rpc = NULL;

    /* receive any leftover messages */
    while (nc_read_msg_poll_io(session, 0, &msg) == 1) {
        ly_in_free(msg, 1);
    }

    /* send the <close-session> RPC */
    r = nc_session_free_send_close_session(session, &close_rpc);

    /* regardless of RPC-send result, send transport shutdown indication */
    nc_session_free_send_transport_shutdown(session);

    if (!r) {
        /* if we sent the RPC successfully, wait for the server reply */
        nc_session_free_wait_close_session_reply(session, close_rpc);
    }
    lyd_free_tree(close_rpc);
}

/**
 * @brief Free transport implementation members of a session.
 *
 * @param[in] session Session to free.
 * @param[out] multisession Whether there are other NC sessions on the same SSH sessions.
 */
static void
nc_session_free_transport(struct nc_session *session, int *multisession)
{
    int sock = -1;

    *multisession = 0;

    /* transport implementation cleanup */
    switch (session->ti_type) {
    case NC_TI_FD:
        /* nothing needed - file descriptors were provided by caller,
         * so it is up to the caller to close them correctly
         * TODO use callbacks
         */
        break;

    case NC_TI_UNIX:
        sock = session->ti.unixsock.sock;
        break;

#ifdef NC_ENABLED_SSH_TLS
    case NC_TI_SSH: {
        int r;
        struct nc_session *siter;
        void **channel_cbs = NULL, **channel_cbs_tmp;
        uint16_t channel_cbs_count = 0, i;

        /* There can be multiple NETCONF sessions on the same SSH session (NETCONF session maps to
         * SSH channel). So destroy the SSH session only if there is no other NETCONF session using
         * it. Also, avoid concurrent free by multiple threads of sessions that share the SSH session.
         */
        /* SESSION IO RD/WR LOCK */
        r = nc_mutex_lock(session->io_rd_lock, NC_SESSION_FREE_LOCK_TIMEOUT, __func__);
        if (r == 1) {
            r = nc_mutex_lock(session->io_wr_lock, NC_SESSION_FREE_LOCK_TIMEOUT, __func__);
            if (r != 1) {
                nc_mutex_unlock(session->io_rd_lock, __func__);
            }
        }

        if (session->ti.libssh.channel) {
            if ((session->side == NC_CLIENT) ||
                    ((session->side == NC_SERVER) && (NC_SESSION_TERM_REASON_GET(session) == NC_SESSION_TERM_CLOSED))) {
                /* NC_SERVER: session was properly closed by the client, so he should have sent SSH channel EOF.
                 * Polling here should properly set libssh internal state and avoid libssh WRN log about writing
                 * to a closed channel in ssh_channel_free().
                 * NC_CLIENT: we are waiting for the server to acknowledge our SSH channel EOF
                 * by sending us its own SSH channel EOF. */
                if (ssh_channel_poll_timeout(session->ti.libssh.channel, NC_SESSION_FREE_SSH_POLL_EOF_TIMEOUT, 0) != SSH_EOF) {
                    WRN(session, "Timeout for receiving SSH channel EOF from the %s elapsed.",
                            session->side == NC_CLIENT ? "server" : "client");
                }
            }
            ssh_channel_free(session->ti.libssh.channel);
            free(session->ti.libssh.channel_cb);
        }

        if (session->ti.libssh.next) {
            for (siter = session->ti.libssh.next; siter != session; siter = siter->ti.libssh.next) {
                if (NC_SESSION_STATUS_GET(siter) != NC_STATUS_STARTING) {
                    *multisession = 1;
                    break;
                }
            }
        }

        if (!*multisession) {
            /* it's not multisession yet, but we still need to free the starting sessions */
            if (session->ti.libssh.next) {
                do {
                    siter = session->ti.libssh.next;
                    session->ti.libssh.next = siter->ti.libssh.next;

                    /* free starting SSH NETCONF session (channel will be freed in ssh_free()) */
                    free(siter->username);
                    free(siter->host);
                    if (siter->ti.libssh.channel_cb) {
                        /* channel callbacks must stay valid until all the channels are freed in
                         * ssh_free(), so only collect them here and free them afterwards */
                        channel_cbs_tmp = realloc(channel_cbs, (channel_cbs_count + 1) * sizeof *channel_cbs);
                        if (channel_cbs_tmp) {
                            channel_cbs = channel_cbs_tmp;
                            channel_cbs[channel_cbs_count++] = siter->ti.libssh.channel_cb;
                        } else {
                            /* leak this one struct, the channel would otherwise use freed callbacks */
                            ERRMEM;
                        }
                    }
                    if (!(siter->flags & NC_SESSION_SHAREDCTX)) {
                        ly_ctx_destroy((struct ly_ctx *)siter->ctx);
                    }

                    free(siter);
                } while (session->ti.libssh.next != session);
            }

            /* remember sock so we can close it */
            sock = ssh_get_fd(session->ti.libssh.session);

            /* clears sock but does not close it if passed via options (libssh >= 0.10) */
            ssh_disconnect(session->ti.libssh.session);
#if (LIBSSH_VERSION_MAJOR == 0 && LIBSSH_VERSION_MINOR < 10)
            sock = -1;
#endif

#if LIBSSH_0_12
            /* Free ssh event before freeing the session */
            ssh_event_free(session->ti.libssh.event);
#endif

            /* closes sock if set */
            ssh_free(session->ti.libssh.session);

            /* all the SSH channels were freed now, free their callback data */
            for (i = 0; i < channel_cbs_count; ++i) {
                free(channel_cbs[i]);
            }
            free(channel_cbs);

#if LIBSSH_0_12
            /* Free callback data after session is destroyed */
            nc_server_ssh_cb_data_free(session->ti.libssh.cb_data);
#endif
        } else {
            /* remove the session from the list */
            for (siter = session->ti.libssh.next; siter->ti.libssh.next != session; siter = siter->ti.libssh.next) {}
            if (session->ti.libssh.next == siter) {
                /* there will be only one session */
                siter->ti.libssh.next = NULL;
            } else {
                /* there are still multiple sessions, keep the ring list */
                siter->ti.libssh.next = session->ti.libssh.next;
            }
#if LIBSSH_0_12
            /* transfer cb_data to a remaining session so it's freed when the SSH session is freed */
            if (session->ti.libssh.cb_data) {
                /* the callback data now belongs to the surviving session */
                ((struct nc_server_ssh_cb_data *)session->ti.libssh.cb_data)->session = siter;
                siter->ti.libssh.cb_data = session->ti.libssh.cb_data;
                session->ti.libssh.cb_data = NULL;
            }
            if (session->ti.libssh.event) {
                siter->ti.libssh.event = session->ti.libssh.event;
                session->ti.libssh.event = NULL;
            }
#endif
        }

        /* SESSION IO RD/WR UNLOCK */
        if (r == 1) {
            nc_mutex_unlock(session->io_rd_lock, __func__);
            nc_mutex_unlock(session->io_wr_lock, __func__);
        }
        break;
    }
    case NC_TI_TLS:
        sock = nc_tls_get_fd_wrap(session);

        nc_tls_ctx_destroy_wrap(&session->ti.tls.ctx);
        memset(&session->ti.tls.ctx, 0, sizeof session->ti.tls.ctx);
        nc_tls_session_destroy_wrap(session->ti.tls.session);
        session->ti.tls.session = NULL;
        nc_tls_config_destroy_wrap(session->ti.tls.config);
        session->ti.tls.config = NULL;

        if (session->side == NC_SERVER) {
            nc_tls_cert_destroy_wrap(session->opts.server.client_cert);
        }

        break;
#endif /* NC_ENABLED_SSH_TLS */
    case NC_TI_NONE:
        break;
    }

    /* close socket separately */
    if (sock > -1) {
        close(sock);
    }
}

API void
nc_session_free(struct nc_session *session, void (*data_free)(void *))
{
    int r, i, rpc_locked = 0, ch_locked = 0;
    int multisession = 0; /* flag for more NETCONF sessions on a single SSH session */
    struct timespec ts;
    NC_STATUS status;

    if (!session) {
        return;
    }

    /* check whether this session is already closing */
    if (NC_SESSION_STATUS_GET(session) == NC_STATUS_CLOSING) {
        return;
    }

    if (session->side == NC_CLIENT) {
        if (session->flags & NC_SESSION_CLIENT_MONITORED) {
            /* remove the session from the monitored list */
            nc_client_monitoring_session_stop(session, 1);
        }

        if (ATOMIC_LOAD_RELAXED(session->opts.client.ntf_thread_running)) {
            /* stop notification threads if any */
            nc_client_notification_threads_stop(session);
        }
    }

    if (session->side == NC_SERVER) {
        /* RPC LOCK, not to receive new RPCs while we're freeing the session, continue on error */
        r = nc_session_rpc_lock(session, NC_SESSION_FREE_LOCK_TIMEOUT, __func__);
        if (r == -1) {
            return;
        } else if (r) {
            rpc_locked = 1;
        } else {
            /* else failed to lock it, too bad */
            ERR(session, "Freeing a session while an RPC is being processed.");
        }
    }

    if (session->side == NC_CLIENT) {
        /* free queued messages */
        nc_client_msgs_free(session);
    }

    /* notify the peer that we're closing the session, either if:
     * - session running - normal disconnect from client
     * - session invalid - client disconnected from a Call Home session */
    status = NC_SESSION_STATUS_GET(session);
    if ((status == NC_STATUS_RUNNING) ||
            ((session->side == NC_SERVER) && (session->flags & NC_SESSION_CALLHOME) &&
            (status == NC_STATUS_INVALID) && (NC_SESSION_TERM_REASON_GET(session) == NC_SESSION_TERM_CLOSED))) {
        if (session->side == NC_CLIENT) {
            /* graceful close: <close-session> + transport shutdown indication */
            nc_session_free_client_close_graceful(session);
        } else if (session->side == NC_SERVER) {
            /* only send transport shutdown indication to the peer */
            nc_session_free_send_transport_shutdown(session);
        }
    }

    if ((session->side == NC_SERVER) && (session->flags & NC_SESSION_CALLHOME)) {
        /* CH LOCK, continue on error */
        if (nc_mutex_lock(&session->opts.server.ch_lock, NC_SESSION_CH_LOCK_TIMEOUT, __func__) == 1) {
            ch_locked = 1;
        }
    }

    /* mark session for closing */
    NC_SESSION_STATUS_SET(session, NC_STATUS_CLOSING);

    if ((session->side == NC_SERVER) && (session->flags & NC_SESSION_CALLHOME)) {
        /* wake up the Call Home thread so that it learns the session is closing, done while holding
         * ch_lock (if we got it) so that a thread about to wait on the condition cannot miss it */
        pthread_cond_signal(&session->opts.server.ch_cond);

        /* CH UNLOCK */
        if (ch_locked) {
            /* only if we locked it */
            nc_mutex_unlock(&session->opts.server.ch_lock, __func__);
        }

        /* wait for the Call Home thread to stop using the session, it needs ch_lock to get there
         * so this must not be done while holding it */
        nc_timeouttime_get(&ts, NC_SESSION_FREE_LOCK_TIMEOUT);
        while (ATOMIC_LOAD_ACQUIRE(session->opts.server.ch_thread_active)) {
            if (nc_timeouttime_cur_diff(&ts) < 1) {
                ERR(session, "Waiting for the Call Home thread timed out.");
                break;
            }
            usleep(NC_TIMEOUT_STEP);
        }
    }

    /* transport implementation cleanup */
    nc_session_free_transport(session, &multisession);

    /* final cleanup */
    free(session->username);
    free(session->host);
    free(session->path);
    if (session->cpblts) {
        for (i = 0; session->cpblts[i]; i++) {
            free(session->cpblts[i]);
        }
        free(session->cpblts);
    }

    if (session->data && data_free) {
        data_free(session->data);
    }

    if (session->side == NC_SERVER) {
        pthread_mutex_destroy(&session->opts.server.ntf_status_lock);
        if (rpc_locked) {
            nc_session_rpc_unlock(session, NC_SESSION_LOCK_TIMEOUT, __func__);
        }
        pthread_mutex_destroy(&session->opts.server.rpc_lock);
        pthread_cond_destroy(&session->opts.server.rpc_cond);
    }

    if (session->io_rd_lock && !multisession) {
        pthread_mutex_destroy(session->io_rd_lock);
        free(session->io_rd_lock);
    }
    if (session->io_wr_lock && !multisession) {
        pthread_mutex_destroy(session->io_wr_lock);
        free(session->io_wr_lock);
    }

    if (!(session->flags & NC_SESSION_SHAREDCTX)) {
        ly_ctx_destroy((struct ly_ctx *)session->ctx);
    }

    if (session->side == NC_SERVER) {
        /* free CH synchronization structures */
        pthread_cond_destroy(&session->opts.server.ch_cond);
        pthread_mutex_destroy(&session->opts.server.ch_lock);
    } else {
        pthread_mutex_destroy(&session->opts.client.msgs_lock);
    }

    free(session);
}

/**
 * @brief Add a capability into an array.
 *
 * @param[in] capab Capability to add.
 * @param[in,out] cpblts Array of capabilities to add to, terminated with NULL.
 * @param[in,out] count Count of @p cpblts.
 * @return 0 on success;
 * @return -1 on error.
 */
static int
nc_add_cpblt(const char *capab, char ***cpblts, uint32_t *count)
{
    uint32_t i, len;
    const char *p;

    /*  check if already present */
    p = strchr(capab, '?');
    if (p) {
        len = p - capab;
    } else {
        len = strlen(capab);
    }
    for (i = 0; i < *count; i++) {
        if (!strncmp((*cpblts)[i], capab, len) && (((*cpblts)[i][len] == '\0') || ((*cpblts)[i][len] == '?'))) {
            /* already present, do not duplicate it */
            return 0;
        }
    }

    /* add another capability */
    *cpblts = nc_realloc(*cpblts, (*count + 2) * sizeof **cpblts);
    if (!(*cpblts)) {
        ERRMEM;
        return -1;
    }

    (*cpblts)[*count] = strdup(capab);
    if (!(*cpblts)[*count]) {
        ERRMEM;
        return -1;
    }
    ++(*count);

    /* terminating NULL */
    (*cpblts)[*count] = NULL;

    return 0;
}

/**
 * @brief Append string to a string buffer.
 *
 * @param[in,out] str String to append to.
 * @param[in,out] used Used bytes of @p str excluding the terminating 0 byte.
 * @param[in,out] size Size of @p str.
 * @param[in] app_format Format string to append.
 * @param[in] ... Format string arguments.
 * @return 0 on success,
 * @return -1 on error.
 */
static int
nc_str_append(char **str, uint32_t *used, uint32_t *size, const char *app_format, ...)
{
    va_list ap;
    char *ptr;
    int r;

    /* get the string end to avoid (NULL + 0) (which UBSAN reports as undefined behaviour :| ) */
    ptr = *str ? *str + *used : NULL;

    /* try to append */
    va_start(ap, app_format);
    r = vsnprintf(ptr, *size - *used, app_format, ap);
    va_end(ap);

    if (*used + r >= *size) {
        /* enlarge */
        *str = nc_realloc(*str, *used + r + 1);
        NC_CHECK_ERRMEM_RET(!*str, -1);

        *size = *used + r + 1;

        /* append */
        va_start(ap, app_format);
        *used += vsnprintf(*str + *used, *size - *used, app_format, ap);
        va_end(ap);
    } else {
        *used += r;
    }

    return 0;
}

/**
 * @brief Get the server capabilities.
 *
 * @param[in] ctx libyang context.
 * @param[in] version YANG version of the schemas to be included in result.
 * @return Array of capabilities terminated with NULL, NULL on error.
 */
static char **
_nc_server_get_cpblts_version(const struct ly_ctx *ctx, LYS_VERSION version)
{
    char **cpblts;
    const struct lys_module *mod;
    uint32_t i, count, str_used = 0, str_size = 0;
    LYA_COUNT_T v;
    char *yl_content_id = NULL;
    uint32_t wd_also_supported, wd_basic_mode;
    char *str = NULL;
    const struct nc_server_config *config;

    NC_CHECK_ARG_RET(NULL, ctx, NULL);

    /* pin the configuration, only the ignored module names are needed from it, so if there is none
     * (the server is not initialized) simply no module is ignored */
    config = nc_server_config_acquire();

    cpblts = malloc(3 * sizeof *cpblts);
    NC_CHECK_ERRMEM_GOTO(!cpblts, , error);
    cpblts[0] = strdup("urn:ietf:params:netconf:base:1.0");
    cpblts[1] = strdup("urn:ietf:params:netconf:base:1.1");
    cpblts[2] = NULL;
    count = 2;

    mod = ly_ctx_get_module_implemented(ctx, "ietf-netconf");
    if (mod) {
        if (lys_feature_value(mod, "writable-running") == LY_SUCCESS) {
            NC_CHECK_GOTO(nc_add_cpblt("urn:ietf:params:netconf:capability:writable-running:1.0", &cpblts, &count), error);
        }
        if (lys_feature_value(mod, "candidate") == LY_SUCCESS) {
            NC_CHECK_GOTO(nc_add_cpblt("urn:ietf:params:netconf:capability:candidate:1.0", &cpblts, &count), error);
            if (lys_feature_value(mod, "confirmed-commit") == LY_SUCCESS) {
                NC_CHECK_GOTO(nc_add_cpblt("urn:ietf:params:netconf:capability:confirmed-commit:1.1", &cpblts, &count), error);
            }
        }
        if (lys_feature_value(mod, "rollback-on-error") == LY_SUCCESS) {
            NC_CHECK_GOTO(nc_add_cpblt("urn:ietf:params:netconf:capability:rollback-on-error:1.0", &cpblts, &count), error);
        }
        if (lys_feature_value(mod, "validate") == LY_SUCCESS) {
            NC_CHECK_GOTO(nc_add_cpblt("urn:ietf:params:netconf:capability:validate:1.1", &cpblts, &count), error);
        }
        if (lys_feature_value(mod, "startup") == LY_SUCCESS) {
            NC_CHECK_GOTO(nc_add_cpblt("urn:ietf:params:netconf:capability:startup:1.0", &cpblts, &count), error);
        }

        /* The URL capability must be set manually using nc_server_set_capability()
         * because of the need for supported protocols to be included.
         * https://tools.ietf.org/html/rfc6241#section-8.8.3
         */
        // if (lys_feature_value(mod, "url") == LY_SUCCESS) {
        // NC_CHECK_GOTO(nc_add_cpblt("urn:ietf:params:netconf:capability:url:1.0", &cpblts, &count), error);
        // }

        if (lys_feature_value(mod, "xpath") == LY_SUCCESS) {
            NC_CHECK_GOTO(nc_add_cpblt("urn:ietf:params:netconf:capability:xpath:1.0", &cpblts, &count), error);
        }
    }

    /* HELLO LOCK */
    if (nc_rwlock_lock(&server_opts.hello_lock, NC_RWLOCK_READ, NC_HELLO_LOCK_TIMEOUT, __func__) != 1) {
        goto error;
    }

    mod = ly_ctx_get_module_implemented(ctx, "ietf-netconf-with-defaults");
    if (mod) {
        wd_basic_mode = server_opts.wd_basic_mode;
        if (!wd_basic_mode) {
            VRB(NULL, "with-defaults capability will not be advertised even though \"ietf-netconf-with-defaults\" "
                    "model is present, unknown basic-mode.");
        } else {
            str_used = 0;
            NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "urn:ietf:params:netconf:capability:with-defaults:1.0"),
                    unlock_error);
            switch (wd_basic_mode) {
            case NC_WD_ALL:
                NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "?basic-mode=report-all"), unlock_error);
                break;
            case NC_WD_TRIM:
                NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "?basic-mode=trim"), unlock_error);
                break;
            case NC_WD_EXPLICIT:
                NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "?basic-mode=explicit"), unlock_error);
                break;
            default:
                ERRINT;
                goto unlock_error;
            }

            wd_also_supported = server_opts.wd_also_supported;
            if (wd_also_supported) {
                NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "&also-supported="), unlock_error);
                if (wd_also_supported & NC_WD_ALL) {
                    NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "report-all,"), unlock_error);
                }
                if (wd_also_supported & NC_WD_ALL_TAG) {
                    NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "report-all-tagged,"), unlock_error);
                }
                if (wd_also_supported & NC_WD_TRIM) {
                    NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "trim,"), unlock_error);
                }
                if (wd_also_supported & NC_WD_EXPLICIT) {
                    NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "explicit,"), unlock_error);
                }
                str[str_used] = '\0';
                --str_used;

                NC_CHECK_GOTO(nc_add_cpblt(str, &cpblts, &count), unlock_error);
            }
        }
    }

    /* other capabilities */
    for (i = 0; i < server_opts.capabilities_count; i++) {
        NC_CHECK_GOTO(nc_add_cpblt(server_opts.capabilities[i], &cpblts, &count), unlock_error);
    }

    /* models */
    i = 0;
    while ((mod = ly_ctx_get_module_iter(ctx, &i))) {
        if (nc_server_is_mod_ignored(config, mod->name)) {
            /* ignored, not part of the cababilities */
            continue;
        }

        if (!strcmp(mod->name, "ietf-yang-library")) {
            if (!mod->revision || (strcmp(mod->revision, "2016-06-21") && strcmp(mod->revision, "2019-01-04"))) {
                ERR(NULL, "Unknown \"ietf-yang-library\" revision, only 2016-06-21 and 2019-01-04 are supported.");
                goto unlock_error;
            }

            /* get content-id */
            if (server_opts.content_id_clb) {
                yl_content_id = server_opts.content_id_clb(server_opts.content_id_data);
                NC_CHECK_ERRMEM_GOTO(!yl_content_id, , unlock_error);
            } else {
                yl_content_id = malloc(11);
                NC_CHECK_ERRMEM_GOTO(!yl_content_id, , unlock_error);
                sprintf(yl_content_id, "%" PRIu16, ly_ctx_get_change_count(ctx));
            }

            if (!strcmp(mod->revision, "2019-01-04")) {
                /* new one (capab defined in RFC 8526 section 2) */
                str_used = 0;
                NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size,
                        "urn:ietf:params:netconf:capability:yang-library:1.1?revision=%s&content-id=%s",
                        mod->revision, yl_content_id), unlock_error);
                NC_CHECK_GOTO(nc_add_cpblt(str, &cpblts, &count), unlock_error);
            } else {
                /* old one (capab defined in RFC 7950 section 5.6.4) */
                str_used = 0;
                NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size,
                        "urn:ietf:params:netconf:capability:yang-library:1.0?revision=%s&module-set-id=%s",
                        mod->revision, yl_content_id), unlock_error);
                NC_CHECK_GOTO(nc_add_cpblt(str, &cpblts, &count), unlock_error);
            }
            free(yl_content_id);
            yl_content_id = NULL;
            continue;
        } else if (mod->version != version) {
            /* skip YANG 1.0 or 1.1 modules */
            continue;
        }

        str_used = 0;
        NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "%s?module=%s%s%s", mod->ns, mod->name,
                mod->revision ? "&revision=" : "", mod->revision ? mod->revision : ""), unlock_error);

        if (mod->compiled) {
            LYA_FOR(mod->compiled->features, v) {
                if (!v) {
                    NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "&features="), unlock_error);
                } else {
                    NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, ","), unlock_error);
                }
                NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, mod->compiled->features[v]), unlock_error);
            }
        }

        LYA_FOR(mod->deviated_by, v) {
            if (!v) {
                NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, "&deviations="), unlock_error);
            } else {
                NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, ","), unlock_error);
            }
            NC_CHECK_GOTO(nc_str_append(&str, &str_used, &str_size, mod->deviated_by[v]->name), unlock_error);
        }

        NC_CHECK_GOTO(nc_add_cpblt(str, &cpblts, &count), unlock_error);
    }

    /* HELLO UNLOCK */
    nc_rwlock_unlock(&server_opts.hello_lock, __func__);

    nc_server_config_release(config);
    free(str);
    return cpblts;

unlock_error:
    /* HELLO UNLOCK */
    nc_rwlock_unlock(&server_opts.hello_lock, __func__);

error:
    nc_server_config_release(config);
    if (cpblts) {
        for (i = 0; cpblts[i]; ++i) {
            free(cpblts[i]);
        }
        free(cpblts);
    }
    free(yl_content_id);
    free(str);
    return NULL;
}

API char **
nc_server_get_cpblts_version(const struct ly_ctx *ctx, LYS_VERSION version)
{
    return _nc_server_get_cpblts_version(ctx, version);
}

API char **
nc_server_get_cpblts(const struct ly_ctx *ctx)
{
    return _nc_server_get_cpblts_version(ctx, LYS_VERSION_UNDEF);
}

/**
 * @brief Parse received capabilities.
 *
 * @param[in] capabilities Opaque capability nodes.
 * @param[out] list List of parsed capabilities terminated by NULL.
 * @return NETCONF version;
 * @return -1 on error.
 */
static int
nc_parse_cpblts(struct lyd_node *capabilities, char ***list)
{
    struct lyd_node *iter;
    struct lyd_node_opaq *cpblt;
    int ver = -1, i = 0;
    const char *cpb_start, *cpb_end;

    /* get the storage for capabilities */
    LY_LIST_FOR(lyd_child(capabilities), iter) {
        i++;
    }
    /* last item remains NULL */
    *list = calloc(i + 1, sizeof **list);
    NC_CHECK_ERRMEM_RET(!*list, -1);
    i = 0;

    LY_LIST_FOR(lyd_child(capabilities), iter) {
        cpblt = (struct lyd_node_opaq *)iter;

        if (strcmp(cpblt->name.name, "capability") || !cpblt->name.module_ns || strcmp(cpblt->name.module_ns, NC_NS_BASE)) {
            ERR(NULL, "Unexpected <%s> element in client's <hello>.", cpblt->name.name);
            return -1;
        }

        /* skip leading/trailing whitespaces */
        for (cpb_start = cpblt->value; isspace(cpb_start[0]); ++cpb_start) {}
        for (cpb_end = cpblt->value + strlen(cpblt->value); (cpb_end > cpblt->value) && isspace(cpb_end[-1]); --cpb_end) {}
        if (!cpb_start[0] || (cpb_end == cpblt->value)) {
            ERR(NULL, "Empty capability \"%s\" received.", cpblt->value);
            return -1;
        }

        /* detect NETCONF version */
        if ((ver < 0) && !strncmp(cpb_start, "urn:ietf:params:netconf:base:1.0", cpb_end - cpb_start)) {
            ver = 0;
        } else if ((ver < 1) && !strncmp(cpb_start, "urn:ietf:params:netconf:base:1.1", cpb_end - cpb_start)) {
            ver = 1;
        }

        /* store capabilities */
        (*list)[i] = strndup(cpb_start, cpb_end - cpb_start);
        NC_CHECK_ERRMEM_RET(!(*list)[i], -1);
        i++;
    }

    if (ver == -1) {
        ERR(NULL, "Peer does not support a compatible NETCONF version.");
    }

    return ver;
}

/**
 * @brief Get client-side capabilities.
 *
 * @return Array of capabilities terminated with NULL, NULL on error.
 */
static char **
nc_client_get_cpblts(void)
{
    char **cpblts = NULL;
    uint32_t i, count;

    cpblts = malloc(3 * sizeof *cpblts);
    NC_CHECK_ERRMEM_GOTO(!cpblts, , error);

    cpblts[0] = strdup("urn:ietf:params:netconf:base:1.0");
    NC_CHECK_ERRMEM_GOTO(!cpblts[0], , error);
    cpblts[1] = strdup("urn:ietf:params:netconf:base:1.1");
    NC_CHECK_ERRMEM_GOTO(!cpblts[1], , error);
    cpblts[2] = NULL;
    count = 2;

    /* custom capabilities */
    for (i = 0; i < client_opts.capabilities_count; ++i) {
        NC_CHECK_GOTO(nc_add_cpblt(client_opts.capabilities[i], &cpblts, &count), error);
    }

    return cpblts;

error:
    if (cpblts) {
        for (i = 0; cpblts[i]; ++i) {
            free(cpblts[i]);
        }
        free(cpblts);
    }
    return NULL;
}

/**
 * @brief Send NETCONF hello message on a session.
 *
 * @param[in] session Session to send the message on.
 * @return Sent message type.
 */
static NC_MSG_TYPE
nc_send_hello_io(struct nc_session *session)
{
    NC_MSG_TYPE ret;
    int i, timeout_io;
    char **cpblts;
    uint32_t *sid;
    uint16_t idle_timeout;

    if (session->side == NC_CLIENT) {
        /* client side hello - send only NETCONF base capabilities */
        cpblts = nc_client_get_cpblts();
        if (!cpblts) {
            return NC_MSG_ERROR;
        }

        timeout_io = NC_CLIENT_HELLO_TIMEOUT * 1000;
        sid = NULL;
    } else {
        cpblts = _nc_server_get_cpblts_version(session->ctx, LYS_VERSION_1_0);
        if (!cpblts) {
            return NC_MSG_ERROR;
        }

        if (session->flags & NC_SESSION_CALLHOME) {
            timeout_io = NC_SERVER_CH_HELLO_TIMEOUT * 1000;
        } else {
            idle_timeout = (uint16_t)ATOMIC_LOAD_RELAXED(server_opts.idle_timeout);
            timeout_io = idle_timeout ? idle_timeout * 1000 : -1;
        }
        sid = &session->id;
    }

    ret = nc_write_msg_io(session, timeout_io, NC_MSG_HELLO, cpblts, sid);

    for (i = 0; cpblts[i]; ++i) {
        free(cpblts[i]);
    }
    free(cpblts);

    return ret;
}

/**
 * @brief Receive server hello message on the client.
 *
 * @param[in] session Client session to use.
 * @return Received message type.
 */
static NC_MSG_TYPE
nc_client_recv_hello_io(struct nc_session *session)
{
    struct ly_in *msg;
    struct lyd_node *hello = NULL, *iter;
    struct lyd_node_opaq *node;
    int r, ver = -1, flag = 0;
    char *str;
    long long id;
    NC_MSG_TYPE rc = NC_MSG_HELLO;

    r = nc_read_msg_poll_io(session, NC_CLIENT_HELLO_TIMEOUT * 1000, &msg);
    switch (r) {
    case 1:
        /* parse <hello> data */
        if (lyd_parse_data(session->ctx, NULL, msg, LYD_XML, LYD_PARSE_ONLY | LYD_PARSE_OPAQ, 0, &hello)) {
            ERR(session, "Failed to parse server <hello>.");
            rc = NC_MSG_ERROR;
            goto cleanup;
        }

        LY_LIST_FOR(lyd_child(hello), iter) {
            node = (struct lyd_node_opaq *)iter;

            if (!node->name.module_ns || strcmp(node->name.module_ns, NC_NS_BASE)) {
                continue;
            } else if (!strcmp(node->name.name, "session-id")) {
                if (!node->value || !strlen(node->value)) {
                    ERR(session, "No value of <session-id> element in server <hello>.");
                    rc = NC_MSG_ERROR;
                    goto cleanup;
                }
                str = NULL;
                id = strtoll(node->value, &str, 10);
                if (*str || (id < 1) || (id > UINT32_MAX)) {
                    ERR(session, "Invalid value of <session-id> element in server <hello>.");
                    rc = NC_MSG_ERROR;
                    goto cleanup;
                }
                session->id = (uint32_t)id;
                continue;
            } else if (strcmp(node->name.name, "capabilities")) {
                ERR(session, "Unexpected <%s> element in server <hello>.", node->name.name);
                rc = NC_MSG_ERROR;
                goto cleanup;
            }

            if (flag) {
                /* multiple capabilities elements */
                ERR(session, "Invalid <hello> message (multiple <capabilities> elements).");
                rc = NC_MSG_ERROR;
                goto cleanup;
            }
            flag = 1;

            if ((ver = nc_parse_cpblts(&node->node, &session->cpblts)) < 0) {
                rc = NC_MSG_ERROR;
                goto cleanup;
            }
            session->version = ver;
        }

        if (!session->id) {
            ERR(session, "Missing <session-id> in server <hello>.");
            rc = NC_MSG_ERROR;
            goto cleanup;
        }
        break;
    case 0:
        ERR(session, "Server <hello> timeout elapsed.");
        rc = NC_MSG_WOULDBLOCK;
        break;
    default:
        rc = NC_MSG_ERROR;
        break;
    }

cleanup:
    ly_in_free(msg, 1);
    lyd_free_tree(hello);
    return rc;
}

/**
 * @brief Receive client hello message on the server.
 *
 * @param[in] session Server session to use.
 * @return Received message type.
 */
static NC_MSG_TYPE
nc_server_recv_hello_io(struct nc_session *session)
{
    struct ly_in *msg;
    struct lyd_node *hello = NULL, *iter;
    struct lyd_node_opaq *node;
    NC_MSG_TYPE rc = NC_MSG_HELLO;
    int r, ver = -1, flag = 0, timeout_io;
    uint16_t idle_timeout;

    if (session->flags & NC_SESSION_CALLHOME) {
        timeout_io = NC_SERVER_CH_HELLO_TIMEOUT * 1000;
    } else {
        idle_timeout = (uint16_t)ATOMIC_LOAD_RELAXED(server_opts.idle_timeout);
        timeout_io = idle_timeout ? idle_timeout * 1000 : -1;
    }

    r = nc_read_msg_poll_io(session, timeout_io, &msg);
    switch (r) {
    case 1:
        /* parse <hello> data */
        if (lyd_parse_data(session->ctx, NULL, msg, LYD_XML, LYD_PARSE_ONLY | LYD_PARSE_OPAQ, 0, &hello)) {
            ERR(session, "Failed to parse client <hello>.");
            rc = NC_MSG_ERROR;
            goto cleanup;
        }

        /* learn NETCONF version */
        LY_LIST_FOR(lyd_child(hello), iter) {
            node = (struct lyd_node_opaq *)iter;

            if (!node->name.module_ns || strcmp(node->name.module_ns, NC_NS_BASE)) {
                continue;
            } else if (strcmp(node->name.name, "capabilities")) {
                ERR(session, "Unexpected <%s> element in client <hello>.", node->name.name);
                rc = NC_MSG_BAD_HELLO;
                goto cleanup;
            }

            if (flag) {
                /* multiple capabilities elements */
                ERR(session, "Invalid <hello> message (multiple <capabilities> elements).");
                rc = NC_MSG_BAD_HELLO;
                goto cleanup;
            }
            flag = 1;

            if ((ver = nc_parse_cpblts(&node->node, &session->cpblts)) < 0) {
                rc = NC_MSG_BAD_HELLO;
                goto cleanup;
            }
            session->version = ver;
        }
        break;
    case 0:
        ERR(session, "Client <hello> timeout elapsed.");
        rc = NC_MSG_WOULDBLOCK;
        break;
    default:
        rc = NC_MSG_ERROR;
        break;
    }

cleanup:
    ly_in_free(msg, 1);
    lyd_free_tree(hello);
    return rc;
}

NC_MSG_TYPE
nc_handshake_io(struct nc_session *session)
{
    NC_MSG_TYPE type;

    type = nc_send_hello_io(session);
    if (type != NC_MSG_HELLO) {
        return type;
    }

    if (session->side == NC_CLIENT) {
        type = nc_client_recv_hello_io(session);
    } else {
        type = nc_server_recv_hello_io(session);
    }

    return type;
}

NC_MSG_TYPE
nc_ch_handshake_io(struct nc_session *session)
{
    NC_MSG_TYPE type;

    if ((session->side != NC_SERVER) || !(session->flags & NC_SESSION_CALLHOME)) {
        ERR(session, "Call Home handshake can only be performed on a server session with Call Home flag set.");
        return NC_MSG_ERROR;
    }

    type = nc_send_hello_io(session);
    if (type != NC_MSG_HELLO) {
        return type;
    }

    type = nc_server_recv_hello_io(session);

    return type;
}

#ifdef NC_ENABLED_SSH_TLS

/**
 * @brief CURL callback for downloading data.
 *
 * @param[in] ptr Downloaded data.
 * @param[in] size Size of one element.
 * @param[in] nmemb Number of elements.
 * @param[in,out] userdata Storage the downloaded data.
 * @return Number of bytes processed.
 */
static size_t
nc_session_curl_cb(char *ptr, size_t size, size_t nmemb, void *userdata)
{
    struct nc_curl_data *data;

    size = nmemb;

    data = (struct nc_curl_data *)userdata;

    data->data = nc_realloc(data->data, data->size + size);
    NC_CHECK_ERRMEM_RET(!data->data, 0);

    memcpy(&data->data[data->size], ptr, size);
    data->size += size;

    return size;
}

/**
 * @brief Download data using CURL.
 *
 * @param[in] handle CURL handle.
 * @param[in] url URL to download the data from.
 * @return 0 on success, 1 on failure.
 */
static int
nc_session_curl_fetch(CURL *handle, const char *url)
{
    char err_buf[CURL_ERROR_SIZE];

    /* set uri */
    if (curl_easy_setopt(handle, CURLOPT_URL, url)) {
        ERR(NULL, "Setting URI \"%s\" to download CRL from failed.", url);
        return 1;
    }

    /* set err buf */
    if (curl_easy_setopt(handle, CURLOPT_ERRORBUFFER, err_buf)) {
        ERR(NULL, "Setting CURL error buffer option failed.");
        return 1;
    }

    /* download */
    if (curl_easy_perform(handle)) {
        ERR(NULL, "Downloading CRL from \"%s\" failed (%s).", url, err_buf);
        return 1;
    }

    return 0;
}

/**
 * @brief Check if a URI has already been processed, add it to the seen list if not.
 *
 * @param[in] uri URI to check.
 * @param[in,out] seen_uris Array of already seen URIs.
 * @param[in,out] seen_count Number of seen URIs.
 * @return 1 if already seen, 0 if added (not seen before), -1 on error.
 */
static int
nc_session_uri_seen(const char *uri, char ***seen_uris, int *seen_count)
{
    int i;
    char **tmp;

    for (i = 0; i < *seen_count; i++) {
        if (!strcmp((*seen_uris)[i], uri)) {
            return 1;
        }
    }

    tmp = realloc(*seen_uris, (*seen_count + 1) * sizeof **seen_uris);
    NC_CHECK_ERRMEM_RET(!tmp, -1);
    *seen_uris = tmp;
    (*seen_uris)[*seen_count] = strdup(uri);
    NC_CHECK_ERRMEM_RET(!(*seen_uris)[*seen_count], -1);
    (*seen_count)++;

    return 0;
}

/**
 * @brief Free the seen URIs array.
 *
 * @param[in] seen_uris Array of seen URIs.
 * @param[in] seen_count Number of seen URIs.
 */
static void
nc_session_seen_uris_free(char **seen_uris, int seen_count)
{
    int i;

    for (i = 0; i < seen_count; i++) {
        free(seen_uris[i]);
    }
    free(seen_uris);
}

/**
 * @brief Restrict allowed CURL protocols to prevent SSRF via malicious CRL DP URIs.
 *
 * Only HTTP(S) and, if supported by the linked libcurl, LDAP(S) are allowed.
 *
 * @param[in] handle CURL handle to configure.
 * @return 0 on success, 1 on failure.
 */
static int
nc_session_curl_set_protocols(CURL *handle)
{
    curl_version_info_data *ver;
    int i, have_ldap = 0, have_ldaps = 0;

#if CURL_AT_LEAST_VERSION(7, 85, 0)
    char proto_str[32]; /* "http,https,ldap,ldaps" + NUL */
#else
    long protocols = CURLPROTO_HTTP | CURLPROTO_HTTPS;
#endif

    ver = curl_version_info(CURLVERSION_NOW);
    if (ver && ver->protocols) {
        for (i = 0; ver->protocols[i]; i++) {
            if (!strcmp(ver->protocols[i], "ldap")) {
                have_ldap = 1;
            } else if (!strcmp(ver->protocols[i], "ldaps")) {
                have_ldaps = 1;
            }
        }
    }

#if CURL_AT_LEAST_VERSION(7, 85, 0)
    /* curl 7.85.0+ uses a string-based option to avoid deprecation */
    snprintf(proto_str, sizeof proto_str, "http,https%s%s",
            have_ldap ? ",ldap" : "", have_ldaps ? ",ldaps" : "");
    if (curl_easy_setopt(handle, CURLOPT_PROTOCOLS_STR, proto_str)) {
        ERR(NULL, "Setting CURLOPT_PROTOCOLS_STR failed.");
        return 1;
    }
#else
    if (have_ldap) {
        protocols |= CURLPROTO_LDAP;
    }
    if (have_ldaps) {
        protocols |= CURLPROTO_LDAPS;
    }
    if (curl_easy_setopt(handle, CURLOPT_PROTOCOLS, protocols)) {
        ERR(NULL, "Setting CURLOPT_PROTOCOLS failed.");
        return 1;
    }
#endif

    return 0;
}

/**
 * @brief Initialize CURL handle for downloading CRL.
 *
 * @param[out] handle CURL handle.
 * @param[out] data Stores the downloaded data.
 * @return 0 on success, 1 on failure.
 */
static int
nc_session_curl_init(CURL **handle, struct nc_curl_data *data)
{
    NC_CHECK_ARG_RET(NULL, handle, data, -1);

    *handle = NULL;

    *handle = curl_easy_init();
    if (!*handle) {
        ERR(NULL, "Initializing CURL failed.");
        return 1;
    }

    /* limit connection phase to avoid long delays on unreachable CRL hosts */
    if (curl_easy_setopt(*handle, CURLOPT_CONNECTTIMEOUT_MS, NC_CURL_CONNECT_TIMEOUT_MS)) {
        ERR(NULL, "Setting curl connection timeout failed.");
        return 1;
    }

    /* limit the whole transfer, a host that connects and then stalls would block the TLS handshake */
    if (curl_easy_setopt(*handle, CURLOPT_TIMEOUT_MS, NC_CURL_TIMEOUT_MS)) {
        ERR(NULL, "Setting curl transfer timeout failed.");
        return 1;
    }

    /* do not use signals for timeouts, required for thread safety */
    if (curl_easy_setopt(*handle, CURLOPT_NOSIGNAL, 1L)) {
        ERR(NULL, "Setting CURLOPT_NOSIGNAL failed.");
        return 1;
    }

    /* restrict allowed protocols to prevent SSRF via malicious CRL DP URIs */
    if (nc_session_curl_set_protocols(*handle)) {
        return 1;
    }

    if (curl_easy_setopt(*handle, CURLOPT_WRITEFUNCTION, nc_session_curl_cb)) {
        ERR(NULL, "Setting curl callback failed.");
        return 1;
    }

    if (curl_easy_setopt(*handle, CURLOPT_WRITEDATA, data)) {
        ERR(NULL, "Setting curl callback data failed.");
        return 1;
    }

    return 0;
}

/**
 * @brief Advance past the end of the current LDIF line.
 *
 * @param[in] line_end Pointer to the end of the line content (after stripping CR).
 * @param[in] data_end End of the whole LDIF buffer.
 * @return Pointer to the start of the next line, or data_end if at the end.
 */
static char *
nc_session_ldif_next_line(char *line_end, char *data_end)
{
    char *next;

    if (line_end >= data_end) {
        return data_end;
    }

    /* skip the CR of a CRLF pair */
    if (*line_end == '\r') {
        next = line_end + 2;
    } else {
        next = line_end + 1;
    }

    if (next > data_end) {
        next = data_end;
    }

    return next;
}

/**
 * @brief Check if an LDIF attribute name is a known CRL attribute.
 *
 * Accepts certificateRevocationList, authorityRevocationList, and
 * deltaRevocationList, optionally followed by a transfer option such
 * as ';binary' (RFC 4523).
 *
 * @param[in] name Attribute name (not null-terminated).
 * @param[in] len Length of the attribute name.
 * @return 1 if it is a CRL attribute, 0 otherwise.
 */
static int
nc_session_ldif_is_crl_attr(const char *name, uint32_t len)
{
    static const char *crl_attrs[] = {"certificateRevocationList", "authorityRevocationList", "deltaRevocationList"};
    uint32_t i, attr_len;

    for (i = 0; i < (sizeof crl_attrs) / (sizeof crl_attrs[0]); i++) {
        attr_len = (uint32_t)strlen(crl_attrs[i]);
        /* the name must match exactly or be followed by ';' (transfer option) */
        if ((len == attr_len) || ((len > attr_len) && (name[attr_len] == ';'))) {
            if (!strncasecmp(name, crl_attrs[i], attr_len)) {
                return 1;
            }
        }
    }

    return 0;
}

/**
 * @brief Extract a binary CRL from an LDIF response.
 *
 * The LDIF data is not null-terminated, so we scan it as a byte buffer.
 * We look for an attribute line carrying a known CRL attribute (see
 * nc_session_ldif_is_crl_attr) with the '::' binary value marker, collect
 * its base64 value (including folded continuation lines starting with a
 * space), and decode it to raw DER.
 *
 * @param[in] ldif LDIF response data.
 * @param[out] crl_data Extracted raw CRL data.
 * @param[out] crl_size Size of the extracted CRL data.
 * @return 0 on success, 1 on failure.
 */
static int
nc_session_ldif_extract_crl(struct nc_curl_data *ldif, unsigned char **crl_data, uint32_t *crl_size)
{
    int ret, rc = 0;
    char *line_start, *line_end, *b64_start, *attr_colon, *tmp;
    char *b64_buf = NULL;
    uint32_t b64_len = 0, b64_cap = 0, line_len;
    char *pos, *data_end;

    *crl_data = NULL;
    *crl_size = 0;

    if (!ldif->data || !ldif->size) {
        return 1;
    }

    data_end = (char *)ldif->data + ldif->size;
    pos = (char *)ldif->data;

    while (pos < data_end) {
        /* find end of current line */
        line_start = pos;
        line_end = memchr(pos, '\n', data_end - pos);
        if (!line_end) {
            line_end = data_end;
        } else {
            /* strip trailing \r */
            if ((line_end > line_start) && (line_end[-1] == '\r')) {
                line_end--;
            }
        }
        line_len = (uint32_t)(line_end - line_start);

        /* strip leading tabs (curl's LDIF output indents attribute lines) */
        while ((line_len > 0) && (line_start[0] == '\t')) {
            line_start++;
            line_len--;
        }

        /* advance pos past the newline for the next iteration */
        pos = nc_session_ldif_next_line(line_end, data_end);

        /* skip empty lines and comments */
        if ((line_len == 0) || (line_start[0] == '#')) {
            continue;
        }

        /* skip continuation lines (start with space) */
        if (line_start[0] == ' ') {
            continue;
        }

        /* look for '::' which marks a binary attribute value */
        attr_colon = memchr(line_start, ':', line_len);
        if (attr_colon && (attr_colon + 1 < line_end) && (attr_colon[1] == ':')) {
            /* check the attribute name is a known CRL attribute */
            if (!nc_session_ldif_is_crl_attr(line_start, (uint32_t)(attr_colon - line_start))) {
                continue;
            }

            /* found the CRL attribute; b64 starts after ":: " */
            b64_start = attr_colon + 2;
            if ((b64_start < line_end) && (b64_start[0] == ' ')) {
                b64_start++;
            }

            /* collect this first chunk */
            b64_len = (uint32_t)(line_end - b64_start);
            b64_cap = b64_len + 1;
            b64_buf = malloc(b64_cap);
            NC_CHECK_ERRMEM_GOTO(!b64_buf, rc = 1, cleanup);
            memcpy(b64_buf, b64_start, b64_len);
            b64_buf[b64_len] = '\0';

            /* now collect continuation lines (folded, start with space) */
            while (pos < data_end) {
                if ((pos[0] != ' ') && (pos[0] != '\t')) {
                    break;
                }

                line_start = pos;
                line_end = memchr(pos, '\n', data_end - pos);
                if (!line_end) {
                    line_end = data_end;
                } else {
                    if ((line_end > line_start) && (line_end[-1] == '\r')) {
                        line_end--;
                    }
                }
                line_len = (uint32_t)(line_end - line_start);

                /* advance pos */
                pos = nc_session_ldif_next_line(line_end, data_end);

                /* skip leading whitespace (the fold marker) */
                while ((line_len > 0) && ((line_start[0] == ' ') || (line_start[0] == '\t'))) {
                    line_start++;
                    line_len--;
                }

                if (b64_len + line_len + 1 > b64_cap) {
                    b64_cap = b64_len + line_len + 1;
                    tmp = realloc(b64_buf, b64_cap);
                    NC_CHECK_ERRMEM_GOTO(!tmp, rc = 1, cleanup);
                    b64_buf = tmp;
                }
                memcpy(b64_buf + b64_len, line_start, line_len);
                b64_len += line_len;
                b64_buf[b64_len] = '\0';
            }

            break;
        }
    }

    if (!b64_buf) {
        ERR(NULL, "No binary CRL attribute found in LDIF response.");
        rc = 1;
        goto cleanup;
    }

    /* decode base64 to raw DER */
    ret = nc_base64_decode_wrap(b64_buf, crl_data);
    if (ret == -1) {
        ERR(NULL, "Decoding base64 CRL data from LDIF failed.");
        rc = 1;
        goto cleanup;
    }

    /* nc_base64_decode_wrap returns the decoded length */
    *crl_size = (uint32_t)ret;

cleanup:
    free(b64_buf);
    return rc;
}

/**
 * @brief Fetch a CRL from an LDAP URL via CURL and parse the LDIF response.
 *
 * @param[in] handle CURL handle.
 * @param[in] url LDAP URL to fetch the CRL from.
 * @param[in,out] data Stores the downloaded LDIF, then the decoded raw CRL.
 * @return 0 on success, 1 on failure.
 */
static int
nc_session_ldap_fetch(CURL *handle, const char *url, struct nc_curl_data *data)
{
    int ret;
    unsigned char *crl_data = NULL;
    uint32_t crl_size = 0;

    /* fetch via curl, which handles the LDAP protocol natively */
    ret = nc_session_curl_fetch(handle, url);
    if (ret) {
        return ret;
    }

    /* parse the LDIF response and extract the base64-encoded CRL */
    ret = nc_session_ldif_extract_crl(data, &crl_data, &crl_size);
    if (ret) {
        return ret;
    }

    /* replace the LDIF data with the decoded raw CRL */
    free(data->data);
    data->data = crl_data;
    data->size = crl_size;

    return 0;
}

/**
 * @brief Download CRLs for certificates in the peer's chain and merge them into crl_store.
 *
 * @param[in] peer_chain Peer's certificate chain.
 * @param[in] cert_store Certificate store containing CAs (for resolving CRL distribution points).
 * @param[in,out] crl_store CRL store to add downloaded CRLs to.
 * @return 0 on success, non-zero on error.
 */
static int
nc_session_tls_crl_fetch_for_peer_chain(void *peer_chain, void *cert_store, void *crl_store)
{
    int i, ret = 0, uri_count = 0, j, seen_count = 0, uri_seen;
    void *cert = NULL;
    CURL *handle = NULL;
    struct nc_curl_data downloaded = {0};
    char **uris = NULL, **seen_uris = NULL;

    /* init curl */
    ret = nc_session_curl_init(&handle, &downloaded);
    if (ret) {
        goto cleanup;
    }

    /* iterate over all certificates in the peer chain and collect CRL distribution point URIs */
    for (i = 0; i < nc_tls_get_num_certs_wrap(peer_chain); i++) {
        cert = nc_tls_get_cert_wrap(peer_chain, i);
        uris = NULL;
        uri_count = 0;

        /*
         * For the first (leaf) cert, pass cert_store to also extract CRL DPs
         * from the CA certificates. For subsequent certs, pass NULL to only
         * extract their own CRL DPs, avoiding duplicates from cert_store.
         */
        ret = nc_server_tls_get_crl_distpoint_uris_wrap(cert, i == 0 ? cert_store : NULL, &uris, &uri_count);
        if (ret) {
            goto cleanup;
        }

        for (j = 0; j < uri_count; j++) {
            uri_seen = nc_session_uri_seen(uris[j], &seen_uris, &seen_count);
            if (uri_seen == 1) {
                /* already downloaded this URI, skip */
                continue;
            } else if (uri_seen == -1) {
                ret = 1;
                for (j++; j < uri_count; j++) {
                    free(uris[j]);
                }
                free(uris);
                uris = NULL;
                goto cleanup;
            }

            VRB(NULL, "Downloading CRL from \"%s\".", uris[j]);
            if (!strncasecmp(uris[j], "ldap://", 7) || !strncasecmp(uris[j], "ldaps://", 8)) {
                ret = nc_session_ldap_fetch(handle, uris[j], &downloaded);
            } else {
                ret = nc_session_curl_fetch(handle, uris[j]);
            }
            if (ret) {
                WRN(NULL, "Failed to fetch CRL from \"%s\".", uris[j]);
                free(downloaded.data);
                downloaded.data = NULL;
                downloaded.size = 0;
                continue;
            }

            ret = nc_server_tls_add_crl_to_store_wrap(downloaded.data, downloaded.size, crl_store);

            free(downloaded.data);
            downloaded.data = NULL;
            downloaded.size = 0;

            if (ret) {
                for (j = j + 1; j < uri_count; j++) {
                    free(uris[j]);
                }
                free(uris);
                uris = NULL;
                goto cleanup;
            }
        }

        for (j = 0; j < uri_count; j++) {
            free(uris[j]);
        }
        free(uris);
        uris = NULL;
    }

cleanup:
    curl_easy_cleanup(handle);
    free(downloaded.data);
    nc_session_seen_uris_free(seen_uris, seen_count);
    if (uris) {
        for (i = 0; i < uri_count; i++) {
            free(uris[i]);
        }
        free(uris);
    }
    return ret;
}

int
nc_session_tls_crl_verify_post_handshake(void *tls_session, void *cert_store)
{
    int ret = 0;
    void *peer_chain = NULL, *crl_store = NULL;

    peer_chain = nc_tls_get_peer_cert_chain_wrap(tls_session);
    if (!peer_chain) {
        /* no peer certificate, nothing to verify */
        return 0;
    }

    if (!cert_store) {
        /* no cert store, nothing to verify */
        return 0;
    }

    crl_store = nc_tls_crl_store_for_post_handshake_wrap(cert_store);
    if (!crl_store) {
        return 1;
    }

    /* download CRLs for peer certificates and add them to the CRL store */
    ret = nc_session_tls_crl_fetch_for_peer_chain(peer_chain, cert_store, crl_store);
    if (ret) {
        goto cleanup;
    }

    /* verify the peer chain against the CRLs */
    ret = nc_tls_verify_cert_chain_crl_wrap(peer_chain, cert_store, crl_store);
    if (ret) {
        ERR(NULL, "Post-handshake CRL verification failed.");
    }

cleanup:
    nc_tls_crl_store_post_handshake_free_wrap(crl_store);
    return ret;
}

#endif /* NC_ENABLED_SSH_TLS */

/**
 * @brief Initialize or destroy the global state of the libraries used by libnetconf2.
 *
 * @param[in] side Side that is being initialized/destroyed.
 * @param[in] destroy Whether to destroy the global state instead of initializing it.
 * @return 0 on success, -1 on error.
 */
static int
nc_global_init_destroy(NC_SIDE side, int destroy)
{
#ifdef NC_ENABLED_SSH_TLS
    /* lock protecting the init flags and the global init of the libraries, which is not thread-safe */
    static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

    /* whether the client/server side has the libraries initialized */
    static int init_client = 0, init_server = 0;

    int rc = 0, curl_inited = 0, tls_inited = 0, *inited;

    inited = (side == NC_CLIENT) ? &init_client : &init_server;

    /* GLOBAL INIT LOCK */
    pthread_mutex_lock(&lock);

    if (destroy) {
        if (!*inited) {
            /* this side has not initialized the libraries */
            goto cleanup;
        }
        *inited = 0;

        if (!init_client && !init_server) {
            /* the last side using the libraries, destroy them in the reverse order */
            ssh_finalize();
            nc_tls_backend_destroy_wrap();
            curl_global_cleanup();
        }
        goto cleanup;
    }

    if (init_client || init_server) {
        /* the libraries are already initialized by the other side */
        *inited = 1;
        goto cleanup;
    }

    if (curl_global_init(CURL_GLOBAL_SSL | CURL_GLOBAL_ACK_EINTR)) {
        ERR(NULL, "%s: failed to init CURL.", __func__);
        rc = -1;
        goto cleanup;
    }
    curl_inited = 1;

    if (nc_tls_backend_init_wrap()) {
        ERR(NULL, "%s: failed to init the SSL library backend.", __func__);
        rc = -1;
        goto cleanup;
    }
    tls_inited = 1;

    /* optional for dynamic library, mandatory for static */
    if (ssh_init()) {
        ERR(NULL, "%s: failed to init libssh.", __func__);
        rc = -1;
        goto cleanup;
    }

    *inited = 1;

cleanup:
    if (rc) {
        /* leave no library initialized behind */
        if (tls_inited) {
            nc_tls_backend_destroy_wrap();
        }
        if (curl_inited) {
            curl_global_cleanup();
        }
    }

    /* GLOBAL INIT UNLOCK */
    pthread_mutex_unlock(&lock);

    return rc;
#else
    (void)side;
    (void)destroy;

    return 0;
#endif /* NC_ENABLED_SSH_TLS */
}

int
nc_global_init(NC_SIDE side)
{
    return nc_global_init_destroy(side, 0);
}

void
nc_global_destroy(NC_SIDE side)
{
    nc_global_init_destroy(side, 1);
}

API const char *
nc_yang_module_dir(void)
{
    return NC_SERVER_SEARCH_DIR;
}
