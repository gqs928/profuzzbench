/**
 * @file tree_schema.c
 * @author Radek Krejci <rkrejci@cesnet.cz>
 * @author Michal Vasko <mvasko@cesnet.cz>
 * @brief Schema tree implementation
 *
 * Copyright (c) 2015 - 2026 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */

#define _GNU_SOURCE /* asprintf, strdup */

#include "tree_schema.h"

#include <assert.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "compat.h"
#include "context.h"
#include "dict.h"
#include "in.h"
#include "in_internal.h"
#include "log.h"
#include "ly_array.h"
#include "ly_common.h"
#include "parser_internal.h"
#include "parser_schema.h"
#include "path.h"
#include "plugins_exts.h"
#include "plugins_internal.h"
#include "schema_compile.h"
#include "schema_compile_amend.h"
#include "schema_diff.h"
#include "schema_features.h"
#include "set.h"
#include "tree_schema_free.h"
#include "tree_schema_internal.h"
#include "utils.h"
#include "xml.h"
#include "xpath.h"

const char * const ly_devmod_list[] = {
    [LYS_DEV_NOT_SUPPORTED] = "not-supported",
    [LYS_DEV_ADD] = "add",
    [LYS_DEV_DELETE] = "delete",
    [LYS_DEV_REPLACE] = "replace",
};

LIBYANG_API_DEF LY_ERR
lysc_tree_dfs_full(const struct lysc_node *root, lysc_dfs_clb dfs_clb, void *data)
{
    struct lysc_node *elem, *elem2;
    const struct lysc_node_action *action;
    const struct lysc_node_notif *notif;

    LY_CHECK_ARG_RET(NULL, root, dfs_clb, LY_EINVAL);

    LYSC_TREE_DFS_BEGIN(root, elem) {
        /* schema node */
        LY_CHECK_RET(dfs_clb(elem, data, &LYSC_TREE_DFS_continue));

        LY_LIST_FOR(lysc_node_actions(elem), action) {
            LYSC_TREE_DFS_BEGIN(action, elem2) {
                /* action subtree */
                LY_CHECK_RET(dfs_clb(elem2, data, &LYSC_TREE_DFS_continue));

                LYSC_TREE_DFS_END(action, elem2);
            }
        }

        LY_LIST_FOR(lysc_node_notifs(elem), notif) {
            LYSC_TREE_DFS_BEGIN(notif, elem2) {
                /* notification subtree */
                LY_CHECK_RET(dfs_clb(elem2, data, &LYSC_TREE_DFS_continue));

                LYSC_TREE_DFS_END(notif, elem2);
            }
        }

        LYSC_TREE_DFS_END(root, elem);
    }

    return LY_SUCCESS;
}

LIBYANG_API_DEF LY_ERR
lysc_module_dfs_full(const struct lys_module *mod, lysc_dfs_clb dfs_clb, void *data)
{
    const struct lysc_node *root;

    LY_CHECK_ARG_RET(NULL, mod, mod->compiled, dfs_clb, LY_EINVAL);

    /* schema nodes */
    LY_LIST_FOR(mod->compiled->data, root) {
        LY_CHECK_RET(lysc_tree_dfs_full(root, dfs_clb, data));
    }

    /* RPCs */
    LY_LIST_FOR((const struct lysc_node *)mod->compiled->rpcs, root) {
        LY_CHECK_RET(lysc_tree_dfs_full(root, dfs_clb, data));
    }

    /* notifications */
    LY_LIST_FOR((const struct lysc_node *)mod->compiled->notifs, root) {
        LY_CHECK_RET(lysc_tree_dfs_full(root, dfs_clb, data));
    }

    return LY_SUCCESS;
}

/**
 * @brief Find import prefix in imports.
 */
static const struct lys_module *
ly_schema_resolve_prefix(const struct ly_ctx *UNUSED(ctx), const char *prefix, uint32_t prefix_len, const void *prefix_data)
{
    const struct lysp_module *prefix_mod = prefix_data;
    LYA_COUNT_T u;
    const char *local_prefix;

    local_prefix = prefix_mod->is_submod ? ((struct lysp_submodule *)prefix_mod)->prefix : prefix_mod->mod->prefix;
    if (!prefix_len || !ly_strncmp(local_prefix, prefix, prefix_len)) {
        /* it is the prefix of the module itself */
        return prefix_mod->mod;
    }

    /* search in imports */
    LYA_FOR(prefix_mod->imports, u) {
        if (!ly_strncmp(prefix_mod->imports[u].prefix, prefix, prefix_len)) {
            return prefix_mod->imports[u].module;
        }
    }

    return NULL;
}

/**
 * @brief Find resolved module for a prefix in prefix - module pairs.
 */
static const struct lys_module *
ly_schema_resolved_resolve_prefix(const struct ly_ctx *UNUSED(ctx), const char *prefix, uint32_t prefix_len,
        const void *prefix_data)
{
    const struct lysc_prefix *prefixes = prefix_data;
    LYA_COUNT_T u;

    LYA_FOR(prefixes, u) {
        if ((!prefixes[u].prefix && !prefix_len) || (prefixes[u].prefix && !ly_strncmp(prefixes[u].prefix, prefix, prefix_len))) {
            return prefixes[u].mod;
        }
    }

    return NULL;
}

/**
 * @brief Find XML namespace prefix in XML namespaces, which are then mapped to modules.
 */
static const struct lys_module *
ly_xml_resolve_prefix(const struct ly_ctx *ctx, const char *prefix, uint32_t prefix_len, const void *prefix_data)
{
    const struct lys_module *mod;
    const struct lyxml_ns *ns;
    const struct ly_set *ns_set = prefix_data;

    ns = lyxml_ns_get(ns_set, prefix, prefix_len);
    if (!ns) {
        return NULL;
    }

    mod = ly_ctx_get_module_implemented_ns(ctx, ns->uri);
    if (!mod) {
        /* for YIN extension prefix resolution */
        mod = ly_ctx_get_module_latest_ns(ctx, ns->uri);
    }
    return mod;
}

/**
 * @brief Find module name.
 */
static const struct lys_module *
ly_json_resolve_prefix(const struct ly_ctx *ctx, const char *prefix, uint32_t prefix_len, const void *UNUSED(prefix_data))
{
    return ly_ctx_get_module_implemented2(ctx, prefix, prefix_len);
}

const struct lys_module *
ly_resolve_prefix(const struct ly_ctx *ctx, const void *prefix, uint32_t prefix_len, LY_VALUE_FORMAT format,
        const void *prefix_data)
{
    const struct lys_module *mod = NULL;

    LY_CHECK_ARG_RET(ctx, prefix, prefix_len, NULL);

    switch (format) {
    case LY_VALUE_SCHEMA:
        mod = ly_schema_resolve_prefix(ctx, prefix, prefix_len, prefix_data);
        break;
    case LY_VALUE_SCHEMA_RESOLVED:
        mod = ly_schema_resolved_resolve_prefix(ctx, prefix, prefix_len, prefix_data);
        break;
    case LY_VALUE_XML:
    case LY_VALUE_STR_NS:
        mod = ly_xml_resolve_prefix(ctx, prefix, prefix_len, prefix_data);
        break;
    case LY_VALUE_CANON:
    case LY_VALUE_JSON:
    case LY_VALUE_LYB:
    case LY_VALUE_CBOR:
        mod = ly_json_resolve_prefix(ctx, prefix, prefix_len, prefix_data);
        break;
    }

    return mod;
}

LIBYANG_API_DEF const struct lys_module *
lys_find_module(const struct ly_ctx *ctx, const struct lysc_node *ctx_node, const char *prefix, uint32_t prefix_len,
        LY_VALUE_FORMAT format, const void *prefix_data)
{
    if (prefix_len) {
        return ly_resolve_prefix(ctx, prefix, prefix_len, format, prefix_data);
    } else {
        switch (format) {
        case LY_VALUE_SCHEMA:
            /* use local module */
            return ly_schema_resolve_prefix(ctx, prefix, prefix_len, prefix_data);
        case LY_VALUE_SCHEMA_RESOLVED:
            /* use local module */
            return ly_schema_resolved_resolve_prefix(ctx, prefix, prefix_len, prefix_data);
        case LY_VALUE_CANON:
        case LY_VALUE_JSON:
        case LY_VALUE_LYB:
        case LY_VALUE_CBOR:
        case LY_VALUE_STR_NS:
            /* use context node module (as specified) */
            return ctx_node ? ctx_node->module : NULL;
        case LY_VALUE_XML:
            /* use the default namespace */
            return ly_xml_resolve_prefix(ctx, NULL, 0, prefix_data);
        }
    }

    return NULL;
}

static void
lys_getnext_into_case(const struct lysc_node_case *first_case, const struct lysc_node **last, const struct lysc_node **next)
{
    for ( ; first_case; first_case = (const struct lysc_node_case *)first_case->next) {
        if (first_case->child) {
            /* there is something to return */
            (*next) = first_case->child;
            return;
        }
    }

    /* no children in choice's cases, so go to the choice's sibling instead of into it */
    (*last) = (*next);
    (*next) = (*next)->next;
}

LIBYANG_API_DEF const struct lysc_node *
lys_getnext(const struct lysc_node *last, const struct lysc_node *parent, const struct lysc_module *module, uint32_t options)
{
    const struct lysc_node *next = NULL;
    ly_bool action_flag = 0, notif_flag = 0;

    LY_CHECK_ARG_RET(NULL, last || parent || module, NULL);

next:
    if (!last) {
        /* first call */

        /* learn where to start */
        if (parent) {
            /* schema subtree */
            next = last = lysc_node_child(parent);
        } else {
            /* top level data */
            next = last = module->data;
        }
        if (!next) {
            /* try to get action or notification */
            goto repeat;
        }
        /* test if the next can be returned */
        goto check;

    } else if (last->nodetype & (LYS_RPC | LYS_ACTION)) {
        action_flag = 1;
        next = last->next;
    } else if (last->nodetype == LYS_NOTIF) {
        action_flag = notif_flag = 1;
        next = last->next;
    } else {
        next = last->next;
    }

repeat:
    if (!next) {
        if (last && (last->parent != parent)) {
            /* go back to parent */
            last = last->parent;
            goto next;
        } else if (!action_flag) {
            action_flag = 1;
            if (parent) {
                next = (struct lysc_node *)lysc_node_actions(parent);
            } else if (module) {
                next = (struct lysc_node *)module->rpcs;
            }
        } else if (!notif_flag) {
            notif_flag = 1;
            if (parent) {
                next = (struct lysc_node *)lysc_node_notifs(parent);
            } else if (module) {
                next = (struct lysc_node *)module->notifs;
            }
        } else {
            return NULL;
        }
        goto repeat;
    }
check:
    switch (next->nodetype) {
    case LYS_RPC:
    case LYS_ACTION:
    case LYS_NOTIF:
    case LYS_LEAF:
    case LYS_ANYXML:
    case LYS_ANYDATA:
    case LYS_LIST:
    case LYS_LEAFLIST:
        break;
    case LYS_CASE:
        if (options & LYS_GETNEXT_WITHCASE) {
            break;
        } else {
            /* go into */
            lys_getnext_into_case((const struct lysc_node_case *)next, &last, &next);
        }
        goto repeat;
    case LYS_CONTAINER:
        if (!(next->flags & LYS_PRESENCE) && (options & LYS_GETNEXT_INTONPCONT)) {
            if (lysc_node_child(next)) {
                /* go into */
                next = lysc_node_child(next);
            } else {
                last = next;
                next = next->next;
            }
            goto repeat;
        }
        break;
    case LYS_CHOICE:
        if (options & LYS_GETNEXT_WITHCHOICE) {
            break;
        } else if ((options & LYS_GETNEXT_NOCHOICE) || !lysc_node_child(next)) {
            next = next->next;
        } else {
            if (options & LYS_GETNEXT_WITHCASE) {
                next = lysc_node_child(next);
            } else {
                /* go into */
                lys_getnext_into_case(((struct lysc_node_choice *)next)->cases, &last, &next);
            }
        }
        goto repeat;
    case LYS_INPUT:
        if (options & LYS_GETNEXT_OUTPUT) {
            /* skip */
            next = next->next;
        } else {
            /* go into */
            next = lysc_node_child(next);
        }
        goto repeat;
    case LYS_OUTPUT:
        if (!(options & LYS_GETNEXT_OUTPUT)) {
            /* skip */
            next = next->next;
        } else {
            /* go into */
            next = lysc_node_child(next);
        }
        goto repeat;
    default:
        /* we should not be here */
        LOGINT(NULL);
        return NULL;
    }

    return next;
}

/**
 * @brief Get schema node in extension instance according to the given parameters.
 *
 * @param[in] ext Extension instance which top-level schema node is being searched.
 * @param[in] parent Parsed parent data node.
 * @param[in] sparent Schema parent node.
 * @param[in] module Optional parameter to match the extension instance's (and its data) module.
 * @param[in] name Name of the schema node to find, if the string is not NULL-terminated, the @p name_len must be set.
 * @param[in] name_len Length of the @p name string, use in case the @p name is not NULL-terminated string.
 * @param[in] nodetype Allowed [type of the node](@ref schemanodetypes).
 * @param[in] is_xpath Set if searching for nodes in an XPath expression.
 * @param[out] snode Found schema node, NULL if no suitable was found.
 * @return Found schema node if there is some satisfy the provided requirements.
 */
static LY_ERR
lys_ext_find_node(const struct lysc_ext_instance *ext, const struct lyd_node *parent, const struct lysc_node *sparent,
        const char *prefix, uint32_t prefix_len, LY_VALUE_FORMAT format, void *prefix_data, const char *name,
        uint32_t name_len, ly_bool is_xpath, const struct lysc_node **snode)
{
    LY_ERR rc = LY_SUCCESS;
    struct lyplg_ext *plg_ext;
    const struct lys_module *mod;
    const struct lysc_node *node;

    plg_ext = LYSC_GET_EXT_PLG(ext->def->plugin_ref);
    if (!plg_ext) {
        return LY_ENOT;
    }

    /* standard nodes */
    if (is_xpath && plg_ext->snode_xpath) {
        rc = plg_ext->snode_xpath((struct lysc_ext_instance *)ext, prefix, prefix_len, format, prefix_data, name,
                name_len, snode);
    } else if (!is_xpath && plg_ext->snode) {
        rc = plg_ext->snode((struct lysc_ext_instance *)ext, parent, sparent, prefix, prefix_len, format,
                prefix_data, name, name_len, snode);
    } else {
        lyplg_ext_get_storage(ext, LY_STMT_DATA_NODE_MASK, sizeof node, (const void **)&node);
        if (node) {
            /* find the module */
            mod = lys_find_module((*snode)->module->ctx, parent ? parent->schema : sparent, prefix, prefix_len, format,
                    prefix_data);
        }
        if (node && mod && mod->implemented) {
            while ((node = lys_getnext(node, node->parent, NULL, 0))) {
                if (node->module != mod) {
                    continue;
                }
                if (ly_strncmp(node->name, name, name_len)) {
                    continue;
                }

                break;
            }
            if (node) {
                /* matching node */
                *snode = node;
            }
        }
        if (!*snode) {
            rc = LY_ENOT;
        }
    }

    return rc;
}

LY_ERR
lys_find_child_node_ext(const struct ly_ctx *ctx, const struct lys_module *mod, const struct lyd_node *parent,
        const struct lysc_node *sparent, const char *prefix, uint32_t prefix_len, LY_VALUE_FORMAT format,
        void *prefix_data, const char *name, uint32_t name_len, ly_bool is_xpath, const struct lysc_node **snode,
        struct lysc_ext_instance **ext)
{
    LY_ERR r;
    LYA_COUNT_T u;
    struct lysc_ext_instance *exts;

    *snode = NULL;
    if (ext) {
        *ext = NULL;
    }

    /* check if there are any nested parent extension instances */
    if (parent && parent->schema) {
        exts = parent->schema->exts;
    } else if (sparent) {
        exts = sparent->exts;
    } else {
        exts = NULL;
    }
    LYA_FOR(exts, u) {
        r = lys_ext_find_node(&exts[u], parent, sparent, prefix, prefix_len, format, prefix_data, name, name_len,
                is_xpath, snode);
        if (!r) {
            if (ext) {
                /* schema node found, remember the ext instance */
                *ext = &exts[u];
            }
            return LY_SUCCESS;
        } else if (r != LY_ENOT) {
            return r;
        }

        /* data was not from this ext instance, continue */
    }

    /* check if there are global module ext instances */
    if (!mod) {
        mod = lys_find_module(ctx, parent ? parent->schema : sparent, prefix, prefix_len, format, prefix_data);
    }
    if (mod && mod->implemented) {
        exts = mod->compiled->exts;
    } else {
        exts = NULL;
    }
    LYA_FOR(exts, u) {
        r = lys_ext_find_node(&exts[u], parent, sparent, prefix, prefix_len, format, prefix_data, name, name_len,
                is_xpath, snode);
        if (!r) {
            if (ext) {
                *ext = &exts[u];
            }
            return LY_SUCCESS;
        } else if (r != LY_ENOT) {
            return r;
        }
    }

    /* no extensions or none matched */
    return LY_ENOT;
}

LY_ERR
lys_find_child_node(const struct ly_ctx *ctx, const struct lysc_node *parent, const struct lys_module *mod,
        const char *prefix, uint32_t prefix_len, LY_VALUE_FORMAT format, void *prefix_data, const char *name,
        uint32_t name_len, uint32_t options, const struct lysc_node **snode, struct lysc_ext_instance **ext)
{
    const struct lysc_node *node = NULL;

    assert(name);

    *snode = NULL;
    if (ext) {
        *ext = NULL;
    }

    if (prefix && !prefix_len) {
        prefix_len = strlen(prefix);
    }
    if (!name_len) {
        name_len = strlen(name);
    }

    /* find the module */
    if (!mod) {
        mod = lys_find_module(ctx, parent, prefix, prefix_len, format, prefix_data);
    }

    /* look for a standard schema node */
    if (mod && mod->implemented) {
        if (!parent && !mod->compiled) {
            assert(mod->to_compile && (ctx->opts & LY_CTX_EXPLICIT_COMPILE));
            LOGERR(ctx, LY_EINVAL, "Context needs to be explicitly compiled.");
            return LY_EINVAL;
        }

        while ((node = lys_getnext(node, parent, mod->compiled, options))) {
            /* check module */
            if (node->module != mod) {
                continue;
            }

            /* check name */
            if (!ly_strncmp(node->name, name, name_len)) {
                *snode = node;
                return LY_SUCCESS;
            }
        }
    }

    /* look for an ext instance node */
    return lys_find_child_node_ext(ctx, mod, NULL, parent, prefix, prefix_len, format, prefix_data, name, name_len,
            0, snode, ext);
}

LIBYANG_API_DEF const struct lysc_node *
lys_find_child(const struct ly_ctx *ctx, const struct lysc_node *parent, const struct lys_module *mod,
        const char *mod_name, uint32_t mod_len, const char *name, uint32_t name_len, uint32_t options)
{
    const struct lysc_node *snode = NULL;

    LY_CHECK_ARG_RET(NULL, ctx || parent || mod, (mod || mod_name) && (!mod || !mod_name), name, NULL);

    if (parent) {
        ctx = parent->module->ctx;
    } else if (mod) {
        ctx = mod->ctx;
    }

    if (mod) {
        mod_name = mod->name;
    }

    if (mod_name && !mod_len) {
        mod_len = strlen(mod_name);
    }
    if (!name_len) {
        name_len = strlen(name);
    }

    lys_find_child_node(ctx, parent, mod, mod_name, mod_len, LY_VALUE_JSON, NULL, name, name_len, options, &snode, NULL);
    return snode;
}

LIBYANG_API_DEF LY_ERR
lys_find_xpath_atoms(const struct ly_ctx *ctx, const struct lysc_node *ctx_node, const char *xpath, uint32_t options,
        struct ly_set **set)
{
    LY_ERR ret = LY_SUCCESS;
    struct lyxp_set xp_set = {0};
    struct lyxp_expr *exp = NULL;
    uint32_t i;

    LY_CHECK_ARG_RET(NULL, ctx || ctx_node, xpath, set, LY_EINVAL);
    LY_CHECK_CTX_EQUAL_RET(__func__, ctx, ctx_node ? ctx_node->module->ctx : NULL, LY_EINVAL);
    if (!(options & LYXP_SCNODE_ALL)) {
        options |= LYXP_SCNODE;
    }
    if (!ctx) {
        ctx = ctx_node->module->ctx;
    }

    /* allocate return set */
    ret = ly_set_new(set);
    LY_CHECK_GOTO(ret, cleanup);

    /* compile expression */
    ret = lyxp_expr_parse(ctx, NULL, xpath, 0, 1, &exp);
    LY_CHECK_GOTO(ret, cleanup);

    /* atomize expression */
    ret = lyxp_atomize(ctx, exp, NULL, LY_VALUE_JSON, NULL, ctx_node, ctx_node, &xp_set, options);
    LY_CHECK_GOTO(ret, cleanup);

    /* transform into ly_set */
    (*set)->objs = malloc(xp_set.used * sizeof *(*set)->objs);
    LY_CHECK_ERR_GOTO(!(*set)->objs, LOGMEM(ctx); ret = LY_EMEM, cleanup);
    (*set)->size = xp_set.used;

    for (i = 0; i < xp_set.used; ++i) {
        if (xp_set.val.scnodes[i].type == LYXP_NODE_ELEM) {
            ret = ly_set_add(*set, xp_set.val.scnodes[i].scnode, 1, NULL);
            LY_CHECK_GOTO(ret, cleanup);
        }
    }

cleanup:
    lyxp_set_free_content(&xp_set);
    lyxp_expr_free(exp);
    return ret;
}

LIBYANG_API_DEF LY_ERR
lys_find_expr_atoms(const struct lysc_node *ctx_node, const struct lys_module *cur_mod, const struct lyxp_expr *expr,
        const struct lysc_prefix *prefixes, uint32_t options, struct ly_set **set)
{
    LY_ERR ret = LY_SUCCESS;
    struct lyxp_set xp_set = {0};
    uint32_t i;

    LY_CHECK_ARG_RET(NULL, cur_mod, expr, prefixes, set, LY_EINVAL);
    LY_CHECK_CTX_EQUAL_RET(__func__, ctx_node ? ctx_node->module->ctx : NULL, cur_mod->ctx, LY_EINVAL);
    if (!(options & LYXP_SCNODE_ALL)) {
        options = LYXP_SCNODE;
    }

    /* allocate return set */
    ret = ly_set_new(set);
    LY_CHECK_GOTO(ret, cleanup);

    /* atomize expression */
    ret = lyxp_atomize(cur_mod->ctx, expr, cur_mod, LY_VALUE_SCHEMA_RESOLVED, (void *)prefixes, ctx_node, ctx_node,
            &xp_set, options);
    LY_CHECK_GOTO(ret, cleanup);

    /* transform into ly_set */
    (*set)->objs = malloc(xp_set.used * sizeof *(*set)->objs);
    LY_CHECK_ERR_GOTO(!(*set)->objs, LOGMEM(cur_mod->ctx); ret = LY_EMEM, cleanup);
    (*set)->size = xp_set.used;

    for (i = 0; i < xp_set.used; ++i) {
        if ((xp_set.val.scnodes[i].type == LYXP_NODE_ELEM) && (xp_set.val.scnodes[i].in_ctx >= LYXP_SET_SCNODE_ATOM_NODE)) {
            assert((xp_set.val.scnodes[i].in_ctx == LYXP_SET_SCNODE_ATOM_NODE) ||
                    (xp_set.val.scnodes[i].in_ctx == LYXP_SET_SCNODE_ATOM_VAL) ||
                    (xp_set.val.scnodes[i].in_ctx == LYXP_SET_SCNODE_ATOM_CTX));
            ret = ly_set_add(*set, xp_set.val.scnodes[i].scnode, 1, NULL);
            LY_CHECK_GOTO(ret, cleanup);
        }
    }

cleanup:
    lyxp_set_free_content(&xp_set);
    if (ret) {
        ly_set_free(*set, NULL);
        *set = NULL;
    }
    return ret;
}

LIBYANG_API_DEF LY_ERR
lys_find_xpath(const struct ly_ctx *ctx, const struct lysc_node *ctx_node, const char *xpath, uint32_t options,
        struct ly_set **set)
{
    LY_ERR ret = LY_SUCCESS;
    struct lyxp_set xp_set = {0};
    struct lyxp_expr *exp = NULL;
    uint32_t i;

    LY_CHECK_ARG_RET(NULL, ctx || ctx_node, xpath, set, LY_EINVAL);
    LY_CHECK_CTX_EQUAL_RET(__func__, ctx, ctx_node ? ctx_node->module->ctx : NULL, LY_EINVAL);
    if (!(options & LYXP_SCNODE_ALL)) {
        options |= LYXP_SCNODE;
    }
    if (!ctx) {
        ctx = ctx_node->module->ctx;
    }

    /* allocate return set */
    ret = ly_set_new(set);
    LY_CHECK_GOTO(ret, cleanup);

    /* compile expression */
    ret = lyxp_expr_parse(ctx, NULL, xpath, 0, 1, &exp);
    LY_CHECK_GOTO(ret, cleanup);

    /* atomize expression */
    ret = lyxp_atomize(ctx, exp, NULL, LY_VALUE_JSON, NULL, ctx_node, ctx_node, &xp_set, options);
    LY_CHECK_GOTO(ret, cleanup);

    /* transform into ly_set */
    (*set)->objs = malloc(xp_set.used * sizeof *(*set)->objs);
    LY_CHECK_ERR_GOTO(!(*set)->objs, LOGMEM(ctx); ret = LY_EMEM, cleanup);
    (*set)->size = xp_set.used;

    for (i = 0; i < xp_set.used; ++i) {
        if ((xp_set.val.scnodes[i].type == LYXP_NODE_ELEM) && (xp_set.val.scnodes[i].in_ctx == LYXP_SET_SCNODE_ATOM_CTX)) {
            ret = ly_set_add(*set, xp_set.val.scnodes[i].scnode, 1, NULL);
            LY_CHECK_GOTO(ret, cleanup);
        }
    }

cleanup:
    lyxp_set_free_content(&xp_set);
    lyxp_expr_free(exp);
    if (ret) {
        ly_set_free(*set, NULL);
        *set = NULL;
    }
    return ret;
}

LIBYANG_API_DEF LY_ERR
lys_find_lypath_atoms(const struct ly_path *path, struct ly_set **set)
{
    LY_ERR ret = LY_SUCCESS;
    LYA_COUNT_T u, v;

    LY_CHECK_ARG_RET(NULL, path, set, LY_EINVAL);

    /* allocate return set */
    LY_CHECK_RET(ly_set_new(set));

    LYA_FOR(path, u) {
        /* add nodes from the path */
        LY_CHECK_GOTO(ret = ly_set_add(*set, (void *)path[u].node, 0, NULL), cleanup);
        LYA_FOR(path[u].predicates, v) {
            if ((path[u].predicates[v].type == LY_PATH_PREDTYPE_LIST) || (path[u].predicates[v].type == LY_PATH_PREDTYPE_LIST_VAR)) {
                /* add all the keys in a predicate */
                LY_CHECK_GOTO(ret = ly_set_add(*set, (void *)path[u].predicates[v].key, 0, NULL), cleanup);
            }
        }
    }

cleanup:
    if (ret) {
        ly_set_free(*set, NULL);
        *set = NULL;
    }
    return ret;
}

LIBYANG_API_DEF LY_ERR
lys_find_path_atoms(const struct ly_ctx *ctx, const struct lysc_node *ctx_node, const char *path, ly_bool output,
        struct ly_set **set)
{
    LY_ERR ret = LY_SUCCESS;
    uint8_t oper;
    struct lyxp_expr *expr = NULL;
    struct ly_path *p = NULL;

    LY_CHECK_ARG_RET(ctx, ctx || ctx_node, path, set, LY_EINVAL);
    LY_CHECK_CTX_EQUAL_RET(__func__, ctx, ctx_node ? ctx_node->module->ctx : NULL, LY_EINVAL);

    if (!ctx) {
        ctx = ctx_node->module->ctx;
    }

    /* parse */
    ret = ly_path_parse(ctx, ctx_node, path, 0, 0, LY_PATH_BEGIN_EITHER, LY_PATH_PREFIX_FIRST,
            LY_PATH_PRED_SIMPLE, &expr);
    LY_CHECK_GOTO(ret, cleanup);

    /* compile */
    oper = output ? LY_PATH_OPER_OUTPUT : LY_PATH_OPER_INPUT;
    ret = ly_path_compile(ctx, ctx_node, expr, oper, LY_PATH_TARGET_MANY, 0, LY_VALUE_JSON, NULL, &p);
    LY_CHECK_GOTO(ret, cleanup);

    /* resolve */
    ret = lys_find_lypath_atoms(p, set);

cleanup:
    ly_path_free(p);
    lyxp_expr_free(expr);
    return ret;
}

LIBYANG_API_DEF const struct lysc_node *
lys_find_path(const struct ly_ctx *ctx, const struct lysc_node *ctx_node, const char *path, ly_bool output)
{
    const struct lysc_node *snode = NULL;
    struct lyxp_expr *expr = NULL;
    struct ly_path *p = NULL;
    LY_ERR ret;
    uint8_t oper;

    LY_CHECK_ARG_RET(ctx, ctx || ctx_node, path, NULL);
    LY_CHECK_CTX_EQUAL_RET(__func__, ctx, ctx_node ? ctx_node->module->ctx : NULL, NULL);

    if (!ctx) {
        ctx = ctx_node->module->ctx;
    }

    /* parse */
    ret = ly_path_parse(ctx, ctx_node, path, 0, 0, LY_PATH_BEGIN_EITHER, LY_PATH_PREFIX_FIRST,
            LY_PATH_PRED_SIMPLE, &expr);
    LY_CHECK_GOTO(ret, cleanup);

    /* compile */
    oper = output ? LY_PATH_OPER_OUTPUT : LY_PATH_OPER_INPUT;
    ret = ly_path_compile(ctx, ctx_node, expr, oper, LY_PATH_TARGET_MANY, 0, LY_VALUE_JSON, NULL, &p);
    LY_CHECK_GOTO(ret, cleanup);

    /* get last node */
    snode = p[LYA_COUNT(p) - 1].node;

cleanup:
    ly_path_free(p);
    lyxp_expr_free(expr);
    return snode;
}

char *
lysc_path_until(const struct lysc_node *node, const struct lysc_node *parent, LYSC_PATH_TYPE pathtype, char *buffer,
        size_t buflen)
{
    const struct lysc_node *iter, *par, *key;
    char *path = NULL;
    int len = 0;
    ly_bool skip_schema;

    if (buffer) {
        LY_CHECK_ARG_RET(node->module->ctx, buflen > 1, NULL);
        buffer[0] = '\0';
    }

    if ((pathtype == LYSC_PATH_DATA) || (pathtype == LYSC_PATH_DATA_PATTERN)) {
        /* skip schema-only nodes */
        skip_schema = 1;
    } else {
        skip_schema = 0;
    }

    for (iter = node; iter && (iter != parent) && (len >= 0); iter = iter->parent) {
        char *s;
        const char *slash;

        if (skip_schema && (iter->nodetype & (LYS_CHOICE | LYS_CASE | LYS_INPUT | LYS_OUTPUT))) {
            /* schema-only node */
            continue;
        }

        if ((pathtype == LYSC_PATH_DATA_PATTERN) && (iter->nodetype == LYS_LIST)) {
            char *predicates = NULL;

            key = NULL;
            while ((key = lys_getnext(key, iter, NULL, 0)) && lysc_is_key(key)) {
                s = predicates;

                /* print key predicate */
                if (asprintf(&predicates, "%s[%s='%%s']", s ? s : "", key->name) == -1) {
                    free(s);
                    free(path);
                    return NULL;
                }
                free(s);
            }
            s = buffer ? strdup(buffer) : path;
            if (buffer) {
                len = snprintf(buffer, buflen, "%s%s", predicates ? predicates : "", s ? s : "");
            } else {
                len = asprintf(&path, "%s%s", predicates ? predicates : "", s ? s : "");
            }
            free(predicates);
            free(s);

            if (buffer && (buflen <= (size_t)len)) {
                /* not enough space in buffer */
                break;
            }
        }

        s = buffer ? strdup(buffer) : path;
        if (parent && (iter->parent == parent)) {
            slash = "";
        } else {
            slash = "/";
        }

        if (skip_schema) {
            par = lysc_data_parent(iter);
        } else {
            par = iter->parent;
        }

        if (!par || (par->module != iter->module)) {
            /* print prefix */
            if (buffer) {
                len = snprintf(buffer, buflen, "%s%s:%s%s", slash, iter->module->name, iter->name, s ? s : "");
            } else {
                len = asprintf(&path, "%s%s:%s%s", slash, iter->module->name, iter->name, s ? s : "");
            }
        } else {
            /* prefix is the same as in parent */
            if (buffer) {
                len = snprintf(buffer, buflen, "%s%s%s", slash, iter->name, s ? s : "");
            } else {
                len = asprintf(&path, "%s%s%s", slash, iter->name, s ? s : "");
            }
        }
        free(s);

        if (buffer && (buflen <= (size_t)len)) {
            /* not enough space in buffer */
            break;
        }
    }

    if (len < 0) {
        free(path);
        path = NULL;
    } else if (len == 0) {
        if (buffer) {
            strcpy(buffer, "/");
        } else {
            free(path);
            path = strdup("/");
        }
    }

    if (buffer) {
        return buffer;
    } else {
        return path;
    }
}

LIBYANG_API_DEF char *
lysc_path(const struct lysc_node *node, LYSC_PATH_TYPE pathtype, char *buffer, size_t buflen)
{
    return lysc_path_until(node, NULL, pathtype, buffer, buflen);
}

LY_ERR
_lys_set_implemented(struct lys_module *mod, const char **features, struct lys_glob_unres *unres)
{
    LY_ERR ret = LY_SUCCESS, r;
    struct lys_module *mod_iter;
    const char **imp_f, *all_f[] = {"*", NULL};
    uint32_t i;

    if (mod->implemented) {
        /* mod is already implemented, set the features */
        r = lys_set_features(mod->parsed, features);
        if (r == LY_EEXIST) {
            /* no changes */
            return LY_SUCCESS;
        } else if (!r) {
            /* mark the module as changed */
            mod->to_compile = 1;
            LY_CHECK_RET(ly_set_add(&unres->compiling, mod, 1, NULL));
        }

        return r;
    }

    /* implement, ignore recompilation because it must always take place later */
    r = lys_implement(mod, features, unres);
    LY_CHECK_ERR_GOTO(r && (r != LY_ERECOMPILE), ret = r, cleanup);

    if (mod->ctx->opts & LY_CTX_ALL_IMPLEMENTED) {
        /* implement all the imports as well */
        for (i = 0; i < unres->creating.count; ++i) {
            mod = unres->creating.objs[i];
            if (mod->implemented) {
                continue;
            }

            imp_f = (mod->ctx->opts & LY_CTX_ENABLE_IMP_FEATURES) ? all_f : NULL;
            r = lys_implement(mod, imp_f, unres);
            LY_CHECK_ERR_GOTO(r && (r != LY_ERECOMPILE), ret = r, cleanup);
        }
    }

    /* try to find module with LYS_MOD_IMPORTED_REV flag */
    i = 0;
    while ((mod_iter = ly_ctx_get_module_iter(mod->ctx, &i))) {
        if (!strcmp(mod_iter->name, mod->name) && (mod_iter != mod) && (mod_iter->latest_revision & LYS_MOD_IMPORTED_REV)) {
            LOGVRB("Implemented module \"%s@%s\" was not and will not be imported if the revision-date is missing"
                    " in the import statement. Instead, the revision \"%s\" is imported.", mod->name, mod->revision,
                    mod_iter->revision);
            break;
        }
    }

cleanup:
    return ret;
}

/**
 * @brief Check whether it may be needed to (re)compile a module from a particular dependency set
 * and if so, add it into its dep set.
 *
 * Dependency set includes all modules that need to be (re)compiled in case any of the module(s)
 * in the dep set are (re)compiled.
 *
 * The reason for recompilation is possible disabled nodes and updating
 * leafref targets to point to the newly compiled modules. Using the import relation, the
 * dependency is reflexive because of possible foreign augments and deviations, which are compiled
 * during the target module compilation.
 *
 * - every module must belong to exactly one dep set
 * - implement flag must be ignored because it can be changed during dep set compilation
 *
 * @param[in] mod Module to process.
 * @param[in,out] ctx_set Set with all not-yet-processed modules.
 * @param[in,out] dep_set Current dependency set to update.
 * @param[in] aux_set Set of traversed non-compiled modules, should be empty on first call.
 * @return LY_ERR value.
 */
static LY_ERR
lys_unres_dep_sets_create_mod_r(struct lys_module *mod, struct ly_set *ctx_set, struct ly_set *dep_set,
        struct ly_set *aux_set)
{
    struct lys_module *mod2;
    struct lysp_import *imports;
    uint32_t i;
    LYA_COUNT_T u, v;
    ly_bool found;

    if (LYS_IS_SINGLE_DEP_SET(mod)) {
        /* is already in a separate dep set */
        if (!lys_has_dep_mods(mod)) {
            /* break the dep set here, no modules depend on this one */
            return LY_SUCCESS;
        }

        if (ly_set_contains(aux_set, mod, NULL)) {
            /* it was traversed */
            return LY_SUCCESS;
        }

        /* add a new auxiliary module */
        LY_CHECK_RET(ly_set_add(aux_set, mod, 1, NULL));
    } else {
        if (!ly_set_contains(ctx_set, mod, &i)) {
            /* it was already processed */
            return LY_SUCCESS;
        }

        /* remove it from the set, we are processing it now */
        ly_set_rm_index(ctx_set, i, NULL);

        /* add a new dependent module into the dep set */
        LY_CHECK_RET(ly_set_add(dep_set, mod, 1, NULL));
    }

    /* process imports of the module and submodules */
    imports = mod->parsed->imports;
    LYA_FOR(imports, u) {
        mod2 = imports[u].module;
        LY_CHECK_RET(lys_unres_dep_sets_create_mod_r(mod2, ctx_set, dep_set, aux_set));
    }
    LYA_FOR(mod->parsed->includes, v) {
        imports = mod->parsed->includes[v].submodule->imports;
        LYA_FOR(imports, u) {
            mod2 = imports[u].module;
            if (LYS_IS_SINGLE_DEP_SET(mod2) && !lys_has_dep_mods(mod2)) {
                /* break the dep set here, no modules depend on this one */
                continue;
            }

            LY_CHECK_RET(lys_unres_dep_sets_create_mod_r(imports[u].module, ctx_set, dep_set, aux_set));
        }
    }

    /* process modules and submodules importing this module */
    for (i = 0; i < mod->ctx->modules.count; ++i) {
        mod2 = mod->ctx->modules.objs[i];
        found = 0;

        imports = mod2->parsed->imports;
        LYA_FOR(imports, u) {
            if (imports[u].module == mod) {
                found = 1;
                break;
            }
        }

        if (!found) {
            LYA_FOR(mod2->parsed->includes, v) {
                imports = mod2->parsed->includes[v].submodule->imports;
                LYA_FOR(imports, u) {
                    if (imports[u].module == mod) {
                        found = 1;
                        break;
                    }
                }

                if (found) {
                    break;
                }
            }
        }

        if (found) {
            LY_CHECK_RET(lys_unres_dep_sets_create_mod_r(mod2, ctx_set, dep_set, aux_set));
        }
    }

    return LY_SUCCESS;
}

/**
 * @brief Add all simple modules (that have nothing to (re)compile) into separate dep sets.
 *
 * @param[in,out] ctx_set Set with all not-yet-processed modules.
 * @param[in,out] main_set Set of dependency module sets.
 * @return LY_ERR value.
 */
static LY_ERR
lys_unres_dep_sets_create_single(struct ly_set *ctx_set, struct ly_set *main_set)
{
    LY_ERR ret = LY_SUCCESS;
    struct lys_module *m;
    uint32_t i = 0;
    struct ly_set *dep_set = NULL;

    while (i < ctx_set->count) {
        m = ctx_set->objs[i];
        if (LYS_IS_SINGLE_DEP_SET(m)) {
            /* remove it from the set, we are processing it now */
            ly_set_rm_index(ctx_set, i, NULL);

            /* this module can be in a separate dep set (but there still may be modules importing this one
             * that depend on imports of this one in case it defines groupings) */
            LY_CHECK_GOTO(ret = ly_set_new(&dep_set), cleanup);
            LY_CHECK_GOTO(ret = ly_set_add(dep_set, m, 1, NULL), cleanup);
            LY_CHECK_GOTO(ret = ly_set_add(main_set, dep_set, 1, NULL), cleanup);
            dep_set = NULL;
        } else {
            ++i;
        }
    }

cleanup:
    ly_set_free(dep_set, NULL);
    return ret;
}

LY_ERR
lys_unres_dep_sets_create(struct ly_ctx *ctx, struct ly_set *main_set, const struct ly_set *compile_set)
{
    LY_ERR ret = LY_SUCCESS;
    struct lys_module *cur_mod, *m;
    struct ly_set *dep_set = NULL, *ctx_set = NULL, aux_set = {0};
    uint32_t i, compile_i = 0;
    ly_bool found;

    assert(!main_set->count);

    /* start with a duplicate set of modules that we will remove from */
    LY_CHECK_GOTO(ret = ly_set_dup(&ctx->modules, NULL, &ctx_set), cleanup);

    /* first create all dep sets with single modules */
    LY_CHECK_GOTO(ret = lys_unres_dep_sets_create_single(ctx_set, main_set), cleanup);

    while (ctx_set->count) {
        /* get the next module to create a dep set for */
        if (compile_set) {
            cur_mod = NULL;
            while (compile_i < compile_set->count) {
                m = compile_set->objs[compile_i];
                ++compile_i;

                if (m->to_compile && ly_set_contains(ctx_set, m, NULL)) {
                    /* next module */
                    cur_mod = m;
                    break;
                }
            }

            if (!cur_mod) {
                /* have dep sets for all the modules that will be compiled now */
                break;
            }
        } else {
            /* just use first ctx mod */
            cur_mod = ctx_set->objs[0];
        }

        /* create new dep set */
        LY_CHECK_GOTO(ret = ly_set_new(&dep_set), cleanup);

        /* use the module and create a dep set with the rest of its dependent modules */
        LY_CHECK_GOTO(ret = lys_unres_dep_sets_create_mod_r(cur_mod, ctx_set, dep_set, &aux_set), cleanup);
        ly_set_erase(&aux_set, NULL);
        assert(dep_set->count);

        /* check whether there is any module that will be (re)compiled */
        found = 0;
        for (i = 0; i < dep_set->count; ++i) {
            m = dep_set->objs[i];
            if (m->to_compile) {
                found = 1;
                break;
            }
        }

        if (found) {
            /* if there is, all the implemented modules need to be recompiled */
            for (i = 0; i < dep_set->count; ++i) {
                m = dep_set->objs[i];
                if (m->implemented) {
                    m->to_compile = 1;
                }
            }
        }

        /* add the dep set into main set */
        LY_CHECK_GOTO(ret = ly_set_add(main_set, dep_set, 1, NULL), cleanup);
        dep_set = NULL;
    }

#ifndef NDEBUG
    LOGDBG(LY_LDGDEPSETS, "dep sets created (%" PRIu32 "):", main_set->count);
    for (i = 0; i < main_set->count; ++i) {
        struct ly_set *iter_set = main_set->objs[i];

        LOGDBG(LY_LDGDEPSETS, "dep set #%" PRIu32 ":", i);
        for (uint32_t j = 0; j < iter_set->count; ++j) {
            m = iter_set->objs[j];
            LOGDBG(LY_LDGDEPSETS, "\t%s", m->name);
        }
    }
#endif

cleanup:
    assert(ret || main_set->objs);
    ly_set_erase(&aux_set, NULL);
    ly_set_free(dep_set, NULL);
    ly_set_free(ctx_set, NULL);
    return ret;
}

void
lys_unres_glob_revert(struct ly_ctx *ctx, struct lys_glob_unres *unres)
{
    uint32_t i, j, idx, *prev_lo, temp_lo = 0;
    struct lys_module *mod;
    struct ly_set *dep_set;
    LY_ERR ret;

    for (i = 0; i < unres->implementing.count; ++i) {
        mod = unres->implementing.objs[i];
        assert(mod->implemented);

        /* make the module correctly non-implemented again */
        mod->implemented = 0;
        lys_precompile_augments_deviations_revert(ctx, mod);
        lysc_module_free(ctx, mod->compiled);
        mod->compiled = NULL;

        /* should not be made implemented */
        mod->to_compile = 0;
    }

    for (i = 0; i < unres->creating.count; ++i) {
        mod = unres->creating.objs[i];

        /* remove the module from the context */
        ly_set_rm(&ctx->modules, mod, NULL);

        /* remove it also from dep sets */
        for (j = 0; j < unres->dep_sets.count; ++j) {
            dep_set = unres->dep_sets.objs[j];
            if (ly_set_contains(dep_set, mod, &idx)) {
                ly_set_rm_index(dep_set, idx, NULL);
                break;
            }
        }

        /* free the module */
        lys_module_free(ctx, mod, 1);
    }

    if (unres->implementing.count) {
        /* recompile previous context because some implemented modules are no longer implemented,
         * we can reuse the current to_compile flags */
        prev_lo = ly_temp_log_options(&temp_lo);
        ret = lys_compile_depset_all(ctx, &ctx->unres);
        ly_temp_log_options(prev_lo);
        if (ret) {
            LOGINT(ctx);
        }
    }
}

/**
 * @brief Revert changes stored in global compile context after a failed compilation for a single module.
 *
 * @param[in] ctx libyang context.
 * @param[in] unres Global unres to use.
 * @param[in] mod Failed module to free.
 */
static void
lys_unres_glob_revert_erase_mod(struct ly_ctx *ctx, struct lys_glob_unres *unres, struct lys_module *mod)
{
    uint32_t idx, i, j;
    struct ly_set *dep_set;

    if (ly_set_contains(&unres->implementing, mod, &i)) {
        /* make the module correctly non-implemented again */
        mod->implemented = 0;
        lys_precompile_augments_deviations_revert(ctx, mod);
        lysc_module_free(ctx, mod->compiled);
        mod->compiled = NULL;

        /* should not be made implemented */
        mod->to_compile = 0;

        /* remove from the set */
        ly_set_rm_index(&unres->implementing, i, NULL);
    }

    if (ly_set_contains(&unres->creating, mod, &i)) {
        /* remove the module from the context */
        ly_set_rm(&ctx->modules, mod, NULL);

        /* remove it also from dep sets */
        for (j = 0; j < unres->dep_sets.count; ++j) {
            dep_set = unres->dep_sets.objs[j];
            if (ly_set_contains(dep_set, mod, &idx)) {
                ly_set_rm_index(dep_set, idx, NULL);
                break;
            }
        }

        /* free the module */
        lys_module_free(ctx, mod, 1);

        /* remove from the set */
        ly_set_rm_index(&unres->creating, i, NULL);
    }
}

void
lys_unres_glob_erase(struct lys_glob_unres *unres)
{
    uint32_t i;

    for (i = 0; i < unres->dep_sets.count; ++i) {
        ly_set_free(unres->dep_sets.objs[i], NULL);
    }
    ly_set_erase(&unres->dep_sets, NULL);
    ly_set_erase(&unres->implementing, NULL);
    ly_set_erase(&unres->compiling, NULL);
    ly_set_erase(&unres->creating, NULL);

    assert(!unres->ds_unres.whens.count);
    assert(!unres->ds_unres.musts.count);
    assert(!unres->ds_unres.leafrefs.count);
    assert(!unres->ds_unres.disabled_leafrefs.count);
    assert(!unres->ds_unres.dflts.count);
    assert(!unres->ds_unres.disabled.count);
}

LIBYANG_API_DEF LY_ERR
lys_set_implemented(struct lys_module *mod, const char **features)
{
    LY_ERR rc = LY_SUCCESS;
    struct lys_glob_unres *unres = &mod->ctx->unres;

    LY_CHECK_ARG_RET(NULL, mod, mod->parsed, !(mod->ctx->opts & LY_CTX_INT_IMMUTABLE), LY_EINVAL);

    /* implement */
    rc = _lys_set_implemented(mod, features, unres);
    LY_CHECK_GOTO(rc, cleanup);

    if (!mod->to_compile) {
        /* no changes to the module */
        goto cleanup;
    }

    if (!(mod->ctx->opts & LY_CTX_EXPLICIT_COMPILE)) {
        /* create dep set for the module and mark all the modules that will be (re)compiled */
        LY_CHECK_GOTO(rc = lys_unres_dep_sets_create(mod->ctx, &unres->dep_sets, &unres->compiling), cleanup);

        /* (re)compile the whole dep set (other dep sets will have no modules marked for compilation) */
        LY_CHECK_GOTO(rc = lys_compile_depset_all(mod->ctx, unres), cleanup);

        /* unres resolved */
        lys_unres_glob_erase(unres);

        /* new context state */
        ly_ctx_new_change(mod->ctx);
    }

cleanup:
    if (rc) {
        lys_unres_glob_revert(mod->ctx, unres);
        lys_unres_glob_erase(unres);
    }
    return rc;
}

LIBYANG_API_DEF LY_ERR
lys_compare(const struct ly_ctx *ctx, const struct lys_module *src_mod, const struct lys_module *trg_mod,
        ly_bool gen_local, ly_bool gen_full, struct lyd_node **schema_diff)
{
    LY_ERR rc = LY_SUCCESS;
    const struct lys_module *cmp_mod;
    struct lys_diff_s diff = {0};

    LY_CHECK_ARG_RET(NULL, ctx, src_mod, trg_mod, gen_local || gen_full, schema_diff, LY_EINVAL);

    *schema_diff = NULL;

    /* check arguments */
    cmp_mod = ly_ctx_get_module_implemented(ctx, "ietf-yang-schema-comparison-output");
    if (!cmp_mod) {
        LOGERR(ctx, LY_ENOTFOUND, "Module \"ietf-yang-schema-comparison-output\" not found.");
        rc = LY_ENOTFOUND;
        goto cleanup;
    } else if (!cmp_mod->revision || strcmp(cmp_mod->revision, "2026-09-02")) {
        LOGERR(ctx, LY_ENOTFOUND, "Module \"ietf-yang-schema-comparison\" not in the expected revision \"2026-09-02\".");
        rc = LY_ENOTFOUND;
        goto cleanup;
    }

    if (strcmp(src_mod->name, trg_mod->name)) {
        LOGERR(ctx, LY_EINVAL, "Source module \"%s\" and target module \"%s\" have different names.", src_mod->name,
                trg_mod->name);
        rc = LY_EINVAL;
        goto cleanup;
    } else if (!src_mod->implemented) {
        LOGERR(ctx, LY_EINVAL, "Source module \"%s@%s\" not implemented.", src_mod->name,
                src_mod->revision ? src_mod->revision : "<none>");
        rc = LY_EINVAL;
        goto cleanup;
    } else if (!trg_mod->implemented) {
        LOGERR(ctx, LY_EINVAL, "Target module \"%s@%s\" not implemented.", trg_mod->name,
                trg_mod->revision ? trg_mod->revision : "<none>");
        rc = LY_EINVAL;
        goto cleanup;
    } else if (!(ly_ctx_get_options(src_mod->ctx) & LY_CTX_SET_PRIV_PARSED)) {
        LOGERR(ctx, LY_EINVAL, "Source module \"%s@%s\" context LY_CTX_SET_PRIV_PARSED option not set.",
                src_mod->name, src_mod->revision ? src_mod->revision : "<none>");
        rc = LY_EINVAL;
        goto cleanup;
    } else if (!(ly_ctx_get_options(trg_mod->ctx) & LY_CTX_SET_PRIV_PARSED)) {
        LOGERR(ctx, LY_EINVAL, "Target module \"%s@%s\" context LY_CTX_SET_PRIV_PARSED option not set.",
                trg_mod->name, trg_mod->revision ? trg_mod->revision : "<none>");
        rc = LY_EINVAL;
        goto cleanup;
    } else if (!src_mod->parsed) {
        LOGERR(ctx, LY_EINVAL, "Source parsed module \"%s@%s\" missing.", src_mod->name,
                src_mod->revision ? src_mod->revision : "<none>");
        rc = LY_EINVAL;
        goto cleanup;
    } else if (!trg_mod->parsed) {
        LOGERR(ctx, LY_EINVAL, "Target parsed module \"%s@%s\" missing.", trg_mod->name,
                trg_mod->revision ? trg_mod->revision : "<none>");
        rc = LY_EINVAL;
        goto cleanup;
    }

    /* store module prefixes */
    diff.old_prefix = src_mod->prefix;
    diff.new_prefix = trg_mod->prefix;

    /* decide what rules to use based on the YANG version of the new module */
    diff.is_yang10 = (trg_mod->version & LYS_VERSION_1_1) ? 0 : 1;

    /* store other params */
    diff.gen_local = gen_local;
    diff.gen_full = gen_full;
    diff.ctx = ctx;

    /* generate the diff */
    LY_CHECK_GOTO(rc = lysc_diff_changes(src_mod, trg_mod, &diff), cleanup);

    /* create schema-comparison data from the diff */
    LY_CHECK_GOTO(rc = lysc_diff_tree(src_mod, trg_mod, &diff, cmp_mod, schema_diff), cleanup);

cleanup:
    lysc_diff_erase(&diff);
    return rc;
}

/**
 * @brief Resolve (find) all imported and included modules.
 *
 * @param[in] pctx Parser context.
 * @param[in] pmod Parsed module to resolve.
 * @param[out] new_mods Set with all the newly loaded modules.
 * @return LY_ERR value.
 */
static LY_ERR
lysp_resolve_import_include(struct lysp_ctx *pctx, struct lysp_module *pmod, struct ly_set *new_mods)
{
    struct lysp_import *imp;
    LYA_COUNT_T u, v;

    pmod->parsing = 1;
    LYA_FOR(pmod->imports, u) {
        imp = &pmod->imports[u];
        if (!imp->module) {
            LY_CHECK_RET(lys_parse_load(PARSER_CTX(pctx), imp->name, imp->rev[0] ? imp->rev : NULL, new_mods, &imp->module));

            if (!imp->rev[0]) {
                /* This module must be selected for the next similar
                 * import without revision-date to avoid incorrect
                 * derived identities in the ::lys_module.identities.
                 */
                imp->module->latest_revision |= LYS_MOD_IMPORTED_REV;
            }
        }

        /* check for importing the same module twice */
        for (v = 0; v < u; ++v) {
            if (imp->module == pmod->imports[v].module) {
                LOGWRN(PARSER_CTX(pctx), "Single revision of the module \"%s\" imported twice.", imp->name);
            }
        }
    }
    LY_CHECK_RET(lysp_load_submodules(pctx, pmod, new_mods));

    pmod->parsing = 0;

    return LY_SUCCESS;
}

/**
 * @brief Generate path of the given parsed node.
 *
 * @param[in] node Schema path of this node will be generated.
 * @param[in] parent Build relative path only until this parent is found. If NULL, the full absolute path is printed.
 * @param[in] pmod Parsed module of a top-level parent of @p node.
 * @return NULL in case of memory allocation error, path of the node otherwise.
 * In case the @p buffer is NULL, the returned string is dynamically allocated and caller is responsible to free it.
 */
static char *
lysp_path_until(const struct lysp_node *node, const struct lysp_node *parent, const struct lysp_module *pmod)
{
    const struct lysp_node *iter;
    char *path = NULL, *s;
    const char *slash, *mod_colon, *mod_prefix, *node_start, *node_end;
    int len = 0;

    for (iter = node; iter && (iter != parent) && (len >= 0); iter = iter->parent) {
        if (parent && (iter->parent == parent)) {
            slash = "";
        } else {
            slash = "/";
        }

        if (iter->parent) {
            /* prefix is the same as in parent */
            mod_colon = "";
            mod_prefix = "";
        } else {
            /* print prefix */
            mod_colon = ":";
            mod_prefix = pmod->mod->name;
        }

        /* non-compiled schema nodes */
        switch (iter->nodetype) {
        case LYS_CONTAINER:
        case LYS_CHOICE:
        case LYS_LEAF:
        case LYS_LEAFLIST:
        case LYS_LIST:
        case LYS_ANYXML:
        case LYS_ANYDATA:
        case LYS_CASE:
        case LYS_RPC:
        case LYS_ACTION:
        case LYS_NOTIF:
        case LYS_INPUT:
        case LYS_OUTPUT:
            node_start = "";
            node_end = "";
            break;
        case LYS_USES:
            node_start = "{uses='";
            node_end = "'}";
            break;
        case LYS_GROUPING:
            node_start = "{grouping='";
            node_end = "'}";
            break;
        case LYS_AUGMENT:
            node_start = "{augment='";
            node_end = "'}";
            break;
        default:
            len = -1;
            goto cleanup;
        }

        s = path;
        len = asprintf(&path, "%s%s%s%s%s%s%s", slash, mod_prefix, mod_colon, node_start, iter->name, node_end, s ? s : "");
        free(s);
    }

    if (len == 0) {
        path = strdup("/");
    }

cleanup:
    if (len < 0) {
        free(path);
        path = NULL;
    }
    return path;
}

/**
 * @brief Append the log path of a statement to a string, recursively.
 *
 * @param[in] ctx Context for logging.
 * @param[in] stmt Statement to append.
 * @param[in] stmt_idx Index of @p stmt.
 * @param[in] stmt_p Pointer to the statement structure.
 * @param[in] pmod Parsed module to use.
 * @param[in,out] buf Buffer to use.
 * @param[in,out] used Used bytes of @p buf without terminating 0.
 * @param[in,out] size Size of @p buf.
 * @return LY_ERR value.
 */
static LY_ERR
lysp_ext_instance_path_stmt_append_r(const struct ly_ctx *ctx, enum ly_stmt stmt, LYA_COUNT_T stmt_idx,
        const void *stmt_p, const struct lysp_module *pmod, char **buf, uint32_t *used, uint32_t *size)
{
    if (*used && ((*buf)[*used - 1] != ':')) {
        /* slash after the previous path, if not module name */
        LY_CHECK_RET(ly_append_str(buf, size, used, "/"));
    }

    switch (stmt) {
    case LY_STMT_NOTIFICATION:
    case LY_STMT_INPUT:
    case LY_STMT_OUTPUT:
    case LY_STMT_ACTION:
    case LY_STMT_RPC:
    case LY_STMT_ANYDATA:
    case LY_STMT_ANYXML:
    case LY_STMT_AUGMENT:
    case LY_STMT_CASE:
    case LY_STMT_CHOICE:
    case LY_STMT_CONTAINER:
    case LY_STMT_GROUPING:
    case LY_STMT_LEAF:
    case LY_STMT_LEAF_LIST:
    case LY_STMT_LIST:
    case LY_STMT_USES:
        *buf = lysp_path_until(stmt_p, NULL, pmod);
        LY_CHECK_ERR_RET(!buf, LOGMEM(ctx), LY_EMEM);
        *used = strlen(*buf);
        *size = *used + 1;
        break;
    case LY_STMT_ARGUMENT:
    case LY_STMT_YIN_ELEMENT:
        LY_CHECK_RET(lysp_ext_instance_path_stmt_append_r(ctx, LY_STMT_EXTENSION, 0, stmt_p, pmod, buf, used, size));
        LY_CHECK_RET(ly_append_str(buf, size, used, "/{%s}", lyplg_ext_stmt2str(stmt)));
        break;
    case LY_STMT_BASE: {
        const char * const *bases = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), bases[stmt_idx]));
        break;
    }
    case LY_STMT_BELONGS_TO: {
        const struct lysp_submodule *submod = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), submod->name));
        break;
    }
    case LY_STMT_BIT:
    case LY_STMT_ENUM: {
        const struct lysp_type_enum *be = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), be->name));
        break;
    }
    case LY_STMT_CONFIG:
    case LY_STMT_CONTACT:
    case LY_STMT_DESCRIPTION:
    case LY_STMT_MANDATORY:
    case LY_STMT_MAX_ELEMENTS:
    case LY_STMT_MIN_ELEMENTS:
    case LY_STMT_NAMESPACE:
    case LY_STMT_ORGANIZATION:
    case LY_STMT_PREFIX:
    case LY_STMT_YANG_VERSION:
        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s}", lyplg_ext_stmt2str(stmt)));
        break;
    case LY_STMT_DEFAULT: {
        const struct lysp_qname *qn = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), qn->str));
        break;
    }
    case LY_STMT_DEVIATE: {
        const struct lysp_deviate *d = stmt_p;

        switch (d->mod) {
        case LYS_DEV_NOT_SUPPORTED:
            LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='not-supported'}", lyplg_ext_stmt2str(stmt)));
            break;
        case LYS_DEV_ADD:
            LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='add'}", lyplg_ext_stmt2str(stmt)));
            break;
        case LYS_DEV_DELETE:
            LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='delete'}", lyplg_ext_stmt2str(stmt)));
            break;
        case LYS_DEV_REPLACE:
            LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='replace'}", lyplg_ext_stmt2str(stmt)));
            break;
        }
        break;
    }
    case LY_STMT_DEVIATION: {
        const struct lysp_deviation *dev = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), dev->nodeid));
        break;
    }
    case LY_STMT_ERROR_APP_TAG:
    case LY_STMT_ERROR_MESSAGE:
        LY_CHECK_RET(ly_append_str(buf, size, used, "{restriction}/{%s}", lyplg_ext_stmt2str(stmt)));
        break;
    case LY_STMT_EXTENSION: {
        const struct lysp_ext *ext = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), ext->name));
        break;
    }
    case LY_STMT_EXTENSION_INSTANCE: {
        const struct lysp_ext_instance *ext = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{ext-inst='%s'}", ext->name));
        if (ext->argument) {
            LY_CHECK_RET(ly_append_str(buf, size, used, "/%s", ext->argument));
        }
        break;
    }
    case LY_STMT_FEATURE: {
        const struct lysp_feature *f = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), f->name));
        break;
    }
    case LY_STMT_FRACTION_DIGITS:
    case LY_STMT_PATH:
    case LY_STMT_REQUIRE_INSTANCE:
        LY_CHECK_RET(lysp_ext_instance_path_stmt_append_r(ctx, LY_STMT_TYPE, 0, stmt_p, pmod, buf, used, size));
        LY_CHECK_RET(ly_append_str(buf, size, used, "/{%s}", lyplg_ext_stmt2str(stmt)));
        break;
    case LY_STMT_IDENTITY: {
        const struct lysp_ident *id = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), id->name));
        break;
    }
    case LY_STMT_IF_FEATURE:
    case LY_STMT_UNIQUE: {
        const struct lysp_qname *qns = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), qns[stmt_idx].str));
        break;
    }
    case LY_STMT_IMPORT: {
        const struct lysp_import *imp = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), imp->name));
        break;
    }
    case LY_STMT_INCLUDE:  {
        const struct lysp_include *inc = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), inc->name));
        break;
    }
    case LY_STMT_KEY:
    case LY_STMT_ORDERED_BY:
        LY_CHECK_RET(lysp_ext_instance_path_stmt_append_r(ctx, LY_STMT_LIST, 0, stmt_p, pmod, buf, used, size));
        LY_CHECK_RET(ly_append_str(buf, size, used, "/{%s}", lyplg_ext_stmt2str(stmt)));
        break;
    case LY_STMT_LENGTH:
    case LY_STMT_MUST:
    case LY_STMT_RANGE: {
        const struct lysp_restr *res = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), res->arg.str));
        break;
    }
    case LY_STMT_MODIFIER:
        LY_CHECK_RET(lysp_ext_instance_path_stmt_append_r(ctx, LY_STMT_PATTERN, 0, stmt_p, pmod, buf, used, size));
        LY_CHECK_RET(ly_append_str(buf, size, used, "/{%s}", lyplg_ext_stmt2str(stmt)));
        break;
    case LY_STMT_PATTERN: {
        const struct lysp_restr *res = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), res->arg.str + 1));
        break;
    }
    case LY_STMT_POSITION:
        LY_CHECK_RET(lysp_ext_instance_path_stmt_append_r(ctx, LY_STMT_BIT, 0, stmt_p, pmod, buf, used, size));
        LY_CHECK_RET(ly_append_str(buf, size, used, "/{%s}", lyplg_ext_stmt2str(stmt)));
        break;
    case LY_STMT_PRESENCE:
    case LY_STMT_REFERENCE:
    case LY_STMT_REVISION_DATE:
    case LY_STMT_UNITS: {
        const char *str = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), str));
        break;
    }
    case LY_STMT_REFINE: {
        const struct lysp_refine *rf = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), rf->nodeid));
        break;
    }
    case LY_STMT_REVISION: {
        const struct lysp_revision *rev = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), rev->date));
        break;
    }
    case LY_STMT_STATUS: {
        const uint16_t *flags = stmt_p;

        if (*flags & LYS_STATUS_OBSLT) {
            LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='obsolete'}", lyplg_ext_stmt2str(stmt)));
        } else if (*flags & LYS_STATUS_DEPRC) {
            LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='deprecated'}", lyplg_ext_stmt2str(stmt)));
        } else {
            LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='current'}", lyplg_ext_stmt2str(stmt)));
        }
        break;
    }
    case LY_STMT_TYPE: {
        const struct lysp_type *typ = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), typ->name));
        break;
    }
    case LY_STMT_TYPEDEF: {
        const struct lysp_tpdf *tpdf = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), tpdf->name));
        break;
    }
    case LY_STMT_VALUE:
        LY_CHECK_RET(lysp_ext_instance_path_stmt_append_r(ctx, LY_STMT_ENUM, 0, stmt_p, pmod, buf, used, size));
        LY_CHECK_RET(ly_append_str(buf, size, used, "/{%s}", lyplg_ext_stmt2str(stmt)));
        break;
    case LY_STMT_WHEN: {
        const struct lysp_when *wh = stmt_p;

        LY_CHECK_RET(ly_append_str(buf, size, used, "{%s='%s'}", lyplg_ext_stmt2str(stmt), wh->cond));
        break;
    }
    case LY_STMT_NONE:
    case LY_STMT_MODULE:
    case LY_STMT_SUBMODULE:
    case LY_STMT_SYNTAX_SEMICOLON:
    case LY_STMT_SYNTAX_LEFT_BRACE:
    case LY_STMT_SYNTAX_RIGHT_BRACE:
    case LY_STMT_ARG_TEXT:
    case LY_STMT_ARG_VALUE:
        /* invalid */
        LOGINT_RET(ctx);
    }

    return LY_SUCCESS;
}

LY_ERR
lysp_ext_instance_path(const struct ly_ctx *ctx, const struct lysp_module *pmod, const struct lysp_ext_instance *ext,
        char **path)
{
    char *buf = NULL;
    uint32_t used = 0, size = 0;

    if (ext->parent_stmt == LY_STMT_MODULE) {
        /* module name */
        LY_CHECK_RET(ly_append_str(&buf, &size, &used, "/%s:", ((struct lysp_module *)ext->parent)->mod->name));
    } else if (ext->parent_stmt == LY_STMT_SUBMODULE) {
        /* submodule name */
        LY_CHECK_RET(ly_append_str(&buf, &size, &used, "/%s:", ((struct lysp_submodule *)ext->parent)->name));
    } else {
        /* start with the module name unless a node is parent, which will include its module name */
        if (!(ext->parent_stmt & LY_STMT_NODE_MASK)) {
            LY_CHECK_RET(ly_append_str(&buf, &size, &used, "/%s:", pmod->mod->name));
        }

        /* generate path of the parent statement */
        LY_CHECK_RET(lysp_ext_instance_path_stmt_append_r(ctx, ext->parent_stmt, ext->parent_stmt_index, ext->parent,
                pmod, &buf, &used, &size));
    }

    /* append the extension instance path */
    LY_CHECK_RET(lysp_ext_instance_path_stmt_append_r(ctx, LY_STMT_EXTENSION_INSTANCE, 0, ext, pmod, &buf, &used, &size));

    *path = buf;
    return LY_SUCCESS;
}

/**
 * @brief Find extension plugins for all the parsed extensions in a parsed (sub)module.
 *
 * @param[in] pmod Parsed (sub)module to use.
 */
static void
lysp_resolve_extension_plugins(const struct lysp_module *pmod)
{
    LYA_COUNT_T u;

    LYA_FOR(pmod->extensions, u) {
        pmod->extensions[u].plugin_ref = lyplg_ext_plugin_find(pmod->mod->ctx, pmod->mod->name, pmod->mod->revision,
                pmod->extensions[u].name);
    }
}

/**
 * @brief Resolve (find) all extension instance records and finish their parsing.
 *
 * @param[in] pctx Parse context with all the parsed extension instances.
 * @return LY_ERR value.
 */
static LY_ERR
lysp_resolve_ext_instance_records(struct lysp_ctx *pctx)
{
    LY_ERR r;
    struct lysp_ext_instance *ext, *exts;
    struct lysp_ext *ext_def;
    const struct lys_module *mod;
    uint32_t i;
    LYA_COUNT_T u;
    char *path = NULL;
    struct lyplg_ext *ext_plg;

    /* first finish parsing all extension instances ... */
    for (i = 0; i < pctx->ext_inst.count; ++i) {
        exts = pctx->ext_inst.objs[i];
        LYA_FOR(exts, u) {
            ext = &exts[u];

            /* find the extension definition, use its plugin */
            LY_CHECK_RET(lysp_ext_find_definition(PARSER_CTX(pctx), PARSER_CUR_PMOD(pctx), ext, &mod, &ext_def));
            ext->plugin_ref = ext_def->plugin_ref;

            /* resolve the argument, if needed */
            LY_CHECK_RET(lysp_ext_instance_resolve_argument(PARSER_CTX(pctx), PARSER_CUR_PMOD(pctx), ext_def, ext));
        }
    }

    /* ... then call the parse callback */
    for (i = 0; i < pctx->ext_inst.count; ++i) {
        exts = pctx->ext_inst.objs[i];
        u = 0;
        while (u < LYA_COUNT(exts)) {
            ext = &exts[u];
            if (!ext->plugin_ref || !(ext_plg = LYSC_GET_EXT_PLG(ext->plugin_ref))->parse) {
                goto next_iter;
            }

            /* set up log path */
            LY_CHECK_RET(lysp_ext_instance_path(PARSER_CTX(pctx), PARSER_CUR_PMOD(pctx), ext, &path));
            ly_log_location(NULL, path, NULL);

            /* parse */
            r = ext_plg->parse(pctx, ext);

            ly_log_location_revert(0, 1, 0);
            free(path);

            if (r == LY_ENOT) {
                /* instance should be ignored, remove it */
                lysp_ext_instance_free(PARSER_CTX(pctx), ext);
                LYA_DECREMENT(exts);
                if (u < LYA_COUNT(exts)) {
                    /* replace by the last item */
                    *ext = exts[LYA_COUNT(exts)];
                } /* else if there are no more items, leave the empty array, we are not able to free it */
                continue;
            } else if (r) {
                /* error */
                return r;
            }

next_iter:
            ++u;
        }
    }

    return LY_SUCCESS;
}

/**
 * @brief Generate a warning if the filename does not match the expected module name and version.
 *
 * @param[in] ctx Context for logging.
 * @param[in] name Expected module name.
 * @param[in] revision Expected module revision, if any.
 * @param[in] semver Expected module semantic version, if any.
 * @param[in] path File path to be checked.
 */
static void
ly_check_module_filename(const struct ly_ctx *ctx, const char *name, const char *revision, const char *semver,
        const char *path)
{
    const char *filename, *at, *dot, *rev = NULL, *ver = NULL;
    uint32_t name_len, at_len;

    /* get the filename */
    filename = strrchr(path, '/');

#ifdef _WIN32
    const char *backslash = strrchr(path, '\\');

    if (!filename || (filename && backslash && (backslash > filename))) {
        filename = backslash;
    }
#endif

    if (!filename) {
        filename = path;
    } else {
        filename++; /* leading slash */
    }

    /* find the name, revision/version, and file extension */
    at = strchr(filename, '@');
    dot = strrchr(filename, '.');
    if (at) {
        name_len = at - filename;
    } else if (dot) {
        name_len = dot - filename;
    } else {
        name_len = strlen(filename);
    }
    if (at) {
        ++at;
        at_len = dot ? dot - at : (uint32_t)strlen(at);
    }

    /* check valid revision/version and file extension */
    if (!dot) {
        LOGWRN(ctx, "File name \"%s\" missing file extension.", filename);
    }
    if (at) {
        if (!lys_check_date(NULL, at, at_len, "revision")) {
            rev = at;
        } else if (!lyplg_ext_semver_parse(ctx, at, at_len, 0, NULL)) {
            ver = at;
        }
    }

    /* name */
    if ((name_len != strlen(name)) || strncmp(filename, name, name_len)) {
        LOGWRN(ctx, "File name \"%s\" does not match module name \"%s\".", filename, name);
    }

    /* revision */
    if (rev && (!revision || strncmp(revision, rev, at_len))) {
        LOGWRN(ctx, "File name \"%s\" does not match module revision \"%s\".", filename, revision ? revision : "<none>");
    }

    /* version */
    if (ver && (!semver || strncmp(semver, ver, at_len))) {
        LOGWRN(ctx, "File name \"%s\" does not match module version \"%s\".", filename, semver ? semver : "<none>");
    }
}

/**
 * @brief Check recommended-min-date and recommended-min-version extensions, if present.
 *
 * Import revision-date is checked when loading the (sub)module.
 *
 * @param[in] pmod Module whose imports to check.
 */
static void
lysp_check_import_exts(const struct lysp_module *pmod)
{
    LYA_COUNT_T u, v;
    const struct lysp_import *imp;
    const struct lysp_ext_instance *min_date_ext = NULL, *min_ver_ext = NULL;
    const struct lys_ext_instance_semver *semver;
    const char *mod_name, *name, *semver_str;

    LYA_FOR(pmod->imports, u) {
        imp = &pmod->imports[u];
        assert(imp->module);

        if (!imp->module->revision) {
            /* nothing to check, has no revision nor version */
            continue;
        }

        min_date_ext = NULL;
        min_ver_ext = NULL;
        LYA_FOR(imp->exts, v) {
            lysp_nodeid_find_module(pmod->mod->ctx, imp->exts[v].name, imp->exts[v].format, imp->exts[v].prefix_data,
                    &mod_name, &name);

            if (!strcmp(mod_name, "ietf-yang-revisions") && !strcmp(name, "recommended-min-date")) {
                min_date_ext = &imp->exts[v];
            } else if (!strcmp(mod_name, "ietf-yang-semver") && !strcmp(name, "recommended-min-version")) {
                min_ver_ext = &imp->exts[v];
                assert(min_ver_ext->parsed);
            }
        }

        if (min_date_ext && (strcmp(min_date_ext->argument, imp->module->revision) > 0)) {
            LOGWRN(pmod->mod->ctx, "Module \"%s@%s\" import recommended minimal date %s.", imp->module->name,
                    imp->module->revision, min_date_ext->argument);
        }

        if (min_ver_ext) {
            semver = lys_semver_get(imp->module, &semver_str);
            if (!semver) {
                LOGWRN(pmod->mod->ctx, "Module \"%s@%s\" without version but import recommended minimal version is %s.",
                        imp->module->name, imp->module->revision, min_ver_ext->argument);
            } else if (lys_semver_cmp(min_ver_ext->parsed, semver) > 0) {
                LOGWRN(pmod->mod->ctx, "Module \"%s@%s\" with version %s but import recommended minimal version is %s.",
                        imp->module->name, imp->module->revision, semver_str, min_ver_ext->argument);
            }
        }
    }
}

/**
 * @brief Check created (sub)module that it matches the expected module.
 *
 * @param[in] ctx Context to use.
 * @param[in] mod Parsed module.
 * @param[in] submod Parsed submodule.
 * @param[in] mod_data Expected module data.
 * @return LY_SUCCESS on success;
 * @return LY_EEXIST if the same module already exists;
 * @return LY_ERR on error.
 */
static LY_ERR
lysp_load_module_data_check(const struct ly_ctx *ctx, struct lysp_module *mod, struct lysp_submodule *submod,
        const struct lysp_load_module_data *mod_data)
{
    const char *name, *revision;
    uint8_t latest_revision;

    name = mod ? mod->mod->name : submod->name;
    revision = mod ? lysp_last_revision(NULL, mod->revs) : lysp_last_revision(NULL, submod->revs);
    latest_revision = mod ? mod->mod->latest_revision : submod->latest_revision;

    if (mod_data->name) {
        /* check name of the parsed module */
        if (strcmp(mod_data->name, name)) {
            LOGERR(ctx, LY_EINVAL, "Unexpected module \"%s\" parsed instead of \"%s\".", name, mod_data->name);
            return LY_EINVAL;
        }
    }

    if (mod_data->revision) {
        /* check revision of the parsed module */
        if (!revision || strcmp(mod_data->revision, revision)) {
            LOGERR(ctx, LY_EINVAL, "Module \"%s\" parsed with the wrong revision (\"%s\" instead \"%s\").", name,
                    revision ? revision : "none", mod_data->revision);
            return LY_EINVAL;
        }
    } else if (!latest_revision) {
        /* do not log, we just need to drop the schema and use the latest revision from the context */
        return LY_EEXIST;
    }

    if (submod) {
        assert(mod_data->submoduleof);

        /* check that the submodule belongs-to our module */
        if (strcmp(mod_data->submoduleof, submod->mod->name)) {
            LOGVAL(ctx, NULL, LYVE_REFERENCE, "Included \"%s\" submodule from \"%s\" belongs-to a different module \"%s\".",
                    submod->name, mod_data->submoduleof, submod->mod->name);
            return LY_EVALID;
        }
        /* check circular dependency */
        if (submod->parsing) {
            LOGVAL(ctx, NULL, LYVE_REFERENCE, "A circular dependency (include) for module \"%s\".", submod->name);
            return LY_EVALID;
        }
    }

    return LY_SUCCESS;
}

LY_ERR
lys_parse_submodule(struct ly_ctx *ctx, struct ly_in *in, LYS_INFORMAT format, struct lysp_ctx *main_ctx,
        const struct lysp_load_module_data *mod_data, ly_bool in_searchdirs, struct ly_set *new_mods,
        struct lysp_submodule **submodule)
{
    LY_ERR rc = LY_SUCCESS, r;
    struct lysp_submodule *submod = NULL, *latest_sp;
    struct lysp_yang_ctx *yangctx = NULL;
    struct lysp_yin_ctx *yinctx = NULL;
    struct lysp_ctx *pctx = NULL;
    const char *last_revision, *last_revision2, *semver;

    LY_CHECK_ARG_RET(ctx, ctx, in, LY_EINVAL);

    *submodule = NULL;

    switch (format) {
    case LYS_IN_YIN:
        rc = yin_parse_submodule(&yinctx, ctx, main_ctx, in, &submod);
        pctx = (struct lysp_ctx *)yinctx;
        break;
    case LYS_IN_YANG:
        rc = yang_parse_submodule(&yangctx, ctx, main_ctx, in, &submod);
        pctx = (struct lysp_ctx *)yangctx;
        break;
    default:
        LOGERR(ctx, LY_EINVAL, "Invalid schema input format.");
        rc = LY_EINVAL;
        break;
    }
    LY_CHECK_GOTO(rc, cleanup);
    assert(submod);

    /* check the revisions are ordered */
    last_revision = lysp_last_revision((struct lysp_module *)submod, submod->revs);

    /* decide the latest revision */
    latest_sp = (struct lysp_submodule *)ly_ctx_get_submodule2_latest(submod->mod, submod->name);
    if (latest_sp) {
        if (last_revision) {
            last_revision2 = lysp_last_revision(NULL, latest_sp->revs);
            if (!last_revision2) {
                /* latest has no revision, so mod is anyway newer */
                submod->latest_revision = latest_sp->latest_revision;
                /* the latest_sp is zeroed later when the new module is being inserted into the context */
            } else if (strcmp(last_revision, last_revision2) > 0) {
                submod->latest_revision = latest_sp->latest_revision;
                /* the latest_sp is zeroed later when the new module is being inserted into the context */
            } else {
                latest_sp = NULL;
            }
        } else {
            latest_sp = NULL;
        }
    } else {
        /* if found in searchdirs and looking for the latest revision, it is the latest revision available,
         * otherwise the only such submodule in the context */
        submod->latest_revision = (in_searchdirs && !mod_data->revision) ? 2 : 1;
    }

    /* check the parsed submodule is as expected */
    r = lysp_load_module_data_check(ctx, NULL, submod, mod_data);
    if (r == LY_EEXIST) {
        /* not an error, the submodule already exists so free this one */
        ly_set_erase(&pctx->tpdfs_nodes, NULL);
        ly_set_erase(&pctx->grps_nodes, NULL);
        ly_set_erase(&pctx->ext_inst, NULL);
        lysp_module_free(ctx, (struct lysp_module *)submod);
        submod = NULL;
        goto cleanup;
    } else if (r) {
        rc = r;
        goto cleanup;
    }

    if (latest_sp) {
        latest_sp->latest_revision = 0;
    }

    /* store path */
    LY_CHECK_GOTO(rc = lys_parser_fill_filepath(ctx, in, &submod->filepath), cleanup);

    /* resolve imports and includes */
    LY_CHECK_GOTO(rc = lysp_resolve_import_include(pctx, (struct lysp_module *)submod, new_mods), cleanup);

    /* resolve extension plugins and parse extension instances */
    lysp_resolve_extension_plugins((struct lysp_module *)submod);
    LY_CHECK_GOTO(rc = lysp_resolve_ext_instance_records(pctx), cleanup);

    /* now check all the imports */
    lysp_check_import_exts((struct lysp_module *)submod);

    /* check path */
    if (submod->filepath) {
        lysp_semver_get((struct lysp_module *)submod, &semver);
        ly_check_module_filename(ctx, submod->name, last_revision, semver, submod->filepath);
    }

cleanup:
    if (rc) {
        LOGERR(ctx, rc, "Parsing submodule \"%s\" failed.", mod_data->name);
        if (pctx) {
            ly_set_erase(&pctx->tpdfs_nodes, NULL);
            ly_set_erase(&pctx->grps_nodes, NULL);
            ly_set_erase(&pctx->ext_inst, NULL);
        }
        lysp_module_free(ctx, (struct lysp_module *)submod);
    } else if (submod) {
        *submodule = submod;

        /* merge submod unres into main_ctx unres */
        ly_set_merge(&pctx->main_ctx->tpdfs_nodes, &pctx->tpdfs_nodes, 1, NULL);
        ly_set_erase(&pctx->tpdfs_nodes, NULL);
        ly_set_merge(&pctx->main_ctx->grps_nodes, &pctx->grps_nodes, 1, NULL);
        ly_set_erase(&pctx->grps_nodes, NULL);
        /* ext_insts already parsed */
        ly_set_erase(&pctx->ext_inst, NULL);
    }

    if (format == LYS_IN_YANG) {
        lysp_yang_ctx_free(yangctx);
    } else {
        lysp_yin_ctx_free(yinctx);
    }
    return rc;
}

/**
 * @brief Add ietf-netconf metadata to the parsed module. Operation, filter, and select are added.
 *
 * @param[in] pctx Parse context.
 * @param[in] mod Parsed module to add to.
 * @return LY_SUCCESS on success.
 * @return LY_ERR on error.
 */
static LY_ERR
lysp_add_internal_ietf_netconf(struct lysp_ctx *pctx, struct lysp_module *mod)
{
    struct lysp_ext_instance *extp, *prev_exts = mod->exts;
    struct lysp_stmt *stmt;
    struct lysp_node_leaf *leaf;
    struct lysp_node_container *cont;
    struct lysp_type_enum *enm;
    struct lysp_import *imp;
    uint32_t idx;

    /*
     * 1) edit-config's operation
     */
    LYA_ADD_ITEM(mod->exts, extp, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_ERR_RET(!extp, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "md_:annotation", 0, &extp->name));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "operation", 0, &extp->argument));
    extp->format = LY_VALUE_SCHEMA;
    extp->prefix_data = mod;
    extp->parent = mod;
    extp->parent_stmt = LY_STMT_MODULE;
    extp->flags = LYS_INTERNAL;

    extp->child = stmt = calloc(1, sizeof *extp->child);
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "type", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enumeration", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_TYPE;

    stmt->child = calloc(1, sizeof *stmt->child);
    stmt = stmt->child;
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enum", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "merge", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_ENUM;

    stmt->next = calloc(1, sizeof *stmt->child);
    stmt = stmt->next;
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enum", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "replace", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_ENUM;

    stmt->next = calloc(1, sizeof *stmt->child);
    stmt = stmt->next;
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enum", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "create", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_ENUM;

    stmt->next = calloc(1, sizeof *stmt->child);
    stmt = stmt->next;
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enum", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "delete", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_ENUM;

    stmt->next = calloc(1, sizeof *stmt->child);
    stmt = stmt->next;
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enum", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "remove", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_ENUM;

    /*
     * 2) filter's type
     */
    LYA_ADD_ITEM(mod->exts, extp, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_ERR_RET(!extp, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "md_:annotation", 0, &extp->name));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "type", 0, &extp->argument));
    extp->format = LY_VALUE_SCHEMA;
    extp->prefix_data = mod;
    extp->parent = mod;
    extp->parent_stmt = LY_STMT_MODULE;
    extp->flags = LYS_INTERNAL;

    extp->child = stmt = calloc(1, sizeof *extp->child);
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "type", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enumeration", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_TYPE;

    stmt->child = calloc(1, sizeof *stmt->child);
    stmt = stmt->child;
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enum", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "subtree", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_ENUM;

    stmt->next = calloc(1, sizeof *stmt->child);
    stmt = stmt->next;
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enum", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "xpath", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_ENUM;

    /* if-feature for enum allowed only for YANG 1.1 modules */
    if (mod->version >= LYS_VERSION_1_1) {
        stmt->child = calloc(1, sizeof *stmt->child);
        stmt = stmt->child;
        LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
        LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "if-feature", 0, &stmt->stmt));
        LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "xpath", 0, &stmt->arg));
        stmt->format = LY_VALUE_SCHEMA;
        stmt->prefix_data = mod;
        stmt->kw = LY_STMT_IF_FEATURE;
    }

    /*
     * 3) filter's select
     */
    LYA_ADD_ITEM(mod->exts, extp, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_ERR_RET(!extp, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "md_:annotation", 0, &extp->name));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "select", 0, &extp->argument));
    extp->format = LY_VALUE_SCHEMA;
    extp->prefix_data = mod;
    extp->parent = mod;
    extp->parent_stmt = LY_STMT_MODULE;
    extp->flags = LYS_INTERNAL;

    extp->child = stmt = calloc(1, sizeof *extp->child);
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "type", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "yang_:xpath1.0", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_TYPE;

    if (!prev_exts) {
        /* first extension instances */
        assert(pctx->main_ctx == pctx);
        LY_CHECK_RET(ly_set_add(&pctx->ext_inst, mod->exts, 1, NULL));
    } else {
        /* replace previously stored extension instances */
        if (!ly_set_contains(&pctx->ext_inst, prev_exts, &idx)) {
            LOGINT_RET(mod->mod->ctx);
        }
        pctx->ext_inst.objs[idx] = mod->exts;
    }

    /*
     * 4) rpc-error
     */
    cont = lysp_parser_node_new(sizeof *cont, &mod->data);
    LY_CHECK_ERR_RET(!cont, LOGMEM(mod->mod->ctx), LY_EMEM);
    cont->nodetype = LYS_CONTAINER;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "rpc-error", 0, &cont->name));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "presence", 0, &cont->presence));
    cont->flags = LYS_INTERNAL;

    leaf = lysp_parser_node_new(sizeof *leaf, &cont->child);
    LY_CHECK_ERR_RET(!leaf, LOGMEM(mod->mod->ctx), LY_EMEM);
    leaf->nodetype = LYS_LEAF;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "error-type", 0, &leaf->name));
    leaf->flags = LYS_INTERNAL;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enumeration", 0, &leaf->type.name));
    leaf->type.pmod = mod;
    leaf->type.flags = LYS_SET_ENUM;
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "transport", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "rpc", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "protocol", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "application", 0, &enm->name));

    leaf = lysp_parser_node_new(sizeof *leaf, &cont->child);
    LY_CHECK_ERR_RET(!leaf, LOGMEM(mod->mod->ctx), LY_EMEM);
    leaf->nodetype = LYS_LEAF;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "error-tag", 0, &leaf->name));
    leaf->flags = LYS_INTERNAL;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enumeration", 0, &leaf->type.name));
    leaf->type.pmod = mod;
    leaf->type.flags = LYS_SET_ENUM;
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "in-use", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "invalid-value", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "too-big", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "missing-attribute", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "bad-attribute", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "unknown-attribute", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "missing-element", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "bad-element", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "unknown-element", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "unknown-namespace", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "access-denied", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "lock-denied", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "resource-denied", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "rollback-failed", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "data-exists", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "data-missing", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "operation-not-supported", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "operation-failed", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "partial-operation", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "malformed-message", 0, &enm->name));

    leaf = lysp_parser_node_new(sizeof *leaf, &cont->child);
    LY_CHECK_ERR_RET(!leaf, LOGMEM(mod->mod->ctx), LY_EMEM);
    leaf->nodetype = LYS_LEAF;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "error-severity", 0, &leaf->name));
    leaf->flags = LYS_INTERNAL;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "enumeration", 0, &leaf->type.name));
    leaf->type.pmod = mod;
    leaf->type.flags = LYS_SET_ENUM;
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "error", 0, &enm->name));
    LYA_ADD_ITEM(leaf->type.enums, enm, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "warning", 0, &enm->name));

    leaf = lysp_parser_node_new(sizeof *leaf, &cont->child);
    LY_CHECK_ERR_RET(!leaf, LOGMEM(mod->mod->ctx), LY_EMEM);
    leaf->nodetype = LYS_LEAF;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "error-app-tag", 0, &leaf->name));
    leaf->flags = LYS_INTERNAL;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "string", 0, &leaf->type.name));
    leaf->type.pmod = mod;

    leaf = lysp_parser_node_new(sizeof *leaf, &cont->child);
    LY_CHECK_ERR_RET(!leaf, LOGMEM(mod->mod->ctx), LY_EMEM);
    leaf->nodetype = LYS_LEAF;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "error-path", 0, &leaf->name));
    leaf->flags = LYS_INTERNAL;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "yang_:xpath1.0", 0, &leaf->type.name));
    leaf->type.pmod = mod;

    /* the rest are opaque nodes, error-message (because of 'xml:lang' attribute) and error-info (because can be any nodes) */

    /* create new imports for the used prefixes */
    LYA_ADD_ITEM(mod->imports, imp, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "ietf-yang-metadata", 0, &imp->name));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "md_", 0, &imp->prefix));
    imp->flags = LYS_INTERNAL;

    LYA_ADD_ITEM(mod->imports, imp, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "ietf-yang-types", 0, &imp->name));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "yang_", 0, &imp->prefix));
    imp->flags = LYS_INTERNAL;

    return LY_SUCCESS;
}

/**
 * @brief Add ietf-netconf-with-defaults "default" metadata to the parsed module.
 *
 * @param[in] pctx Parse context.
 * @param[in] mod Parsed module to add to.
 * @return LY_SUCCESS on success.
 * @return LY_ERR on error.
 */
static LY_ERR
lysp_add_internal_ietf_netconf_with_defaults(struct lysp_ctx *pctx, struct lysp_module *mod)
{
    struct lysp_ext_instance *extp, *prev_exts = mod->exts;
    struct lysp_stmt *stmt;
    struct lysp_import *imp;
    uint32_t idx;

    /* add new extension instance */
    LYA_ADD_ITEM(mod->exts, extp, LOGMEM(mod->mod->ctx); return LY_EMEM);

    /* fill in the extension instance fields */
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "md_:annotation", 0, &extp->name));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "default", 0, &extp->argument));
    extp->format = LY_VALUE_SCHEMA;
    extp->prefix_data = mod;
    extp->parent = mod;
    extp->parent_stmt = LY_STMT_MODULE;
    extp->flags = LYS_INTERNAL;

    extp->child = stmt = calloc(1, sizeof *extp->child);
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "type", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "boolean", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_TYPE;

    if (!prev_exts) {
        /* first extension instances */
        assert(pctx->main_ctx == pctx);
        LY_CHECK_RET(ly_set_add(&pctx->ext_inst, mod->exts, 1, NULL));
    } else {
        /* replace previously stored extension instances */
        if (!ly_set_contains(&pctx->ext_inst, prev_exts, &idx)) {
            LOGINT_RET(mod->mod->ctx);
        }
        pctx->ext_inst.objs[idx] = mod->exts;
    }

    /* create new import for the used prefix */
    LYA_ADD_ITEM(mod->imports, imp, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "ietf-yang-metadata", 0, &imp->name));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "md_", 0, &imp->prefix));
    imp->flags = LYS_INTERNAL;

    return LY_SUCCESS;
}

/**
 * @brief Add lyds_tree metadata and date-and-time compiled leaves to the 'yang' internal module.
 *
 * The 'lyds_tree' is a data type containing a reference to a binary search tree
 * by which the data nodes are ordered.
 *
 * @param[in] pctx Parse context.
 * @param[in] mod Parsed module to add to.
 * @return LY_SUCCESS on success.
 * @return LY_ERR on error.
 */
static LY_ERR
lysp_add_internal_yang(struct lysp_ctx *pctx, struct lysp_module *mod)
{
    struct lysp_ext_instance *extp, *prev_exts = mod->exts;
    struct lysp_stmt *stmt;
    struct lysp_tpdf *tpdf;
    struct lysp_node_leaf *leaf;
    struct lysp_import *imp;
    uint32_t idx;

    /* add new typedef */
    LYA_ADD_ITEM(mod->typedefs, tpdf, LOGMEM(PARSER_CTX(pctx)); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(PARSER_CTX(pctx), "lyds_tree", 0, &tpdf->name));
    LY_CHECK_RET(lysdict_insert(PARSER_CTX(pctx), "uint64", 0, &tpdf->type.name));
    tpdf->type.pmod = mod;
    tpdf->flags = LYS_INTERNAL;

    /* add new extension instance */
    LYA_ADD_ITEM(mod->exts, extp, LOGMEM(PARSER_CTX(pctx)); return LY_EMEM);

    /* fill in the extension instance fields */
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "md:annotation", 0, &extp->name));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "lyds_tree", 0, &extp->argument));
    extp->format = LY_VALUE_SCHEMA;
    extp->prefix_data = mod;
    extp->parent = mod;
    extp->parent_stmt = LY_STMT_MODULE;
    extp->flags = LYS_INTERNAL;

    /* prepare for metadata plugin */
    extp->child = stmt = calloc(1, sizeof *extp->child);
    LY_CHECK_ERR_RET(!stmt, LOGMEM(mod->mod->ctx), LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "type", 0, &stmt->stmt));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "lyds_tree", 0, &stmt->arg));
    stmt->format = LY_VALUE_SCHEMA;
    stmt->prefix_data = mod;
    stmt->kw = LY_STMT_TYPE;

    if (!prev_exts) {
        /* first extension instances */
        assert(pctx->main_ctx == pctx);
        LY_CHECK_RET(ly_set_add(&pctx->ext_inst, mod->exts, 1, NULL));
    } else {
        /* replace previously stored extension instances */
        if (!ly_set_contains(&pctx->ext_inst, prev_exts, &idx)) {
            LOGINT_RET(mod->mod->ctx);
        }
        pctx->ext_inst.objs[idx] = mod->exts;
    }

    /* add a date-and-time leaf so that such values can be validated (there is a compiled type) */
    leaf = lysp_parser_node_new(sizeof *leaf, &mod->data);
    LY_CHECK_ERR_RET(!leaf, LOGMEM(mod->mod->ctx), LY_EMEM);
    leaf->nodetype = LYS_LEAF;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "date-and-time", 0, &leaf->name));
    leaf->flags = LYS_INTERNAL;
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "yang_:date-and-time", 0, &leaf->type.name));
    leaf->type.pmod = mod;

    /* create new imports for the used prefixes */
    LYA_ADD_ITEM(mod->imports, imp, LOGMEM(mod->mod->ctx); return LY_EMEM);
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "ietf-yang-types", 0, &imp->name));
    LY_CHECK_RET(lysdict_insert(mod->mod->ctx, "yang_", 0, &imp->prefix));
    imp->flags = LYS_INTERNAL;

    return LY_SUCCESS;
}

/**
 * @brief Compile (copy) all submodules of a parsed module.
 *
 * @param[in] mod Module with the parsed and compiled module.
 * @return LY_ERR value.
 */
static LY_ERR
lys_compile_submodules(struct lys_module *mod)
{
    LY_ERR rc = LY_SUCCESS;
    LYA_COUNT_T u;
    const struct lysp_submodule *submodp;
    struct lysc_submodule *submod;
    const char *last_revision;

    LYA_FOR(mod->parsed->includes, u) {
        submodp = mod->parsed->includes[u].submodule;

        LYA_ADD_ITEM(mod->submodules, submod, LOGMEM(mod->ctx); rc = LY_EMEM; goto cleanup);
        DUP_STRING_GOTO(mod->ctx, submodp->name, submod->name, rc, cleanup);
        last_revision = lysp_last_revision(NULL, submodp->revs);
        if (last_revision) {
            LY_CHECK_GOTO(rc = lysdict_insert(mod->ctx, last_revision, 0, &submod->revision), cleanup);
        }
        DUP_STRING_GOTO(mod->ctx, submodp->filepath, submod->filepath, rc, cleanup);
    }

cleanup:
    return rc;
}

LY_ERR
lys_parse_in(struct ly_ctx *ctx, struct ly_in *in, LYS_INFORMAT format, const struct lysp_load_module_data *mod_data,
        struct ly_set *new_mods, struct lys_module **module)
{
    LY_ERR rc = LY_SUCCESS, r;
    struct lys_module *mod = NULL, *latest, *mod_dup = NULL;
    struct lysp_yang_ctx *yangctx = NULL;
    struct lysp_yin_ctx *yinctx = NULL;
    struct lysp_ctx *pctx = NULL;
    ly_bool mod_created = 0, mod_exists = 0;
    const char *last_revision, *semver;

    assert(ctx && in && new_mods);

    if (module) {
        *module = NULL;
    }

    mod = calloc(1, sizeof *mod);
    LY_CHECK_ERR_RET(!mod, LOGMEM(ctx), LY_EMEM);
    mod->ctx = ctx;

    /* parse */
    switch (format) {
    case LYS_IN_YIN:
        rc = yin_parse_module(&yinctx, in, mod);
        pctx = (struct lysp_ctx *)yinctx;
        break;
    case LYS_IN_YANG:
        rc = yang_parse_module(&yangctx, in, mod);
        pctx = (struct lysp_ctx *)yangctx;
        break;
    default:
        LOGERR(ctx, LY_EINVAL, "Invalid schema input format.");
        rc = LY_EINVAL;
        break;
    }
    LY_CHECK_GOTO(rc, cleanup);

    /* check the revisions are ordered */
    last_revision = lysp_last_revision(mod->parsed, mod->parsed->revs);
    if (last_revision) {
        LY_CHECK_GOTO(rc = lysdict_insert(ctx, last_revision, 0, &mod->revision), cleanup);
    }

    /* set YANG version */
    switch (mod->parsed->version) {
    case LYS_VERSION_UNDEF:
    case LYS_VERSION_1_0:
        mod->version = LYS_VERSION_1_0;
        break;
    case LYS_VERSION_1_1:
        mod->version = LYS_VERSION_1_1;
        break;
    }

    /* decide the latest revision */
    latest = ly_ctx_get_module_latest(ctx, mod->name);
    if (latest) {
        if (mod->revision) {
            if (!latest->revision) {
                /* latest has no revision, so mod is anyway newer */
                mod->latest_revision = latest->latest_revision & (LYS_MOD_LATEST_REV | LYS_MOD_LATEST_SEARCHDIRS);
                /* the latest is zeroed later when the new module is being inserted into the context */
            } else if (strcmp(mod->revision, latest->revision) > 0) {
                mod->latest_revision = latest->latest_revision & (LYS_MOD_LATEST_REV | LYS_MOD_LATEST_SEARCHDIRS);
                /* the latest is zeroed later when the new module is being inserted into the context */
            } else {
                latest = NULL;
            }
        } else {
            latest = NULL;
        }
    } else {
        mod->latest_revision = LYS_MOD_LATEST_REV;
    }

    if (mod_data) {
        /* check the parsed module it is as expected */
        r = lysp_load_module_data_check(ctx, mod->parsed, NULL, mod_data);
        if (r == LY_EEXIST) {
            mod_exists = 1;
            goto cleanup;
        } else if (r) {
            rc = r;
            goto cleanup;
        }
    }

    /* check whether it is not already in the context in the same revision */
    mod_dup = ly_ctx_get_module(ctx, mod->name, mod->revision);
    if (mod_dup) {
        /* nothing to do */
        LOGVRB("Module \"%s@%s\" is already present in the context.", mod_dup->name,
                mod_dup->revision ? mod_dup->revision : "<none>");
        goto cleanup;
    }

    /* check whether there is not a namespace collision */
    mod_dup = ly_ctx_get_module_latest_ns(ctx, mod->ns);
    if (mod_dup && (mod_dup->revision == mod->revision)) {
        LOGERR(ctx, LY_EINVAL, "Two different modules (\"%s\" and \"%s\") have the same namespace \"%s\".",
                mod_dup->name, mod->name, mod->ns);
        rc = LY_EINVAL;
        goto cleanup;
    }

    /* store path */
    LY_CHECK_GOTO(rc = lys_parser_fill_filepath(ctx, in, &mod->filepath), cleanup);

    if (latest) {
        latest->latest_revision &= ~(LYS_MOD_LATEST_REV | LYS_MOD_LATEST_SEARCHDIRS);
    }

    /* add internal data in case specific modules were parsed */
    if (!strcmp(mod->name, "ietf-netconf")) {
        LY_CHECK_GOTO(rc = lysp_add_internal_ietf_netconf(pctx, mod->parsed), cleanup);
    } else if (!strcmp(mod->name, "ietf-netconf-with-defaults")) {
        LY_CHECK_GOTO(rc = lysp_add_internal_ietf_netconf_with_defaults(pctx, mod->parsed), cleanup);
    } else if (!strcmp(mod->name, "yang")) {
        LY_CHECK_GOTO(rc = lysp_add_internal_yang(pctx, mod->parsed), cleanup);
    }

    /* add the module into newly created module set, will also be freed from there on any error */
    LY_CHECK_GOTO(rc = ly_set_add(new_mods, mod, 1, NULL), cleanup);
    mod_created = 1;

    /* add into context */
    rc = ly_set_add(&ctx->modules, mod, 1, NULL);
    LY_CHECK_GOTO(rc, cleanup);

    /* resolve imports and includes */
    LY_CHECK_GOTO(rc = lysp_resolve_import_include(pctx, mod->parsed, new_mods), cleanup);

    /* resolve extension plugins and parse extension instances */
    lysp_resolve_extension_plugins(mod->parsed);
    LY_CHECK_GOTO(rc = lysp_resolve_ext_instance_records(pctx), cleanup);

    /* now check all the imports */
    lysp_check_import_exts(mod->parsed);

    /* check path */
    if (mod->filepath) {
        lys_semver_get(mod, &semver);
        ly_check_module_filename(ctx, mod->name, last_revision, semver, mod->filepath);
    }

    /* check name collisions */
    LY_CHECK_GOTO(rc = lysp_check_dup_typedefs(pctx, mod->parsed), cleanup);
    LY_CHECK_GOTO(rc = lysp_check_dup_groupings(pctx, mod->parsed), cleanup);
    LY_CHECK_GOTO(rc = lysp_check_dup_features(pctx, mod->parsed), cleanup);
    LY_CHECK_GOTO(rc = lysp_check_dup_identities(pctx, mod->parsed), cleanup);

    /* compile features, extensions, identities, and submodules */
    LY_CHECK_GOTO(rc = lys_compile_feature_iffeatures(mod->parsed), cleanup);
    LY_CHECK_GOTO(rc = lys_compile_extensions(mod), cleanup);
    LY_CHECK_GOTO(rc = lys_compile_identities(mod), cleanup);
    LY_CHECK_GOTO(rc = lys_compile_submodules(mod), cleanup);

cleanup:
    if (rc && mod && mod->name) {
        /* there are cases when path is not available for parsing error, so this additional
         * message tries to add information about the module where the error occurred */
        const struct ly_err_item *e = ly_err_last(ctx);

        if (e && (!e->schema_path || e->line)) {
            LOGERR(ctx, LY_EOTHER, "Parsing module \"%s\" failed.", mod->name);
        }
    }
    if (!mod_created) {
        lys_module_free(ctx, mod, 0);
        mod = mod_dup;
    }

    if (format == LYS_IN_YANG) {
        lysp_yang_ctx_free(yangctx);
    } else {
        lysp_yin_ctx_free(yinctx);
    }

    if (!rc && !mod_exists && module) {
        *module = mod;
    }
    return rc;
}

static LYS_INFORMAT
lys_parse_get_format(const struct ly_in *in, LYS_INFORMAT format)
{
    if (!format && (in->type == LY_IN_FILEPATH)) {
        /* unknown format - try to detect it from filename's suffix */
        const char *path = in->method.fpath.filepath;
        size_t len = strlen(path);

        /* ignore trailing whitespaces */
        for ( ; len > 0 && isspace(path[len - 1]); len--) {}

        if ((len >= LY_YANG_SUFFIX_LEN + 1) &&
                !strncmp(&path[len - LY_YANG_SUFFIX_LEN], LY_YANG_SUFFIX, LY_YANG_SUFFIX_LEN)) {
            format = LYS_IN_YANG;
        } else if ((len >= LY_YIN_SUFFIX_LEN + 1) &&
                !strncmp(&path[len - LY_YIN_SUFFIX_LEN], LY_YIN_SUFFIX, LY_YIN_SUFFIX_LEN)) {
            format = LYS_IN_YIN;
        } /* else still unknown */
    }

    return format;
}

LIBYANG_API_DEF LY_ERR
lys_parse(struct ly_ctx *ctx, struct ly_in *in, LYS_INFORMAT format, const char **features, struct lys_module **module)
{
    LY_ERR ret = LY_SUCCESS;
    struct lys_module *mod = NULL;

    if (module) {
        *module = NULL;
    }
    LY_CHECK_ARG_RET(NULL, ctx, !(ctx->opts & LY_CTX_INT_IMMUTABLE), in, LY_EINVAL);

    format = lys_parse_get_format(in, format);
    LY_CHECK_ARG_RET(ctx, format, LY_EINVAL);

    /* remember input position */
    in->func_start = in->current;

    /* parse */
    ret = lys_parse_in(ctx, in, format, NULL, &ctx->unres.creating, &mod);
    LY_CHECK_GOTO(ret, cleanup);

    /* implement */
    ret = _lys_set_implemented(mod, features, &ctx->unres);
    LY_CHECK_GOTO(ret, cleanup);

    if (!(ctx->opts & LY_CTX_EXPLICIT_COMPILE)) {
        /* create dep set for the module and mark all the modules that will be (re)compiled */
        LY_CHECK_GOTO(ret = lys_unres_dep_sets_create(ctx, &ctx->unres.dep_sets, &ctx->unres.compiling), cleanup);

        /* (re)compile the whole dep set (other dep sets will have no modules marked for compilation) */
        LY_CHECK_GOTO(ret = lys_compile_depset_all(ctx, &ctx->unres), cleanup);

        /* unres resolved */
        lys_unres_glob_erase(&ctx->unres);

        /* new context state */
        ly_ctx_new_change(ctx);
    }

cleanup:
    if (ret) {
        if (!(ctx->opts & LY_CTX_EXPLICIT_COMPILE)) {
            /* full revert */
            lys_unres_glob_revert(ctx, &ctx->unres);
            lys_unres_glob_erase(&ctx->unres);
        } else {
            /* revert only this module parsing (any side effects in the context will remain) */
            lys_unres_glob_revert_erase_mod(ctx, &ctx->unres, mod);
        }
    } else if (module) {
        *module = mod;
    }
    return ret;
}

LIBYANG_API_DEF LY_ERR
lys_parse_mem(struct ly_ctx *ctx, const char *data, LYS_INFORMAT format, struct lys_module **module)
{
    LY_ERR ret;
    struct ly_in *in = NULL;

    LY_CHECK_ARG_RET(ctx, ctx, !(ctx->opts & LY_CTX_INT_IMMUTABLE), data, format != LYS_IN_UNKNOWN, LY_EINVAL);

    LY_CHECK_ERR_RET(ret = ly_in_new_memory(data, &in), LOGERR(ctx, ret, "Unable to create input handler."), ret);

    ret = lys_parse(ctx, in, format, NULL, module);
    ly_in_free(in, 0);

    return ret;
}

LIBYANG_API_DEF LY_ERR
lys_parse_fd(struct ly_ctx *ctx, int fd, LYS_INFORMAT format, struct lys_module **module)
{
    LY_ERR ret;
    struct ly_in *in = NULL;

    LY_CHECK_ARG_RET(ctx, ctx, !(ctx->opts & LY_CTX_INT_IMMUTABLE), fd > -1, format != LYS_IN_UNKNOWN, LY_EINVAL);

    LY_CHECK_ERR_RET(ret = ly_in_new_fd(fd, &in), LOGERR(ctx, ret, "Unable to create input handler."), ret);

    ret = lys_parse(ctx, in, format, NULL, module);
    ly_in_free(in, 0);

    return ret;
}

LIBYANG_API_DEF LY_ERR
lys_parse_path(struct ly_ctx *ctx, const char *path, LYS_INFORMAT format, struct lys_module **module)
{
    LY_ERR ret;
    struct ly_in *in = NULL;

    LY_CHECK_ARG_RET(ctx, ctx, !(ctx->opts & LY_CTX_INT_IMMUTABLE), path, format != LYS_IN_UNKNOWN, LY_EINVAL);

    LY_CHECK_ERR_RET(ret = ly_in_new_filepath(path, 0, &in),
            LOGERR(ctx, ret, "Unable to create input handler for filepath %s.", path), ret);

    ret = lys_parse(ctx, in, format, NULL, module);
    ly_in_free(in, 0);

    return ret;
}

/**
 * @brief Check file type of a file.
 *
 * @param[in] file Dirent file to check.
 * @param[in] wd Working directory.
 * @param[in,out] dirs Set with searched directories to add to.
 * @param[in] implicit_cwd Whether implicit CWD is used.
 * @param[out] skip Whether to skip this file.
 * @return LY_ERR value.
 */
static LY_ERR
lys_search_localfile_file_type(const struct dirent *file, const char *wd, struct ly_set *dirs, ly_bool implicit_cwd,
        ly_bool *skip)
{
    LY_ERR rc = LY_SUCCESS;
    char *str = NULL;
    ly_bool is_dir = 0, is_reg = 0, need_stat = 1;
    struct stat st;

    *skip = 0;

#ifdef HAVE_DIRENT_D_TYPE
    if (file->d_type == DT_DIR) {
        /* dirent - dir */
        is_dir = 1;
        need_stat = 0;
    } else if (file->d_type == DT_REG) {
        /* dirent - file */
        is_reg = 1;
        need_stat = 0;
    } else if ((file->d_type != DT_UNKNOWN) && (file->d_type != DT_LNK)) {
        /* it is a known type, but not dir or regular file, so trust d_type and just skip it */
        need_stat = 0;
    }
#endif // HAVE_DIRENT_D_TYPE

    if (need_stat) {
        /* need to use stat to determine the file type */
        if (asprintf(&str, "%s/%s", wd, file->d_name) == -1) {
            LOGMEM(NULL);
            rc = LY_EMEM;
            goto cleanup;
        }
        if (stat(str, &st)) {
            LOGWRN(NULL, "Unable to get information about \"%s\" file in \"%s\" when searching for (sub)modules (%s)",
                    file->d_name, wd, strerror(errno));
        } else if (S_ISDIR(st.st_mode)) {
            /* stat - dir */
            is_dir = 1;
        } else if (S_ISREG(st.st_mode)) {
            /* stat - file */
            is_reg = 1;
        }
    }

    if (is_dir && (dirs->count || !implicit_cwd)) {
        /* we have another subdirectory in searchpath to explore,
         * subdirectories are not taken into account in current working dir (dirs->set.g[0]) */
        if (!str && (asprintf(&str, "%s/%s", wd, file->d_name) == -1)) {
            LOGMEM(NULL);
            rc = LY_EMEM;
            goto cleanup;
        }
        if ((rc = ly_set_add(dirs, str, 0, NULL))) {
            goto cleanup;
        }
        str = NULL;

        /* continue with the next item in current directory */
        *skip = 1;
    } else if (!is_reg) {
        /* not a regular file (note that we see the target of symlinks instead of symlinks */
        *skip = 1;
    }

cleanup:
    free(str);
    return rc;
}

/**
 * @brief Check that a found file matches (or is a better match than a previously found match).
 *
 * @param[in] ctx Context for version parsing.
 * @param[in] file_atsuffix Pointer to the file name at its @-suffix, if any.
 * @param[in] file_suffix_len Length of YANG/YIN file suffix.
 * @param[in] revision Optional searched revision.
 * @param[in] prev_match Previous match value.
 * @param[in,out] match_rev Previous match revision, if any. Is updated on a match.
 * @param[in,out] match_ver Previous match version, if any. Is updated on a match.
 * @return 2 if the file is the best possible match,
 * @return 1 if the file is a match or a better match than the previous match,
 * @return 0 if not a suitable file.
 */
static int
lys_search_localfile_is_match(const struct ly_ctx *ctx, const char *file_atsuffix, uint32_t file_suffix_len,
        const char *revision, int prev_match, char **match_rev, struct lys_ext_instance_semver **match_ver)
{
    int match = 0;
    ly_bool file_no_suffix = 0, file_has_rev;
    struct lys_ext_instance_semver *semver = NULL;

    if (file_atsuffix[0] != '@') {
        /* no @-suffix, accept only if nothing else found */
        if (!prev_match) {
            match = 1;
            file_no_suffix = 1;
        }
        goto cleanup;
    }

    /* check valid revision/version */
    if (!lys_check_date(NULL, file_atsuffix + 1, strlen(file_atsuffix) - file_suffix_len - 1, "revision")) {
        file_has_rev = 1;
    } else if (!lyplg_ext_semver_parse(ctx, file_atsuffix + 1, strlen(file_atsuffix) - file_suffix_len - 1, 0, &semver)) {
        file_has_rev = 0;
    } else {
        goto cleanup;
    }

    if (revision) {
        if (file_has_rev && !strncmp(revision, file_atsuffix + 1, LY_REV_SIZE - 1)) {
            /* exact revision found */
            match = 2;
        }

        /* ignore other revisions or versions */
        goto cleanup;
    }

    if (!prev_match || (!*match_ver && !*match_rev)) {
        /* no current match or has no @-suffix, always prefer specific revision/version */
        match = 1;
        goto cleanup;
    }

    /* now simply searching for the latest revision/highest version */
    assert(*match_rev || *match_ver);
    if (file_has_rev) {
        /* file with a revision, prefer versions to revisions */
        if (*match_rev && (strncmp(*match_rev, file_atsuffix + 1, LY_REV_SIZE - 1) < 0)) {
            /* newer revision */
            match = 1;
        }
    } else {
        /* file with a version */
        if (*match_rev) {
            /* prefer versions to revisions */
            match = 1;
        } else if (lys_semver_cmp(*match_ver, semver) < 0) {
            /* higher version */
            match = 1;
        }
    }

cleanup:
    if (match) {
        /* unset previous match */
        free(*match_rev);
        *match_rev = NULL;
        lyplg_ext_semver_free(*match_ver);
        *match_ver = NULL;

        if (file_no_suffix) {
            /* just unset */
        } else if (file_has_rev) {
            *match_rev = strdup(file_atsuffix + 1);
        } else {
            assert(semver);
            *match_ver = semver;
        }
    } else {
        lyplg_ext_semver_free(semver);
    }
    return match;
}

/**
 * @brief Collect all searched directories.
 *
 * @param[in] ctx Context for logging.
 * @param[in] searchpaths Explicit searchpaths to use.
 * @param[in,out] cwd Set if CWD should be used, is unset if found in @p searchdirs.
 * @param[out] dirs Collected directories.
 * @return LY_ERR value.
 */
static LY_ERR
lys_search_localfile_collect_dirs(const struct ly_ctx *ctx, const char * const *searchpaths, ly_bool *cwd,
        struct ly_set **dirs)
{
    LY_ERR rc = LY_SUCCESS;
    char *dir = NULL;
    uint32_t i;

    *dirs = NULL;

    LY_CHECK_RET(ly_set_new(dirs));

    if (*cwd) {
        /* add CWD, not searched recursively */
        dir = get_current_dir_name();
        if (!dir) {
            LOGMEM(ctx);
            rc = LY_EMEM;
            goto cleanup;
        }

        LY_CHECK_GOTO(rc = ly_set_add(*dirs, dir, 0, NULL), cleanup);
        dir = NULL;
    }

    if (searchpaths) {
        for (i = 0; searchpaths[i]; i++) {
            /* check for duplicities with the implicit current working directory */
            if (*cwd && !strcmp((*dirs)->objs[0], searchpaths[i])) {
                *cwd = 0;
                continue;
            }

            /* add new dir */
            dir = strdup(searchpaths[i]);
            if (!dir) {
                LOGMEM(ctx);
                rc = LY_EMEM;
                goto cleanup;
            }

            LY_CHECK_GOTO(rc = ly_set_add(*dirs, dir, 0, NULL), cleanup);
            dir = NULL;
        }
    }

cleanup:
    free(dir);
    if (rc) {
        ly_set_free(*dirs, free);
        *dirs = NULL;
    }

    return rc;
}

LY_ERR
_lys_search_localfile(const struct ly_ctx *ctx, const char * const *searchpaths, ly_bool cwd, const char *name,
        const char *revision, char **localfile, LYS_INFORMAT *format)
{
    LY_ERR rc = LY_SUCCESS;
    int match = 0, m;
    size_t name_len, flen;
    ly_bool skip;
    const char *wd;
    DIR *dir = NULL;
    struct dirent *file;
    char *match_name = NULL, *match_rev = NULL;
    LYS_INFORMAT format_aux, match_format = 0;
    struct lys_ext_instance_semver *match_ver = NULL;
    struct ly_set *dirs = NULL;
    uint32_t i;

    /* collect all the dirs to search */
    LY_CHECK_GOTO(rc = lys_search_localfile_collect_dirs(ctx, searchpaths, &cwd, &dirs), cleanup);

    /* start searching */
    name_len = strlen(name);
    for (i = 0; (i < dirs->count) && (match < 2); ++i) {
        wd = dirs->objs[i];
        LOGVRB("Searching for \"%s\" in \"%s\".", name, wd);

        if (dir) {
            closedir(dir);
        }
        dir = opendir(wd);
        if (!dir) {
            LOGWRN(NULL, "Unable to open directory \"%s\" for searching (sub)modules (%s).", wd, strerror(errno));
            continue;
        }

        /* search the directory */
        while ((file = readdir(dir))) {
            if (!strcmp(".", file->d_name) || !strcmp("..", file->d_name)) {
                /* skip . and .. */
                continue;
            }

            /* check file type */
            LY_CHECK_GOTO(rc = lys_search_localfile_file_type(file, wd, dirs, cwd, &skip), cleanup);
            if (skip) {
                continue;
            }

            /* here we know that the item is a file which can contain a module */
            if (strncmp(name, file->d_name, name_len) || ((file->d_name[name_len] != '.') && (file->d_name[name_len] != '@'))) {
                /* different filename than the module we search for */
                continue;
            }

            /* get type according to filename suffix */
            flen = strlen(file->d_name);
            if ((flen >= LY_YANG_SUFFIX_LEN + 1) && !strcmp(&file->d_name[flen - LY_YANG_SUFFIX_LEN], LY_YANG_SUFFIX)) {
                format_aux = LYS_IN_YANG;
            } else if ((flen >= LY_YIN_SUFFIX_LEN + 1) && !strcmp(&file->d_name[flen - LY_YIN_SUFFIX_LEN], LY_YIN_SUFFIX)) {
                format_aux = LYS_IN_YIN;
            } else {
                /* not supported suffix/file format */
                continue;
            }

            /* check the file @-suffix */
            m = lys_search_localfile_is_match(ctx, &file->d_name[name_len],
                    (format_aux == LYS_IN_YANG) ? LY_YANG_SUFFIX_LEN : LY_YIN_SUFFIX_LEN, revision, match, &match_rev,
                    &match_ver);

            if (m) {
                /* file matches, store */
                free(match_name);
                if (asprintf(&match_name, "%s/%s", wd, file->d_name) == -1) {
                    LOGMEM(ctx);
                    rc = LY_EMEM;
                    goto cleanup;
                }
                match_format = format_aux;
                match = m;
            }

            if (match == 2) {
                /* exact match found, finish */
                break;
            }
        }
    }

    /* return best found match */
    (*localfile) = match_name;
    match_name = NULL;
    if (format) {
        (*format) = match_format;
    }

cleanup:
    if (dir) {
        closedir(dir);
    }
    free(match_name);
    free(match_rev);
    lyplg_ext_semver_free(match_ver);
    ly_set_free(dirs, free);

    return rc;
}

LIBYANG_API_DEF LY_ERR
lys_search_localfile(const char * const *searchpaths, ly_bool cwd, const char *name, const char *revision,
        char **localfile, LYS_INFORMAT *format)
{
    LY_CHECK_ARG_RET(NULL, name, localfile, LY_EINVAL);

    return _lys_search_localfile(NULL, searchpaths, cwd, name, revision, localfile, format);
}

LIBYANG_API_DEF LY_ERR
lys_sid_gen(const struct lys_module *module, uint64_t entry_point, uint64_t size,
        LYS_SID_FILE_STATUS status, const char *description, struct lyd_node **sid_file)
{
    LY_CHECK_ARG_RET(NULL, module, sid_file, LY_EINVAL);
    LY_CHECK_ARG_RET(NULL, module->compiled, module->parsed, size, LY_EINVAL);
    LY_CHECK_ARG_RET(NULL, ly_ctx_get_module_implemented(module->ctx, "ietf-sid-file"), LY_ENOTFOUND);

    *sid_file = NULL;
    return sid_file_gen(module, entry_point, size, status, description, sid_file);
}

LIBYANG_API_DEF LY_ERR
lys_sid_update(const struct lys_module *module, const struct lyd_node *prev_sid_file,
        LYS_SID_FILE_STATUS status, const char *description, struct lyd_node **sid_file)
{
    LY_CHECK_ARG_RET(NULL, module, prev_sid_file, sid_file, LY_EINVAL);
    LY_CHECK_ARG_RET(NULL, module->compiled, module->parsed, LY_EINVAL);
    LY_CHECK_ARG_RET(NULL, ly_ctx_get_module_implemented(module->ctx, "ietf-sid-file"), LY_ENOTFOUND);

    *sid_file = NULL;
    return sid_file_update(module, prev_sid_file, status, description, sid_file);
}

LIBYANG_API_DEF LY_ERR
lys_sid_range_add(struct lyd_node *sid_file, uint64_t entry_point, uint64_t size)
{
    LY_CHECK_ARG_RET(NULL, sid_file, LY_EINVAL);
    LY_CHECK_ARG_RET(NULL, size, LY_EINVAL);

    return sid_range_append(sid_file, entry_point, size);
}
