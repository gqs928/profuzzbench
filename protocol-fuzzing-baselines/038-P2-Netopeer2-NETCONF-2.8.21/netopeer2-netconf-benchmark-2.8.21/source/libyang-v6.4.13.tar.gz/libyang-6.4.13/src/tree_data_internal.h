/**
 * @file tree_data_internal.h
 * @author Radek Krejci <rkrejci@cesnet.cz>
 * @author Michal Vasko <mvasko@cesnet.cz>
 * @brief internal functions for YANG schema trees.
 *
 * Copyright (c) 2015 - 2026 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */

#ifndef LY_TREE_DATA_INTERNAL_H_
#define LY_TREE_DATA_INTERNAL_H_

#include "compat.h"
#include "log.h"
#include "plugins_types.h"
#include "tree_data.h"

#include <stddef.h>

struct ly_path_predicate;
struct lyd_ctx;
struct lysc_module;

#define LY_XML_SUFFIX ".xml"
#define LY_XML_SUFFIX_LEN 4
#define LY_JSON_SUFFIX ".json"
#define LY_JSON_SUFFIX_LEN 5
#define LY_LYB_SUFFIX ".lyb"
#define LY_LYB_SUFFIX_LEN 4
#define LY_CBOR_SUFFIX ".cbor"
#define LY_CBOR_SUFFIX_LEN 5

/**
 * @brief Internal item structure for remembering "used" instances of duplicate node instances.
 */
struct lyd_dup_inst {
    struct ly_set *set;
    uint32_t used;
};

/**
 * @brief Update a found inst using a duplicate instance cache hash table. Needs to be called for every "used"
 * (that should not be considered next time) instance.
 *
 * @param[in,out] inst Found instance, is updated so that the same instance is not returned twice.
 * @param[in] dup_inst_ht Duplicate instance cache hash table.
 * @return LY_ERR value.
 */
LY_ERR lyd_dup_inst_next(struct lyd_node **inst, struct ly_ht **dup_inst_ht);

/**
 * @brief Free duplicate instance cache.
 *
 * @param[in] dup_inst Duplicate instance cache hash table to free.
 */
void lyd_dup_inst_free(struct ly_ht *dup_inst_ht);

/**
 * @brief Just like ::lys_getnext() but iterates over all data instances of the schema nodes.
 *
 * @param[in] last Last returned data node.
 * @param[in] sibling Data node sibling to search in.
 * @param[in,out] slast Schema last node, set to NULL for first call and do not change afterwards.
 * May not be set if the function is used only for any suitable node existence check (such as the existence
 * of any choice case data).
 * @param[in] parent Schema parent of the iterated children nodes.
 * @param[in] module Schema module of the iterated top-level nodes.
 * @return Next matching data node,
 * @return NULL if last data node was already returned.
 */
struct lyd_node *lys_getnext_data(const struct lyd_node *last, const struct lyd_node *sibling,
        const struct lysc_node **slast, const struct lysc_node *parent, const struct lysc_module *module);

/**
 * @brief Get address of a node's child pointer if any.
 *
 * @param[in] node Node to check.
 * @return Address of the node's child member,
 * @return NULL if there is no child pointer.
 */
struct lyd_node **lyd_node_child_p(struct lyd_node *node);

/**
 * @brief Update node pointer to point to the first data node of a module, leave unchanged if there is none.
 *
 * @param[in,out] node Node pointer, may be updated.
 * @param[in] mod Module whose data to search for.
 */
void lyd_first_module_sibling(struct lyd_node **node, const struct lys_module *mod);

/**
 * @brief Iterate over implemented modules for functions that accept specific modules or the whole context.
 *
 * @param[in] tree Data tree.
 * @param[in] module Selected module, NULL for all.
 * @param[in] ctx Context, NULL for selected modules.
 * @param[in,out] i Iterator, set to 0 on first call.
 * @param[out] first First sibling of the returned module.
 * @return Next module.
 * @return NULL if all modules were traversed.
 */
const struct lys_module *lyd_mod_next_module(struct lyd_node *tree, const struct lys_module *module,
        const struct ly_ctx *ctx, uint32_t *i, struct lyd_node **first);

/**
 * @brief Iterate over modules for functions that want to traverse all the top-level data.
 *
 * @param[in,out] next Pointer to the next module data, set to first top-level sibling on first call.
 * @param[out] first First sibling of the returned module.
 * @return Next module.
 * @return NULL if all modules were traversed.
 */
const struct lys_module *lyd_data_next_module(struct lyd_node **next, struct lyd_node **first);

/**
 * @brief Search in the given siblings (NOT recursively) for the first schema node data instance.
 * Uses hashes - should be used whenever possible for best performance.
 *
 * @param[in] siblings Siblings to search in including preceding and succeeding nodes.
 * @param[in] schema Target data node schema to find.
 * @param[out] match Can be NULL, otherwise the found data node.
 * @return LY_SUCCESS on success, @p match set.
 * @return LY_ENOTFOUND if not found, @p match set to NULL.
 * @return LY_ERR value if another error occurred.
 */
LY_ERR lyd_find_sibling_schema(const struct lyd_node *siblings, const struct lysc_node *schema, struct lyd_node **match);

/**
 * @brief Check whether a node to be deleted is the root node, move it if it is.
 *
 * @param[in] root Root sibling.
 * @param[in] to_del Node to be deleted.
 * @param[in] mod If set, it is expected @p tree should point to the first node of @p mod. Otherwise it will simply be
 * the first top-level sibling.
 */
void lyd_del_move_root(struct lyd_node **root, const struct lyd_node *to_del, const struct lys_module *mod);

/**
 * @brief After adding a default child, check the node and all of its parent NP containers and set their dflt flag.
 *
 * @param[in] parent Changed first parent to check.
 */
void lyd_np_cont_dflt_set(struct lyd_node *parent);

/**
 * @brief After adding a non-default child, remove the dflt flag from parent and other parent NP containers.
 *
 * @param[in] parent Changed first parent to update.
 */
void lyd_np_cont_dflt_del(struct lyd_node *parent);

/**
 * @brief Free stored prefix data.
 *
 * @param[in] format Format of the prefixes.
 * @param[in] prefix_data Format-specific data to free:
 *      LY_PREF_SCHEMA          - const struct lysp_module * (module used for resolving prefixes from imports)
 *      LY_PREF_SCHEMA_RESOLVED - struct lyd_value_prefix * (sized array of pairs: prefix - module)
 *      LY_PREF_XML             - const struct ly_set * (set with defined namespaces stored as ::lyxml_ns)
 *      LY_PREF_JSON            - NULL
 */
void ly_free_prefix_data(LY_VALUE_FORMAT format, void *prefix_data);

/**
 * @brief Duplicate prefix data.
 *
 * @param[in] ctx libyang context.
 * @param[in] format Format of the prefixes in the value.
 * @param[in] prefix_data Prefix data to duplicate.
 * @param[out] prefix_data_p Duplicated prefix data.
 * @return LY_ERR value.
 */
LY_ERR ly_dup_prefix_data(const struct ly_ctx *ctx, LY_VALUE_FORMAT format, const void *prefix_data, void **prefix_data_p);

/**
 * @brief Store used prefixes in a string.
 *
 * If @p prefix_data_p are non-NULL, they are treated as valid according to the @p format_p and new possible
 * prefixes are simply added. This way it is possible to store prefix data for several strings together.
 *
 * @param[in] ctx libyang context.
 * @param[in] value Value to be parsed.
 * @param[in] value_size Size of the @p value in bytes.
 * @param[in] format Format of the prefixes in the value.
 * @param[in] prefix_data Format-specific data for resolving any prefixes (see ::ly_resolve_prefix).
 * @param[in,out] format_p Resulting format of the prefixes.
 * @param[in,out] prefix_data_p Resulting prefix data for the value in format @p format_p.
 * @return LY_ERR value.
 */
LY_ERR ly_store_prefix_data(const struct ly_ctx *ctx, const void *value, uint32_t value_size, LY_VALUE_FORMAT format,
        const void *prefix_data, LY_VALUE_FORMAT *format_p, void **prefix_data_p);

/**
 * @brief Get string name of the format.
 *
 * @param[in] format Format whose name to get.
 * @return Format string name.
 */
const char *ly_format2str(LY_VALUE_FORMAT format);

/**
 * @brief Create a term (leaf/leaf-list) node from a string value.
 *
 * Hash is calculated and new node flag is set.
 *
 * @param[in] schema Schema node of the new data node.
 * @param[in] lnode Parent node for logging.
 * @param[in] value Value to be parsed.
 * @param[in] value_size_bits Size of @p value in bits, must be set correctly.
 * @param[in] is_utf8 Whether @p value is a valid UTF-8 string, if applicable.
 * @param[in] store_only Whether to perform storing operation only.
 * @param[in,out] dynamic Flag if @p value is dynamically allocated, is adjusted when @p value is consumed.
 * @param[in] format Input format of @p value.
 * @param[in] prefix_data Format-specific data for resolving any prefixes (see ::ly_resolve_prefix).
 * @param[in] hints [Value hints](@ref lydvalhints) from the parser regarding the value type.
 * @param[out] incomplete Whether the value needs to be resolved, optional.
 * @param[out] node Created node.
 * @return LY_SUCCESS on success.
 * @return LY_ERR value if an error occurred.
 */
LY_ERR lyd_create_term(const struct lysc_node *schema, const struct lyd_node *lnode, const void *value,
        uint64_t value_size_bits, ly_bool is_utf8, ly_bool store_only, ly_bool *dynamic, LY_VALUE_FORMAT format,
        void *prefix_data, uint32_t hints, ly_bool *incomplete, struct lyd_node **node);

/**
 * @brief Create an inner (container/list/RPC/action/notification) node.
 *
 * Hash is calculated and new node flag is set except
 * for list with keys, when the hash is not calculated!
 * Also, non-presence container has its default flag set.
 *
 * @param[in] schema Schema node of the new data node.
 * @param[out] node Created node.
 * @return LY_SUCCESS on success.
 * @return LY_ERR value if an error occurred.
 */
LY_ERR lyd_create_inner(const struct lysc_node *schema, struct lyd_node **node);

/**
 * @brief Create a list with all its keys (cannot be used for key-less list).
 *
 * Hash is calculated and new node flag is set.
 *
 * @param[in] schema Schema node of the new data node.
 * @param[in] predicates Compiled key list predicates.
 * @param[in] vars Array of defined variables to use in predicates, may be NULL.
 * @param[in] store_only Whether to perform storing operation only.
 * @param[out] node Created node.
 * @return LY_SUCCESS on success.
 * @return LY_ERR value if an error occurred.
 */
LY_ERR lyd_create_list(const struct lysc_node *schema, const struct ly_path_predicate *predicates,
        const struct lyxp_var *vars, ly_bool store_only, struct lyd_node **node);

/**
 * @brief Create a list with all its keys (cannot be used for key-less list).
 *
 * Hash is calculated and new node flag is set.
 *
 * @param[in] schema Schema node of the new data node.
 * @param[in] keys Key list predicates.
 * @param[in] keys_len Length of @p keys.
 * @param[in] store_only Whether to perform storing operation only.
 * @param[out] node Created node.
 * @return LY_SUCCESS on success.
 * @return LY_ERR value if an error occurred.
 */
LY_ERR lyd_create_list2(const struct lysc_node *schema, const char *keys, size_t keys_len, ly_bool store_only,
        struct lyd_node **node);

/**
 * @brief Create an anyxml/anydata node.
 *
 * @param[in] schema Schema node of the new data node.
 * @param[in] child Data tree value.
 * @param[in] value String value.
 * @param[in] hints Value hints.
 * @param[in] use_value Whether to use @p child / @p value or duplicate it.
 * @param[in] try_parse Set if parsing the string value into a data tree should be attempted.
 * @param[out] node Created node.
 * @return LY_SUCCESS on success.
 * @return LY_ERR value if an error occurred.
 */
LY_ERR lyd_create_any(const struct lysc_node *schema, const struct lyd_node *child, const char *value, uint32_t hints,
        ly_bool use_value, ly_bool try_parse, struct lyd_node **node);

/**
 * @brief Create an opaque node.
 *
 * @param[in] ctx libyang context.
 * @param[in] name Element name.
 * @param[in] name_len Length of @p name, must be set correctly.
 * @param[in] prefix Element prefix.
 * @param[in] pref_len Length of @p prefix, must be set correctly.
 * @param[in] module_key Mandatory key to reference module, can be namespace or name.
 * @param[in] module_key_len Length of @p module_key, must be set correctly.
 * @param[in] value String value to be parsed.
 * @param[in] value_len Length of @p value, must be set correctly.
 * @param[in,out] dynamic Flag if @p value is dynamically allocated, is adjusted when @p value is consumed.
 * @param[in] format Input format of @p value and @p ns.
 * @param[in] val_prefix_data Format-specific prefix data, param is spent (even in case the function fails):
 *      LY_PREF_SCHEMA          - const struct lysp_module * (module used for resolving prefixes from imports)
 *      LY_PREF_SCHEMA_RESOLVED - struct lyd_value_prefix * (sized array of pairs: prefix - module)
 *      LY_PREF_XML             - const struct ly_set * (set with defined namespaces stored as ::lyxml_ns)
 *      LY_PREF_JSON            - NULL
 * @param[in] hints [Hints](@ref lydhints) from the parser regarding the node/value type.
 * @param[out] node Created node.
 * @return LY_SUCCESS on success.
 * @return LY_ERR value if an error occurred.
 */
LY_ERR lyd_create_opaq(const struct ly_ctx *ctx, const char *name, uint32_t name_len, const char *prefix, uint32_t pref_len,
        const char *module_key, uint32_t module_key_len, const char *value, uint32_t value_len, ly_bool *dynamic,
        LY_VALUE_FORMAT format, void *val_prefix_data, uint32_t hints, struct lyd_node **node);

/**
 * @brief Change the value of a term (leaf or leaf-list) node.
 *
 * Node changed this way is always considered explicitly set, meaning its default flag
 * is always cleared.
 *
 * @param[in] term Term node to change.
 * @param[in] val New value to use.
 * @param[in] use_val Whether @p val can be used and spent or should only be duplicated.
 * @param[in] is_dflt Whether @p val is a default value or not.
 * @return LY_SUCCESS if value was changed,
 * @return LY_EEXIST if value was the same and only the default flag was cleared,
 * @return LY_ENOT if the values were equal and no change occured,
 * @return LY_ERR value on other errors.
 */
LY_ERR lyd_change_term_val(struct lyd_node *term, struct lyd_value *val, ly_bool use_val, ly_bool is_dflt);

/**
 * @brief Create a new node in the data tree based on a ly_path structure @p. All node types can be created.
 *
 * If @p path points to a list key, the key value from the predicate is used and @p value is ignored.
 * Also, if a leaf-list is being created and both a predicate is defined in @p path
 * and @p value is set, the predicate is preferred.
 *
 * For key-less lists and state leaf-lists, positional predicates can be used. If no preciate is used for these
 * nodes, they are always created.
 *
 * @param[in] parent Data parent to add to/modify, can be NULL. Note that in case a first top-level sibling is used,
 * it may no longer be first if @p path is absolute and starts with a non-existing top-level node inserted
 * before @p parent. Use ::lyd_first_sibling() to adjust @p parent in these cases.
 * @param[in] ctx libyang context, must be set if @p parent is NULL.
 * @param[in] p Compiled path.
 * @param[in] path [Path](@ref howtoXPath) to create.
 * @param[in] value Value of the new leaf/leaf-list (const char *) in ::LY_VALUE_JSON format. If creating an
 * anyxml/anydata node, the expected type depends on @p value_type. For other node types, it should be NULL.
 * @param[in] value_size_bits Size of @p value in bits, must be set correctly. Ignored when
 * creating anyxml/anydata nodes.
 * @param[in] any_hints Hints for @p value when creating an anyxml/anydata node.
 * @param[in] options Bitmask of new value creation options, see @ref newvaloptions.
 * @param[out] new_parent Optional first parent node created. If only one node was created, equals to @p new_node.
 * @param[out] new_node Optional last node created.
 * @return LY_ERR value.
 */
LY_ERR lyd_new_path_create(struct lyd_node *parent, const struct ly_ctx *ctx, struct ly_path *p, const char *path,
        const void *value, uint64_t value_size_bits, uint32_t any_hints, uint32_t options, struct lyd_node **new_parent,
        struct lyd_node **new_node);

/**
 * @brief Check the existence and create any non-existing implicit children.
 *
 * @param[in] parent Parent of the potential default values, NULL for top-level siblings.
 * @param[in,out] first First sibling.
 * @param[in] sparent Schema parent of the siblings, NULL if schema of @p parent can be used.
 * @param[in] mod Module of the default values, NULL for nested siblings.
 * @param[in] node_when Optional set to add nodes with "when" conditions into.
 * @param[in] node_types Optional set to add nodes with unresolved types into.
 * @param[in] ext_val Optional set to add nodes with extension instances into.
 * @param[in] impl_opts Implicit options (@ref implicitoptions).
 * @param[in,out] getnext_ht Getnext HT to use, new @p sparent is added to it.
 * @param[in,out] diff Validation diff.
 * @return LY_ERR value.
 */
LY_ERR lyd_new_implicit(struct lyd_node *parent, struct lyd_node **first, const struct lysc_node *sparent,
        const struct lys_module *mod, struct ly_set *node_when, struct ly_set *node_types, struct ly_set *ext_val,
        uint32_t impl_opts, struct ly_ht *getnext_ht, struct lyd_node **diff);

/**
 * @brief Check the existence and create any non-existing implicit children, recursively for containers.
 *
 * @param[in] parent Parent of the potential default values, NULL for top-level siblings.
 * @param[in,out] first First sibling.
 * @param[in] sparent Schema parent of the siblings, NULL if schema of @p parent can be used.
 * @param[in] mod Module of the default values, NULL for nested siblings.
 * @param[in] node_when Optional set to add nodes with "when" conditions into.
 * @param[in] node_types Optional set to add nodes with unresolved types into.
 * @param[in] ext_val Optional set to add nodes with extension instances into.
 * @param[in] impl_opts Implicit options (@ref implicitoptions).
 * @param[in,out] getnext_ht Getnext HT to use, new @p sparent is added to it.
 * @param[in,out] diff Validation diff.
 * @return LY_ERR value.
 */
LY_ERR lyd_new_implicit_r(struct lyd_node *parent, struct lyd_node **first, const struct lysc_node *sparent,
        const struct lys_module *mod, struct ly_set *node_when, struct ly_set *node_types, struct ly_set *ext_val,
        uint32_t impl_opts, struct ly_ht *getnext_ht, struct lyd_node **diff);

/**
 * @brief Find the next node, before which to insert the new node.
 *
 * @param[in] first_sibling First sibling of the nodes to consider.
 * @param[in] new_node Node that will be inserted.
 * @return Node to insert after.
 * @return NULL if the new node should be first.
 */
struct lyd_node *lyd_insert_get_next_anchor(const struct lyd_node *first_sibling, const struct lyd_node *new_node);

/**
 * @brief Insert node after a sibling.
 *
 * Handles inserting into NP containers and key-less lists.
 *
 * @param[in,out] first_sibling Optional, useful for optimization. The function operates with the first sibling
 * only if the node is inserted last. It is optimal when the first sibling is set. If it is set to NULL or
 * if it points to a NULL pointer, then the function will find the first sibling itself.
 * @param[in] sibling Sibling to insert after.
 * @param[in] node Node to insert.
 */
void lyd_insert_after_node(struct lyd_node **first_sibling, struct lyd_node *sibling, struct lyd_node *node);

/**
 * @brief Insert node before a sibling.
 *
 * Handles inserting into NP containers and key-less lists.
 *
 * @param[in] sibling Sibling to insert before.
 * @param[in] node Node to insert.
 */
void lyd_insert_before_node(struct lyd_node *sibling, struct lyd_node *node);

/**
 * @defgroup insertorder Data insert order.
 *
 * Various options for optimal node insertion.
 * Flags that cause the order of nodes not to be checked are adapted to fast insertion but can cause
 * nodes for (leaf-)lists with LYS_ORDBY_SYSTEM flag set to be out of order, which is an undesirable state,
 * so these flags must be set carefully. In such exceptional cases, (leaf-)list instances may remain unsorted,
 * in which case inserting a new node causes sorting to be invoked.
 * @{
 */

#define LYD_INSERT_NODE_DEFAULT         0x00 /**< Default behavior. Node is inserted to preserve order. */
#define LYD_INSERT_NODE_LAST            0x01 /**< Node inserted as last sibling. Node ordering is checked only
                                                  in Debug build, to detect misuse of the LYD_PARSE_ORDERED flag. */
#define LYD_INSERT_NODE_LAST_BY_SCHEMA  0x02 /**< The node is inserted according to the schema as a last instance.
                                                  Node order not checked. */

/** @} insertorder */

/**
 * @brief Insert a node into parent/siblings. Order and hashes are fully handled.
 *
 * @param[in] parent Parent to insert into, NULL for top-level sibling.
 * @param[in,out] first_sibling First sibling, NULL if no top-level sibling exist yet. Can be also NULL if @p parent is set.
 * @param[in] node Individual node (without siblings) to insert.
 * @param[in] order Options for inserting (sorting) the node (@ref insertorder).
 */
void lyd_insert_node(struct lyd_node *parent, struct lyd_node **first_sibling, struct lyd_node *node,
        uint32_t order);

/**
 * @brief Insert a node into parent/siblings, either before the 'anchor' or as the last sibling.
 *
 * @param[in] parent Parent to insert into, NULL for top-level sibling.
 * @param[in,out] first_sibling First sibling, pointing to NULL pointer if no top-level sibling exist yet
 * or if @p parent is set.
 * @param[in] node Individual node (without siblings) to insert.
 */
void lyd_insert_node_ordby_schema(struct lyd_node *parent, struct lyd_node **first_sibling, struct lyd_node *node);

/**
 * @brief Unlink the specified data subtree.
 *
 * @param[in] node Data tree node to be unlinked (together with all the children).
 */
void lyd_unlink(struct lyd_node *node);

/**
 * @brief Insert a metadata (last) into a parent
 *
 * @param[in] parent Parent of the metadata.
 * @param[in] meta Metadata (list) to be added into the @p parent.
 * @param[in] clear_dflt Whether to clear dflt flag starting from @p parent, recursively all NP containers.
 */
void lyd_insert_meta(struct lyd_node *parent, struct lyd_meta *meta, ly_bool clear_dflt);

/**
 * @brief Unlink a single metadata instance.
 *
 * @param[in] meta Metadata to unlink.
 */
void lyd_unlink_meta_single(struct lyd_meta *meta);

/**
 * @brief Get the annotation definition in the module.
 *
 * @param[in] mod Metadata module (with the annotation definition).
 * @param[in] name Metadata name.
 * @param[in] name_len Length of @p name, must be set correctly.
 * @return YANG extension annotation instance.
 */
struct lysc_ext_instance *lyd_get_meta_annotation(const struct lys_module *mod, const char *name, size_t name_len);

/**
 * @brief Create and insert a metadata (last) into a parent.
 *
 * @param[in] parent Parent of the metadata, can be NULL.
 * @param[in,out] meta Metadata list to add at its end if @p parent is NULL, returned created attribute.
 * @param[in] mod Metadata module (with the annotation definition).
 * @param[in] name Metadata name.
 * @param[in] name_len Length of @p name, must be set correctly.
 * @param[in] value Value to be parsed.
 * @param[in] value_size_bits Size of @p value in bits, must be set correctly.
 * @param[in] is_utf8 Whether @p value is a valid UTF-8 string, if applicable.
 * @param[in] store_only Whether to perform storing operation only.
 * @param[in,out] dynamic Flag if @p value is dynamically allocated, is adjusted when @p value is consumed.
 * @param[in] format Input format of @p value.
 * @param[in] prefix_data Format-specific data for resolving any prefixes (see ::ly_resolve_prefix).
 * @param[in] hints [Value hints](@ref lydvalhints) from the parser regarding the value type.
 * @param[in] ctx_node Value context node, may be NULL for metadata.
 * @param[in] lnode Data node for logging.
 * @param[in] clear_dflt Whether to clear dflt flag starting from @p parent, recursively all NP containers.
 * @param[out] incomplete Whether the value needs to be resolved.
 * @return LY_SUCCESS on success.
 * @return LY_EINCOMPLETE in case data tree is needed to finish the validation.
 * @return LY_ERR value if an error occurred.
 */
LY_ERR lyd_create_meta(struct lyd_node *parent, struct lyd_meta **meta, const struct lys_module *mod, const char *name,
        uint32_t name_len, const void *value, uint64_t value_size_bits, ly_bool is_utf8, ly_bool store_only,
        ly_bool *dynamic, LY_VALUE_FORMAT format, void *prefix_data, uint32_t hints, const struct lysc_node *ctx_node,
        const struct lyd_node *lnode, ly_bool clear_dflt, ly_bool *incomplete);

/**
 * @brief Create a copy of the metadata.
 *
 * @param[in] parent_ctx Target context for duplicated nodes.
 * @param[in] meta Metadata to copy.
 * @param[in] parent Node where to append the new metadata.
 * @param[out] dup Optional created metadata copy.
 * @return LY_ERR value.
 */
LY_ERR lyd_dup_meta_single_to_ctx(const struct ly_ctx *parent_ctx, const struct lyd_meta *meta, struct lyd_node *parent,
        struct lyd_meta **dup);

/**
 * @brief Insert an attribute (last) into a parent
 *
 * @param[in] parent Parent of the attributes.
 * @param[in] attr Attribute (list) to be added into the @p parent.
 */
void lyd_insert_attr(struct lyd_node *parent, struct lyd_attr *attr);

/**
 * @brief Create and insert a generic attribute (last) into a parent.
 *
 * @param[in] parent Parent of the attribute, can be NULL.
 * @param[in,out] attr Attribute list to add at its end if @p parent is NULL, returned created attribute.
 * @param[in] ctx libyang context.
 * @param[in] name Attribute name.
 * @param[in] name_len Length of @p name, must be set correctly.
 * @param[in] prefix Attribute prefix.
 * @param[in] prefix_len Attribute prefix length.
 * @param[in] module_key Mandatory key to reference module, can be namespace or name.
 * @param[in] module_key_len Length of @p module_key, must be set correctly.
 * @param[in] value String value to be parsed.
 * @param[in] value_len Length of @p value, must be set correctly.
 * @param[in,out] dynamic Flag if @p value is dynamically allocated, is adjusted when @p value is consumed.
 * @param[in] format Input format of @p value and @p ns.
 * @param[in] val_prefix_data Format-specific prefix data, param is spent (even in case the function fails).
 * @param[in] hints [Hints](@ref lydhints) from the parser regarding the node/value type.
 * @return LY_SUCCESS on success,
 * @return LY_ERR value on error.
 */
LY_ERR lyd_create_attr(struct lyd_node *parent, struct lyd_attr **attr, const struct ly_ctx *ctx, const char *name,
        uint32_t name_len, const char *prefix, uint32_t prefix_len, const char *module_key, uint32_t module_key_len,
        const char *value, uint32_t value_len, ly_bool *dynamic, LY_VALUE_FORMAT format, void *val_prefix_data, uint32_t hints);

/**
 * @brief Check the equality of the two schemas.
 *
 * @param[in] schema1 Schema of first node.
 * @param[in] schema2 Schema of second node.
 * @param[in] cmp_parents Whether to also compare all the parents.
 * @return 1 if the schemas are equal otherwise 0.
 */
ly_bool lyd_compare_schema_equal(const struct lysc_node *schema1, const struct lysc_node *schema2, ly_bool cmp_parents);

/**
 * @brief Store and canonize the given @p value into @p val according to the schema node type rules.
 *
 * @param[in] ctx libyang context.
 * @param[in] lnode Data node for logging.
 * @param[in,out] val Storage for the value.
 * @param[in] type Type of the value.
 * @param[in] value Value to be parsed, must not be NULL.
 * @param[in] value_size_bits Size of @p value in bits, must be set correctly.
 * @param[in] is_utf8 Whether @p value is a valid UTF-8 string, if applicable.
 * @param[in] store_only Whether to perform storing operation only.
 * @param[in,out] dynamic Flag if @p value is dynamically allocated, is adjusted when @p value is consumed.
 * @param[in] format Input format of @p value.
 * @param[in] prefix_data Format-specific data for resolving any prefixes (see ::ly_resolve_prefix).
 * @param[in] hints [Value hints](@ref lydvalhints) from the parser.
 * @param[in] ctx_snode Context schema node.
 * @param[out] incomplete Optional, set if the value also needs to be resolved.
 * @return LY_SUCCESS on success,
 * @return LY_ERR value on error.
 */
LY_ERR lyd_value_store(const struct ly_ctx *ctx, const struct lyd_node *lnode, struct lyd_value *val,
        const struct lysc_type *type, const void *value, uint64_t value_size_bits, ly_bool is_utf8, ly_bool store_only,
        ly_bool *dynamic, LY_VALUE_FORMAT format, void *prefix_data, uint32_t hints, const struct lysc_node *ctx_snode,
        ly_bool *incomplete);

/**
 * @brief Validate previously incompletely stored value.
 *
 * @param[in] ctx libyang context.
 * @param[in] type Schema type of the value (not the stored one, but the original one).
 * @param[in,out] val Stored value to resolve.
 * @param[in] ctx_node Context node for the resolution.
 * @param[in] tree Data tree for the resolution.
 * @return LY_SUCCESS on success,
 * @return LY_ERR value on error.
 */
LY_ERR lyd_value_validate_incomplete(const struct ly_ctx *ctx, const struct lysc_type *type, struct lyd_value *val,
        const struct lyd_node *ctx_node, const struct lyd_node *tree);

/**
 * @brief Check type restrictions applicable to the particular leaf/leaf-list with the given string @p value.
 *
 * This function check just the type's restriction, if you want to check also the data tree context (e.g. in case of
 * require-instance restriction), use ::lyd_value_validate().
 *
 * @param[in] ctx libyang context for logging (function does not log errors when @p ctx is NULL)
 * @param[in] node Schema node for the @p value.
 * @param[in] value Value to be checked in @p format.
 * @param[in] value_size_bits Size of the given @p value in bits.
 * @param[in] format Value prefix format.
 * @param[in] prefix_data Format-specific data for resolving any prefixes (see ::ly_resolve_prefix).
 * @param[in] hints Value encoding hints.
 * @return LY_SUCCESS on success
 * @return LY_ERR value if an error occurred.
 */
LY_ERR ly_value_validate(const struct ly_ctx *ctx, const struct lysc_node *node, const void *value,
        uint64_t value_size_bits, LY_VALUE_FORMAT format, void *prefix_data, uint32_t hints);

/**
 * @brief Check type restrictions applicable to the particular leaf/leaf-list with the given string @p value.
 *
 * The given node is not modified in any way - it is just checked if the @p value can be set to the node.
 *
 * @param[in] ctx Context to use.
 * @param[in] type Type of @p value to use.
 * @param[in] value String value to be checked, it is expected to be in JSON format.
 * @param[in] value_len Length of the given @p value (mandatory).
 * @param[in] format Value prefix format.
 * @param[in] prefix_data Format-specific data for resolving any prefixes (see ::ly_resolve_prefix).
 * @param[in] hints Value hints, bitmap of LYD_VALHINT_* values.
 * @param[in] ctx_node Optional data tree context node for the value (leafref target, instance-identifier).
 * If not set and is required for the validation to complete, ::LY_EINCOMPLETE is be returned.
 * @param[in] ctx_scnode Optinal schema context node, for logging.
 * @param[in] log Whether to log errors or not.
 * @param[out] realtype Optional real type of @p value.
 * @param[out] canonical Optional canonical value of @p value (in the dictionary).
 * @return LY_SUCCESS on success
 * @return LY_EINCOMPLETE in case the @p ctx_node is not provided and it was needed to finish the validation
 * (e.g. due to require-instance).
 * @return LY_ERR value if an error occurred.
 */
LY_ERR lyd_value_validate3(const struct ly_ctx *ctx, const struct lysc_type *type, const char *value, size_t value_len,
        LY_VALUE_FORMAT format, void *prefix_data, uint32_t hints, const struct lyd_node *ctx_node,
        const struct lysc_node *ctx_scnode, int log, const struct lysc_type **realtype, const char **canonical);

/**
 * @defgroup datahash Data nodes hash manipulation
 * @ingroup datatree
 * @{
 */

/**
 * @brief Generate hash for the node.
 *
 * @param[in] node Data node to (re)generate hash value.
 * @return LY_ERR value.
 */
LY_ERR lyd_hash(struct lyd_node *node);

/**
 * @brief Compare callback for values in hash table.
 *
 * Implementation of ::lyht_value_equal_cb.
 */
ly_bool lyd_hash_table_val_equal(void *val1_p, void *val2_p, ly_bool mod, void *cb_data);

/**
 * @brief Insert hash of the node into the hash table of its parent.
 *
 * @param[in] node Data node which hash will be inserted into the ::lyd_node_inner.children_ht hash table of its parent.
 * @return LY_ERR value.
 */
LY_ERR lyd_insert_hash(struct lyd_node *node);

/**
 * @brief Maintain node's parent's children hash table when unlinking the node.
 *
 * When completely freeing data tree, it is expected to free the parent's children hash table first, at once.
 *
 * @param[in] node The data node being unlinked from its parent.
 */
void lyd_unlink_hash(struct lyd_node *node);

/** @} datahash */

/**
 * @brief Append all list key predicates to path.
 *
 * @param[in] node Node with keys to print.
 * @param[in,out] buffer Buffer to print to.
 * @param[in,out] buflen Current buffer length.
 * @param[in,out] bufused Current number of characters used in @p buffer.
 * @param[in] is_static Whether buffer is static or can be reallocated.
 * @return LY_ERR value.
 */
LY_ERR lyd_path_list_predicate(const struct lyd_node *node, char **buffer, size_t *buflen, size_t *bufused, ly_bool is_static);

/**
 * @brief Generate a path similar to ::lyd_path() except read the parents from a set.
 *
 * @param[in] dnodes Set with the data nodes, from parent to the last descendant.
 * @param[in] pathtype Type of data path to generate.
 * @return Generated data path.
 */
char *lyd_path_set(const struct ly_set *dnodes, LYD_PATH_TYPE pathtype);

/**
 * @brief Remove an object on the specific set index keeping the order of the other objects.
 *
 * @param[in] set Set from which a node will be removed.
 * @param[in] index Index of the object to remove in the \p set.
 * @param[in] destructor Optional function to free the objects being removed.
 * @return LY_ERR value.
 */
LY_ERR ly_set_rm_index_ordered(struct ly_set *set, uint32_t index, void (*destructor)(void *obj));

/**
 * @brief Frees data within leafref links record
 *
 * @param[in] rec The leafref links record
 */
void lyd_free_leafref_links_rec(struct lyd_leafref_links_rec *rec);

/**
 * @brief Frees all leafref nodes and target node of given data node
 *
 * @param[in] node The data node, which leafref nodes and/or target node should be cleared.
 */
void lyd_free_leafref_nodes(const struct lyd_node_term *node);

/**
 * @brief Gets or creates the leafref links record.
 *
 * @param[in] node The term data node.
 * @param[out] record The leafref links record.
 * @param[in] create Whether to create record if not exists.
 * @return LY_SUCCESS on success.
 * @return LY_ERR value on error.
 */
LY_ERR lyd_get_or_create_leafref_links_record(const struct lyd_node_term *node, struct lyd_leafref_links_rec **record, ly_bool create);

/**
 * @brief Adds links between leafref and data node.
 *
 * If the links were already added, it will not be added again.
 * This API requires usage of LY_CTX_LEAFREF_LINKING context flag.
 *
 * @param[in] node Data node to which, the leafref is pointing to.
 * @param[in] leafref_node The leafref, which points to given node.
 * @return LY_SUCCESS on success.
 * @return LY_ERR value on error.
 */
LY_ERR lyd_link_leafref_node(const struct lyd_node_term *node, const struct lyd_node_term *leafref_node);

/**
 * @brief Removes links between leafref and data node.
 *
 * If the links were never added, it will be silently ignored.
 * This API requires usage of LY_CTX_LEAFREF_LINKING context flag.
 *
 * @param[in] node Data node to which, the leafref is pointing to.
 * @param[in] leafref_node The leafref, which points to given node.
 * @return LY_SUCCESS on success.
 * @return LY_ERR value on error.
 */
LY_ERR lyd_unlink_leafref_node(const struct lyd_node_term *node, const struct lyd_node_term *leafref_node);

/**
 * @brief Unlink the specified data subtree.
 *
 * The lyds_unlink() is NOT called in this function.
 *
 * @param[in,out] first_sibling Optional, performs an update if @p node is first or @p sibling is last.
 * @param[in] node Data tree node to be unlinked (together with all the children).
 */
void lyd_unlink_ignore_lyds(struct lyd_node **first_sibling, struct lyd_node *node);

#endif /* LY_TREE_DATA_INTERNAL_H_ */
