/**
 * @file instanceid.c
 * @author Radek Krejci <rkrejci@cesnet.cz>
 * @author Michal Vasko <mvasko@cesnet.cz>
 * @brief Built-in instance-identifier type plugin.
 *
 * Copyright (c) 2019 - 2026 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */
#define _GNU_SOURCE /* strdup */

#include "plugins_types.h"

#include <assert.h>
#include <stdint.h>
#include <stdlib.h>

#include "compat.h"
#include "dict.h"
#include "ly_array.h"
#include "ly_common.h"
#include "path.h"
#include "plugins_internal.h"

/**
 * @page howtoDataLYB LYB Binary Format
 * @subsection howtoDataLYBTypesInstanceIdentifier instance-identifier (built-in)
 *
 * | Size (b) | Mandatory | Type | Meaning |
 * | :------  | :-------: | :--: | :-----: |
 * | variable, full bytes | yes | `char *` | string JSON format of the instance-identifier |
 */

/**
 * @brief Convert compiled path (instance-identifier) into string.
 *
 * @param[in] path Compiled path.
 * @param[in] format Value format.
 * @param[in] prefix_data Format-specific data for resolving prefixes.
 * @param[out] str Printed instance-identifier.
 * @return LY_ERR value.
 */
static LY_ERR
instanceid_path2str(const struct ly_path *path, LY_VALUE_FORMAT format, void *prefix_data, char **str)
{
    LY_ERR ret = LY_SUCCESS;
    LYA_COUNT_T u, v;
    char *result = NULL, quot;
    const struct lys_module *mod = NULL, *local_mod = NULL;
    struct ly_set *mods = NULL;
    ly_bool inherit_prefix = 0;
    const char *strval;

    switch (format) {
    case LY_VALUE_XML:
    case LY_VALUE_STR_NS:
        /* zero the local module so that all the prefixes are printed */
        mods = prefix_data;
        local_mod = mods->objs[0];
        mods->objs[0] = NULL;
        break;
    case LY_VALUE_SCHEMA:
    case LY_VALUE_SCHEMA_RESOLVED:
        /* nothing to do */
        break;
    case LY_VALUE_CANON:
    case LY_VALUE_CBOR:
    case LY_VALUE_JSON:
    case LY_VALUE_LYB:
        /* zero the local module so that the first node is always prefixed */
        prefix_data = NULL;
        break;
    }

    switch (format) {
    case LY_VALUE_XML:
    case LY_VALUE_SCHEMA:
    case LY_VALUE_SCHEMA_RESOLVED:
        /* everything is prefixed */
        inherit_prefix = 0;
        break;
    case LY_VALUE_CANON:
    case LY_VALUE_CBOR:
    case LY_VALUE_JSON:
    case LY_VALUE_LYB:
    case LY_VALUE_STR_NS:
        /* the same prefix is inherited and skipped */
        inherit_prefix = 1;
        break;
    }

    LYA_FOR(path, u) {
        /* new node */
        if (!inherit_prefix || (mod != path[u].node->module)) {
            mod = path[u].node->module;
            ret = ly_strcat(&result, "/%s:%s", lyplg_type_get_prefix(mod, format, prefix_data), path[u].node->name);
        } else {
            ret = ly_strcat(&result, "/%s", path[u].node->name);
        }
        LY_CHECK_GOTO(ret, cleanup);

        /* node predicates */
        LYA_FOR(path[u].predicates, v) {
            struct ly_path_predicate *pred = &path[u].predicates[v];

            switch (pred->type) {
            case LY_PATH_PREDTYPE_POSITION:
                /* position predicate */
                ret = ly_strcat(&result, "[%" PRIu64 "]", pred->position);
                break;
            case LY_PATH_PREDTYPE_LIST:
                /* key-predicate */
                ret = lyplg_type_print_val(pred->key, pred->value, format, prefix_data, &strval);
                LY_CHECK_GOTO(ret, cleanup);

                /* default quote */
                LY_CHECK_GOTO(ret = ly_val_get_quot(pred->key->module->ctx, strval, &quot), cleanup);
                if (inherit_prefix) {
                    /* always the same prefix as the parent */
                    ret = ly_strcat(&result, "[%s=%c%s%c]", pred->key->name, quot, strval, quot);
                } else {
                    ret = ly_strcat(&result, "[%s:%s=%c%s%c]", lyplg_type_get_prefix(pred->key->module, format, prefix_data),
                            pred->key->name, quot, strval, quot);
                }
                lydict_remove(pred->key->module->ctx, strval);
                break;
            case LY_PATH_PREDTYPE_LEAFLIST:
                /* leaf-list-predicate */
                ret = lyplg_type_print_val(path[u].node, pred->value, format, prefix_data, &strval);
                LY_CHECK_GOTO(ret, cleanup);

                /* default quote */
                LY_CHECK_GOTO(ret = ly_val_get_quot(path[u].node->module->ctx, strval, &quot), cleanup);
                ret = ly_strcat(&result, "[.=%c%s%c]", quot, strval, quot);
                lydict_remove(path[u].node->module->ctx, strval);
                break;
            case LY_PATH_PREDTYPE_LIST_VAR:
                LOGINT(path[u].node->module->ctx);
                ret = LY_EINT;
                goto cleanup;
            }

            LY_CHECK_GOTO(ret, cleanup);
        }
    }

cleanup:
    if (local_mod) {
        mods->objs[0] = (void *)local_mod;
    }
    if (ret) {
        free(result);
    } else {
        *str = result;
    }
    return ret;
}

static LY_ERR
lyplg_type_store_instanceid(const struct ly_ctx *ctx, const struct lysc_type *type, const void *value, uint64_t value_size_bits,
        uint32_t options, LY_VALUE_FORMAT format, void *prefix_data, uint32_t hints, const struct lysc_node *ctx_node,
        struct lyd_value *storage, struct lys_glob_unres *unres, struct ly_err_item **err)
{
    LY_ERR ret = LY_SUCCESS;
    struct lysc_type_instanceid *type_inst = (struct lysc_type_instanceid *)type;
    uint32_t value_size;
    struct ly_path *path;
    char *canon;

    /* init storage */
    memset(storage, 0, sizeof *storage);
    storage->realtype = type;

    /* check value length */
    ret = lyplg_type_check_value_size("instance-identifier", format, value_size_bits, LYPLG_LYB_SIZE_VARIABLE_BYTES, 0,
            &value_size, err);
    LY_CHECK_GOTO(ret, cleanup);

    /* check hints */
    ret = lyplg_type_check_hints(hints, value, value_size, type->basetype, NULL, err);
    LY_CHECK_GOTO(ret, cleanup);

    /* compile instance-identifier into path */
    ret = lyplg_type_lypath_new(ctx, value, value_size, options, (format == LY_VALUE_LYB) ? LY_VALUE_JSON : format,
            prefix_data, ctx_node, unres, &path, err);
    LY_CHECK_GOTO(ret, cleanup);

    /* store value */
    storage->target = path;

    /* check status */
    ret = lyplg_type_lypath_check_status(ctx_node, path, format, prefix_data, err);
    LY_CHECK_GOTO(ret, cleanup);

    /* store canonical value */
    if (format == LY_VALUE_CANON) {
        if (options & LYPLG_TYPE_STORE_DYNAMIC) {
            ret = lydict_insert_zc(ctx, (char *)value, &storage->_canonical);
            options &= ~LYPLG_TYPE_STORE_DYNAMIC;
            LY_CHECK_GOTO(ret, cleanup);
        } else {
            ret = lydict_insert(ctx, value, value_size, &storage->_canonical);
            LY_CHECK_GOTO(ret, cleanup);
        }
    } else {
        /* JSON format with prefix is the canonical one */
        ret = instanceid_path2str(path, LY_VALUE_JSON, NULL, &canon);
        LY_CHECK_GOTO(ret, cleanup);

        ret = lydict_insert_zc(ctx, canon, &storage->_canonical);
        LY_CHECK_GOTO(ret, cleanup);
    }

cleanup:
    if (options & LYPLG_TYPE_STORE_DYNAMIC) {
        free((void *)value);
    }

    if (ret) {
        lyplg_type_free_instanceid(ctx, storage);
    }
    if (!ret && type_inst->require_instance) {
        /* needs to be resolved */
        return LY_EINCOMPLETE;
    } else {
        return ret;
    }
}

static LY_ERR
lyplg_type_validate_tree_instanceid(const struct ly_ctx *ctx, const struct lysc_type *UNUSED(type),
        const struct lyd_node *ctx_node, const struct lyd_node *UNUSED(tree), struct lyd_value *storage,
        struct ly_err_item **err)
{
    LY_ERR ret = LY_SUCCESS;
    struct lysc_type_instanceid *type_inst = (struct lysc_type_instanceid *)storage->realtype;
    const char *value;
    char *path;

    /* instance-identifier must be a leaf or leaf-list */
    assert(ctx_node);

    *err = NULL;

    if (!type_inst->require_instance) {
        /* redundant to resolve */
        return LY_SUCCESS;
    }

    /* find the target in data */
    if ((ret = ly_path_eval(storage->target, ctx_node, NULL, NULL))) {
        value = lyd_value_get_canonical(ctx, storage);
        path = lyd_path(ctx_node, LYD_PATH_STD, NULL, 0);
        return ly_err_new(err, ret, LYVE_DATA, path, strdup("instance-required"), LY_ERRMSG_NOINST, value);
    }

    return LY_SUCCESS;
}

static const void *
lyplg_type_print_instanceid(const struct ly_ctx *UNUSED(ctx), const struct lyd_value *value, LY_VALUE_FORMAT format,
        void *prefix_data, ly_bool *dynamic, uint64_t *value_size_bits)
{
    char *ret;

    switch (format) {
    case LY_VALUE_CANON:
    case LY_VALUE_JSON:
    case LY_VALUE_LYB:
    case LY_VALUE_CBOR:
        if (dynamic) {
            *dynamic = 0;
        }
        if (value_size_bits) {
            *value_size_bits = strlen(value->_canonical) * 8;
        }
        return value->_canonical;
    default:
        break;
    }

    /* print the value in the specific format */
    if (instanceid_path2str(value->target, format, prefix_data, &ret)) {
        return NULL;
    }

    *dynamic = 1;
    if (value_size_bits) {
        *value_size_bits = strlen(ret) * 8;
    }

    return ret;
}

static LY_ERR
lyplg_type_dup_instanceid(const struct ly_ctx *ctx, const struct lyd_value *original, struct lyd_value *dup)
{
    LY_ERR ret;

    memset(dup, 0, sizeof *dup);

    /* canonical value */
    ret = lydict_insert(ctx, original->_canonical, 0, &dup->_canonical);
    LY_CHECK_GOTO(ret, error);

    /* copy path */
    ret = ly_path_dup(ctx, original->target, &dup->target);
    LY_CHECK_GOTO(ret, error);

    dup->realtype = original->realtype;
    return LY_SUCCESS;

error:
    lyplg_type_free_instanceid(ctx, dup);
    return ret;
}

LIBYANG_API_DEF void
lyplg_type_free_instanceid(const struct ly_ctx *ctx, struct lyd_value *value)
{
    lydict_remove(ctx, value->_canonical);
    value->_canonical = NULL;
    ly_path_free(value->target);
}

/**
 * @brief Plugin information for instance-identifier type implementation.
 *
 * Note that external plugins are supposed to use:
 *
 *   LYPLG_TYPES = {
 */
const struct lyplg_type_record plugins_instanceid[] = {
    {
        .module = "",
        .revision = NULL,
        .name = LY_TYPE_INST_STR,

        .plugin.id = "ly2 instance-identifier",
        .plugin.lyb_size = lyplg_type_lyb_size_variable_bytes,
        .plugin.store = lyplg_type_store_instanceid,
        .plugin.validate_value = NULL,
        .plugin.validate_tree = lyplg_type_validate_tree_instanceid,
        .plugin.compare = lyplg_type_compare_simple,
        .plugin.sort = lyplg_type_sort_simple,
        .plugin.print = lyplg_type_print_instanceid,
        .plugin.duplicate = lyplg_type_dup_instanceid,
        .plugin.free = lyplg_type_free_instanceid,
    },
    {0}
};
