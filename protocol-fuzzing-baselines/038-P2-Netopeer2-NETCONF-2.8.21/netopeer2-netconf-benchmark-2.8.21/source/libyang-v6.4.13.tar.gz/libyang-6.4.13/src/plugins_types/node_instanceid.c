/**
 * @file node_instanceid.c
 * @author Michal Vasko <mvasko@cesnet.cz>
 * @brief ietf-netconf-acm node-instance-identifier type plugin.
 *
 * Copyright (c) 2019 - 2026 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */

#include "plugins_types.h"

#include <stdint.h>
#include <stdlib.h>

#include "compat.h"
#include "dict.h"
#include "ly_array.h"
#include "ly_common.h"
#include "path.h"
#include "plugins_internal.h"
#include "xpath.h"

/**
 * @page howtoDataLYB LYB Binary Format
 * @subsection howtoDataLYBTypesNodeInstanceIdentifier node-instance-identifier (ietf-netconf-acm)
 *
 * | Size (b) | Mandatory | Type | Meaning |
 * | :------  | :-------: | :--: | :-----: |
 * | variable, full bytes | yes | `char *` | string JSON format of the instance-identifier |
 */

/**
 * @brief Convert compiled path (node-instance-identifier) or NULL ("/") into string.
 *
 * @param[in] path Compiled path.
 * @param[in] format Value format.
 * @param[in] prefix_data Format-specific data for resolving prefixes.
 * @param[out] str Printed instance-identifier.
 * @return LY_ERR value.
 */
static LY_ERR
node_instanceid_path2str(const struct ly_path *path, LY_VALUE_FORMAT format, void *prefix_data, char **str)
{
    LY_ERR ret = LY_SUCCESS;
    LYA_COUNT_T u, v;
    char *result = NULL, quot;
    const struct lys_module *mod = NULL, *local_mod = NULL;
    struct ly_set *mods;
    ly_bool inherit_prefix = 0;
    const char *strval;

    if (!path) {
        /* special path */
        ret = ly_strcat(&result, "/");
        goto cleanup;
    }

    switch (format) {
    case LY_VALUE_XML:
    case LY_VALUE_STR_NS:
        /* zero the local module so that all the prefixes are printed */
        mods = prefix_data;
        local_mod = mods->objs[0];
        mods->objs[0] = NULL;
        break;
    case LY_VALUE_SCHEMA:
    case LY_VALUE_SCHEMA_RESOLVED:
        /* nothing to do */
        break;
    case LY_VALUE_CANON:
    case LY_VALUE_CBOR:
    case LY_VALUE_JSON:
    case LY_VALUE_LYB:
        /* zero the local module so that the first node is always prefixed */
        prefix_data = NULL;
        break;
    }

    switch (format) {
    case LY_VALUE_XML:
    case LY_VALUE_SCHEMA:
    case LY_VALUE_SCHEMA_RESOLVED:
        /* everything is prefixed */
        inherit_prefix = 0;
        break;
    case LY_VALUE_CANON:
    case LY_VALUE_CBOR:
    case LY_VALUE_JSON:
    case LY_VALUE_LYB:
    case LY_VALUE_STR_NS:
        /* the same prefix is inherited and skipped */
        inherit_prefix = 1;
        break;
    }

    LYA_FOR(path, u) {
        /* new node */
        if (!inherit_prefix || (mod != path[u].node->module)) {
            mod = path[u].node->module;
            ret = ly_strcat(&result, "/%s:%s", lyplg_type_get_prefix(mod, format, prefix_data), path[u].node->name);
        } else {
            ret = ly_strcat(&result, "/%s", path[u].node->name);
        }
        LY_CHECK_GOTO(ret, cleanup);

        /* node predicates */
        LYA_FOR(path[u].predicates, v) {
            struct ly_path_predicate *pred = &path[u].predicates[v];

            switch (pred->type) {
            case LY_PATH_PREDTYPE_POSITION:
                /* position predicate */
                ret = ly_strcat(&result, "[%" PRIu64 "]", pred->position);
                break;
            case LY_PATH_PREDTYPE_LIST:
                /* key-predicate */
                ret = lyplg_type_print_val(pred->key, pred->value, format, prefix_data, &strval);
                LY_CHECK_GOTO(ret, cleanup);

                /* default quote */
                LY_CHECK_GOTO(ret = ly_val_get_quot(pred->key->module->ctx, strval, &quot), cleanup);
                if (inherit_prefix) {
                    /* always the same prefix as the parent */
                    ret = ly_strcat(&result, "[%s=%c%s%c]", pred->key->name, quot, strval, quot);
                } else {
                    ret = ly_strcat(&result, "[%s:%s=%c%s%c]", lyplg_type_get_prefix(pred->key->module, format, prefix_data),
                            pred->key->name, quot, strval, quot);
                }
                lydict_remove(pred->key->module->ctx, strval);
                break;
            case LY_PATH_PREDTYPE_LEAFLIST:
                /* leaf-list-predicate */
                ret = lyplg_type_print_val(path[u].node, pred->value, format, prefix_data, &strval);
                LY_CHECK_GOTO(ret, cleanup);

                /* default quote */
                LY_CHECK_GOTO(ret = ly_val_get_quot(path[u].node->module->ctx, strval, &quot), cleanup);
                ret = ly_strcat(&result, "[.=%c%s%c]", quot, strval, quot);
                lydict_remove(path[u].node->module->ctx, strval);
                break;
            case LY_PATH_PREDTYPE_LIST_VAR:
                /* key-predicate with a variable */
                if (inherit_prefix) {
                    /* always the same prefix as the parent */
                    ret = ly_strcat(&result, "[%s=$%s]", pred->key->name, pred->variable);
                } else {
                    ret = ly_strcat(&result, "[%s:%s=$%s]", lyplg_type_get_prefix(pred->key->module, format, prefix_data),
                            pred->key->name, pred->variable);
                }
                break;
            }

            LY_CHECK_GOTO(ret, cleanup);
        }
    }

cleanup:
    if (local_mod) {
        mods->objs[0] = (void *)local_mod;
    }
    if (ret) {
        free(result);
    } else {
        *str = result;
    }
    return ret;
}

/**
 * @brief Implementation of ::lyplg_type_store_clb for the node-instance-identifier ietf-netconf-acm type.
 */
static LY_ERR
lyplg_type_store_node_instanceid(const struct ly_ctx *ctx, const struct lysc_type *type, const void *value, uint64_t value_size_bits,
        uint32_t options, LY_VALUE_FORMAT format, void *prefix_data, uint32_t hints, const struct lysc_node *ctx_node,
        struct lyd_value *storage, struct lys_glob_unres *unres, struct ly_err_item **err)
{
    LY_ERR ret = LY_SUCCESS;
    struct lyxp_expr *exp = NULL;
    uint32_t value_size, prefix_opt = 0;
    struct ly_path *path = NULL;
    char *canon;

    /* init storage */
    memset(storage, 0, sizeof *storage);
    storage->realtype = type;

    /* check value length */
    ret = lyplg_type_check_value_size("node-instance-identifier", format, value_size_bits, LYPLG_LYB_SIZE_VARIABLE_BYTES,
            0, &value_size, err);
    LY_CHECK_GOTO(ret, cleanup);

    /* check hints */
    ret = lyplg_type_check_hints(hints, value, value_size, type->basetype, NULL, err);
    LY_CHECK_GOTO(ret, cleanup);

    if ((((char *)value)[0] == '/') && (value_size == 1)) {
        /* special path */
        format = LY_VALUE_CANON;
        goto store;
    }

    switch (format) {
    case LY_VALUE_SCHEMA:
    case LY_VALUE_SCHEMA_RESOLVED:
    case LY_VALUE_XML:
        prefix_opt = LY_PATH_PREFIX_MANDATORY;
        break;
    case LY_VALUE_CANON:
    case LY_VALUE_LYB:
    case LY_VALUE_CBOR:
    case LY_VALUE_JSON:
    case LY_VALUE_STR_NS:
        prefix_opt = LY_PATH_PREFIX_STRICT_INHERIT;
        break;
    }

    /* parse the value */
    ret = ly_path_parse(ctx, ctx_node, value, value_size, 0, LY_PATH_BEGIN_ABSOLUTE, prefix_opt, LY_PATH_PRED_SIMPLE, &exp);
    if (ret) {
        ret = ly_err_new(err, LY_EVALID, LYVE_DATA, NULL, NULL,
                "Invalid node-instance-identifier \"%.*s\" value - syntax error.", (int)value_size, (char *)value);
        goto cleanup;
    }

    if (options & LYPLG_TYPE_STORE_IMPLEMENT) {
        /* implement all prefixes */
        LY_CHECK_GOTO(ret = lys_compile_expr_implement(ctx, exp, format, prefix_data, 1, unres, NULL), cleanup);
    }

    /* resolve it on schema tree, use JSON format instead of LYB because for this type they are equal but for some
     * nested types (such as numbers in predicates in the path) LYB would be invalid */
    ret = ly_path_compile(ctx, ctx_node, exp, (ctx_node && (ctx_node->flags & LYS_IS_OUTPUT)) ?
            LY_PATH_OPER_OUTPUT : LY_PATH_OPER_INPUT, LY_PATH_TARGET_MANY, 1, (format == LY_VALUE_LYB) ?
            LY_VALUE_JSON : format, prefix_data, &path);
    if (ret) {
        ret = ly_err_new(err, ret, LYVE_DATA, NULL, NULL,
                "Invalid node-instance-identifier \"%.*s\" value - semantic error.", (int)value_size, (char *)value);
        goto cleanup;
    }

store:
    /* store value */
    storage->target = path;

    /* store canonical value */
    if (format == LY_VALUE_CANON) {
        if (options & LYPLG_TYPE_STORE_DYNAMIC) {
            ret = lydict_insert_zc(ctx, (char *)value, &storage->_canonical);
            options &= ~LYPLG_TYPE_STORE_DYNAMIC;
            LY_CHECK_GOTO(ret, cleanup);
        } else {
            ret = lydict_insert(ctx, value, value_size, &storage->_canonical);
            LY_CHECK_GOTO(ret, cleanup);
        }
    } else {
        /* JSON format with prefix is the canonical one */
        ret = node_instanceid_path2str(path, LY_VALUE_JSON, NULL, &canon);
        LY_CHECK_GOTO(ret, cleanup);

        ret = lydict_insert_zc(ctx, canon, &storage->_canonical);
        LY_CHECK_GOTO(ret, cleanup);
    }

cleanup:
    lyxp_expr_free(exp);
    if (options & LYPLG_TYPE_STORE_DYNAMIC) {
        free((void *)value);
    }

    if (ret) {
        lyplg_type_free_instanceid(ctx, storage);
    }
    return ret;
}

/**
 * @brief Implementation of ::lyplg_type_print_clb for the node-instance-identifier ietf-netconf-acm type.
 */
static const void *
lyplg_type_print_node_instanceid(const struct ly_ctx *UNUSED(ctx), const struct lyd_value *value, LY_VALUE_FORMAT format,
        void *prefix_data, ly_bool *dynamic, uint64_t *value_size_bits)
{
    char *ret;

    if ((format == LY_VALUE_CANON) || (format == LY_VALUE_JSON) || (format == LY_VALUE_LYB)) {
        if (dynamic) {
            *dynamic = 0;
        }
        if (value_size_bits) {
            *value_size_bits = strlen(value->_canonical) * 8;
        }
        return value->_canonical;
    }

    /* print the value in the specific format */
    if (node_instanceid_path2str(value->target, format, prefix_data, &ret)) {
        return NULL;
    }
    *dynamic = 1;
    if (value_size_bits) {
        *value_size_bits = strlen(ret) * 8;
    }
    return ret;
}

/**
 * @brief Implementation of ::lyplg_type_dup_clb for the node-instance-identifier ietf-netconf-acm type.
 */
static LY_ERR
lyplg_type_dup_node_instanceid(const struct ly_ctx *ctx, const struct lyd_value *original, struct lyd_value *dup)
{
    LY_ERR ret;

    memset(dup, 0, sizeof *dup);

    /* canonical value */
    ret = lydict_insert(ctx, original->_canonical, 0, &dup->_canonical);
    LY_CHECK_GOTO(ret, error);

    if (original->target) {
        /* copy path */
        ret = ly_path_dup(ctx, original->target, &dup->target);
        LY_CHECK_GOTO(ret, error);
    } /* else is the special path "/" that has no target stored */

    dup->realtype = original->realtype;
    return LY_SUCCESS;

error:
    lyplg_type_free_instanceid(ctx, dup);
    return ret;
}

/**
 * @brief Plugin information for instance-identifier type implementation.
 *
 * Note that external plugins are supposed to use:
 *
 *   LYPLG_TYPES = {
 */
const struct lyplg_type_record plugins_node_instanceid[] = {
    {
        .module = "ietf-netconf-acm",
        .revision = NULL,
        .name = "node-instance-identifier",

        .plugin.id = "ly2 node-instance-identifier",
        .plugin.lyb_size = lyplg_type_lyb_size_variable_bytes,
        .plugin.store = lyplg_type_store_node_instanceid,
        .plugin.validate_value = NULL,
        .plugin.validate_tree = NULL,
        .plugin.compare = lyplg_type_compare_simple,
        .plugin.sort = lyplg_type_sort_simple,
        .plugin.print = lyplg_type_print_node_instanceid,
        .plugin.duplicate = lyplg_type_dup_node_instanceid,
        .plugin.free = lyplg_type_free_instanceid,
    },
    {0}
};
