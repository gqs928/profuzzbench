/**
 * @file ipv6_address_prefix.c
 * @author Michal Vasko <mvasko@cesnet.cz>
 * @brief ietf-inet-types ipv6-prefix and ipv6-address-and-prefix type plugin.
 *
 * Copyright (c) 2019 - 2026 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */

#define _GNU_SOURCE /* strndup */

#include "plugins_internal.h"
#include "plugins_types.h"

#ifdef _WIN32
# include <winsock2.h>
# include <ws2tcpip.h>
#else
#  include <arpa/inet.h>
#  if defined (__FreeBSD__) || defined (__NetBSD__) || defined (__OpenBSD__)
#    include <netinet/in.h>
#    include <sys/socket.h>
#  endif
#endif
#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "compat.h"
#include "dict.h"
#include "ly_common.h"
/**
 * @page howtoDataLYB LYB Binary Format
 * @subsection howtoDataLYBTypesIPv6Prefix ipv6-prefix and ipv6-address-and-prefix (ietf-inet-types)
 *
 * | Size (b) | Mandatory | Type | Meaning |
 * | :------  | :-------: | :--: | :-----: |
 * | 128 | yes | `struct in6_addr *` | IPv6 address in network-byte order |
 * | 8 | yes | `uint8_t *` | prefix length up to 128 |
 */

#define LYPLG_IPV6PREF_LYB_VALUE_SIZE 136

static void lyplg_type_free_ipv6_address_prefix(const struct ly_ctx *ctx, struct lyd_value *value);

/**
 * @brief Convert IP address with a prefix in string to a binary network-byte order value.
 *
 * @param[in] value String to convert.
 * @param[in] value_len Length of @p value.
 * @param[in,out] val contains addr and prefix to fill.
 * @param[out] err Error information on error.
 * @return LY_ERR value.
 */
static LY_ERR
ipv6prefix_str2ip(const char *value, uint32_t value_len, struct lyd_value_ipv6_prefix *val,
        struct ly_err_item **err)
{
    LY_ERR ret = LY_SUCCESS;
    const char *pref_str;
    char *mask_str = NULL;

    /* it passed the pattern validation */
    pref_str = ly_strnchr(value, '/', value_len);
    ly_strntou8(pref_str + 1, value_len - (pref_str + 1 - value), &val->prefix);

    /* get just the network prefix */
    mask_str = strndup(value, pref_str - value);
    LY_CHECK_ERR_GOTO(!mask_str, ret = ly_err_new_no_mem(err), cleanup);

    /* convert it to netword-byte order */
    if (inet_pton(AF_INET6, mask_str, &val->addr) != 1) {
        ret = ly_err_new(err, LY_EVALID, LYVE_DATA, NULL, NULL, "Failed to store IPv6 address \"%s\".", mask_str);
        goto cleanup;
    }

cleanup:
    free(mask_str);
    return ret;
}

/**
 * @brief Zero host-portion of the IP address.
 *
 * @param[in,out] addr IP address.
 * @param[in] prefix Prefix length.
 */
static void
ipv6prefix_zero_host(struct in6_addr *addr, uint8_t prefix)
{
    uint32_t i, j, mask;

    /* zero host bits */
    for (i = 0; i < 4; ++i) {
        mask = 0;
        for (j = 0; j < 32; ++j) {
            mask <<= 1;
            if (prefix > (i * 32) + j) {
                mask |= 1;
            }
        }
        mask = htonl(mask);
        ((uint32_t *)addr->s6_addr)[i] &= mask;
    }
}

static void
lyplg_type_lyb_size_ipv6_address_prefix(const struct lysc_type *UNUSED(type), enum lyplg_lyb_size_type *size_type,
        uint64_t *fixed_size_bits)
{
    *size_type = LYPLG_LYB_SIZE_FIXED_BITS;
    *fixed_size_bits = LYPLG_IPV6PREF_LYB_VALUE_SIZE;
}

/**
 * @brief Implementation of ::lyplg_type_store_clb for the ipv6-prefix and ipv6-address-and-prefix ietf-inet-types type.
 */
static LY_ERR
lyplg_type_store_ipv6_address_prefix(const struct ly_ctx *ctx, const struct lysc_type *type, const void *value,
        uint64_t value_size_bits, uint32_t options, LY_VALUE_FORMAT format, void *UNUSED(prefix_data), uint32_t hints,
        const struct lysc_node *UNUSED(ctx_node), struct lyd_value *storage, struct lys_glob_unres *UNUSED(unres),
        struct ly_err_item **err)
{
    LY_ERR ret = LY_SUCCESS;
    const struct lysc_type_str *type_str = (struct lysc_type_str *)type;
    struct lyd_value_ipv6_prefix *val;
    uint32_t value_size;

    /* init storage */
    memset(storage, 0, sizeof *storage);
    storage->realtype = type;

    /* check value length */
    ret = lyplg_type_check_value_size(type->name, format, value_size_bits, LYPLG_LYB_SIZE_FIXED_BITS,
            LYPLG_IPV6PREF_LYB_VALUE_SIZE, &value_size, err);
    LY_CHECK_GOTO(ret, cleanup);

    if (format == LY_VALUE_LYB) {
        /* validation */
        if (((uint8_t *)value)[16] > 128) {
            ret = ly_err_new(err, LY_EVALID, LYVE_DATA, NULL, NULL, "Invalid LYB %s prefix length %" PRIu8 ".",
                    type->name, ((uint8_t *)value)[16]);
            goto cleanup;
        }

        /* store/allocate value */
        if ((options & LYPLG_TYPE_STORE_DYNAMIC) && LYPLG_TYPE_VAL_IS_DYN(val)) {
            storage->dyn_mem = (void *)value;
            options &= ~LYPLG_TYPE_STORE_DYNAMIC;

            LYD_VALUE_GET(storage, val);
        } else {
            LYPLG_TYPE_VAL_INLINE_PREPARE(storage, val);
            LY_CHECK_ERR_GOTO(!val, ret = ly_err_new_no_mem(err), cleanup);

            memcpy(val, value, value_size);
        }

        if (!strcmp(type->name, "ipv6-prefix")) {
            /* zero host */
            ipv6prefix_zero_host(&val->addr, val->prefix);
        }

        /* success */
        goto cleanup;
    }

    /* allocate value */
    LYPLG_TYPE_VAL_INLINE_PREPARE(storage, val);
    LY_CHECK_ERR_GOTO(!val, ret = ly_err_new_no_mem(err), cleanup);

    /* check hints */
    ret = lyplg_type_check_hints(hints, value, value_size, type->basetype, NULL, err);
    LY_CHECK_GOTO(ret, cleanup);

    if (!(options & LYPLG_TYPE_STORE_ONLY)) {
        /* length restriction of the string */
        if (type_str->length) {
            ret = lyplg_type_validate_range(LY_TYPE_STRING, type_str->length, value_size, value, value_size, err);
            LY_CHECK_GOTO(ret, cleanup);
        }

        /* validate patterns */
        ret = lyplg_type_validate_patterns(ctx, type_str->patterns, value, value_size, err);
        LY_CHECK_GOTO(ret, cleanup);
    }

    /* get the mask in network-byte order */
    ret = ipv6prefix_str2ip(value, value_size, val, err);
    LY_CHECK_GOTO(ret, cleanup);

    if (!strcmp(type->name, "ipv6-prefix")) {
        /* zero host */
        ipv6prefix_zero_host(&val->addr, val->prefix);
    }

    if (format == LY_VALUE_CANON) {
        /* store canonical value */
        if (options & LYPLG_TYPE_STORE_DYNAMIC) {
            ret = lydict_insert_zc(ctx, (char *)value, &storage->_canonical);
            options &= ~LYPLG_TYPE_STORE_DYNAMIC;
            LY_CHECK_GOTO(ret, cleanup);
        } else {
            ret = lydict_insert(ctx, value_size ? value : "", value_size, &storage->_canonical);
            LY_CHECK_GOTO(ret, cleanup);
        }
    }

cleanup:
    if (options & LYPLG_TYPE_STORE_DYNAMIC) {
        free((void *)value);
    }

    if (ret) {
        lyplg_type_free_ipv6_address_prefix(ctx, storage);
    }
    return ret;
}

/**
 * @brief Implementation of ::lyplg_type_compare_clb for the ietf-inet-types ipv6-prefix and ipv6-address-and-prefix type.
 */
static LY_ERR
lyplg_type_compare_ipv6_address_prefix(const struct ly_ctx *UNUSED(ctx), const struct lyd_value *val1,
        const struct lyd_value *val2)
{
    struct lyd_value_ipv6_prefix *v1, *v2;

    LYD_VALUE_GET(val1, v1);
    LYD_VALUE_GET(val2, v2);

    if (memcmp(v1, v2, sizeof *v1)) {
        return LY_ENOT;
    }
    return LY_SUCCESS;
}

/**
 * @brief Implementation of ::lyplg_type_sort_clb for the ietf-inet-types ipv6-prefix and ipv6-address-and-prefix type.
 */
static int
lyplg_type_sort_ipv6_address_prefix(const struct ly_ctx *UNUSED(ctx), const struct lyd_value *val1,
        const struct lyd_value *val2)
{
    struct lyd_value_ipv6_prefix *v1, *v2;

    LYD_VALUE_GET(val1, v1);
    LYD_VALUE_GET(val2, v2);

    return memcmp(v1, v2, sizeof *v1);
}

/**
 * @brief Implementation of ::lyplg_type_compare_clb for the ietf-inet-types ipv6-prefix and ipv6-address-and-prefix type.
 */
static const void *
lyplg_type_print_ipv6_address_prefix(const struct ly_ctx *ctx, const struct lyd_value *value, LY_VALUE_FORMAT format,
        void *UNUSED(prefix_data), ly_bool *dynamic, uint64_t *value_size_bits)
{
    struct lyd_value_ipv6_prefix *val;
    char *ret;

    LYD_VALUE_GET(value, val);

    if (format == LY_VALUE_LYB) {
        *dynamic = 0;
        if (value_size_bits) {
            *value_size_bits = LYPLG_IPV6PREF_LYB_VALUE_SIZE;
        }
        return val;
    }

    /* generate canonical value if not already */
    if (!value->_canonical) {
        /* IPv6 mask + '/' + prefix */
        ret = malloc(INET6_ADDRSTRLEN + 4);
        LY_CHECK_RET(!ret, NULL);

        /* convert back to string */
        if (!inet_ntop(AF_INET6, &val->addr, ret, INET6_ADDRSTRLEN)) {
            free(ret);
            return NULL;
        }

        /* add the prefix */
        sprintf(ret + strlen(ret), "/%" PRIu8, val->prefix);

        /* store it */
        if (lydict_insert_zc(ctx, ret, (const char **)&value->_canonical)) {
            LOGMEM(ctx);
            return NULL;
        }
    }

    /* use the cached canonical value */
    if (dynamic) {
        *dynamic = 0;
    }
    if (value_size_bits) {
        *value_size_bits = strlen(value->_canonical) * 8;
    }
    return value->_canonical;
}

/**
 * @brief Implementation of ::lyplg_type_dup_clb for the ietf-inet-types ipv6-prefix and ipv6-address-and-prefix type.
 */
static LY_ERR
lyplg_type_dup_ipv6_address_prefix(const struct ly_ctx *ctx, const struct lyd_value *original, struct lyd_value *dup)
{
    LY_ERR ret;
    struct lyd_value_ipv6_prefix *orig_val, *dup_val;

    memset(dup, 0, sizeof *dup);

    ret = lydict_insert(ctx, original->_canonical, 0, &dup->_canonical);
    LY_CHECK_GOTO(ret, error);

    LYPLG_TYPE_VAL_INLINE_PREPARE(dup, dup_val);
    LY_CHECK_ERR_GOTO(!dup_val, ret = LY_EMEM, error);

    LYD_VALUE_GET(original, orig_val);
    memcpy(dup_val, orig_val, sizeof *orig_val);

    dup->realtype = original->realtype;
    return LY_SUCCESS;

error:
    lyplg_type_free_ipv6_address_prefix(ctx, dup);
    return ret;
}

/**
 * @brief Implementation of ::lyplg_type_free_clb for the ietf-inet-types ipv6-prefix and ipv6-address-and-prefix type.
 */
static void
lyplg_type_free_ipv6_address_prefix(const struct ly_ctx *ctx, struct lyd_value *value)
{
    struct lyd_value_ipv6_prefix *val;

    lydict_remove(ctx, value->_canonical);
    value->_canonical = NULL;
    LYD_VALUE_GET(value, val);
    LYPLG_TYPE_VAL_INLINE_DESTROY(val);
}

/**
 * @brief Plugin information for ipv6-prefix and ipv6-address-and-prefix type implementation.
 *
 * Note that external plugins are supposed to use:
 *
 *   LYPLG_TYPES = {
 */
const struct lyplg_type_record plugins_ipv6_address_prefix[] = {
    {
        .module = "ietf-inet-types",
        .revision = NULL,
        .name = "ipv6-prefix",

        .plugin.id = "ly2 ipv6-address-prefix",
        .plugin.lyb_size = lyplg_type_lyb_size_ipv6_address_prefix,
        .plugin.store = lyplg_type_store_ipv6_address_prefix,
        .plugin.validate_value = NULL,
        .plugin.validate_tree = NULL,
        .plugin.compare = lyplg_type_compare_ipv6_address_prefix,
        .plugin.sort = lyplg_type_sort_ipv6_address_prefix,
        .plugin.print = lyplg_type_print_ipv6_address_prefix,
        .plugin.duplicate = lyplg_type_dup_ipv6_address_prefix,
        .plugin.free = lyplg_type_free_ipv6_address_prefix,
    },
    {
        .module = "ietf-inet-types",
        .revision = NULL,
        .name = "ipv6-address-and-prefix",

        .plugin.id = "ly2 ipv6-address-prefix",
        .plugin.lyb_size = lyplg_type_lyb_size_ipv6_address_prefix,
        .plugin.store = lyplg_type_store_ipv6_address_prefix,
        .plugin.validate_value = NULL,
        .plugin.validate_tree = NULL,
        .plugin.compare = lyplg_type_compare_ipv6_address_prefix,
        .plugin.sort = lyplg_type_sort_ipv6_address_prefix,
        .plugin.print = lyplg_type_print_ipv6_address_prefix,
        .plugin.duplicate = lyplg_type_dup_ipv6_address_prefix,
        .plugin.free = lyplg_type_free_ipv6_address_prefix,
    },
    {0}
};
