/**
 * @file schema_diff_change_full.c
 * @author Michal Vasko <mvasko@cesnet.cz>
 * @brief Schema diff change fully resolved module functions
 *
 * Copyright (c) 2025 - 2026 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */

#include "schema_diff.h"

#include <assert.h>
#include <stdlib.h>

#include "ly_common.h"
#include "tree_schema_internal.h"
#include "xpath.h"

static LY_ERR schema_diff_node_type_change(const struct lysc_type *type1, const struct lysc_type *type2,
        enum lys_diff_changed_e parent_changed, struct lys_diff_changes_s *changes,
        struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_s *diff);

/**
 * @brief Add a new schema node change pair.
 *
 * @param[in] snode_old Old changed schema node.
 * @param[in] snode_new New changed schema node.
 * @param[in,out] diff Diff to use and add to.
 * @param[out] node_change Added node change structure.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_add_node_change(const struct lysc_node *snode_old, const struct lysc_node *snode_new, struct lys_diff_s *diff,
        struct lys_diff_node_change_s **node_change)
{
    void *mem;
    struct lys_diff_node_change_s *nc;

    /* add new node_change */
    mem = realloc(diff->node_changes, (diff->node_change_count + 1) * sizeof *diff->node_changes);
    LY_CHECK_ERR_RET(!mem, LOGMEM(NULL), LY_EMEM);
    diff->node_changes = mem;
    nc = &diff->node_changes[diff->node_change_count];
    ++diff->node_change_count;

    /* fill new node_change */
    nc->snode_old = snode_old;
    nc->snode_new = snode_new;
    nc->changes.changes = NULL;
    nc->changes.count = 0;
    nc->ext_changes.changes = NULL;
    nc->ext_changes.count = 0;
    nc->pext_changes.changes = NULL;
    nc->pext_changes.count = 0;

    *node_change = nc;
    return LY_SUCCESS;
}

/**
 * @brief Add a new ext-instance change pair.
 *
 * @param[in] ext_old Old changed ext-instance.
 * @param[in] ext_new New changed ext-instance.
 * @param[in,out] ext_changes Ext-instance changes to add to.
 * @param[out] ext_change Added ext-instance change structure.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_add_ext_change(const struct lysc_ext_instance *ext_old, const struct lysc_ext_instance *ext_new,
        struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_ext_change_s **ext_change)
{
    void *mem;
    struct lys_diff_ext_change_s *ec;

    /* add new ext_change */
    mem = realloc(ext_changes->changes, (ext_changes->count + 1) * sizeof *ext_changes->changes);
    LY_CHECK_ERR_RET(!mem, LOGMEM(NULL), LY_EMEM);
    ext_changes->changes = mem;
    ec = &ext_changes->changes[ext_changes->count];
    ++ext_changes->count;

    /* fill new ext_change */
    ec->ext_old = ext_old;
    ec->ext_new = ext_new;
    ec->changes.changes = NULL;
    ec->changes.count = 0;

    *ext_change = ec;
    return LY_SUCCESS;
}

/**
 * @brief Check what conformance is signified by an extension.
 *
 * @param[in] ext Ext instance to check.
 * @param[in] default_conform Conformance to return if @p ext is not a relevant extension.
 * @param[out] is_conform_ext Optional flag set if @p ext is a conformance ext instance.
 * @return Conformance of the extension.
 */
static enum lys_diff_conform_e
schema_diff_is_ext_conform(const struct lysc_ext_instance *ext, enum lys_diff_conform_e default_conform,
        ly_bool *is_conform_ext)
{
    if (!strcmp(ext->def->module->name, "ietf-yang-schema-comparison")) {
        if (!strcmp(ext->def->name, "ed-change-at")) {
            if (is_conform_ext) {
                *is_conform_ext = 1;
            }
            return LYS_CONFORM_ED;
        } else if (!strcmp(ext->def->name, "bc-change-at")) {
            if (is_conform_ext) {
                *is_conform_ext = 1;
            }
            return LYS_CONFORM_BC;
        } else if (!strcmp(ext->def->name, "nbc-change-at")) {
            if (is_conform_ext) {
                *is_conform_ext = 1;
            }
            return LYS_CONFORM_NBC;
        }
    }

    if (is_conform_ext) {
        *is_conform_ext = 0;
    }
    return default_conform;
}

/**
 * @brief Check extensions for an explicit conformance extension and return it.
 *
 * @param[in] exts Sized-array of extension-instances.
 * @param[in] parent_stmt Optional parent statement to only consider.
 * @param[in] default_conform Conformance to return if no @p exts are relevant extensions.
 * @param[out] has_conform_ext Optional flag set in case a relevant extension is found.
 * @return Found conformance.
 */
static enum lys_diff_conform_e
schema_diff_exts_conform(const struct lysc_ext_instance *exts, enum ly_stmt parent_stmt,
        enum lys_diff_conform_e default_conform, ly_bool *has_conform_ext)
{
    LYA_COUNT_T u;
    enum lys_diff_conform_e conform;
    ly_bool is_conform_ext;

    if (has_conform_ext) {
        *has_conform_ext = 1;
    }

    LYA_FOR(exts, u) {
        if (parent_stmt && (exts[u].parent_stmt != parent_stmt)) {
            continue;
        }

        conform = schema_diff_is_ext_conform(&exts[u], default_conform, &is_conform_ext);
        if (is_conform_ext) {
            return conform;
        }
    }

    if (has_conform_ext) {
        *has_conform_ext = 0;
    }
    return default_conform;
}

/**
 * @brief Check changes of a 'description'.
 *
 * @param[in] text1 First description.
 * @param[in] dsc2 Second description.
 * @param[in] exts2 Extension instances of the second statement.
 * @param[in] stmt Changed statement.
 * @param[in] parent_changed Parent statement of the change.
 * @param[in,out] changes Changes to add to.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_text(const char *text1, const char *text2, const struct lysc_ext_instance *exts2,
        enum ly_stmt stmt, enum lys_diff_changed_e parent_changed, struct lys_diff_changes_s *changes)
{
    enum lys_diff_conform_e conform;

    if (text1 && !text2) {
        /* removed, always NBC */
        LY_CHECK_RET(schema_diff_add_change(LYS_CHANGE_REMOVED, parent_changed, schema_diff_stmt2changed(stmt),
                LYS_CONFORM_NBC, changes));
    } else if (!text1 && text2) {
        /* added */
        LY_CHECK_RET(schema_diff_add_change(LYS_CHANGE_ADDED, parent_changed, schema_diff_stmt2changed(stmt),
                LYS_CONFORM_BC, changes));
    } else if (text1 && text2 && strcmp(text1, text2)) {
        /* modified, look for extensions */
        conform = schema_diff_exts_conform(exts2, stmt, LYS_CONFORM_ED, NULL);
        LY_CHECK_RET(schema_diff_add_change(LYS_CHANGE_MODIFIED, parent_changed, schema_diff_stmt2changed(stmt), conform,
                changes));
    }

    return LY_SUCCESS;
}

/**
 * @brief Check changes of 'must' arrays.
 *
 * @param[in] musts1 First must array.
 * @param[in] musts2 Second must array.
 * @param[in] parent_changed Parent statement of the change.
 * @param[in,out] changes Changes to add to.
 * @param[in,out] ext_changes Ext-instance changes to add to.
 * @param[in,out] diff Diff to use.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_musts_change(const struct lysc_must *musts1, const struct lysc_must *musts2,
        enum lys_diff_changed_e parent_changed, struct lys_diff_changes_s *changes,
        struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_s *diff)
{
    LY_ERR rc = LY_SUCCESS;
    LYA_COUNT_T u, v;
    ly_bool found, *must2_found = NULL;

    /* prepare array for marking found musts */
    must2_found = calloc(LYA_COUNT(musts2), sizeof *must2_found);
    LY_CHECK_ERR_GOTO(!must2_found, LOGMEM(NULL); rc = LY_EMEM, cleanup)

    LYA_FOR(musts1, u) {
        found = 0;
        LYA_FOR(musts2, v) {
            if (must2_found[v]) {
                continue;
            }

            /* condition */
            if (!strcmp(lyxp_get_expr(musts1[u].cond), lyxp_get_expr(musts2[v].cond))) {
                /* found */
                found = 1;
                must2_found[v] = 1;
                break;
            }
        }
        if (!found) {
            /* removed */
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, parent_changed, LYS_CHANGED_MUST,
                    LYS_CONFORM_BC, changes), cleanup);
            continue;
        }

        /* description, reference, error-message, error-app-tag */
        LY_CHECK_GOTO(rc = schema_diff_text(musts1[u].dsc, musts2[v].dsc, musts2[v].exts, LY_STMT_DESCRIPTION,
                LYS_CHANGED_MUST, changes), cleanup);
        LY_CHECK_GOTO(rc = schema_diff_text(musts1[u].ref, musts2[v].ref, musts2[v].exts, LY_STMT_REFERENCE,
                LYS_CHANGED_MUST, changes), cleanup);
        LY_CHECK_GOTO(rc = schema_diff_text_nbc(musts1[u].emsg, musts2[v].emsg, LYS_CHANGED_MUST, LYS_CHANGED_ERR_MSG,
                changes), cleanup);
        LY_CHECK_GOTO(rc = schema_diff_text_nbc(musts1[u].eapptag, musts2[v].eapptag, LYS_CHANGED_MUST,
                LYS_CHANGED_ERR_APP_TAG, changes), cleanup);

        /* ext-instance */
        LY_CHECK_GOTO(rc = schema_diff_ext_insts_change(musts1[u].exts, musts2[v].exts, ext_changes, diff), cleanup);
    }

    LYA_FOR(musts2, v) {
        if (must2_found[v]) {
            continue;
        }

        /* added, detect compatibility by the extension presence */
        LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_ADDED, parent_changed, LYS_CHANGED_MUST,
                schema_diff_exts_conform(musts2[v].exts, LY_STMT_MUST, LYS_CONFORM_NBC, NULL), changes), cleanup);
    }

cleanup:
    free(must2_found);
    return rc;
}

/**
 * @brief Check changes of a 'mandatory'.
 *
 * @param[in] flags1 First flags.
 * @param[in] flags2 Second flags.
 * @param[in] parent_changed Parent statement of the change.
 * @param[in,out] changes Changes to add to.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_mandatory_change(uint16_t flags1, uint16_t flags2, enum lys_diff_changed_e parent_changed,
        struct lys_diff_changes_s *changes)
{
    if ((flags1 & LYS_MAND_TRUE) && !(flags2 & LYS_MAND_TRUE)) {
        LY_CHECK_RET(schema_diff_add_change(LYS_CHANGE_REMOVED, parent_changed, LYS_CHANGED_MANDATORY, LYS_CONFORM_BC,
                changes));
    } else if (!(flags1 & LYS_MAND_TRUE) && (flags2 & LYS_MAND_TRUE)) {
        LY_CHECK_RET(schema_diff_add_change(LYS_CHANGE_ADDED, parent_changed, LYS_CHANGED_MANDATORY, LYS_CONFORM_NBC,
                changes));
    }

    return LY_SUCCESS;
}

/**
 * @brief Check changes of a 'odrered-by'.
 *
 * @param[in] flags1 First flags.
 * @param[in] flags2 Second flags.
 * @param[in] parent_changed Parent statement of the change.
 * @param[in,out] changes Changes to add to.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_ordby_change(uint16_t flags1, uint16_t flags2, enum lys_diff_changed_e parent_changed,
        struct lys_diff_changes_s *changes)
{
    if ((flags1 & LYS_ORDBY_MASK) != (flags2 & LYS_ORDBY_MASK)) {
        LY_CHECK_RET(schema_diff_add_change(LYS_CHANGE_MODIFIED, parent_changed, LYS_CHANGED_ORDERED_BY,
                LYS_CONFORM_NBC, changes));
    }

    return LY_SUCCESS;
}

/**
 * @brief Check changes of leaf-list 'default' arrays.
 *
 * @param[in] llist1 First leaf-list.
 * @param[in] llist2 Second leaf-list.
 * @param[in] parent_changed Parent statement of the change.
 * @param[in,out] changes Changes to add to.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_defaults_change(const struct lysc_node_leaflist *llist1, const struct lysc_node_leaflist *llist2,
        enum lys_diff_changed_e parent_changed, struct lys_diff_changes_s *changes)
{
    LY_ERR rc = LY_SUCCESS;
    LYA_COUNT_T u, v;
    ly_bool found, *dflt2_found = NULL;

    /* prepare array for marking found defaults */
    dflt2_found = calloc(LYA_COUNT(llist2->dflts), sizeof *dflt2_found);
    LY_CHECK_ERR_GOTO(!dflt2_found, LOGMEM(NULL); rc = LY_EMEM, cleanup);

    LYA_FOR(llist1->dflts, u) {
        found = 0;
        LYA_FOR(llist2->dflts, v) {
            if (dflt2_found[v]) {
                continue;
            }

            /* value */
            if (!strcmp(llist1->dflts[u].str, llist2->dflts[v].str)) {
                found = 1;
                dflt2_found[v] = 1;
                break;
            }
        }

        if (!found) {
            /* removed */
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, parent_changed, LYS_CHANGED_DEFAULT,
                    LYS_CONFORM_NBC, changes), cleanup);
            continue;
        }
    }

    LYA_FOR(llist2->dflts, v) {
        if (dflt2_found[v]) {
            continue;
        }

        /* added */
        LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_ADDED, parent_changed, LYS_CHANGED_DEFAULT, LYS_CONFORM_NBC,
                changes), cleanup);
    }

cleanup:
    free(dflt2_found);
    return rc;
}

/**
 * @brief Check changes of a 'when'.
 *
 * @param[in] when1 First when.
 * @param[in] when2 Second when.
 * @param[in] parent_changed Parent statement of the change.
 * @param[in,out] changes Changes to add to.
 * @param[in,out] ext_changes Ext-instance changes to add to.
 * @param[in,out] diff Diff to use.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_when_change(const struct lysc_when *when1, const struct lysc_when *when2,
        enum lys_diff_changed_e parent_changed, struct lys_diff_changes_s *changes,
        struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_s *diff)
{
    LY_ERR rc = LY_SUCCESS;
    enum lys_diff_conform_e conform;

    if (!when1 && !when2) {
        return LY_SUCCESS;
    } else if (!when1) {
        /* added, detect compatibility by the extension presence */
        if (diff->is_yang10) {
            conform = LYS_CONFORM_NBC;
        } else {
            conform = schema_diff_exts_conform(when2->exts, LY_STMT_WHEN, LYS_CONFORM_NBC, NULL);
        }
        return schema_diff_add_change(LYS_CHANGE_ADDED, parent_changed, LYS_CHANGED_WHEN, conform, changes);
    } else if (!when2) {
        /* removed, NBC for YANG 1.0 */
        return schema_diff_add_change(LYS_CHANGE_REMOVED, parent_changed, LYS_CHANGED_WHEN,
                diff->is_yang10 ? LYS_CONFORM_NBC : LYS_CONFORM_BC, changes);
    }

    /* condition */
    if (strcmp(lyxp_get_expr(when1->cond), lyxp_get_expr(when2->cond))) {
        /* modified, detect compatibility by the extension presence */
        if (diff->is_yang10) {
            conform = LYS_CONFORM_NBC;
        } else {
            conform = schema_diff_exts_conform(when2->exts, LY_STMT_WHEN, LYS_CONFORM_NBC, NULL);
        }
        LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_MODIFIED, parent_changed, LYS_CHANGED_WHEN, conform,
                changes), cleanup);
    }

    /* description, reference */
    LY_CHECK_GOTO(rc = schema_diff_text(when1->dsc, when2->dsc, when2->exts, LY_STMT_DESCRIPTION, LYS_CHANGED_WHEN,
            changes), cleanup);
    LY_CHECK_GOTO(rc = schema_diff_text(when1->ref, when2->ref, when2->exts, LY_STMT_REFERENCE, LYS_CHANGED_WHEN,
            changes), cleanup);

    /* status */
    LY_CHECK_GOTO(rc = schema_diff_status_change(when1->flags, when2->flags, LYS_CHANGED_WHEN, changes), cleanup);

    /* ext-instance */
    LY_CHECK_GOTO(rc = schema_diff_ext_insts_change(when1->exts, when2->exts, ext_changes, diff), cleanup);

cleanup:
    return rc;
}

/**
 * @brief Check changes of 'unique' arrays.
 *
 * @param[in] uniques1 First unique array.
 * @param[in] uniques2 Second unique array.
 * @param[in,out] changes Changes to add to.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_uniques_change(struct lysc_node_leaf ***uniques1, struct lysc_node_leaf ***uniques2,
        struct lys_diff_changes_s *changes)
{
    LY_ERR rc = LY_SUCCESS;
    LYA_COUNT_T i, u, v;
    ly_bool found, *unique2_found = NULL;
    const struct lysc_node_leaf *term1, *term2;

    LYA_FOR(uniques1, i) {
        if (LYA_COUNT(uniques2) == i) {
            break;
        }

        /* prepare array for marking found uniques */
        unique2_found = calloc(LYA_COUNT(uniques2[i]), sizeof *unique2_found);
        LY_CHECK_ERR_GOTO(!unique2_found, LOGMEM(NULL); rc = LY_EMEM, cleanup);

        LYA_FOR(uniques1[i], u) {
            found = 0;
            LYA_FOR(uniques2[i], v) {
                if (unique2_found[v]) {
                    continue;
                }

                term1 = uniques1[i][u];
                term2 = uniques2[i][v];

                /* leaf node */
                if (!strcmp(term1->module->name, term2->module->name) && !strcmp(term1->name, term2->name)) {
                    /* found */
                    found = 1;
                    unique2_found[v] = 1;
                    break;
                }
            }

            if (!found) {
                /* removed */
                LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, LYS_CHANGED_NONE, LYS_CHANGED_UNIQUE,
                        LYS_CONFORM_NBC, changes), cleanup);
            }
        }

        LYA_FOR(uniques2[i], v) {
            if (unique2_found[v]) {
                continue;
            }

            /* added */
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_ADDED, LYS_CHANGED_NONE, LYS_CHANGED_UNIQUE,
                    LYS_CONFORM_NBC, changes), cleanup);
        }

        free(unique2_found);
        unique2_found = NULL;
    }

    if (i == LYA_COUNT(uniques1)) {
        /* added */
        while (i < LYA_COUNT(uniques2)) {
            LYA_FOR(uniques2[i], v) {
                LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_ADDED, LYS_CHANGED_NONE, LYS_CHANGED_UNIQUE,
                        LYS_CONFORM_NBC, changes), cleanup);
            }

            ++i;
        }
    } else {
        /* removed */
        assert(i == LYA_COUNT(uniques2));
        while (i < LYA_COUNT(uniques1)) {
            LYA_FOR(uniques1[i], u) {
                LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, LYS_CHANGED_NONE, LYS_CHANGED_UNIQUE,
                        LYS_CONFORM_NBC, changes), cleanup);
            }
        }
    }

cleanup:
    free(unique2_found);
    return rc;
}

LY_ERR
schema_diff_node_type_range_change(const struct lysc_range *range1, const struct lysc_range *range2, ly_bool sign,
        enum lys_diff_changed_e parent_changed, struct lys_diff_changes_s *changes,
        struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_s *diff)
{
    int match, part_match;
    LYA_COUNT_T u, v;
    int64_t min1_s, max1_s, min2_s, max2_s;
    uint64_t min1_u, max1_u, min2_u, max2_u;

    if (!range1 && !range2) {
        return LY_SUCCESS;
    } else if (!range1) {
        /* added */
        return schema_diff_add_change(LYS_CHANGE_ADDED, parent_changed,
                sign ? LYS_CHANGED_RANGE : LYS_CHANGED_LENGTH, LYS_CONFORM_NBC, changes);
    } else if (!range2) {
        /* removed */
        return schema_diff_add_change(LYS_CHANGE_REMOVED, parent_changed,
                sign ? LYS_CHANGED_RANGE : LYS_CHANGED_LENGTH, LYS_CONFORM_BC, changes);
    }

    /* parts (intervals) */
    match = 0;
    LYA_FOR(range1->parts, u) {
        if (sign) {
            min1_s = range1->parts[u].min_64;
            max1_s = range1->parts[u].max_64;
        } else {
            min1_u = range1->parts[u].min_u64;
            max1_u = range1->parts[u].max_u64;
        }

        /* find an interval with this min and max */
        part_match = 0;
        LYA_FOR(range2->parts, v) {
            if (sign) {
                min2_s = range2->parts[v].min_64;
                max2_s = range2->parts[v].max_64;

                if ((min2_s == min1_s) && (max2_s == max1_s)) {
                    /* exact match */
                    part_match = 2;
                    break;
                } else if ((min2_s <= min1_s) && (max2_s >= max1_s)) {
                    /* larger interval */
                    part_match = 1;
                    break;
                }
            } else {
                min2_u = range2->parts[v].min_u64;
                max2_u = range2->parts[v].max_u64;

                if ((min2_u == min1_u) && (max2_u == max1_u)) {
                    /* exact match */
                    part_match = 2;
                    break;
                } else if ((min2_u <= min1_u) && (max2_u >= max1_u)) {
                    /* larger interval */
                    part_match = 1;
                    break;
                }
            }
        }

        /* store the partial result */
        if ((match == 0) || (part_match < 2)) {
            match = part_match;
        }

        if (!match) {
            /* final result */
            break;
        }
    }

    if (match == 0) {
        /* NBC change */
        LY_CHECK_RET(schema_diff_add_change(LYS_CHANGE_MODIFIED, parent_changed,
                sign ? LYS_CHANGED_RANGE : LYS_CHANGED_LENGTH, LYS_CONFORM_NBC, changes));
    } else if (match == 1) {
        /* BC change */
        LY_CHECK_RET(schema_diff_add_change(LYS_CHANGE_MODIFIED, parent_changed,
                sign ? LYS_CHANGED_RANGE : LYS_CHANGED_LENGTH, LYS_CONFORM_BC, changes));
    }

    /* description, reference, error-message, error-app-tag */
    LY_CHECK_RET(schema_diff_text(range1->dsc, range2->dsc, range2->exts, LY_STMT_DESCRIPTION, LYS_CHANGED_TYPE,
            changes));
    LY_CHECK_RET(schema_diff_text(range1->ref, range2->ref, range2->exts, LY_STMT_REFERENCE, LYS_CHANGED_TYPE,
            changes));
    LY_CHECK_RET(schema_diff_text_nbc(range1->emsg, range2->emsg, LYS_CHANGED_TYPE, LYS_CHANGED_ERR_MSG, changes));
    LY_CHECK_RET(schema_diff_text_nbc(range1->eapptag, range2->eapptag, LYS_CHANGED_TYPE, LYS_CHANGED_ERR_APP_TAG,
            changes));

    /* ext-instance */
    LY_CHECK_RET(schema_diff_ext_insts_change(range1->exts, range2->exts, ext_changes, diff));

    return LY_SUCCESS;
}

/**
 * @brief Check changes of 'pattern' arrays.
 *
 * @param[in] patterns1 First pattern array.
 * @param[in] patterns2 Second pattern array.
 * @param[in] parent_changed Parent statement of the change.
 * @param[in,out] changes Changes to add to.
 * @param[in,out] ext_changes Ext-instance changes to add to.
 * @param[in,out] diff Diff to use.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_type_patterns_change(struct lysc_pattern **patterns1, struct lysc_pattern **patterns2,
        enum lys_diff_changed_e parent_changed, struct lys_diff_changes_s *changes,
        struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_s *diff)
{
    LY_ERR rc = LY_SUCCESS;
    LYA_COUNT_T u, v;
    ly_bool found, *pattern2_found = NULL;

    /* prepare array for marking found patterns */
    pattern2_found = calloc(LYA_COUNT(patterns2), sizeof *pattern2_found);
    LY_CHECK_ERR_GOTO(!pattern2_found, LOGMEM(NULL); rc = LY_EMEM, cleanup);

    LYA_FOR(patterns1, u) {
        found = 0;
        LYA_FOR(patterns2, v) {
            if (pattern2_found[v]) {
                continue;
            }

            /* pattern */
            if (!strcmp(patterns1[u]->expr, patterns2[v]->expr)) {
                /* found */
                found = 1;
                pattern2_found[v] = 1;
                break;
            }
        }
        if (!found) {
            /* removed, always BC */
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, parent_changed, LYS_CHANGED_PATTERN,
                    LYS_CONFORM_BC, changes), cleanup);
            continue;
        }

        /* description, reference, error-message, error-app-tag */
        LY_CHECK_GOTO(rc = schema_diff_text(patterns1[u]->dsc, patterns2[v]->dsc, patterns2[v]->exts,
                LY_STMT_DESCRIPTION, LYS_CHANGED_PATTERN, changes), cleanup);
        LY_CHECK_GOTO(rc = schema_diff_text(patterns1[u]->ref, patterns2[v]->ref, patterns2[v]->exts,
                LY_STMT_REFERENCE, LYS_CHANGED_PATTERN, changes), cleanup);
        LY_CHECK_GOTO(rc = schema_diff_text_nbc(patterns1[u]->emsg, patterns2[v]->emsg, LYS_CHANGED_PATTERN,
                LYS_CHANGED_ERR_MSG, changes), cleanup);
        LY_CHECK_GOTO(rc = schema_diff_text_nbc(patterns1[u]->eapptag, patterns2[v]->eapptag, LYS_CHANGED_PATTERN,
                LYS_CHANGED_ERR_APP_TAG, changes), cleanup);

        /* ext-instance */
        LY_CHECK_GOTO(rc = schema_diff_ext_insts_change(patterns1[u]->exts, patterns2[v]->exts, ext_changes, diff), cleanup);

        /* inverted */
        if (patterns1[u]->inverted != patterns2[v]->inverted) {
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_MODIFIED, parent_changed, LYS_CHANGED_PATTERN,
                    LYS_CONFORM_NBC, changes), cleanup);
        }
    }

    LYA_FOR(patterns2, v) {
        if (pattern2_found[v]) {
            continue;
        }

        /* added, detect compatibility by the extension presence */
        LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_ADDED, parent_changed, LYS_CHANGED_PATTERN,
                schema_diff_exts_conform(patterns2[v]->exts, LY_STMT_PATTERN, LYS_CONFORM_NBC, NULL), changes), cleanup);
    }

cleanup:
    free(pattern2_found);
    return rc;
}

/**
 * @brief Check changes of 'bit' or 'enum' arrays.
 *
 * @param[in] bitenums1 First bit/enum array.
 * @param[in] bitenums2 Second bit/enum array.
 * @param[in] parent_changed Parent statement of the change.
 * @param[in,out] changes Changes to add to.
 * @param[in,out] ext_changes Ext-instance changes to add to.
 * @param[in,out] diff Diff to use.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_type_bitenum_change(const struct lysc_type_bitenum_item *bitenums1,
        const struct lysc_type_bitenum_item *bitenums2, enum lys_diff_changed_e parent_changed,
        struct lys_diff_changes_s *changes, struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_s *diff)
{
    LY_ERR rc = LY_SUCCESS;
    LYA_COUNT_T u, v;
    ly_bool found, *bitenum2_found = NULL;
    enum lys_diff_changed_e changed = LYS_CHANGED_NONE;

    /* enum or bit */
    assert(bitenums1 && bitenums2);
    if (bitenums1[0].flags & LYS_IS_ENUM) {
        changed = LYS_CHANGED_ENUM;
    } else {
        changed = LYS_CHANGED_BIT;
    }

    /* prepare array for marking found bitenums */
    bitenum2_found = calloc(LYA_COUNT(bitenums2), sizeof *bitenum2_found);
    LY_CHECK_ERR_GOTO(!bitenum2_found, LOGMEM(NULL); rc = LY_EMEM, cleanup);

    LYA_FOR(bitenums1, u) {
        found = 0;
        LYA_FOR(bitenums2, v) {
            if (bitenum2_found[v]) {
                continue;
            }

            /* name */
            if (!strcmp(bitenums1[u].name, bitenums2[v].name)) {
                /* found */
                found = 1;
                bitenum2_found[v] = 1;
                break;
            }
        }

        if (!found) {
            /* removed */
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, parent_changed, changed, LYS_CONFORM_NBC,
                    changes), cleanup);
            continue;
        }

        /* description */
        LY_CHECK_GOTO(rc = schema_diff_text(bitenums1[u].dsc, bitenums2[v].dsc, bitenums2[v].exts, LY_STMT_DESCRIPTION,
                changed, changes), cleanup);

        /* reference */
        LY_CHECK_GOTO(rc = schema_diff_text(bitenums1[u].ref, bitenums2[v].ref, bitenums2[v].exts, LY_STMT_REFERENCE,
                changed, changes), cleanup);

        /* if-features not supported */

        /* ext-instance */
        LY_CHECK_GOTO(rc = schema_diff_ext_insts_change(bitenums1[u].exts, bitenums2[v].exts, ext_changes, diff), cleanup);

        /* value/position, does not matter */
        if (bitenums1[u].value != bitenums2[v].value) {
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_MODIFIED, parent_changed, changed, LYS_CONFORM_NBC,
                    changes), cleanup);
        }

        /* status */
        LY_CHECK_GOTO(rc = schema_diff_status_change(bitenums1[u].flags, bitenums2[v].flags, changed, changes),
                cleanup);
    }

    LYA_FOR(bitenums2, v) {
        if (bitenum2_found[v]) {
            continue;
        }

        /* added */
        LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_ADDED, parent_changed, changed, LYS_CONFORM_BC, changes),
                cleanup);
    }

cleanup:
    free(bitenum2_found);
    return rc;
}

/**
 * @brief Check changes of 'base' arrays.
 *
 * @param[in] bases1 First base array.
 * @param[in] bases2 Second base array.
 * @param[in,out] changes Changes to add to.
 * @param[in,out] diff Diff to use.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_type_bases_change(struct lysc_ident **bases1, struct lysc_ident **bases2,
        struct lys_diff_changes_s *changes, struct lys_diff_s *diff)
{
    LY_ERR rc = LY_SUCCESS;
    LYA_COUNT_T u, v;
    ly_bool found, *base2_found = NULL;

    /* prepare array for marking found bases */
    base2_found = calloc(LYA_COUNT(bases2), sizeof *base2_found);
    LY_CHECK_ERR_GOTO(!base2_found, LOGMEM(NULL); rc = LY_EMEM, cleanup)

    LYA_FOR(bases1, u) {
        found = 0;
        LYA_FOR(bases2, v) {
            if (base2_found[v]) {
                continue;
            }

            /* base */
            if (!strcmp(bases1[u]->name, bases2[v]->name)) {
                /* found */
                found = 1;
                base2_found[v] = 1;
                break;
            }
        }

        if (!found) {
            /* removed, NBC for YANG 1.0 */
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, LYS_CHANGED_NONE, LYS_CHANGED_BASE,
                    diff->is_yang10 ? LYS_CONFORM_NBC : LYS_CONFORM_BC, changes), cleanup);
        }
    }

    LYA_FOR(bases2, v) {
        if (base2_found[v]) {
            continue;
        }

        /* added */
        LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_ADDED, LYS_CHANGED_NONE, LYS_CHANGED_BASE, LYS_CONFORM_NBC,
                changes), cleanup);
    }

cleanup:
    free(base2_found);
    return rc;
}

/**
 * @brief Check changes of 'union' 'type' arrays.
 *
 * @param[in] types1 First type array.
 * @param[in] types2 Second type array.
 * @param[in,out] changes Changes to add to.
 * @param[in,out] ext_changes Ext-instance changes to add to.
 * @param[in,out] diff Diff to use.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_type_union_change(struct lysc_type **types1, struct lysc_type **types2,
        struct lys_diff_changes_s *changes, struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_s *diff)
{
    LY_ERR rc = LY_SUCCESS;
    LYA_COUNT_T u;

    /* order matters */
    LYA_FOR(types1, u) {
        if (u >= LYA_COUNT(types2)) {
            /* removed */
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, LYS_CHANGED_NONE, LYS_CHANGED_TYPE,
                    LYS_CONFORM_NBC, changes), cleanup);
            continue;
        }

        /* type */
        LY_CHECK_GOTO(rc = schema_diff_node_type_change(types1[u], types2[u], LYS_CHANGED_TYPE, changes, ext_changes,
                diff), cleanup);
    }

    for ( ; u < LYA_COUNT(types2); ++u) {
        /* added */
        LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_ADDED, LYS_CHANGED_NONE, LYS_CHANGED_TYPE, LYS_CONFORM_BC,
                changes), cleanup);
    }

cleanup:
    return rc;
}

/**
 * @brief Check changes of a 'type'.
 *
 * @param[in] type1 First type.
 * @param[in] type2 Second type.
 * @param[in] parent_changed Parent statement of the change.
 * @param[in,out] changes Changes to add to.
 * @param[in,out] ext_changes Ext-instance changes to add to.
 * @param[in,out] diff Diff to use.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_type_change(const struct lysc_type *type1, const struct lysc_type *type2,
        enum lys_diff_changed_e parent_changed, struct lys_diff_changes_s *changes,
        struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_s *diff)
{
    const struct lysc_type_num *type1_num, *type2_num;
    const struct lysc_type_dec *type1_dec, *type2_dec;
    const struct lysc_type_str *type1_str, *type2_str;
    const struct lysc_type_enum *type1_enum, *type2_enum;
    const struct lysc_type_bits *type1_bits, *type2_bits;
    const struct lysc_type_leafref *type1_lref, *type2_lref;
    const struct lysc_type_identityref *type1_identref, *type2_identref;
    const struct lysc_type_instanceid *type1_instid, *type2_instid;
    const struct lysc_type_union *type1_union, *type2_union;
    const struct lysc_type_bin *type1_bin, *type2_bin;

    /* basetype */
    if (type1->basetype != type2->basetype) {
        /* we cannot compare different types */
        return schema_diff_add_change(LYS_CHANGE_MODIFIED, parent_changed, LYS_CHANGED_TYPE, LYS_CONFORM_NBC, changes);
    }

    switch (type1->basetype) {
    case LY_TYPE_BINARY:
        type1_bin = (const struct lysc_type_bin *)type1;
        type2_bin = (const struct lysc_type_bin *)type2;

        /* length */
        LY_CHECK_RET(schema_diff_node_type_range_change(type1_bin->length, type2_bin->length, 1, parent_changed,
                changes, ext_changes, diff));
        break;
    case LY_TYPE_UINT8:
    case LY_TYPE_UINT16:
    case LY_TYPE_UINT32:
    case LY_TYPE_UINT64:
    case LY_TYPE_INT8:
    case LY_TYPE_INT16:
    case LY_TYPE_INT32:
    case LY_TYPE_INT64:
        type1_num = (const struct lysc_type_num *)type1;
        type2_num = (const struct lysc_type_num *)type2;

        /* range */
        LY_CHECK_RET(schema_diff_node_type_range_change(type1_num->range, type2_num->range, 1, parent_changed,
                changes, ext_changes, diff));
        break;
    case LY_TYPE_STRING:
        type1_str = (const struct lysc_type_str *)type1;
        type2_str = (const struct lysc_type_str *)type2;

        /* length */
        LY_CHECK_RET(schema_diff_node_type_range_change(type1_str->length, type2_str->length, 0, parent_changed,
                changes, ext_changes, diff));

        /* pattern */
        LY_CHECK_RET(schema_diff_node_type_patterns_change(type1_str->patterns, type2_str->patterns, parent_changed,
                changes, ext_changes, diff));
        break;
    case LY_TYPE_BITS:
        type1_bits = (const struct lysc_type_bits *)type1;
        type2_bits = (const struct lysc_type_bits *)type2;

        /* bit */
        LY_CHECK_RET(schema_diff_node_type_bitenum_change(type1_bits->bits, type2_bits->bits, parent_changed,
                changes, ext_changes, diff));
        break;
    case LY_TYPE_BOOL:
    case LY_TYPE_EMPTY:
        break;
    case LY_TYPE_DEC64:
        type1_dec = (const struct lysc_type_dec *)type1;
        type2_dec = (const struct lysc_type_dec *)type2;

        /* fraction-digits */
        if (type1_dec->fraction_digits != type2_dec->fraction_digits) {
            LY_CHECK_RET(schema_diff_add_change(LYS_CHANGE_MODIFIED, parent_changed, LYS_CHANGED_FRAC_DIG,
                    LYS_CONFORM_NBC, changes));
        }

        /* range */
        LY_CHECK_RET(schema_diff_node_type_range_change(type1_dec->range, type2_dec->range, 1, parent_changed,
                changes, ext_changes, diff));
        break;
    case LY_TYPE_ENUM:
        type1_enum = (const struct lysc_type_enum *)type1;
        type2_enum = (const struct lysc_type_enum *)type2;

        /* enum */
        LY_CHECK_RET(schema_diff_node_type_bitenum_change(type1_enum->enums, type2_enum->enums, parent_changed,
                changes, ext_changes, diff));
        break;
    case LY_TYPE_IDENT:
        type1_identref = (const struct lysc_type_identityref *)type1;
        type2_identref = (const struct lysc_type_identityref *)type2;

        /* base */
        LY_CHECK_RET(schema_diff_node_type_bases_change(type1_identref->bases, type2_identref->bases, changes, diff));
        break;
    case LY_TYPE_INST:
        type1_instid = (const struct lysc_type_instanceid *)type1;
        type2_instid = (const struct lysc_type_instanceid *)type2;

        /* require-instance */
        LY_CHECK_RET(schema_diff_req_inst_change(type1_instid->require_instance, type2_instid->require_instance,
                parent_changed, changes));
        break;
    case LY_TYPE_LEAFREF:
        type1_lref = (const struct lysc_type_leafref *)type1;
        type2_lref = (const struct lysc_type_leafref *)type2;

        /* path */
        if (strcmp(lyxp_get_expr(type1_lref->path), lyxp_get_expr(type2_lref->path))) {
            LY_CHECK_RET(schema_diff_add_change(LYS_CHANGE_MODIFIED, parent_changed, LYS_CHANGED_PATH, LYS_CONFORM_NBC,
                    changes));
        }

        /* require-instance */
        LY_CHECK_RET(schema_diff_req_inst_change(type1_lref->require_instance, type2_lref->require_instance,
                parent_changed, changes));
        break;
    case LY_TYPE_UNION:
        type1_union = (const struct lysc_type_union *)type1;
        type2_union = (const struct lysc_type_union *)type2;

        /* type */
        LY_CHECK_RET(schema_diff_node_type_union_change(type1_union->types, type2_union->types, changes, ext_changes, diff));
        break;
    case LY_TYPE_UNKNOWN:
        /* invalid */
        assert(0);
        LOGINT_RET(NULL);
    }

    /* ext-instance */
    LY_CHECK_RET(schema_diff_ext_insts_change(type1->exts, type2->exts, ext_changes, diff));

    return LY_SUCCESS;
}

/**
 * @brief Find a specific compiled when.
 *
 * @param[in] pwhen Parsed when to find.
 * @param[in] whens Compiled when array to search in.
 * @return Found compiled when.
 */
static const struct lysc_when *
schema_diff_find_when(const struct lysp_when *pwhen, struct lysc_when **whens)
{
    const struct lysc_when *when = NULL;
    LYA_COUNT_T u;

    if (!pwhen) {
        return NULL;
    }

    LYA_FOR(whens, u) {
        if (!strcmp(lyxp_get_expr(whens[u]->cond), pwhen->cond)) {
            when = whens[u];
            break;
        }
    }

    assert(when);
    return when;
}

/**
 * @brief Check changes of a node.
 *
 * @param[in] node1 First node.
 * @param[in] node2 Second node.
 * @param[in,out] changes Changes to add to.
 * @param[in,out] ext_changes Ext-instance changes to add to.
 * @param[in,out] pext_changes Parsed ext-instance changes to add to, for unresolved foreign types.
 * @param[in,out] diff Diff to use.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_node_change(const struct lysc_node *node1, const struct lysc_node *node2, struct lys_diff_changes_s *changes,
        struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_pext_changes_s *pext_changes, struct lys_diff_s *diff)
{
    const struct lysc_node_leaf *term1, *term2;
    const struct lysp_node_leaf *pterm1, *pterm2;
    const struct lysc_node_leaflist *llist1, *llist2;
    const struct lysc_node_list *list1, *list2;
    const struct lysc_node_choice *choic1, *choic2;
    const struct lysp_node *pnode1, *pnode2;
    const struct lysc_when *when1, *when2;

    if (!node1) {
        /* node added change */
        assert(node2);
        return schema_diff_add_change(LYS_CHANGE_ADDED, LYS_CHANGED_NONE, LYS_CHANGED_NODE,
                (node2->flags & LYS_MAND_TRUE) ? LYS_CONFORM_NBC : LYS_CONFORM_BC, changes);
    } else if (!node2) {
        /* node removed change */
        return schema_diff_add_change(LYS_CHANGE_REMOVED, LYS_CHANGED_NONE, LYS_CHANGED_NODE,
                (node1->flags & LYS_STATUS_OBSLT) ? LYS_CONFORM_BC : LYS_CONFORM_NBC, changes);
    }

    /* config */
    LY_CHECK_RET(schema_diff_config_change(node1->flags, node2->flags, LYS_CHANGED_NONE, changes));

    /* description */
    LY_CHECK_RET(schema_diff_text(node1->dsc, node2->dsc, node2->exts, LY_STMT_DESCRIPTION, LYS_CHANGED_NODE,
            changes));

    /* must */
    LY_CHECK_RET(schema_diff_node_musts_change(lysc_node_musts(node1), lysc_node_musts(node2), LYS_CHANGED_NONE,
            changes, ext_changes, diff));

    /* presence */
    if (node1->nodetype == LYS_CONTAINER) {
        /* compare the parsed string values */
        LY_CHECK_RET(schema_diff_presence_change(((const struct lysp_node_container *)node1->priv)->presence,
                ((const struct lysp_node_container *)node2->priv)->presence, changes));
    }

    /* reference */
    LY_CHECK_RET(schema_diff_text(node1->ref, node2->ref, node2->exts, LY_STMT_REFERENCE, LYS_CHANGED_NODE,
            changes));

    if (diff->gen_local) {
        /* if-features */
        LY_CHECK_RET(schema_diff_iffeatures_change(((struct lysp_node *)node1->priv)->iffeatures, node1->flags,
                ((struct lysp_node *)node2->priv)->iffeatures, LYS_CHANGED_NODE, changes));
    }

    /* status */
    LY_CHECK_RET(schema_diff_status_change(node1->flags, node2->flags, LYS_CHANGED_NONE, changes));

    /* mandatory */
    if (node1->nodetype & (LYS_LEAF | LYS_CHOICE | LYD_NODE_ANY)) {
        LY_CHECK_RET(schema_diff_node_mandatory_change(node1->flags, node2->flags, LYS_CHANGED_NONE, changes));
    }

    /* when ... */
    pnode1 = node1->priv;
    pnode2 = node2->priv;

    /* ... in the node or ... */
    when1 = schema_diff_find_when(lysp_node_when(pnode1), lysc_node_when(node1));
    when2 = schema_diff_find_when(lysp_node_when(pnode2), lysc_node_when(node2));
    LY_CHECK_RET(schema_diff_node_when_change(when1, when2, LYS_CHANGED_NONE, changes, ext_changes, diff));

    /* ... in the parent augment or uses */
    if (pnode1->parent && pnode2->parent && (pnode1->parent->nodetype == pnode2->parent->nodetype) &&
            (pnode1->parent->nodetype & (LYS_AUGMENT | LYS_USES))) {
        when1 = schema_diff_find_when(lysp_node_when(pnode1->parent), lysc_node_when(node1));
        when2 = schema_diff_find_when(lysp_node_when(pnode2->parent), lysc_node_when(node2));
        LY_CHECK_RET(schema_diff_node_when_change(when1, when2, LYS_CHANGED_NONE, changes, ext_changes, diff));
    }

    /* type */
    if (node1->nodetype & LYD_NODE_TERM) {
        term1 = (const struct lysc_node_leaf *)node1;
        term2 = (const struct lysc_node_leaf *)node2;

        if (term1->type && term2->type) {
            /* compiled type */
            LY_CHECK_RET(schema_diff_node_type_change(term1->type, term2->type, LYS_CHANGED_NONE, changes, ext_changes, diff));
        } else {
            /* parsed type */
            assert(!diff->gen_full);
            pterm1 = node1->priv;
            pterm2 = node2->priv;

            LY_CHECK_RET(schema_diff_ptype_change(&pterm1->type, &pterm1->node, &pterm2->type, &pterm2->node,
                    LYS_CHANGED_NONE, changes, pext_changes, diff));
        }
    }

    /* units */
    if (node1->nodetype & LYD_NODE_TERM) {
        term1 = (const struct lysc_node_leaf *)node1;
        term2 = (const struct lysc_node_leaf *)node2;

        LY_CHECK_RET(schema_diff_text_bc_add(term1->units, term2->units, LYS_CHANGED_NONE, LYS_CHANGED_UNITS,
                changes));
    }

    /* ordered-by */
    if (node1->nodetype & (LYS_LIST | LYS_LEAFLIST)) {
        LY_CHECK_RET(schema_diff_node_ordby_change(node1->flags, node2->flags, LYS_CHANGED_NONE, changes));
    }

    /* default */
    if (node1->nodetype == LYS_LEAF) {
        term1 = (const struct lysc_node_leaf *)node1;
        term2 = (const struct lysc_node_leaf *)node2;

        LY_CHECK_RET(schema_diff_text_bc_add(term1->dflt.str, term2->dflt.str, LYS_CHANGED_NONE, LYS_CHANGED_DEFAULT,
                changes));
    } else if (node1->nodetype == LYS_LEAFLIST) {
        llist1 = (const struct lysc_node_leaflist *)node1;
        llist2 = (const struct lysc_node_leaflist *)node2;

        LY_CHECK_RET(schema_diff_node_defaults_change(llist1, llist2, LYS_CHANGED_NONE, changes));
    } else if (node1->nodetype == LYS_CHOICE) {
        choic1 = (const struct lysc_node_choice *)node1;
        choic2 = (const struct lysc_node_choice *)node2;

        LY_CHECK_RET(schema_diff_text_nbc(choic1->dflt ? choic1->dflt->name : NULL,
                choic2->dflt ? choic2->dflt->name : NULL, LYS_CHANGED_NONE, LYS_CHANGED_DEFAULT, changes));
    }

    /* min-elements, max-elements */
    if (node1->nodetype == LYS_LEAFLIST) {
        llist1 = (const struct lysc_node_leaflist *)node1;
        llist2 = (const struct lysc_node_leaflist *)node2;

        LY_CHECK_RET(schema_diff_elem_limit_change(llist1->min, 1, llist2->min, 1, LYS_CHANGED_NONE,
                LYS_CHANGED_MIN_ELEM, changes));
        LY_CHECK_RET(schema_diff_elem_limit_change(llist1->max, 1, llist2->max, 1, LYS_CHANGED_NONE,
                LYS_CHANGED_MAX_ELEM, changes));
    } else if (node1->nodetype == LYS_LIST) {
        list1 = (const struct lysc_node_list *)node1;
        list2 = (const struct lysc_node_list *)node2;

        LY_CHECK_RET(schema_diff_elem_limit_change(list1->min, 1, list2->min, 1, LYS_CHANGED_NONE, LYS_CHANGED_MIN_ELEM,
                changes));
        LY_CHECK_RET(schema_diff_elem_limit_change(list1->max, 1, list2->max, 1, LYS_CHANGED_NONE, LYS_CHANGED_MAX_ELEM,
                changes));
    }

    /* unique */
    if (node1->nodetype == LYS_LIST) {
        list1 = (const struct lysc_node_list *)node1;
        list2 = (const struct lysc_node_list *)node2;

        LY_CHECK_RET(schema_diff_node_uniques_change(list1->uniques, list2->uniques, changes));
    }

    /* ext-instance */
    LY_CHECK_RET(schema_diff_ext_insts_change(node1->exts, node2->exts, ext_changes, diff));

    return LY_SUCCESS;
}

/**
 * @brief Check changes of extension-instance substatement arrays.
 *
 * @param[in] substmts1 First substatement array.
 * @param[in] substmts2 Second substatement array.
 * @param[in] parent_changed Parent statement of the change.
 * @param[in,out] changes Changes to add to.
 * @param[in,out] ext_changes Nested ext-instance changes to add to.
 * @param[in,out] diff Diff to use.
 * @return LY_ERR value.
 */
static LY_ERR
schema_diff_ext_inst_substmts_change(const struct lysc_ext_substmt *substmts1, const struct lysc_ext_substmt *substmts2,
        enum lys_diff_changed_e parent_changed, struct lys_diff_changes_s *changes,
        struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_s *diff)
{
    LY_ERR rc = LY_SUCCESS;
    const struct lysc_ext_substmt **substmts2_array = NULL;
    LYA_COUNT_T u, v;
    ly_bool found, siblings_checked = 0;

    /* collect all the compiled substatements2 to remove from */
    substmts2_array = calloc(LYA_COUNT(substmts2), sizeof *substmts2_array);
    LY_CHECK_ERR_GOTO(!substmts2_array, LOGMEM(NULL); rc = LY_EMEM, cleanup);
    LYA_FOR(substmts2, v) {
        if (substmts2[v].storage_p) {
            substmts2_array[v] = &substmts2[v];
        }
    }

    LYA_FOR(substmts1, u) {
        if (!substmts1[u].storage_p) {
            /* not compiled */
            continue;
        }

        found = 0;
        for (v = 0; v < LYA_COUNT(substmts2); ++v) {
            if (!substmts2_array[v]) {
                continue;
            }

            if (substmts1[u].stmt == substmts2_array[v]->stmt) {
                /* found */
                found = 1;
                substmts2_array[v] = NULL;
                break;
            }
        }
        if (!found) {
            /* compiled statement not found in substmts2 */
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, parent_changed,
                    schema_diff_stmt2changed(substmts1[u].stmt), LYS_CONFORM_NBC, changes), cleanup);
            continue;
        }

        switch (substmts1[u].stmt) {
        case LY_STMT_ACTION:
        case LY_STMT_ANYDATA:
        case LY_STMT_ANYXML:
        case LY_STMT_CASE:
        case LY_STMT_CHOICE:
        case LY_STMT_CONTAINER:
        case LY_STMT_INPUT:
        case LY_STMT_LEAF:
        case LY_STMT_LEAF_LIST:
        case LY_STMT_LIST:
        case LY_STMT_NOTIFICATION:
        case LY_STMT_OUTPUT:
        case LY_STMT_RPC:
        case LY_STMT_USES:
            /* all the nodes are connected into a sibling list, do not repeat the check */
            if (siblings_checked) {
                break;
            }
            siblings_checked = 1;

            LY_CHECK_GOTO(rc = schema_diff_nodes_change_r(*(substmts1[u].storage_p), *(substmts2[v].storage_p), diff),
                    cleanup);
            break;
        case LY_STMT_ARGUMENT:
        case LY_STMT_ERROR_APP_TAG:
        case LY_STMT_ERROR_MESSAGE:
        case LY_STMT_KEY:
        case LY_STMT_MODIFIER:
        case LY_STMT_NAMESPACE:
            /* text NBC */
            LY_CHECK_GOTO(rc = schema_diff_text_nbc(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    LYS_CHANGED_EXT_INST, schema_diff_stmt2changed(substmts1[u].stmt), changes), cleanup);
            break;
        case LY_STMT_CONTACT:
        case LY_STMT_ORGANIZATION:
        case LY_STMT_PRESENCE:
            /* text BC */
            LY_CHECK_GOTO(rc = schema_diff_text_ed(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    LYS_CHANGED_EXT_INST, schema_diff_stmt2changed(substmts1[u].stmt), changes), cleanup);
            break;
        case LY_STMT_REFERENCE:
            /* reference */
            LY_CHECK_GOTO(rc = schema_diff_text(*(substmts1[u].storage_p), *(substmts2[v].storage_p), NULL,
                    LY_STMT_REFERENCE, LYS_CHANGED_EXT_INST, changes), cleanup);
            break;
        case LY_STMT_DESCRIPTION:
            /* description */
            LY_CHECK_GOTO(rc = schema_diff_text(*(substmts1[u].storage_p), *(substmts2[v].storage_p), NULL,
                    LY_STMT_DESCRIPTION, LYS_CHANGED_EXT_INST, changes), cleanup);
            break;
        case LY_STMT_UNITS:
            /* text BC add */
            LY_CHECK_GOTO(rc = schema_diff_text_bc_add(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    LYS_CHANGED_EXT_INST, schema_diff_stmt2changed(substmts1[u].stmt), changes), cleanup);
            break;
        case LY_STMT_BIT:
        case LY_STMT_ENUM:
            /* bitenum struct array */
            LY_CHECK_GOTO(rc = schema_diff_node_type_bitenum_change(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    LYS_CHANGED_EXT_INST, changes, ext_changes, diff), cleanup);
            break;
        case LY_STMT_CONFIG:
            /* config flag */
            LY_CHECK_GOTO(rc = schema_diff_config_change(*(uint16_t *)substmts1[u].storage_p,
                    *(uint16_t *)substmts2[v].storage_p, LYS_CHANGED_EXT_INST, changes), cleanup);
            break;
        case LY_STMT_FRACTION_DIGITS:
        case LY_STMT_REQUIRE_INSTANCE:
            /* uint8 number */
            if (*(uint8_t *)substmts1[u].storage_p != *(uint8_t *)substmts2[v].storage_p) {
                LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_MODIFIED, LYS_CHANGED_EXT_INST,
                        schema_diff_stmt2changed(substmts1[u].stmt), LYS_CONFORM_NBC, changes), cleanup);
            }
            break;
        case LY_STMT_IDENTITY:
            /* identity */
            LY_CHECK_GOTO(rc = schema_diff_module_identities_change(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    LYS_CHANGED_EXT_INST, diff), cleanup);
            break;
        case LY_STMT_LENGTH:
            /* length */
            LY_CHECK_GOTO(rc = schema_diff_node_type_range_change(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    0, LYS_CHANGED_EXT_INST, changes, ext_changes, diff), cleanup);
            break;
        case LY_STMT_RANGE:
            /* range */
            LY_CHECK_GOTO(rc = schema_diff_node_type_range_change(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    1, LYS_CHANGED_EXT_INST, changes, ext_changes, diff), cleanup);
            break;
        case LY_STMT_MANDATORY:
            /* mandatory */
            LY_CHECK_GOTO(rc = schema_diff_node_mandatory_change(*(uint16_t *)substmts1[u].storage_p,
                    *(uint16_t *)substmts2[v].storage_p, LYS_CHANGED_EXT_INST, changes), cleanup);
            break;
        case LY_STMT_ORDERED_BY:
            /* odrered-by */
            LY_CHECK_GOTO(rc = schema_diff_node_ordby_change(*(uint16_t *)substmts1[u].storage_p,
                    *(uint16_t *)substmts2[v].storage_p, LYS_CHANGED_EXT_INST, changes), cleanup);
            break;
        case LY_STMT_MAX_ELEMENTS:
        case LY_STMT_MIN_ELEMENTS:
            /* uint32 number */
            if (*(uint32_t *)substmts1[u].storage_p != *(uint32_t *)substmts2[v].storage_p) {
                LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_MODIFIED, LYS_CHANGED_EXT_INST,
                        schema_diff_stmt2changed(substmts1[u].stmt), LYS_CONFORM_NBC, changes), cleanup);
            }
            break;
        case LY_STMT_MUST:
            /* must array */
            LY_CHECK_GOTO(rc = schema_diff_node_musts_change(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    LYS_CHANGED_EXT_INST, changes, ext_changes, diff), cleanup);
            break;
        case LY_STMT_PATTERN:
            /* pattern array of arrays */
            LY_CHECK_GOTO(rc = schema_diff_node_type_patterns_change(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    LYS_CHANGED_EXT_INST, changes, ext_changes, diff), cleanup);
            break;
        case LY_STMT_POSITION:
        case LY_STMT_VALUE:
            /* uint64/int64 number */
            if (*(uint64_t *)substmts1[u].storage_p != *(uint64_t *)substmts2[v].storage_p) {
                LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_MODIFIED, LYS_CHANGED_EXT_INST,
                        schema_diff_stmt2changed(substmts1[u].stmt), LYS_CONFORM_NBC, changes), cleanup);
            }
            break;
        case LY_STMT_STATUS:
            /* status flag */
            LY_CHECK_GOTO(rc = schema_diff_status_change(*(uint16_t *)substmts1[u].storage_p,
                    *(uint16_t *)substmts2[v].storage_p, LYS_CHANGED_EXT_INST, changes), cleanup);
            break;
        case LY_STMT_TYPE:
            /* type */
            LY_CHECK_GOTO(rc = schema_diff_node_type_change(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    LYS_CHANGED_EXT_INST, changes, ext_changes, diff), cleanup);
            break;
        case LY_STMT_WHEN:
            /* when */
            LY_CHECK_GOTO(rc = schema_diff_node_when_change(*(substmts1[u].storage_p), *(substmts2[v].storage_p),
                    LYS_CHANGED_EXT_INST, changes, ext_changes, diff), cleanup);
            break;
        case LY_STMT_ARG_TEXT:
        case LY_STMT_ARG_VALUE:
        case LY_STMT_AUGMENT:
        case LY_STMT_BASE:
        case LY_STMT_BELONGS_TO:
        case LY_STMT_DEFAULT:
        case LY_STMT_DEVIATE:
        case LY_STMT_DEVIATION:
        case LY_STMT_EXTENSION:
        case LY_STMT_EXTENSION_INSTANCE:
        case LY_STMT_FEATURE:
        case LY_STMT_IF_FEATURE:
        case LY_STMT_GROUPING:
        case LY_STMT_IMPORT:
        case LY_STMT_INCLUDE:
        case LY_STMT_MODULE:
        case LY_STMT_PATH:
        case LY_STMT_PREFIX:
        case LY_STMT_REFINE:
        case LY_STMT_REVISION:
        case LY_STMT_REVISION_DATE:
        case LY_STMT_SUBMODULE:
        case LY_STMT_SYNTAX_LEFT_BRACE:
        case LY_STMT_SYNTAX_RIGHT_BRACE:
        case LY_STMT_SYNTAX_SEMICOLON:
        case LY_STMT_TYPEDEF:
        case LY_STMT_UNIQUE:
        case LY_STMT_YANG_VERSION:
        case LY_STMT_YIN_ELEMENT:
        case LY_STMT_NONE:
            /* not compiled/invalid */
            LOGINT(NULL);
            rc = LY_EINT;
            goto cleanup;
        }
    }

    for (v = 0; v < LYA_COUNT(substmts2); ++v) {
        if (!substmts2_array[v]) {
            continue;
        }

        /* compiled statement not found in substmts1 */
        LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, LYS_CHANGED_EXT_INST,
                schema_diff_stmt2changed(substmts2_array[v]->stmt), LYS_CONFORM_NBC, changes), cleanup);
    }

cleanup:
    free(substmts2_array);
    return rc;
}

LY_ERR
schema_diff_ext_insts_change(const struct lysc_ext_instance *exts1, const struct lysc_ext_instance *exts2,
        struct lys_diff_ext_changes_s *ext_changes, struct lys_diff_s *diff)
{
    LY_ERR rc = LY_SUCCESS;
    ly_bool *exts2_found, found, conform_ext;
    enum lys_diff_changed_e parent_changed;
    enum lys_diff_conform_e conform;
    struct lys_diff_ext_change_s *ext_change;
    LYA_COUNT_T u, v;
    uint32_t i;

    /* prepare array for marking found exts */
    exts2_found = calloc(LYA_COUNT(exts2), sizeof *exts2_found);
    LY_CHECK_ERR_GOTO(!exts2_found, LOGMEM(NULL); rc = LY_SUCCESS, cleanup);

    LYA_FOR(exts1, u) {
        schema_diff_is_ext_conform(&exts1[u], 0, &conform_ext);
        if (conform_ext) {
            /* skip */
            continue;
        }

        found = 0;
        LYA_FOR(exts2, v) {
            schema_diff_is_ext_conform(&exts2[v], 0, &conform_ext);
            if (conform_ext) {
                /* skip */
                continue;
            }

            if (!strcmp(exts1[u].def->name, exts2[v].def->name) && !strcmp(exts1[u].argument, exts2[v].argument)) {
                found = 1;
                exts2_found[v] = 1;
                break;
            }
        }

        /* add new ext-instance to changes */
        LY_CHECK_GOTO(rc = schema_diff_add_ext_change(&exts1[u], found ? &exts2[v] : NULL, ext_changes, &ext_change), cleanup);
        parent_changed = schema_diff_stmt2changed(exts1[u].parent_stmt);

        if (!found) {
            /* removed */
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_REMOVED, parent_changed, LYS_CHANGED_EXT_INST,
                    LYS_CONFORM_BC, &ext_change->changes), cleanup);
            continue;
        }

        /* substatements */
        LY_CHECK_GOTO(rc = schema_diff_ext_inst_substmts_change(exts1[u].substmts, exts2[v].substmts, parent_changed,
                &ext_change->changes, ext_changes, diff), cleanup);

        /* learn conformance */
        conform = schema_diff_exts_conform(exts2[v].exts, 0, LYS_CONFORM_BC, &conform_ext);

        if (conform_ext) {
            /* overwrite based on the extension */
            for (i = 0; i < ext_change->changes.count; ++i) {
                ext_change->changes.changes[i].conform = conform;
            }
        }

        /* ext-instance */
        LY_CHECK_GOTO(rc = schema_diff_ext_insts_change(exts1[u].exts, exts2[v].exts, ext_changes, diff), cleanup);
    }

    LYA_FOR(exts2, v) {
        schema_diff_is_ext_conform(&exts2[v], 0, &conform_ext);
        if (conform_ext || exts2_found[v]) {
            continue;
        }

        /* add new ext-instance to changes */
        LY_CHECK_GOTO(rc = schema_diff_add_ext_change(NULL, &exts2[v], ext_changes, &ext_change), cleanup);
        parent_changed = schema_diff_stmt2changed(exts2[v].parent_stmt);

        /* learn conformance */
        conform = schema_diff_exts_conform(exts2[v].exts, 0, LYS_CONFORM_BC, NULL);

        /* added */
        LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_ADDED, parent_changed, LYS_CHANGED_EXT_INST, conform,
                &ext_change->changes), cleanup);
    }

cleanup:
    free(exts2_found);
    return rc;
}

LY_ERR
schema_diff_nodes_change_r(const struct lysc_node *node1, const struct lysc_node *node2, struct lys_diff_s *diff)
{
    LY_ERR rc = LY_SUCCESS;
    struct lys_diff_node_change_s *node_change;
    const struct lysc_node **node2_array = NULL, *iter;
    uint32_t node2_count = 0, i, prev_i = 0;

    /* prepare array for node2 siblings */
    LY_LIST_FOR(node2, iter) {
        node2_array = ly_realloc(node2_array, (node2_count + 1) * sizeof *node2_array);
        LY_CHECK_ERR_GOTO(!node2_array, LOGMEM(NULL); rc = LY_SUCCESS, cleanup);
        node2_array[node2_count] = iter;
        ++node2_count;
    }

    LY_LIST_FOR(node1, node1) {
        node2 = NULL;
        for (i = 0; i < node2_count; ++i) {
            if (!node2_array[i]) {
                continue;
            }

            if (!strcmp(node1->module->name, node2_array[i]->module->name) && !strcmp(node1->name, node2_array[i]->name) &&
                    (node1->nodetype == node2_array[i]->nodetype)) {
                /* matching nodes */
                node2 = node2_array[i];
                break;
            }
        }

        /* add new node to changes */
        LY_CHECK_GOTO(rc = schema_diff_add_node_change(node1, node2, diff, &node_change), cleanup);

        if (node2 && (i < prev_i)) {
            /* moved */
            LY_CHECK_GOTO(rc = schema_diff_add_change(LYS_CHANGE_MOVED, LYS_CHANGED_NONE, LYS_CHANGED_NODE,
                    LYS_CONFORM_NBC, &node_change->changes), cleanup);
        }

        /* node changes (removed, moved, modified) */
        LY_CHECK_GOTO(rc = schema_diff_node_change(node1, node2, &node_change->changes, &node_change->ext_changes,
                &node_change->pext_changes, diff), cleanup);

        /* recursive changes */
        LY_CHECK_GOTO(rc = schema_diff_nodes_change_r(lysc_node_child(node1), lysc_node_child(node2), diff), cleanup);
        LY_CHECK_GOTO(rc = schema_diff_nodes_change_r((const struct lysc_node *)lysc_node_actions(node1),
                (const struct lysc_node *)lysc_node_actions(node2), diff), cleanup);
        LY_CHECK_GOTO(rc = schema_diff_nodes_change_r((const struct lysc_node *)lysc_node_notifs(node1),
                (const struct lysc_node *)lysc_node_notifs(node2), diff), cleanup);

        if (node2) {
            /* match found */
            prev_i = i;
            node2_array[i] = NULL;
        }
    }

    for (i = 0; i < node2_count; ++i) {
        if (!node2_array[i]) {
            continue;
        }

        /* add new node to changes */
        LY_CHECK_GOTO(rc = schema_diff_add_node_change(NULL, node2_array[i], diff, &node_change), cleanup);

        /* node changes (added) */
        LY_CHECK_GOTO(rc = schema_diff_node_change(NULL, node2_array[i], &node_change->changes,
                &node_change->ext_changes, &node_change->pext_changes, diff), cleanup);

        /* recursive changes */
        LY_CHECK_GOTO(rc = schema_diff_nodes_change_r(NULL, lysc_node_child(node2_array[i]), diff), cleanup);
        LY_CHECK_GOTO(rc = schema_diff_nodes_change_r(NULL, (const struct lysc_node *)lysc_node_actions(node2_array[i]),
                diff), cleanup);
        LY_CHECK_GOTO(rc = schema_diff_nodes_change_r(NULL, (const struct lysc_node *)lysc_node_notifs(node2_array[i]),
                diff), cleanup);
    }

cleanup:
    free(node2_array);
    return rc;
}
