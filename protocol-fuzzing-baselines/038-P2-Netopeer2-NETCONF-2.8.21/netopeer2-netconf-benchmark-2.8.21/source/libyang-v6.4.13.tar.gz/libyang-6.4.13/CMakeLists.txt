if(WIN32)
    cmake_minimum_required(VERSION 3.22.0)
else()
    cmake_minimum_required(VERSION 2.8.12...3.28.1)
endif()

# force out-of-source build
if(${CMAKE_CURRENT_SOURCE_DIR} STREQUAL ${CMAKE_CURRENT_BINARY_DIR})
    message(FATAL_ERROR "In-source build is not allowed. Please make a standalone build directory and run CMake from there. You may need to remove CMakeCache.txt.")
endif()

project(libyang C)

# include custom Modules
set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH} "${CMAKE_CURRENT_SOURCE_DIR}/CMakeModules/")

include(GNUInstallDirs)
include(UseCompat)
include(ABICheck)
include(SourceFormat)
include(GenDoc)
include(GenCoverage)
include(CheckIncludeFile)

# set default build type if not specified by user
if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE Debug)
endif()
# normalize build type string
# see https://github.com/CESNET/libyang/pull/1692 for why CMAKE_C_FLAGS_<type> are not used directly
string(TOUPPER "${CMAKE_BUILD_TYPE}" BUILD_TYPE_UPPER)
if ("${BUILD_TYPE_UPPER}" STREQUAL "RELEASE")
    set(CMAKE_BUILD_TYPE "Release" CACHE STRING "Build Type" FORCE)
    set(CMAKE_C_FLAGS "-DNDEBUG -O2 ${CMAKE_C_FLAGS}")
elseif("${BUILD_TYPE_UPPER}" STREQUAL "DEBUG")
    set(CMAKE_BUILD_TYPE "Debug" CACHE STRING "Build Type" FORCE)
    set(CMAKE_C_FLAGS "-g3 -O0 ${CMAKE_C_FLAGS}")
elseif("${BUILD_TYPE_UPPER}" STREQUAL "RELWITHDEBINFO")
    set(CMAKE_BUILD_TYPE "RelWithDebInfo" CACHE STRING "Build Type" FORCE)
elseif("${BUILD_TYPE_UPPER}" STREQUAL "RELWITHDEBUG")
    set(CMAKE_BUILD_TYPE "RelWithDebug" CACHE STRING "Build Type" FORCE)
elseif("${BUILD_TYPE_UPPER}" STREQUAL "ABICHECK")
    set(CMAKE_BUILD_TYPE "ABICheck" CACHE STRING "Build Type" FORCE)
    set(CMAKE_C_FLAGS "-g -Og ${CMAKE_C_FLAGS}")
elseif("${BUILD_TYPE_UPPER}" STREQUAL "DOCONLY")
    set(CMAKE_BUILD_TYPE "DocOnly" CACHE STRING "Build Type" FORCE)
endif()

#
# variables
#

set(LIBYANG_DESCRIPTION "libyang is YANG data modelling language parser and toolkit written (and providing API) in C.")

# Correct RPATH usage on OS X
set(CMAKE_MACOSX_RPATH TRUE)

# keep all binaries in the build directory
set (CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR})

# set version of the project
set(LIBYANG_MAJOR_VERSION 6)
set(LIBYANG_MINOR_VERSION 4)
set(LIBYANG_MICRO_VERSION 13)
set(LIBYANG_VERSION ${LIBYANG_MAJOR_VERSION}.${LIBYANG_MINOR_VERSION}.${LIBYANG_MICRO_VERSION})

# set version of the library
set(LIBYANG_MAJOR_SOVERSION 5)
set(LIBYANG_MINOR_SOVERSION 11)
set(LIBYANG_MICRO_SOVERSION 11)
set(LIBYANG_SOVERSION_FULL ${LIBYANG_MAJOR_SOVERSION}.${LIBYANG_MINOR_SOVERSION}.${LIBYANG_MICRO_SOVERSION})
set(LIBYANG_SOVERSION ${LIBYANG_MAJOR_SOVERSION})

if(WIN32)
    set(C_STANDARD 11)
    set(C_STANDARD_REQUIRED ON)
    set(CMAKE_C_FLAGS "/Zc:preprocessor /W3 /wd4711 /w14013 /utf-8 ${CMAKE_C_FLAGS}")
else()
    # global C flags (POSIX source because of pthread_rwlock_t)
    set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -Wall -Wextra -Wpedantic -std=c11")
endif()

include_directories(${PROJECT_BINARY_DIR} ${PROJECT_BINARY_DIR}/libyang ${PROJECT_SOURCE_DIR}/src ${PROJECT_SOURCE_DIR}/src/plugins_exts)

# type plugins are separate because they have their documentation generated
set(type_plugins
    src/plugins_types/binary.c
    src/plugins_types/bits.c
    src/plugins_types/boolean.c
    src/plugins_types/decimal64.c
    src/plugins_types/empty.c
    src/plugins_types/enumeration.c
    src/plugins_types/identityref.c
    src/plugins_types/instanceid.c
    src/plugins_types/instanceid_keys.c
    src/plugins_types/integer.c
    src/plugins_types/leafref.c
    src/plugins_types/lyds_tree.c
    src/plugins_types/string.c
    src/plugins_types/union.c
    src/plugins_types/ipv4_address.c
    src/plugins_types/ipv4_address_no_zone.c
    src/plugins_types/ipv6_address.c
    src/plugins_types/ipv6_address_no_zone.c
    src/plugins_types/ipv4_address_prefix.c
    src/plugins_types/ipv6_address_prefix.c
    src/plugins_types/date_and_time.c
    src/plugins_types/date.c
    src/plugins_types/time.c
    src/plugins_types/hex_string.c
    src/plugins_types/xpath1.0.c
    src/plugins_types/node_instanceid.c
    src/plugins_types/time_period.c)

set(libsrc
    src/ly_common.c
    src/log.c
    src/hash_table.c
    src/dict.c
    src/set.c
    src/path.c
    src/diff.c
    src/context.c
    src/json.c
    src/tree_data.c
    src/tree_data_free.c
    src/tree_data_common.c
    src/tree_data_hash.c
    src/tree_data_new.c
    src/parser_xml.c
    src/parser_json.c
    src/parser_lyb.c
    src/out.c
    src/printer_data.c
    src/printer_xml.c
    src/printer_json.c
    src/printer_lyb.c
    src/schema_compile.c
    src/schema_compile_node.c
    src/schema_compile_amend.c
    src/schema_features.c
    src/schema_diff.c
    src/schema_diff_change_full.c
    src/schema_diff_change_local.c
    src/schema_diff_tree.c
    src/tree_data_sorted.c
    src/tree_schema.c
    src/tree_schema_free.c
    src/tree_schema_common.c
    src/in.c
    src/lyb.c
    src/parser_common.c
    src/parser_yang.c
    src/parser_yin.c
    src/printer_schema.c
    src/printer_sid.c
    src/printer_yang.c
    src/printer_yin.c
    src/printer_tree.c
    src/printer_context.c
    src/plugins.c
    src/plugins_types.c
    src/plugins_exts.c
    src/plugins_exts/metadata.c
    src/plugins_exts/nacm.c
    src/plugins_exts/yangdata.c
    src/plugins_exts/schema_mount.c
    src/plugins_exts/structure.c
    src/plugins_exts/openconfig.c
    src/plugins_exts/schema_comparison.c
    src/plugins_exts/revisions.c
    src/plugins_exts/semver.c
    src/xml.c
    src/xpath.c
    src/validation.c
    ${type_plugins})

set(headers
    src/context.h
    src/hash_table.h
    src/dict.h
    src/in.h
    src/libyang.h
    src/ly_array.h
    src/log.h
    src/out.h
    src/parser_data.h
    src/parser_schema.h
    src/plugins.h
    src/plugins_exts.h
    src/plugins_exts/metadata.h
    src/plugins_exts/semver.h
    src/plugins_types.h
    src/printer_data.h
    src/printer_schema.h
    src/set.h
    src/tree_data.h
    src/tree_schema.h
    src/utils.h)

set(internal_headers
    src/ly_common.h
    src/diff.h
    src/hash_table_internal.h
    src/in_internal.h
    src/json.h
    src/lyb.h
    src/out_internal.h
    src/parser_internal.h
    src/path.h
    src/plugins_internal.h
    src/printer_internal.h
    src/schema_compile.h
    src/schema_compile_amend.h
    src/schema_compile_node.h
    src/schema_features.h
    src/schema_diff.h
    src/tree_data_internal.h
    src/tree_schema_internal.h
    src/validation.h
    src/xml.h
    src/xpath.h)

set(gen_headers
    version.h
    ly_config.h)

# files to generate doxygen from
set(doxy_files
    doc/build.dox
    doc/transition_1_2.dox
    doc/transition_2_3.dox
    doc/transition_3_4.dox
    doc/transition_4_5.dox
    ${headers}
    ${PROJECT_BINARY_DIR}/libyang/version.h
    ${type_plugins})

# project (doxygen) logo
set(project_logo
    doc/logo.png)

# source files to be covered by the 'format' target
set(format_sources
    compat/*.c
    compat/*.h*
    src/*.c
    src/*.h
    src/plugins_exts/*
    src/plugins_types/*)

#
# options
#

if(("${BUILD_TYPE_UPPER}" STREQUAL "DEBUG") OR ("${BUILD_TYPE_UPPER}" STREQUAL "RELWITHDEBINFO"))
    option(ENABLE_TESTS "Build tests" ON)
    option(ENABLE_VALGRIND_TESTS "Build tests with valgrind" ON)
else()
    option(ENABLE_TESTS "Build tests" OFF)
    option(ENABLE_VALGRIND_TESTS "Build tests with valgrind" OFF)
endif()
option(ENABLE_COVERAGE "Build code coverage report from tests" OFF)
option(ENABLE_FUZZ_TARGETS "Build target programs suitable for fuzzing with AFL" OFF)
option(ENABLE_INTERNAL_DOCS "Generate doxygen documentation also from internal headers" OFF)
option(ENABLE_YANGLINT_INTERACTIVE "Enable interactive CLI yanglint" ON)
option(ENABLE_TOOLS "Build binary tools 'yanglint' and 'yangre'" ON)
option(ENABLE_COMMON_TARGETS "Define common custom target names such as 'doc' or 'uninstall', may cause conflicts when using add_subdirectory() to build this project" ON)
option(BUILD_SHARED_LIBS "By default, shared libs are enabled. Turn off for a static build." ON)
set(YANG_MODULE_DIR "${CMAKE_INSTALL_PREFIX}/${CMAKE_INSTALL_DATADIR}/yang/modules/libyang" CACHE STRING "Directory where to copy the YANG modules to")

if(ENABLE_INTERNAL_DOCS)
    set(doxy_files ${doxy_files} ${internal_headers})
    set(INTERNAL_DOCS YES)
else()
    set(INTERNAL_DOCS NO)
endif()

set(LYD_VALUE_SIZE "24" CACHE STRING "Maximum size in bytes of data node values that do not need to be allocated dynamically, minimum is 8")
if(LYD_VALUE_SIZE LESS 8)
    message(FATAL_ERROR "Data node value size \"${LYD_VALUE_SIZE}\" is not valid.")
endif()
set(PLUGINS_DIR "${CMAKE_INSTALL_PREFIX}/${CMAKE_INSTALL_LIBDIR}/libyang" CACHE STRING "Directory with libyang plugins (extensions and user types)")
set(PLUGINS_DIR_EXTENSIONS "${PLUGINS_DIR}/extensions" CACHE STRING "Directory with libyang user extensions plugins")
set(PLUGINS_DIR_TYPES "${PLUGINS_DIR}/types" CACHE STRING "Directory with libyang user types plugins")
set(YANGUPDATE_PLUGINS_DIR "" CACHE STRING "Directory with libyang_update static plugin sources, must be set manually")
if(YANGUPDATE_PLUGINS_DIR AND NOT IS_ABSOLUTE ${YANGUPDATE_PLUGINS_DIR})
    message(FATAL_ERROR "Directory with libyang_update plugins \"${YANGUPDATE_PLUGINS_DIR}\" must be absolute.")
endif()

#
# checks
#
if(NOT BUILD_SHARED_LIBS)
    message(STATUS "Disabling tests for static build")
    set(ENABLE_TESTS OFF)
    set(ENABLE_VALGRIND_TESTS OFF)
endif()

if(ENABLE_VALGRIND_TESTS)
    if(NOT ENABLE_TESTS)
        message(WARNING "Tests are disabled! Disabling memory leak tests.")
        set(ENABLE_VALGRIND_TESTS OFF)
    else()
        find_program(VALGRIND_FOUND valgrind)
        if(NOT VALGRIND_FOUND)
            message(WARNING "valgrind executable not found! Disabling memory leak tests.")
            set(ENABLE_VALGRIND_TESTS OFF)
        endif()
    endif()
endif()

if(ENABLE_TESTS)
    find_package(CMocka 1.0.1)
    if(NOT CMOCKA_FOUND)
        message(STATUS "Disabling tests because of missing CMocka")
        set(ENABLE_TESTS OFF)
    endif()
endif()

find_path(VALGRIND_INCLUDE_DIR
    NAMES
    valgrind/callgrind.h
    PATHS
    /usr/include
    /usr/local/include
    /opt/local/include
    /sw/include
    ${CMAKE_INCLUDE_PATH}
    ${CMAKE_INSTALL_PREFIX}/include)
if(VALGRIND_INCLUDE_DIR)
    set(HAVE_CALLGRIND 1)
else()
    message(STATUS "Disabling callgrind macros in performance tests because of missing valgrind headers")
endif()

if(ENABLE_COVERAGE)
    gen_coverage_enable(${ENABLE_TESTS})
endif()

find_package(CBOR)
if(CBOR_FOUND)
    list(APPEND libsrc src/parser_cbor.c src/lcbor.c src/printer_cbor.c)
    list(APPEND headers src/lcbor.h)
    list(APPEND format_sources src/parser_cbor.c src/lcbor.h src/lcbor.c src/printer_cbor.c)
else()
    message(STATUS "libcbor not found, CBOR support disabled")
endif()

if ("${BUILD_TYPE_UPPER}" STREQUAL "DEBUG")
    # enable before adding tests to let them detect that format checking is available - one of the tests is format checking
    source_format_enable(0.77)
endif()

if(ENABLE_FUZZ_TARGETS)
    set(FUZZER "AFL" CACHE STRING "fuzzer type")
    if(FUZZER STREQUAL "LibFuzzer")
        if (NOT CMAKE_C_COMPILER_ID STREQUAL "Clang")
            message(FATAL_ERROR "LibFuzzer works only with clang")
        endif()
        set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -fsanitize=address,undefined -fno-omit-frame-pointer")
    endif()
endif()

# check regex compatibility
check_include_file("regex.h" LY_HAVE_REGEX_H)
if(LY_HAVE_REGEX_H)
    check_symbol_exists(REG_STARTEND "regex.h" HAVE_REG_STARTEND)
endif()

# generate and copy all public header files
configure_file(${PROJECT_SOURCE_DIR}/src/ly_config.h.in ${PROJECT_BINARY_DIR}/libyang/ly_config.h @ONLY)
configure_file(${PROJECT_SOURCE_DIR}/src/version.h.in ${PROJECT_BINARY_DIR}/libyang/version.h @ONLY)
file(COPY ${headers} DESTINATION ${PROJECT_BINARY_DIR}/libyang)

# DOC-only target with no extra dependencies
if("${BUILD_TYPE_UPPER}" STREQUAL "DOCONLY")
    gen_doc("${doxy_files}" ${LIBYANG_VERSION} ${LIBYANG_DESCRIPTION} ${project_logo})
    return()
endif()

#
# targets
#

# link compat
use_compat()

if(${CMAKE_SYSTEM_NAME} MATCHES "SunOS")
    # required for some extensions on Solaris (e.g. strndup), see man 7 standards, section "Feature Test Macros"
    # https://docs.oracle.com/cd/E88353_01/html/E37853/posix-7.html
    add_compile_definitions(__EXTENSIONS__)
endif()

# create static libyang library
if(NOT BUILD_SHARED_LIBS)
    add_definitions(-DSTATIC)

    # allow binaries compilation linking both static and dynamic libraries never linking static glibc
    #set(CMAKE_EXE_LINKER_FLAGS -static)

    # prefer static libraries
    set(CMAKE_FIND_LIBRARY_SUFFIXES .a;.so)
    set(CMAKE_LINK_SEARCH_START_STATIC TRUE)

    set(CMAKE_EXE_LINK_DYNAMIC_C_FLAGS)       # remove -Wl,-Bdynamic
    set(CMAKE_EXE_LINK_DYNAMIC_CXX_FLAGS)
    add_library(yang STATIC ${libsrc} ${compatsrc})
else()
    set(CMAKE_POSITION_INDEPENDENT_CODE TRUE)
    add_library(yangobj OBJECT ${libsrc} ${compatsrc})
    if(NOT WIN32)
        set_target_properties(yangobj PROPERTIES COMPILE_FLAGS "-fvisibility=hidden")
    endif()
    target_compile_definitions(yangobj PRIVATE LIBYANG_BUILD)
    add_library(yang SHARED $<TARGET_OBJECTS:yangobj>)

    if(WIN32)
        find_package(dlfcn-win32 REQUIRED)
        set(CMAKE_DL_LIBS dlfcn-win32::dl)
    endif()

    #link dl
    target_link_libraries(yang ${CMAKE_DL_LIBS})
endif()

if(WIN32)
    find_path(DIRENT_INCLUDE_DIR NAMES dirent.h REQUIRED)
    message(STATUS "Found <dirent.h> at ${DIRENT_INCLUDE_DIR}")

    set(COMPAT_POSIX_INCLUDES
        ${CMAKE_CURRENT_SOURCE_DIR}/compat/posix-shims
        ${DIRENT_INCLUDE_DIR})

    if(TARGET yangobj)
        target_include_directories(yangobj PRIVATE ${COMPAT_POSIX_INCLUDES})
    endif()
    target_include_directories(yang PRIVATE ${COMPAT_POSIX_INCLUDES})
    include_directories(${COMPAT_POSIX_INCLUDES})

    find_package(pthreads REQUIRED)
    set(COMPAT_WIN_LIBRARIES PThreads4W::PThreads4W shlwapi.lib ws2_32)
    target_link_libraries(yang ${COMPAT_WIN_LIBRARIES})
endif()

set_target_properties(yang PROPERTIES VERSION ${LIBYANG_SOVERSION_FULL} SOVERSION ${LIBYANG_SOVERSION})

# link math
if(NOT WIN32)
    target_link_libraries(yang m)
endif()

# find pthreads
set(CMAKE_THREAD_PREFER_PTHREAD TRUE)
find_package(Threads REQUIRED)
target_link_libraries(yang ${CMAKE_THREAD_LIBS_INIT})

# find PCRE2 library
unset(PCRE2_LIBRARY CACHE)
find_package(PCRE2 10.21 REQUIRED)
include_directories(${PCRE2_INCLUDE_DIRS})
target_link_libraries(yang ${PCRE2_LIBRARIES})

# link libcbor if found
if(CBOR_FOUND)
    if(TARGET yangobj)
        target_compile_definitions(yangobj PRIVATE ENABLE_CBOR_SUPPORT)
        target_include_directories(yangobj PRIVATE ${CBOR_INCLUDE_DIR})
    endif()
    target_compile_definitions(yang PRIVATE ENABLE_CBOR_SUPPORT)
    target_include_directories(yang PRIVATE ${CBOR_INCLUDE_DIR})
    target_link_libraries(yang ${CBOR_LIBRARY})
endif()

# XXHash include and library
find_package(XXHash)
if(XXHASH_FOUND)
    add_definitions(-DLY_XXHASH_SUPPORT)
    set(PC_XXHASH_LIB libxxhash)
    include_directories(${XXHASH_INCLUDE_DIR})
    target_link_libraries(yang ${XXHASH_LIBRARY})
    message(STATUS "Hash algorithm: xxhash")
    if (HAVE_XXH3_64BITS_WITHSEED)
        # for 32-bit system compatibility, this may not be available there, so use XXH32 instead
        add_definitions(-DLY_XXH3_64BITS_WITHSEED)
    endif()
else()
    message(STATUS "Hash algorithm: internal Jenkin's one-at-a-time")
endif()

# generated header list
foreach(h IN LISTS gen_headers)
    list(APPEND g_headers ${PROJECT_BINARY_DIR}/libyang/${h})
endforeach()

# install the modules
install(DIRECTORY "${PROJECT_SOURCE_DIR}/modules/" DESTINATION ${YANG_MODULE_DIR} FILES_MATCHING PATTERN "*.yang")

# install all library files
install(TARGETS yang DESTINATION ${CMAKE_INSTALL_LIBDIR})
install(FILES ${headers} ${g_headers} DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}/libyang)

find_package(PkgConfig)
if(PKG_CONFIG_FOUND)
    # generate and install pkg-config file
    configure_file("libyang.pc.in" "libyang.pc" @ONLY)
    install(FILES "${CMAKE_CURRENT_BINARY_DIR}/libyang.pc" DESTINATION "${CMAKE_INSTALL_LIBDIR}/pkgconfig")
    # check that pkg-config includes the used path
    execute_process(COMMAND ${PKG_CONFIG_EXECUTABLE} --variable pc_path pkg-config RESULT_VARIABLE RETURN OUTPUT_VARIABLE PC_PATH ERROR_QUIET)
    if(RETURN EQUAL 0)
    string(STRIP "${PC_PATH}" PC_PATH)
    set(PC_PATH "${PC_PATH}:$ENV{PKG_CONFIG_PATH}")
        string(REGEX MATCH "${CMAKE_INSTALL_PREFIX}/${CMAKE_INSTALL_LIBDIR}/pkgconfig" SUBSTR "${PC_PATH}")
        string(LENGTH "${SUBSTR}" SUBSTR_LEN)
        if(SUBSTR_LEN EQUAL 0)
            message(WARNING "pkg-config will not detect the new package after installation, adjust PKG_CONFIG_PATH using \"export PKG_CONFIG_PATH=\${PKG_CONFIG_PATH}:${CMAKE_INSTALL_PREFIX}/${CMAKE_INSTALL_LIBDIR}/pkgconfig\".")
        endif()
    endif()
endif()

# tests
if(ENABLE_TESTS)
    enable_testing()
    add_subdirectory(tests)
elseif(ENABLE_FUZZ_TARGETS AND NOT WIN32)
    add_subdirectory(tests/fuzz)
endif()

# create coverage target for generating coverage reports
gen_coverage("utest_.*" "utest_.*_valgrind")

# tools - yanglint, yangre
if(ENABLE_TOOLS)
    add_subdirectory(tools)
endif()

# generate doxygen documentation for libyang API
if(ENABLE_COMMON_TARGETS)
    gen_doc("${doxy_files}" ${LIBYANG_VERSION} ${LIBYANG_DESCRIPTION} ${project_logo})
endif()

# generate API/ABI report
if("${BUILD_TYPE_UPPER}" STREQUAL "ABICHECK")
    lib_abi_check(yang "${headers}" ${LIBYANG_SOVERSION_FULL} 78a2b082437c10200714a75291f0eece53795d94)
endif()

# source code format target for Makefile
# - add it after tests which may also update list of sources to format
source_format(${format_sources})

# uninstall
if(ENABLE_COMMON_TARGETS)
    add_custom_target(uninstall "${CMAKE_COMMAND}" -P "${CMAKE_MODULE_PATH}/uninstall.cmake")
endif()

# clean cmake cache
add_custom_target(cclean
        COMMAND make clean
        COMMAND find . -iname '*cmake*' -not -name CMakeLists.txt -not -path './CMakeModules*' -exec rm -rf {} +
        COMMAND rm -rf Makefile Doxyfile
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR})
