# common.sh - contains common functions and variables for the scripts

# arrays of modules to (un)install
NP2_MODULES=(
"ietf-interfaces@2018-02-20.yang"
"ietf-ip@2018-02-22.yang"
"ietf-netconf@2013-09-29.yang -e writable-running -e candidate -e rollback-on-error -e validate -e startup -e url -e xpath -e confirmed-commit"
"ietf-netconf-nmda@2019-01-07.yang -e origin -e with-defaults"
"notifications@2008-07-14.yang"
"nc-notifications@2008-07-14.yang"
"ietf-netconf-monitoring@2010-10-04.yang"
"ietf-network-instance@2019-01-21.yang"
"ietf-subscribed-notifications@2019-09-09.yang -e encode-xml -e replay -e subtree -e xpath"
"ietf-yang-push@2019-09-09.yang -e on-change"
"netopeer-notifications@2026-01-05.yang"
"ietf-system-capabilities@2022-02-17.yang"
"ietf-notification-capabilities@2022-02-17.yang"
"ietf-yp-transport-capabilities@2026-05-15.yang"
"ietf-netconf-private-candidate@2026-02-03.yang -e private-candidate"
)

LN2_MODULES=(
"iana-ssh-encryption-algs@2024-10-16.yang"
"iana-ssh-key-exchange-algs@2024-10-16.yang"
"iana-ssh-mac-algs@2024-10-16.yang"
"iana-ssh-public-key-algs@2024-10-16.yang"
"iana-tls-cipher-suite-algs@2024-10-16.yang"
"ietf-x509-cert-to-name@2014-12-10.yang"
"iana-crypt-hash@2014-04-04.yang -e crypt-hash-md5 -e crypt-hash-sha-256 -e crypt-hash-sha-512"
"ietf-crypto-types@2024-10-10.yang -e cleartext-passwords -e cleartext-private-keys"
"ietf-keystore@2024-10-10.yang -e central-keystore-supported -e inline-definitions-supported -e asymmetric-keys"
"ietf-truststore@2024-10-10.yang -e central-truststore-supported -e inline-definitions-supported -e certificates -e public-keys"
"ietf-tcp-common@2024-10-10.yang -e keepalives-supported"
"ietf-tcp-server@2024-10-10.yang -e tcp-server-keepalives"
"ietf-tcp-client@2024-10-10.yang -e local-binding-supported -e tcp-client-keepalives"
"ietf-ssh-common@2024-10-10.yang -e algorithm-discovery -e transport-params"
"ietf-ssh-server@2024-10-10.yang -e local-users-supported -e local-user-auth-publickey -e local-user-auth-password -e local-user-auth-none"
"ietf-tls-common@2024-10-10.yang -e algorithm-discovery -e tls12 -e tls13 -e hello-params"
"ietf-tls-server@2024-10-10.yang -e server-ident-x509-cert -e client-auth-supported -e client-auth-x509-cert"
"ietf-netconf-server@2025-04-24.yang -e ssh-listen -e tls-listen -e ssh-call-home -e tls-call-home -e central-netconf-server-supported"
"libnetconf2-netconf-server@2026-09-18.yang"
)

# get path to the sysrepocfg executable
function SYSREPOCFG_GET_PATH() {
    if [ -n "$SYSREPOCFG_EXECUTABLE" ]; then
        # from env
        SYSREPOCFG="$SYSREPOCFG_EXECUTABLE"
    elif [ $(id -u) -eq 0 ] && [ -n "$USER" ] && [ $(command -v su) ]; then
        # running as root, avoid problems with sudo PATH
        SYSREPOCFG=$(su -c 'command -v sysrepocfg' -l "$USER")
    else
        # normal user
        SYSREPOCFG=$(command -v sysrepocfg)
    fi

    if [ -z "$SYSREPOCFG" ]; then
        echo "$0: Unable to find sysrepocfg executable." >&2
        exit 1
    fi
}

# get path to the sysrepoctl executable
function SYSREPOCTL_GET_PATH() {
    if [ -n "$SYSREPOCTL_EXECUTABLE" ]; then
        # from env
        SYSREPOCTL="$SYSREPOCTL_EXECUTABLE"
    elif [ $(id -u) -eq 0 ] && [ -n "$USER" ] && [ $(command -v su) ]; then
        # running as root, avoid problems with sudo PATH
        SYSREPOCTL=$(su -c 'command -v sysrepoctl' -l "$USER")
    else
        # normal user
        SYSREPOCTL=$(command -v sysrepoctl)
    fi

    if [ -z "$SYSREPOCTL" ]; then
        echo "$0: Unable to find sysrepoctl executable." >&2
        exit 1
    fi
}

# get path to the mbedtls executable - store in $MBEDTLS
function MBEDTLS_GET_PATH() {
    if [ -n "$MBEDTLS_EXECUTABLE" ]; then
        # from env
        MBEDTLS="$MBEDTLS_EXECUTABLE"
    elif [ $(id -u) -eq 0 ] && [ -n "$USER" ] && [ $(command -v su) ]; then
        # running as root, avoid problems with sudo PATH
        MBEDTLS=$(su -c 'command -v gen_key' -l "$USER")
    else
        # normal user
        MBEDTLS=$(command -v gen_key)
    fi
}

# get path to the openssl executable - store in $OPENSSL
function OPENSSL_GET_PATH() {
    if [ -n "$OPENSSL_EXECUTABLE" ]; then
        # from env
        OPENSSL="$OPENSSL_EXECUTABLE"
    elif [ $(id -u) -eq 0 ] && [ -n "$USER" ] && [ $(command -v su) ]; then
        # running as root, avoid problems with sudo PATH
        OPENSSL=$(su -c 'command -v openssl' -l "$USER")
    else
        # normal user
        OPENSSL=$(command -v openssl)
    fi
}

# get paths to the crypto key generation executables - store in $MBEDTLS and $OPENSSL
function CRYPTO_KEYGEN_GET_PATHS() {
    MBEDTLS_GET_PATH
    OPENSSL_GET_PATH
    if [ -z "$MBEDTLS" ] && [ -z "$OPENSSL" ]; then
        echo "$0: Unable to find mbedtls nor openssl executable." >&2
        exit 1
    fi
}
