package http3

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/http/httptest"
	"net/http/httptrace"
	"os"
	"slices"
	"strings"
	"testing"
	"time"

	"github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3/qlog"
	"github.com/quic-go/quic-go/qlogwriter"
	"github.com/quic-go/quic-go/testutils/events"

	"github.com/quic-go/qpack"

	"github.com/stretchr/testify/require"
	"go.uber.org/mock/gomock"
)

func getDataFrame(data []byte) []byte {
	b := (&dataFrame{Length: uint64(len(data))}).Append(nil)
	return append(b, data...)
}

func TestStreamReadDataFrames(t *testing.T) {
	var buf bytes.Buffer
	mockCtrl := gomock.NewController(t)
	qstr := NewMockDatagramStream(mockCtrl)
	qstr.EXPECT().StreamID().Return(quic.StreamID(42)).AnyTimes()
	qstr.EXPECT().Write(gomock.Any()).DoAndReturn(buf.Write).AnyTimes()
	qstr.EXPECT().Read(gomock.Any()).DoAndReturn(buf.Read).AnyTimes()

	var eventRecorder events.Recorder
	clientConn, _ := newConnPair(t, withClientRecorder(&eventRecorder))
	str := newStream(
		qstr,
		newRawConn(clientConn, false, nil, nopControlStrHandler, &eventRecorder, nil),
		nil,
		func(io.Reader, *headersFrame) error { return nil },
		&eventRecorder,
	)
	require.Same(t, clientConn.QlogTrace(), str.QlogTrace())

	buf.Write(getDataFrame([]byte("foobar")))
	b := make([]byte, 3)
	n, err := str.Read(b)
	require.NoError(t, err)
	require.Equal(t, 3, n)
	require.Equal(t, []byte("foo"), b)
	n, err = str.Read(b)
	require.NoError(t, err)
	require.Equal(t, 3, n)
	require.Equal(t, []byte("bar"), b)

	expectedLen, _ := expectedFrameLength(t, &dataFrame{Length: 6})
	require.Equal(t,
		[]qlogwriter.Event{
			qlog.FrameParsed{
				StreamID: 42,
				Raw:      qlog.RawInfo{Length: expectedLen, PayloadLength: 6},
				Frame:    qlog.Frame{Frame: qlog.DataFrame{}},
			},
		},
		eventRecorder.Events(qlog.FrameParsed{}),
	)
	eventRecorder.Clear()

	buf.Write(getDataFrame([]byte("baz")))
	b = make([]byte, 10)
	n, err = str.Read(b)
	require.NoError(t, err)
	require.Equal(t, 3, n)
	require.Equal(t, []byte("baz"), b[:n])
	require.Len(t, eventRecorder.Events(qlog.FrameParsed{}), 1)
	eventRecorder.Clear()

	buf.Write(getDataFrame([]byte("lorem")))
	buf.Write(getDataFrame([]byte("ipsum")))

	data, err := io.ReadAll(str)
	require.NoError(t, err)
	require.Equal(t, "loremipsum", string(data))
	require.Len(t, eventRecorder.Events(qlog.FrameParsed{}), 2)
	eventRecorder.Clear()

	// invalid frame
	buf.Write([]byte("invalid"))
	_, err = str.Read([]byte{0})
	require.Error(t, err)
}

func TestStreamInvalidFrame(t *testing.T) {
	var buf bytes.Buffer
	b := (&settingsFrame{}).Append(nil)
	buf.Write(b)

	mockCtrl := gomock.NewController(t)
	qstr := NewMockDatagramStream(mockCtrl)
	qstr.EXPECT().StreamID().Return(quic.StreamID(42)).AnyTimes()
	qstr.EXPECT().Write(gomock.Any()).DoAndReturn(buf.Write).AnyTimes()
	qstr.EXPECT().Read(gomock.Any()).DoAndReturn(buf.Read).AnyTimes()
	clientConn, serverConn := newConnPair(t)

	str := newStream(
		qstr,
		newRawConn(clientConn, false, nil, nopControlStrHandler, nil, nil),
		nil,
		func(io.Reader, *headersFrame) error { return nil },
		nil,
	)

	_, err := str.Read([]byte{0})
	require.ErrorContains(t, err, "peer sent an unexpected frame")

	select {
	case <-serverConn.Context().Done():
		var appErr *quic.ApplicationError
		require.ErrorAs(t, context.Cause(serverConn.Context()), &appErr)
		require.Equal(t, quic.ApplicationErrorCode(ErrCodeFrameUnexpected), appErr.ErrorCode)
	case <-time.After(time.Second):
		t.Fatal("timeout")
	}
}

func TestStreamWrite(t *testing.T) {
	var buf bytes.Buffer
	mockCtrl := gomock.NewController(t)
	qstr := NewMockDatagramStream(mockCtrl)
	qstr.EXPECT().StreamID().Return(quic.StreamID(42)).AnyTimes()
	qstr.EXPECT().Write(gomock.Any()).DoAndReturn(buf.Write).AnyTimes()
	var eventRecorder events.Recorder
	clientConn, _ := newConnPair(t)
	str := newStream(qstr, newRawConn(clientConn, false, nil, nopControlStrHandler, &eventRecorder, nil), nil, func(io.Reader, *headersFrame) error { return nil }, &eventRecorder)
	str.Write([]byte("foo"))
	str.Write([]byte("foobar"))

	fp := frameParser{r: &buf}
	f, err := fp.ParseNext(nil)
	require.NoError(t, err)
	f1Len, f1PayloadLen := expectedFrameLength(t, &dataFrame{Length: 3})
	require.Equal(t, &dataFrame{Length: 3}, f)
	b := make([]byte, 3)
	_, err = io.ReadFull(&buf, b)
	require.NoError(t, err)
	require.Equal(t, []byte("foo"), b)

	fp = frameParser{r: &buf}
	f, err = fp.ParseNext(nil)
	require.NoError(t, err)
	f2Len, f2PayloadLen := expectedFrameLength(t, &dataFrame{Length: 6})
	require.Equal(t, &dataFrame{Length: 6}, f)
	b = make([]byte, 6)
	_, err = io.ReadFull(&buf, b)
	require.NoError(t, err)
	require.Equal(t, []byte("foobar"), b)

	require.Equal(t,
		[]qlogwriter.Event{
			qlog.FrameCreated{
				StreamID: 42,
				Raw:      qlog.RawInfo{Length: f1Len, PayloadLength: f1PayloadLen},
				Frame:    qlog.Frame{Frame: qlog.DataFrame{}},
			},
			qlog.FrameCreated{
				StreamID: 42,
				Raw:      qlog.RawInfo{Length: f2Len, PayloadLength: f2PayloadLen},
				Frame:    qlog.Frame{Frame: qlog.DataFrame{}},
			},
		},
		eventRecorder.Events(qlog.FrameCreated{}),
	)
}

func TestStreamWriteRetry(t *testing.T) {
	data := []byte("foobar")
	for cut := range len(getDataFrame(data)) {
		t.Run(fmt.Sprintf("deadline after %d bytes", cut), func(t *testing.T) {
			var buf bytes.Buffer
			deadlineExpired := true
			mockCtrl := gomock.NewController(t)
			qstr := NewMockDatagramStream(mockCtrl)
			qstr.EXPECT().StreamID().Return(quic.StreamID(42)).AnyTimes()
			qstr.EXPECT().Write(gomock.Any()).DoAndReturn(func(b []byte) (int, error) {
				if deadlineExpired && buf.Len()+len(b) > cut {
					n, _ := buf.Write(b[:cut-buf.Len()])
					return n, os.ErrDeadlineExceeded
				}
				return buf.Write(b)
			}).AnyTimes()
			str := newStream(qstr, nil, nil, nil, nil)

			n, err := str.Write(data)
			require.ErrorIs(t, err, os.ErrDeadlineExceeded)
			// retry after extending the write deadline:
			// the unfinished DATA frame is completed, and a new one is started for the rest
			deadlineExpired = false
			_, err = str.Write(slices.Concat(data[n:], []byte("baz")))
			require.NoError(t, err)
			require.Equal(t, append(getDataFrame(data), getDataFrame([]byte("baz"))...), buf.Bytes())
		})
	}
}

func TestStreamTryWriteAllAfterPartialWrite(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	qstr := NewMockDatagramStream(mockCtrl)
	qstr.EXPECT().StreamID().Return(quic.StreamID(42)).AnyTimes()
	qstr.EXPECT().Write((&dataFrame{Length: 6}).Append(nil)).DoAndReturn(io.Discard.Write)
	qstr.EXPECT().Write([]byte("foobar")).Return(2, os.ErrDeadlineExceeded)
	str := newStream(qstr, nil, nil, nil, nil)
	_, err := str.Write([]byte("foobar"))
	require.ErrorIs(t, err, os.ErrDeadlineExceeded)

	// the unfinished DATA frame is completed, and a new one is started for the rest
	data := append([]byte("obar"), getDataFrame([]byte("baz"))...)
	qstr.EXPECT().TryWriteAll(data).Return(quic.ErrWouldBlock)
	require.ErrorIs(t, str.TryWriteAll([]byte("obarbaz")), quic.ErrWouldBlock)
	// nothing was queued, so the next call sends the same data
	qstr.EXPECT().TryWriteAll(data).Return(nil)
	require.NoError(t, str.TryWriteAll([]byte("obarbaz")))
}

func TestStreamQlogWriteAfterConnectionClose(t *testing.T) {
	clientConn, _ := newConnPair(t)
	rec := &closeTrackingRecorder{closed: make(chan struct{})}
	conn := newRawConn(clientConn, false, nil, nopControlStrHandler, rec, nil)
	qstr, err := clientConn.OpenStream()
	require.NoError(t, err)
	str := newStream(conn.TrackStream(qstr), conn, nil, nil, rec)

	clientConn.CloseWithError(0, "")
	select {
	case <-rec.closed:
	case <-time.After(time.Second):
		t.Fatal("timeout")
	}
	// closeTrackingRecorder panics if an event is recorded after Close
	_, err = str.Write([]byte("foo"))
	require.Error(t, err)
}

func TestStreamTryWriteAll(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	qstr := NewMockDatagramStream(mockCtrl)
	qstr.EXPECT().StreamID().Return(quic.StreamID(42)).AnyTimes()
	qstr.EXPECT().TryWriteAll(getDataFrame([]byte("foobar"))).Return(nil)
	qstr.EXPECT().TryWriteAll(getDataFrame([]byte("blocked"))).Return(quic.ErrWouldBlock)

	var eventRecorder events.Recorder
	clientConn, _ := newConnPair(t)
	str := newStream(qstr, newRawConn(clientConn, false, nil, nopControlStrHandler, &eventRecorder, nil), nil, func(io.Reader, *headersFrame) error { return nil }, &eventRecorder)
	require.NoError(t, str.TryWriteAll([]byte("foobar")))
	require.ErrorIs(t, str.TryWriteAll([]byte("blocked")), quic.ErrWouldBlock)

	frameLen, payloadLen := expectedFrameLength(t, &dataFrame{Length: 6})
	require.Equal(t,
		[]qlogwriter.Event{
			qlog.FrameCreated{
				StreamID: 42,
				Raw:      qlog.RawInfo{Length: frameLen, PayloadLength: payloadLen},
				Frame:    qlog.Frame{Frame: qlog.DataFrame{}},
			},
		},
		eventRecorder.Events(qlog.FrameCreated{}),
	)
}

func TestRequestStream(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	qstr := NewMockDatagramStream(mockCtrl)
	qstr.EXPECT().StreamID().Return(quic.StreamID(42)).AnyTimes()
	requestWriter := newRequestWriter()
	clientConn, _ := newConnPair(t)
	str := newRequestStream(
		newStream(
			qstr,
			newRawConn(clientConn, false, nil, nopControlStrHandler, nil, nil),
			&httptrace.ClientTrace{},
			func(io.Reader, *headersFrame) error { return nil },
			nil,
		),
		requestWriter,
		make(chan struct{}),
		qpack.NewDecoder(),
		true,
		math.MaxInt,
		&http.Response{},
	)
	require.Same(t, clientConn.QlogTrace(), str.QlogTrace())

	_, err := str.Read([]byte{0})
	require.EqualError(t, err, "http3: invalid use of RequestStream.Read before ReadResponse")
	_, err = str.Write([]byte{0})
	require.EqualError(t, err, "http3: invalid use of RequestStream.Write before SendRequestHeader")
	require.EqualError(t,
		str.TryWriteAll([]byte{0}),
		"http3: invalid use of RequestStream.TryWriteAll before SendRequestHeader",
	)

	// calling ReadResponse before SendRequestHeader is not valid
	_, err = str.ReadResponse()
	require.EqualError(t, err, "http3: invalid use of RequestStream.ReadResponse before SendRequestHeader")
	// SendRequestHeader can't be used for requests that have a request body
	require.EqualError(t,
		str.SendRequestHeader(
			httptest.NewRequest(http.MethodGet, "https://quic-go.net", strings.NewReader("foobar")),
		),
		"http3: invalid use of RequestStream.SendRequestHeader with a request that has a request body",
	)

	req := httptest.NewRequest(http.MethodGet, "https://quic-go.net", nil)
	qstr.EXPECT().Write(gomock.Any()).AnyTimes()
	require.NoError(t, str.SendRequestHeader(req))
	// duplicate calls are not allowed
	require.EqualError(t, str.SendRequestHeader(req), "http3: invalid duplicate use of RequestStream.SendRequestHeader")
	qstr.EXPECT().TryWriteAll(getDataFrame([]byte("request body"))).Return(nil)
	require.NoError(t, str.TryWriteAll([]byte("request body")))

	buf := bytes.NewBuffer(encodeResponse(t, http.StatusOK))
	buf.Write((&dataFrame{Length: 6}).Append(nil))
	buf.Write([]byte("foobar"))
	qstr.EXPECT().Read(gomock.Any()).DoAndReturn(buf.Read).AnyTimes()
	rsp, err := str.ReadResponse()
	require.NoError(t, err)
	require.Equal(t, http.StatusOK, rsp.StatusCode)

	b := make([]byte, 10)
	n, err := str.Read(b)
	require.NoError(t, err)
	require.Equal(t, 6, n)
	require.Equal(t, []byte("foobar"), b[:n])
}
