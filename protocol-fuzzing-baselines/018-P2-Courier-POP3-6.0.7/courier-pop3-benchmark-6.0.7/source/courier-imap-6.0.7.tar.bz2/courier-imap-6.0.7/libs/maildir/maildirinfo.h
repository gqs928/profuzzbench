#ifndef	maildir_maildirinfo_h
#define	maildir_maildirinfo_h

#include "config.h"

#ifdef  __cplusplus
extern "C" {
#endif

/*
** Copyright 2004 S. Varshavchik.
** See COPYING for distribution information.
*/


struct maildir_info {
	int mailbox_type;
	char *homedir;
	char *maildir;
	char *owner;
};

char *imap_foldername_to_filename(int utf8_format, const char *foldername);

char *imap_filename_to_foldername(int utf8_format, const char *filename);

void maildir_info_destroy(struct maildir_info *); /* Deallocate memory */

int maildir_info_imap_find(struct maildir_info *info, const char *path,
			   const char *myid);

/*
** Initialize info based on path.  Returns 0 for success, -1 if path is
** syntactically invalid.  The mailbox may not actually exist.
**
** 'myid' is my login id, used to initialize owner (see below) for INBOX
** folders.
**
** homedir is set to the mailbox's homedir, which may not necessarily be
** "." if path points to #shared.user.folder.
** maildir is the local mailbox path, such as INBOX.folder
**
** owner will be set to the mailbox's owner, for ACL purposes.
**
** maildir will be NULL for a node in the legacy shared hierarchy.
*/

#define MAILBOXTYPE_INBOX 0	/* Inbox maildir */
#define MAILBOXTYPE_OLDSHARED 1	/* Legacy shared hierarchy */
#define MAILBOXTYPE_NEWSHARED 2 /* #shared hierarchy */

#define MAILBOXTYPE_IGNORE  255 /* Ignore this mailbox */

#define MAILBOXTYPE_ERROR  -1 /* Internal status, not returned */

/*
** The application must define the following callback function that returns
** non-zero if the filename refers to the current account's maildir, and
** should be suppressed from the shared folder hierarchy.
*/
extern int maildir_info_suppress(const char *maildir);

/*
** The shared index files use UTF-8.  Convenience function to convert
** names into IMAP-compatible modified-UTF7.
*/

extern void maildir_info_munge_complex(int);
	/* If true, use "complex" munging */

extern char *maildir_info_imapmunge(const char *name);

#ifdef  __cplusplus
}

#include <string>
#include <string_view>
#include <vector>

namespace maildir {
#if 0
}
#endif

typedef std::vector<const char *> smap_words_t;

struct info {
	int mailbox_type=MAILBOXTYPE_ERROR;
	std::string homedir;
	std::string maildir;
	std::string owner;

	operator bool() const
	{
		return mailbox_type != MAILBOXTYPE_ERROR;
	}

	bool regular_maildir() const
	{
		return !homedir.empty() && !maildir.empty();
	}
};

info info_imap_find(const std::string &path,
		    const std::string &myid);

/*
** The SMAP version:
*/

info info_smap_find(const smap_words_t &, const std::string &myid);

std::vector<std::string> smapfn_fromutf8(const std::string &modutf8);

/*
** Conversions between IMAP folder names to filenames.
**
** Filenames are in UTF-8.
**
** If utf8_format, the same string gets returned, else the folder name
** gets translated from modified-UTF7.
*/

std::string imap_foldername_to_filename(bool utf8_format,
					std::string_view foldername);

std::string imap_filename_to_foldername(bool utf8_format,
					std::string_view filename);

#if 0
{
#endif
}
#endif

#endif
