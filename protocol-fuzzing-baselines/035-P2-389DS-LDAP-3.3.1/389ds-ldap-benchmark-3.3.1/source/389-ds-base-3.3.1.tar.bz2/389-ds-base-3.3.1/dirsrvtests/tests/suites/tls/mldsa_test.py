# --- BEGIN COPYRIGHT BLOCK ---
# Copyright (C) 2026 Red Hat, Inc.
# All rights reserved.
#
# License: GPL (version 3 or any later version).
# See LICENSE for details.
# --- END COPYRIGHT BLOCK ---
#
import logging
import pytest
import os
import sys
import socket
import subprocess
from lib389.utils import ds_is_older, rpm_is_older
from lib389._constants import DN_DM, PW_DM, DEFAULT_SUFFIX
from lib389.config import Encryption, CertmapLegacy
from lib389.idm.user import UserAccount
from test389.topologies import topology_st as topo
from tempfile import TemporaryDirectory

pytestmark = pytest.mark.tier1

DEBUGGING = os.getenv("DEBUGGING", default=False)
if DEBUGGING:
    logging.getLogger(__name__).setLevel(logging.DEBUG)
else:
    logging.getLogger(__name__).setLevel(logging.INFO)
log = logging.getLogger(__name__)


script_content="""
#!/bin/bash
set -e  # Exit if a command fails
set -x  # Log the commands

cd {dir}
inst={instname}
url={url}
rootdn="{rootdn}"
rootpw="{rootpw}"

################################
###### GENERATE CA CERT ########
################################

echo "
[ req ]
distinguished_name = req_distinguished_name
policy             = policy_match
x509_extensions     = v3_ca

# For the CA policy
[ policy_match ]
countryName             = optional
stateOrProvinceName     = optional
organizationName        = optional
organizationalUnitName  = optional
commonName              = supplied
emailAddress            = optional

[ req_distinguished_name ]
countryName			= Country Name (2 letter code)
countryName_default		= FR
countryName_min			= 2
countryName_max			= 2

stateOrProvinceName		= State or Province Name (full name)
stateOrProvinceName_default	= test

localityName			= Locality Name (eg, city)

0.organizationName		= Organization Name (eg, company)
0.organizationName_default	= test-ML-DSA-CA

organizationalUnitName		= Organizational Unit Name (eg, section)
#organizationalUnitName_default	=

commonName			= Common Name (e.g. server FQDN or YOUR name)
commonName_max			= 64


[ v3_ca ]
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical,CA:true
#nsComment = "OpenSSL Generated Certificate"
keyUsage=critical, keyCertSign
" >ca.conf


openssl genpkey -algorithm ML-DSA-87 -out ca.key
openssl req -x509 -new -sha256 -key ca.key -nodes -days 3650 -config ca.conf -subj "/CN=`hostname`/O=test-ML-DSA-CA/C=FR"  -out ca.pem -keyout ca.key
openssl x509 -outform der -in ca.pem -out ca.crt

openssl x509 -text -in ca.pem

####################################
###### GENERATE SERVER CERT ########
####################################

echo "
[ req ]
distinguished_name = req_distinguished_name
policy             = policy_match
x509_extensions     = v3_cert

# For the cert policy
[ policy_match ]
countryName             = optional
stateOrProvinceName     = optional
organizationName        = optional
organizationalUnitName  = optional
commonName              = supplied
emailAddress            = optional

[ req_distinguished_name ]
countryName			= Country Name (2 letter code)
countryName_default		= FR
countryName_min			= 2
countryName_max			= 2

stateOrProvinceName		= State or Province Name (full name)

localityName			= Locality Name (eg, city)

0.organizationName		= Organization Name (eg, company)
0.organizationName_default	= test-ML-DSA

organizationalUnitName		= Organizational Unit Name (eg, section)
#organizationalUnitName_default	=

commonName			= Common Name (e.g. server FQDN or YOUR name)
commonName_max			= 64


[ v3_cert ]
basicConstraints = critical,CA:false
subjectAltName=DNS:`hostname`
keyUsage=digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
#nsComment = "OpenSSL Generated Certificate"
extendedKeyUsage=clientAuth, serverAuth
nsCertType=client, server
" >cert.conf

openssl genpkey -algorithm ML-DSA-65 -out cert.key
openssl req -new -sha256 -key cert.key -nodes  -config cert.conf -subj "/CN=`hostname`/O=test-ML-DSA/C=FR" -out cert.csr
openssl x509 -req -sha256 -days 3650 -extensions v3_cert -extfile cert.conf -in cert.csr -CA ca.pem -CAkey ca.key -CAcreateserial -out cert.pem
openssl pkcs12 -export -inkey cert.key -in cert.pem -name mldsacert -out cert.p12 -passout pass:secret12

openssl x509 -text -in cert.pem



####################################
###### GENERATE CLIENT CERT ########
####################################

echo "
[ req ]
distinguished_name = req_distinguished_name
policy             = policy_match
x509_extensions     = v3_cert

# For the cert policy
[ policy_match ]
countryName             = optional
stateOrProvinceName     = optional
organizationName        = optional
organizationalUnitName  = optional
commonName              = supplied
emailAddress            = optional

[ req_distinguished_name ]
countryName			= Country Name (2 letter code)
countryName_default		= FR
countryName_min			= 2
countryName_max			= 2

stateOrProvinceName		= State or Province Name (full name)

localityName			= Locality Name (eg, city)

0.organizationName		= Organization Name (eg, company)
0.organizationName_default	= test-ML-DSA

organizationalUnitName		= Organizational Unit Name (eg, section)
#organizationalUnitName_default	=

commonName			= Common Name (e.g. server FQDN or YOUR name)
commonName_max			= 64


[ v3_cert ]
basicConstraints = critical,CA:false
subjectAltName=DNS:`hostname`
keyUsage=digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
#nsComment = "OpenSSL Generated Certificate"
extendedKeyUsage=clientAuth
nsCertType=client, server
" >client.conf

openssl genpkey -algorithm ML-DSA-65 -out client.key
openssl req -new -sha256 -key client.key -nodes  -config client.conf -subj "/CN=`hostname`/O=client-test-ML-DSA/C=FR" -out client.csr
openssl x509 -req -sha256 -days 3650 -extensions v3_cert -extfile client.conf -in client.csr -CA ca.pem -CAkey ca.key -CAcreateserial -out client.pem
openssl pkcs12 -export -inkey client.key -in client.pem -name mldsacert2 -out client.p12 -passout pass:secret12

openssl x509 -text -in client.pem


#############################
###### INSTALL CERTS ########
#############################

certdbdir=$PREFIX/etc/dirsrv/slapd-$inst
rm -f $certdbdir/cert9.db $certdbdir/key4.db
certutil -N -d $certdbdir -f $certdbdir/pwdfile.txt

certutil -A -n Self-Signed-CA -t CT,, -f $certdbdir/pwdfile.txt -d $certdbdir -a -i ca.pem
certutil -A -n Client-Cert -t u,, -f $certdbdir/pwdfile.txt -d $certdbdir -a -i client.pem

dsctl $inst tls import-server-key-cert cert.pem cert.key

dsctl $inst restart


#########################
###### TEST CERT ########
#########################
export LDAPTLS_CACERT=$PWD/ca.pem
export LDAPTLS_CERT=$PWD/client.pem
export LDAPTLS_KEY=$PWD/client.key

ldapsearch -x -H $url -D "$rootdn" -w "$rootpw" -b "" -s base
ldapsearch -Y external -H $url -b "" -s base
"""

@pytest.mark.skipif(rpm_is_older("openssl", "3.5"), reason="OpenSSL too old to support PQC")
@pytest.mark.skipif(rpm_is_older("nss", "3.119.1"), reason="NSS too old to support PQC")
def test_mldsa(topo):
    """Test using ML-DSA Certificate - (PQC)

    :id: 87fb19ef-672d-4fa7-934d-dfb4397f2312
    :setup: Standalone Instance
    :steps:
        1. Configure the certmap
        2. Create user mapped with theclient certificate
        3. Generate the test script
        4. Run the test script
        5. Check that ldapsearch returned the namingcontext
    :expectedresults:
        1. No error
        2. No error
        3. No error
        4. No error and exit code should be 0
        5. namingcontext should be in the script output
    """

    inst = topo.standalone
    inst.config.set('nsslapd-errorlog-level', str(16384 + 8))
    inst.enable_tls()

    cm = CertmapLegacy(inst)
    certmaps = cm.list()
    certmaps['default'].update({'DNComps': None, 'CmapLdapAttr': 'description'})
    cm.set(certmaps)

    cert_dn = f'C=FR,O=client-test-ML-DSA,CN={socket.gethostname()}'
    dn = f'uid=test_user,ou=people,{DEFAULT_SUFFIX}'
    UserAccount(inst, dn=dn).create( properties= {
            'uid': 'test_user',
            'cn': 'Test user',
            'sn': 'Test user',
            'uidNumber': '99998',
            'gidNumber': '99998',
            'homeDirectory': '/var/empty',
            'loginShell': '/bin/false',
            'description': cert_dn })

    inst.config.set("nsslapd-accesslog-logbuffering", "off")
    inst.config.set("nsslapd-errorlog-logbuffering", "off")

    tmpdir_kwargs = {}
    if sys.version_info >= (3, 12):
        tmpdir_kwargs['delete'] = not DEBUGGING
    with TemporaryDirectory(**tmpdir_kwargs) as dir:
        scriptname = f"{dir}/doit"
        d = {
            'dir': dir,
            'instname': inst.serverid,
            'url': f"ldaps://localhost:{inst.sslport}",
            'rootdn': DN_DM,
            'rootpw': PW_DM,
        }
        with open(scriptname, 'w') as f:
            f.write(script_content.format(**d))
        res = subprocess.run(('/bin/bash', scriptname), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding='utf-8')
        assert res
        log.info(res.stdout)
        res.check_returncode()
        # If ldapsearch is successful then defaultnamingcontext should be in res.stdout
        assert "defaultnamingcontext" in res.stdout
    assert inst.ds_access_log.match('.*RESULT.*dn="uid=test_user,ou=people,dc=example,dc=com".*')
    assert inst.ds_access_log.match('.*TLS.*[PQC].*')
    assert inst.ds_error_log.match('.*check_pqc.*')


if __name__ == '__main__':
    # Run isolated
    # -s for DEBUG mode
    CURRENT_FILE = os.path.realpath(__file__)
    pytest.main(["-s", CURRENT_FILE])
