/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_SIEVE_SIEVE_SIEVE_H_INCLUDED
# define YY_SIEVE_SIEVE_SIEVE_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int sievedebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    NUMBER = 258,                  /* NUMBER  */
    STRING = 259,                  /* STRING  */
    IF = 260,                      /* IF  */
    ELSIF = 261,                   /* ELSIF  */
    ELSE = 262,                    /* ELSE  */
    REQUIRE = 263,                 /* REQUIRE  */
    STOP = 264,                    /* STOP  */
    DISCARD = 265,                 /* DISCARD  */
    KEEP = 266,                    /* KEEP  */
    FILEINTO = 267,                /* FILEINTO  */
    REDIRECT = 268,                /* REDIRECT  */
    ANYOF = 269,                   /* ANYOF  */
    ALLOF = 270,                   /* ALLOF  */
    EXISTS = 271,                  /* EXISTS  */
    NOT = 272,                     /* NOT  */
    SFALSE = 273,                  /* SFALSE  */
    STRUE = 274,                   /* STRUE  */
    SIZE = 275,                    /* SIZE  */
    HEADERT = 276,                 /* HEADERT  */
    ADDRESS = 277,                 /* ADDRESS  */
    ENVELOPE = 278,                /* ENVELOPE  */
    COMPARATOR = 279,              /* COMPARATOR  */
    OVER = 280,                    /* OVER  */
    UNDER = 281,                   /* UNDER  */
    ALL = 282,                     /* ALL  */
    LOCALPART = 283,               /* LOCALPART  */
    DOMAIN = 284,                  /* DOMAIN  */
    IS = 285,                      /* IS  */
    CONTAINS = 286,                /* CONTAINS  */
    MATCHES = 287,                 /* MATCHES  */
    OCTET = 288,                   /* OCTET  */
    ASCIICASEMAP = 289,            /* ASCIICASEMAP  */
    ASCIINUMERIC = 290,            /* ASCIINUMERIC  */
    UNICODECASEMAP = 291,          /* UNICODECASEMAP  */
    REGEX = 292,                   /* REGEX  */
    QUOTEREGEX = 293,              /* QUOTEREGEX  */
    COPY = 294,                    /* COPY  */
    BODY = 295,                    /* BODY  */
    RAW = 296,                     /* RAW  */
    TEXT = 297,                    /* TEXT  */
    CONTENT = 298,                 /* CONTENT  */
    ENVIRONMENT = 299,             /* ENVIRONMENT  */
    STRINGT = 300,                 /* STRINGT  */
    SET = 301,                     /* SET  */
    LOWER = 302,                   /* LOWER  */
    UPPER = 303,                   /* UPPER  */
    LOWERFIRST = 304,              /* LOWERFIRST  */
    UPPERFIRST = 305,              /* UPPERFIRST  */
    QUOTEWILDCARD = 306,           /* QUOTEWILDCARD  */
    LENGTH = 307,                  /* LENGTH  */
    VACATION = 308,                /* VACATION  */
    DAYS = 309,                    /* DAYS  */
    SUBJECT = 310,                 /* SUBJECT  */
    FROM = 311,                    /* FROM  */
    ADDRESSES = 312,               /* ADDRESSES  */
    MIME = 313,                    /* MIME  */
    HANDLE = 314,                  /* HANDLE  */
    SECONDS = 315,                 /* SECONDS  */
    COUNT = 316,                   /* COUNT  */
    VALUE = 317,                   /* VALUE  */
    GT = 318,                      /* GT  */
    GE = 319,                      /* GE  */
    LT = 320,                      /* LT  */
    LE = 321,                      /* LE  */
    EQ = 322,                      /* EQ  */
    NE = 323,                      /* NE  */
    FLAGS = 324,                   /* FLAGS  */
    HASFLAG = 325,                 /* HASFLAG  */
    SETFLAG = 326,                 /* SETFLAG  */
    ADDFLAG = 327,                 /* ADDFLAG  */
    REMOVEFLAG = 328,              /* REMOVEFLAG  */
    USER = 329,                    /* USER  */
    DETAIL = 330,                  /* DETAIL  */
    DATE = 331,                    /* DATE  */
    CURRENTDATE = 332,             /* CURRENTDATE  */
    ORIGINALZONE = 333,            /* ORIGINALZONE  */
    ZONE = 334,                    /* ZONE  */
    INDEX = 335,                   /* INDEX  */
    LAST = 336,                    /* LAST  */
    ADDHEADER = 337,               /* ADDHEADER  */
    DELETEHEADER = 338,            /* DELETEHEADER  */
    REJCT = 339,                   /* REJCT  */
    EREJECT = 340,                 /* EREJECT  */
    OPTIONS = 341,                 /* OPTIONS  */
    MESSAGE = 342,                 /* MESSAGE  */
    IMPORTANCE = 343,              /* IMPORTANCE  */
    VALIDNOTIFYMETHOD = 344,       /* VALIDNOTIFYMETHOD  */
    NOTIFYMETHODCAPABILITY = 345,  /* NOTIFYMETHODCAPABILITY  */
    NOTIFY = 346,                  /* NOTIFY  */
    ENCODEURL = 347,               /* ENCODEURL  */
    LOW = 348,                     /* LOW  */
    NORMAL = 349,                  /* NORMAL  */
    HIGH = 350,                    /* HIGH  */
    IHAVE = 351,                   /* IHAVE  */
    ERROR = 352,                   /* ERROR  */
    MAILBOXEXISTS = 353,           /* MAILBOXEXISTS  */
    CREATE = 354,                  /* CREATE  */
    METADATA = 355,                /* METADATA  */
    METADATAEXISTS = 356,          /* METADATAEXISTS  */
    SERVERMETADATA = 357,          /* SERVERMETADATA  */
    SERVERMETADATAEXISTS = 358,    /* SERVERMETADATAEXISTS  */
    BYTIMEREL = 359,               /* BYTIMEREL  */
    BYTIMEABS = 360,               /* BYTIMEABS  */
    BYMODE = 361,                  /* BYMODE  */
    BYTRACE = 362,                 /* BYTRACE  */
    DSNNOTIFY = 363,               /* DSNNOTIFY  */
    DSNRET = 364,                  /* DSNRET  */
    VALIDEXTLIST = 365,            /* VALIDEXTLIST  */
    LIST = 366,                    /* LIST  */
    INCLUDE = 367,                 /* INCLUDE  */
    OPTIONAL = 368,                /* OPTIONAL  */
    ONCE = 369,                    /* ONCE  */
    RETURN = 370,                  /* RETURN  */
    PERSONAL = 371,                /* PERSONAL  */
    GLOBAL = 372,                  /* GLOBAL  */
    DUPLICATE = 373,               /* DUPLICATE  */
    HEADER = 374,                  /* HEADER  */
    UNIQUEID = 375,                /* UNIQUEID  */
    SPECIALUSEEXISTS = 376,        /* SPECIALUSEEXISTS  */
    SPECIALUSE = 377,              /* SPECIALUSE  */
    FCC = 378,                     /* FCC  */
    MAILBOXID = 379,               /* MAILBOXID  */
    MAILBOXIDEXISTS = 380,         /* MAILBOXIDEXISTS  */
    SNOOZE = 381,                  /* SNOOZE  */
    MAILBOX = 382,                 /* MAILBOX  */
    ADDFLAGS = 383,                /* ADDFLAGS  */
    REMOVEFLAGS = 384,             /* REMOVEFLAGS  */
    WEEKDAYS = 385,                /* WEEKDAYS  */
    TZID = 386,                    /* TZID  */
    LOG = 387,                     /* LOG  */
    JMAPQUERY = 388,               /* JMAPQUERY  */
    PROCESSCAL = 389,              /* PROCESSCAL  */
    ALLOWPUBLIC = 390,             /* ALLOWPUBLIC  */
    INVITESONLY = 391,             /* INVITESONLY  */
    UPDATESONLY = 392,             /* UPDATESONLY  */
    DELETECANCELLED = 393,         /* DELETECANCELLED  */
    ORGANIZERS = 394,              /* ORGANIZERS  */
    CALENDARID = 395,              /* CALENDARID  */
    OUTCOME = 396,                 /* OUTCOME  */
    REASON = 397,                  /* REASON  */
    PROCESSIMIP = 398,             /* PROCESSIMIP  */
    IKEEP_TARGET = 399             /* IKEEP_TARGET  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define NUMBER 258
#define STRING 259
#define IF 260
#define ELSIF 261
#define ELSE 262
#define REQUIRE 263
#define STOP 264
#define DISCARD 265
#define KEEP 266
#define FILEINTO 267
#define REDIRECT 268
#define ANYOF 269
#define ALLOF 270
#define EXISTS 271
#define NOT 272
#define SFALSE 273
#define STRUE 274
#define SIZE 275
#define HEADERT 276
#define ADDRESS 277
#define ENVELOPE 278
#define COMPARATOR 279
#define OVER 280
#define UNDER 281
#define ALL 282
#define LOCALPART 283
#define DOMAIN 284
#define IS 285
#define CONTAINS 286
#define MATCHES 287
#define OCTET 288
#define ASCIICASEMAP 289
#define ASCIINUMERIC 290
#define UNICODECASEMAP 291
#define REGEX 292
#define QUOTEREGEX 293
#define COPY 294
#define BODY 295
#define RAW 296
#define TEXT 297
#define CONTENT 298
#define ENVIRONMENT 299
#define STRINGT 300
#define SET 301
#define LOWER 302
#define UPPER 303
#define LOWERFIRST 304
#define UPPERFIRST 305
#define QUOTEWILDCARD 306
#define LENGTH 307
#define VACATION 308
#define DAYS 309
#define SUBJECT 310
#define FROM 311
#define ADDRESSES 312
#define MIME 313
#define HANDLE 314
#define SECONDS 315
#define COUNT 316
#define VALUE 317
#define GT 318
#define GE 319
#define LT 320
#define LE 321
#define EQ 322
#define NE 323
#define FLAGS 324
#define HASFLAG 325
#define SETFLAG 326
#define ADDFLAG 327
#define REMOVEFLAG 328
#define USER 329
#define DETAIL 330
#define DATE 331
#define CURRENTDATE 332
#define ORIGINALZONE 333
#define ZONE 334
#define INDEX 335
#define LAST 336
#define ADDHEADER 337
#define DELETEHEADER 338
#define REJCT 339
#define EREJECT 340
#define OPTIONS 341
#define MESSAGE 342
#define IMPORTANCE 343
#define VALIDNOTIFYMETHOD 344
#define NOTIFYMETHODCAPABILITY 345
#define NOTIFY 346
#define ENCODEURL 347
#define LOW 348
#define NORMAL 349
#define HIGH 350
#define IHAVE 351
#define ERROR 352
#define MAILBOXEXISTS 353
#define CREATE 354
#define METADATA 355
#define METADATAEXISTS 356
#define SERVERMETADATA 357
#define SERVERMETADATAEXISTS 358
#define BYTIMEREL 359
#define BYTIMEABS 360
#define BYMODE 361
#define BYTRACE 362
#define DSNNOTIFY 363
#define DSNRET 364
#define VALIDEXTLIST 365
#define LIST 366
#define INCLUDE 367
#define OPTIONAL 368
#define ONCE 369
#define RETURN 370
#define PERSONAL 371
#define GLOBAL 372
#define DUPLICATE 373
#define HEADER 374
#define UNIQUEID 375
#define SPECIALUSEEXISTS 376
#define SPECIALUSE 377
#define FCC 378
#define MAILBOXID 379
#define MAILBOXIDEXISTS 380
#define SNOOZE 381
#define MAILBOX 382
#define ADDFLAGS 383
#define REMOVEFLAGS 384
#define WEEKDAYS 385
#define TZID 386
#define LOG 387
#define JMAPQUERY 388
#define PROCESSCAL 389
#define ALLOWPUBLIC 390
#define INVITESONLY 391
#define UPDATESONLY 392
#define DELETECANCELLED 393
#define ORGANIZERS 394
#define CALENDARID 395
#define OUTCOME 396
#define REASON 397
#define PROCESSIMIP 398
#define IKEEP_TARGET 399

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 181 "sieve/sieve.y"

    int nval;
    char *sval;
    arrayu64_t *nl;
    strarray_t *sl;
    comp_t *ctag;
    test_t *test;
    testlist_t *testl;
    commandlist_t *cl;

#line 366 "sieve/sieve.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif




int sieveparse (sieve_script_t *sscript);


#endif /* !YY_SIEVE_SIEVE_SIEVE_H_INCLUDED  */
