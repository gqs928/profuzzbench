/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1


/* Substitute the variable and function names.  */
#define yyparse         sieveparse
#define yylex           sievelex
#define yyerror         sieveerror
#define yydebug         sievedebug
#define yynerrs         sievenerrs

/* First part of user prologue.  */
#line 1 "sieve/sieve.y"

/* sieve.y -- sieve parser
 * Larry Greenfield
 * Ken Murchison
 *
 * Copyright (c) 1994-2017 Carnegie Mellon University.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The name "Carnegie Mellon University" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For permission or any legal
 *    details, please contact
 *      Carnegie Mellon University
 *      Center for Technology Transfer and Enterprise Creation
 *      4615 Forbes Avenue
 *      Suite 302
 *      Pittsburgh, PA  15213
 *      (412) 268-7393, fax: (412) 268-7395
 *      innovation@andrew.cmu.edu
 *
 * 4. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by Computing Services
 *     at Carnegie Mellon University (http://www.cmu.edu/computing/)."
 *
 * CARNEGIE MELLON UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO
 * THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL CARNEGIE MELLON UNIVERSITY BE LIABLE
 * FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

/*
 * Yacc definitions
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "xmalloc.h"
#include "sieve/bytecode.h"
#include "sieve/comparator.h"
#include "sieve/interp.h"
#include "sieve/script.h"
#include "sieve/tree.h"
#include "sieve/flags.h"
#include "sieve/grammar.h"
#include "sieve/sieve_err.h"

#include "util.h"
#include "imparse.h"
#include "libconfig.h"
#include "times.h"
#include "tok.h"

#define ERR_BUF_SIZE 1024

int encoded_char = 0;    /* used to send encoded-character feedback to lexer */
static comp_t *ctags;    /* used for accessing comp_t* in a test/command union */
static int *copy;        /* used for accessing copy flag in a command union */
static int *create;      /* used for accessing create flag in a command union */
static strarray_t **flags; /* used for accessing imap flags in a command union */
static char **specialuse; /* used for accessing special-use flag in a command */
static char **mailboxid; /* used for accessing mailboxid in a command */
static char **fccfolder; /* used for accessing fcc.folder in a command */
static unsigned bctype;  /* used to set the bytecode command type in mtags */
static unsigned legacy;  /* used to signal a legacy version of a command */

extern int addrparse(sieve_script_t*);
typedef struct yy_buffer_state *YY_BUFFER_STATE;
extern YY_BUFFER_STATE addr_scan_string(const char*);
extern void addr_delete_buffer(YY_BUFFER_STATE);

extern int sievelineno;

void sieveerror_c(sieve_script_t*, int code, ...);

static int check_reqs(sieve_script_t*, strarray_t *sl);
static int chk_match_vars(sieve_script_t*, char *s);

static unsigned bc_precompile(cmdarg_t args[], const char *fmt, ...);

/* construct/canonicalize action commands */
static commandlist_t *build_keep(sieve_script_t*, commandlist_t *c);
static commandlist_t *build_fileinto(sieve_script_t*,
                                     commandlist_t *c, char *folder);
static commandlist_t *build_redirect(sieve_script_t*,
                                     commandlist_t *c, char *addr);
static commandlist_t *build_rej_err(sieve_script_t*, int t, char *message);
static commandlist_t *build_vacation(sieve_script_t*, commandlist_t *t, char *s);
static commandlist_t *build_flag(sieve_script_t*,
                                 commandlist_t *c, strarray_t *flags);
static commandlist_t *build_notify(sieve_script_t*,
                                   commandlist_t *c, char *method);
static commandlist_t *build_include(sieve_script_t*, commandlist_t *c, char*);
static commandlist_t *build_set(sieve_script_t*, commandlist_t *c,
                                char *variable, char *value);
static commandlist_t *build_addheader(sieve_script_t*, commandlist_t *c,
                                      char *name, char *value);
static commandlist_t *build_deleteheader(sieve_script_t*, commandlist_t *c,
                                         char *name, strarray_t *values);
static commandlist_t *build_log(sieve_script_t*, char *text);
static commandlist_t *build_snooze(sieve_script_t *sscript,
                                   commandlist_t *c, arrayu64_t *times);
static commandlist_t *build_cal(sieve_script_t *sscript, commandlist_t *t);
static commandlist_t *build_ikeep_target(sieve_script_t*,
                                         commandlist_t *c, char *folder);

/* construct/canonicalize test commands */
static test_t *build_anyof(sieve_script_t*, testlist_t *tl);
static test_t *build_allof(sieve_script_t*, testlist_t *tl);
static test_t *build_not(sieve_script_t*, test_t *t);
static test_t *build_address(sieve_script_t*, test_t *t,
                             strarray_t *sl, strarray_t *pl);
static test_t *build_envelope(sieve_script_t*, test_t *t,
                              strarray_t *sl, strarray_t *pl);
static test_t *build_header(sieve_script_t*, test_t *t,
                            strarray_t *sl, strarray_t *pl);
static test_t *build_body(sieve_script_t*, test_t *t, strarray_t *pl);
static test_t *build_stringt(sieve_script_t*, test_t *t,
                             strarray_t *sl, strarray_t *pl);
static test_t *build_hasflag(sieve_script_t*, test_t *t,
                             strarray_t *sl, strarray_t *pl);
static test_t *build_date(sieve_script_t*, test_t *t,
                          char *hn, char *part, strarray_t *kl);
static test_t *build_ihave(sieve_script_t*, strarray_t *sa);
static test_t *build_mbox_meta(sieve_script_t*, test_t *t, char *extname,
                               char *keyname, strarray_t *keylist);
static test_t *build_duplicate(sieve_script_t*, test_t *t);
static test_t *build_jmapquery(sieve_script_t*, test_t *t, char *json);

static int verify_weekday(sieve_script_t *sscript, char *day);
static int verify_time(sieve_script_t *sscript, char *time);

void yyerror(sieve_script_t*, const char *msg);
extern int yylex(void*, sieve_script_t*);
extern void sieverestart(FILE *f);

#define supported(capa) (sscript->support & capa)

#define _verify_flaglist(flags) \
  (supported(SIEVE_CAPA_VARIABLES) || verify_flaglist(flags))

#define YYERROR_VERBOSE /* I want better error messages! */

/* byacc default is 500, bison default is 10000 - go with the
   larger to support big sieve scripts (see Bug #3461) */
#define YYSTACKSIZE 10000

#line 243 "sieve/sieve.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_SIEVE_SIEVE_SIEVE_H_INCLUDED
# define YY_SIEVE_SIEVE_SIEVE_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int sievedebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    NUMBER = 258,                  /* NUMBER  */
    STRING = 259,                  /* STRING  */
    IF = 260,                      /* IF  */
    ELSIF = 261,                   /* ELSIF  */
    ELSE = 262,                    /* ELSE  */
    REQUIRE = 263,                 /* REQUIRE  */
    STOP = 264,                    /* STOP  */
    DISCARD = 265,                 /* DISCARD  */
    KEEP = 266,                    /* KEEP  */
    FILEINTO = 267,                /* FILEINTO  */
    REDIRECT = 268,                /* REDIRECT  */
    ANYOF = 269,                   /* ANYOF  */
    ALLOF = 270,                   /* ALLOF  */
    EXISTS = 271,                  /* EXISTS  */
    NOT = 272,                     /* NOT  */
    SFALSE = 273,                  /* SFALSE  */
    STRUE = 274,                   /* STRUE  */
    SIZE = 275,                    /* SIZE  */
    HEADERT = 276,                 /* HEADERT  */
    ADDRESS = 277,                 /* ADDRESS  */
    ENVELOPE = 278,                /* ENVELOPE  */
    COMPARATOR = 279,              /* COMPARATOR  */
    OVER = 280,                    /* OVER  */
    UNDER = 281,                   /* UNDER  */
    ALL = 282,                     /* ALL  */
    LOCALPART = 283,               /* LOCALPART  */
    DOMAIN = 284,                  /* DOMAIN  */
    IS = 285,                      /* IS  */
    CONTAINS = 286,                /* CONTAINS  */
    MATCHES = 287,                 /* MATCHES  */
    OCTET = 288,                   /* OCTET  */
    ASCIICASEMAP = 289,            /* ASCIICASEMAP  */
    ASCIINUMERIC = 290,            /* ASCIINUMERIC  */
    UNICODECASEMAP = 291,          /* UNICODECASEMAP  */
    REGEX = 292,                   /* REGEX  */
    QUOTEREGEX = 293,              /* QUOTEREGEX  */
    COPY = 294,                    /* COPY  */
    BODY = 295,                    /* BODY  */
    RAW = 296,                     /* RAW  */
    TEXT = 297,                    /* TEXT  */
    CONTENT = 298,                 /* CONTENT  */
    ENVIRONMENT = 299,             /* ENVIRONMENT  */
    STRINGT = 300,                 /* STRINGT  */
    SET = 301,                     /* SET  */
    LOWER = 302,                   /* LOWER  */
    UPPER = 303,                   /* UPPER  */
    LOWERFIRST = 304,              /* LOWERFIRST  */
    UPPERFIRST = 305,              /* UPPERFIRST  */
    QUOTEWILDCARD = 306,           /* QUOTEWILDCARD  */
    LENGTH = 307,                  /* LENGTH  */
    VACATION = 308,                /* VACATION  */
    DAYS = 309,                    /* DAYS  */
    SUBJECT = 310,                 /* SUBJECT  */
    FROM = 311,                    /* FROM  */
    ADDRESSES = 312,               /* ADDRESSES  */
    MIME = 313,                    /* MIME  */
    HANDLE = 314,                  /* HANDLE  */
    SECONDS = 315,                 /* SECONDS  */
    COUNT = 316,                   /* COUNT  */
    VALUE = 317,                   /* VALUE  */
    GT = 318,                      /* GT  */
    GE = 319,                      /* GE  */
    LT = 320,                      /* LT  */
    LE = 321,                      /* LE  */
    EQ = 322,                      /* EQ  */
    NE = 323,                      /* NE  */
    FLAGS = 324,                   /* FLAGS  */
    HASFLAG = 325,                 /* HASFLAG  */
    SETFLAG = 326,                 /* SETFLAG  */
    ADDFLAG = 327,                 /* ADDFLAG  */
    REMOVEFLAG = 328,              /* REMOVEFLAG  */
    USER = 329,                    /* USER  */
    DETAIL = 330,                  /* DETAIL  */
    DATE = 331,                    /* DATE  */
    CURRENTDATE = 332,             /* CURRENTDATE  */
    ORIGINALZONE = 333,            /* ORIGINALZONE  */
    ZONE = 334,                    /* ZONE  */
    INDEX = 335,                   /* INDEX  */
    LAST = 336,                    /* LAST  */
    ADDHEADER = 337,               /* ADDHEADER  */
    DELETEHEADER = 338,            /* DELETEHEADER  */
    REJCT = 339,                   /* REJCT  */
    EREJECT = 340,                 /* EREJECT  */
    OPTIONS = 341,                 /* OPTIONS  */
    MESSAGE = 342,                 /* MESSAGE  */
    IMPORTANCE = 343,              /* IMPORTANCE  */
    VALIDNOTIFYMETHOD = 344,       /* VALIDNOTIFYMETHOD  */
    NOTIFYMETHODCAPABILITY = 345,  /* NOTIFYMETHODCAPABILITY  */
    NOTIFY = 346,                  /* NOTIFY  */
    ENCODEURL = 347,               /* ENCODEURL  */
    LOW = 348,                     /* LOW  */
    NORMAL = 349,                  /* NORMAL  */
    HIGH = 350,                    /* HIGH  */
    IHAVE = 351,                   /* IHAVE  */
    ERROR = 352,                   /* ERROR  */
    MAILBOXEXISTS = 353,           /* MAILBOXEXISTS  */
    CREATE = 354,                  /* CREATE  */
    METADATA = 355,                /* METADATA  */
    METADATAEXISTS = 356,          /* METADATAEXISTS  */
    SERVERMETADATA = 357,          /* SERVERMETADATA  */
    SERVERMETADATAEXISTS = 358,    /* SERVERMETADATAEXISTS  */
    BYTIMEREL = 359,               /* BYTIMEREL  */
    BYTIMEABS = 360,               /* BYTIMEABS  */
    BYMODE = 361,                  /* BYMODE  */
    BYTRACE = 362,                 /* BYTRACE  */
    DSNNOTIFY = 363,               /* DSNNOTIFY  */
    DSNRET = 364,                  /* DSNRET  */
    VALIDEXTLIST = 365,            /* VALIDEXTLIST  */
    LIST = 366,                    /* LIST  */
    INCLUDE = 367,                 /* INCLUDE  */
    OPTIONAL = 368,                /* OPTIONAL  */
    ONCE = 369,                    /* ONCE  */
    RETURN = 370,                  /* RETURN  */
    PERSONAL = 371,                /* PERSONAL  */
    GLOBAL = 372,                  /* GLOBAL  */
    DUPLICATE = 373,               /* DUPLICATE  */
    HEADER = 374,                  /* HEADER  */
    UNIQUEID = 375,                /* UNIQUEID  */
    SPECIALUSEEXISTS = 376,        /* SPECIALUSEEXISTS  */
    SPECIALUSE = 377,              /* SPECIALUSE  */
    FCC = 378,                     /* FCC  */
    MAILBOXID = 379,               /* MAILBOXID  */
    MAILBOXIDEXISTS = 380,         /* MAILBOXIDEXISTS  */
    SNOOZE = 381,                  /* SNOOZE  */
    MAILBOX = 382,                 /* MAILBOX  */
    ADDFLAGS = 383,                /* ADDFLAGS  */
    REMOVEFLAGS = 384,             /* REMOVEFLAGS  */
    WEEKDAYS = 385,                /* WEEKDAYS  */
    TZID = 386,                    /* TZID  */
    LOG = 387,                     /* LOG  */
    JMAPQUERY = 388,               /* JMAPQUERY  */
    PROCESSCAL = 389,              /* PROCESSCAL  */
    ALLOWPUBLIC = 390,             /* ALLOWPUBLIC  */
    INVITESONLY = 391,             /* INVITESONLY  */
    UPDATESONLY = 392,             /* UPDATESONLY  */
    DELETECANCELLED = 393,         /* DELETECANCELLED  */
    ORGANIZERS = 394,              /* ORGANIZERS  */
    CALENDARID = 395,              /* CALENDARID  */
    OUTCOME = 396,                 /* OUTCOME  */
    REASON = 397,                  /* REASON  */
    PROCESSIMIP = 398,             /* PROCESSIMIP  */
    IKEEP_TARGET = 399             /* IKEEP_TARGET  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define NUMBER 258
#define STRING 259
#define IF 260
#define ELSIF 261
#define ELSE 262
#define REQUIRE 263
#define STOP 264
#define DISCARD 265
#define KEEP 266
#define FILEINTO 267
#define REDIRECT 268
#define ANYOF 269
#define ALLOF 270
#define EXISTS 271
#define NOT 272
#define SFALSE 273
#define STRUE 274
#define SIZE 275
#define HEADERT 276
#define ADDRESS 277
#define ENVELOPE 278
#define COMPARATOR 279
#define OVER 280
#define UNDER 281
#define ALL 282
#define LOCALPART 283
#define DOMAIN 284
#define IS 285
#define CONTAINS 286
#define MATCHES 287
#define OCTET 288
#define ASCIICASEMAP 289
#define ASCIINUMERIC 290
#define UNICODECASEMAP 291
#define REGEX 292
#define QUOTEREGEX 293
#define COPY 294
#define BODY 295
#define RAW 296
#define TEXT 297
#define CONTENT 298
#define ENVIRONMENT 299
#define STRINGT 300
#define SET 301
#define LOWER 302
#define UPPER 303
#define LOWERFIRST 304
#define UPPERFIRST 305
#define QUOTEWILDCARD 306
#define LENGTH 307
#define VACATION 308
#define DAYS 309
#define SUBJECT 310
#define FROM 311
#define ADDRESSES 312
#define MIME 313
#define HANDLE 314
#define SECONDS 315
#define COUNT 316
#define VALUE 317
#define GT 318
#define GE 319
#define LT 320
#define LE 321
#define EQ 322
#define NE 323
#define FLAGS 324
#define HASFLAG 325
#define SETFLAG 326
#define ADDFLAG 327
#define REMOVEFLAG 328
#define USER 329
#define DETAIL 330
#define DATE 331
#define CURRENTDATE 332
#define ORIGINALZONE 333
#define ZONE 334
#define INDEX 335
#define LAST 336
#define ADDHEADER 337
#define DELETEHEADER 338
#define REJCT 339
#define EREJECT 340
#define OPTIONS 341
#define MESSAGE 342
#define IMPORTANCE 343
#define VALIDNOTIFYMETHOD 344
#define NOTIFYMETHODCAPABILITY 345
#define NOTIFY 346
#define ENCODEURL 347
#define LOW 348
#define NORMAL 349
#define HIGH 350
#define IHAVE 351
#define ERROR 352
#define MAILBOXEXISTS 353
#define CREATE 354
#define METADATA 355
#define METADATAEXISTS 356
#define SERVERMETADATA 357
#define SERVERMETADATAEXISTS 358
#define BYTIMEREL 359
#define BYTIMEABS 360
#define BYMODE 361
#define BYTRACE 362
#define DSNNOTIFY 363
#define DSNRET 364
#define VALIDEXTLIST 365
#define LIST 366
#define INCLUDE 367
#define OPTIONAL 368
#define ONCE 369
#define RETURN 370
#define PERSONAL 371
#define GLOBAL 372
#define DUPLICATE 373
#define HEADER 374
#define UNIQUEID 375
#define SPECIALUSEEXISTS 376
#define SPECIALUSE 377
#define FCC 378
#define MAILBOXID 379
#define MAILBOXIDEXISTS 380
#define SNOOZE 381
#define MAILBOX 382
#define ADDFLAGS 383
#define REMOVEFLAGS 384
#define WEEKDAYS 385
#define TZID 386
#define LOG 387
#define JMAPQUERY 388
#define PROCESSCAL 389
#define ALLOWPUBLIC 390
#define INVITESONLY 391
#define UPDATESONLY 392
#define DELETECANCELLED 393
#define ORGANIZERS 394
#define CALENDARID 395
#define OUTCOME 396
#define REASON 397
#define PROCESSIMIP 398
#define IKEEP_TARGET 399

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 181 "sieve/sieve.y"

    int nval;
    char *sval;
    arrayu64_t *nl;
    strarray_t *sl;
    comp_t *ctag;
    test_t *test;
    testlist_t *testl;
    commandlist_t *cl;

#line 595 "sieve/sieve.c"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif




int sieveparse (sieve_script_t *sscript);


#endif /* !YY_SIEVE_SIEVE_SIEVE_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_NUMBER = 3,                     /* NUMBER  */
  YYSYMBOL_STRING = 4,                     /* STRING  */
  YYSYMBOL_IF = 5,                         /* IF  */
  YYSYMBOL_ELSIF = 6,                      /* ELSIF  */
  YYSYMBOL_ELSE = 7,                       /* ELSE  */
  YYSYMBOL_REQUIRE = 8,                    /* REQUIRE  */
  YYSYMBOL_STOP = 9,                       /* STOP  */
  YYSYMBOL_DISCARD = 10,                   /* DISCARD  */
  YYSYMBOL_KEEP = 11,                      /* KEEP  */
  YYSYMBOL_FILEINTO = 12,                  /* FILEINTO  */
  YYSYMBOL_REDIRECT = 13,                  /* REDIRECT  */
  YYSYMBOL_ANYOF = 14,                     /* ANYOF  */
  YYSYMBOL_ALLOF = 15,                     /* ALLOF  */
  YYSYMBOL_EXISTS = 16,                    /* EXISTS  */
  YYSYMBOL_NOT = 17,                       /* NOT  */
  YYSYMBOL_SFALSE = 18,                    /* SFALSE  */
  YYSYMBOL_STRUE = 19,                     /* STRUE  */
  YYSYMBOL_SIZE = 20,                      /* SIZE  */
  YYSYMBOL_HEADERT = 21,                   /* HEADERT  */
  YYSYMBOL_ADDRESS = 22,                   /* ADDRESS  */
  YYSYMBOL_ENVELOPE = 23,                  /* ENVELOPE  */
  YYSYMBOL_COMPARATOR = 24,                /* COMPARATOR  */
  YYSYMBOL_OVER = 25,                      /* OVER  */
  YYSYMBOL_UNDER = 26,                     /* UNDER  */
  YYSYMBOL_ALL = 27,                       /* ALL  */
  YYSYMBOL_LOCALPART = 28,                 /* LOCALPART  */
  YYSYMBOL_DOMAIN = 29,                    /* DOMAIN  */
  YYSYMBOL_IS = 30,                        /* IS  */
  YYSYMBOL_CONTAINS = 31,                  /* CONTAINS  */
  YYSYMBOL_MATCHES = 32,                   /* MATCHES  */
  YYSYMBOL_OCTET = 33,                     /* OCTET  */
  YYSYMBOL_ASCIICASEMAP = 34,              /* ASCIICASEMAP  */
  YYSYMBOL_ASCIINUMERIC = 35,              /* ASCIINUMERIC  */
  YYSYMBOL_UNICODECASEMAP = 36,            /* UNICODECASEMAP  */
  YYSYMBOL_REGEX = 37,                     /* REGEX  */
  YYSYMBOL_QUOTEREGEX = 38,                /* QUOTEREGEX  */
  YYSYMBOL_COPY = 39,                      /* COPY  */
  YYSYMBOL_BODY = 40,                      /* BODY  */
  YYSYMBOL_RAW = 41,                       /* RAW  */
  YYSYMBOL_TEXT = 42,                      /* TEXT  */
  YYSYMBOL_CONTENT = 43,                   /* CONTENT  */
  YYSYMBOL_ENVIRONMENT = 44,               /* ENVIRONMENT  */
  YYSYMBOL_STRINGT = 45,                   /* STRINGT  */
  YYSYMBOL_SET = 46,                       /* SET  */
  YYSYMBOL_LOWER = 47,                     /* LOWER  */
  YYSYMBOL_UPPER = 48,                     /* UPPER  */
  YYSYMBOL_LOWERFIRST = 49,                /* LOWERFIRST  */
  YYSYMBOL_UPPERFIRST = 50,                /* UPPERFIRST  */
  YYSYMBOL_QUOTEWILDCARD = 51,             /* QUOTEWILDCARD  */
  YYSYMBOL_LENGTH = 52,                    /* LENGTH  */
  YYSYMBOL_VACATION = 53,                  /* VACATION  */
  YYSYMBOL_DAYS = 54,                      /* DAYS  */
  YYSYMBOL_SUBJECT = 55,                   /* SUBJECT  */
  YYSYMBOL_FROM = 56,                      /* FROM  */
  YYSYMBOL_ADDRESSES = 57,                 /* ADDRESSES  */
  YYSYMBOL_MIME = 58,                      /* MIME  */
  YYSYMBOL_HANDLE = 59,                    /* HANDLE  */
  YYSYMBOL_SECONDS = 60,                   /* SECONDS  */
  YYSYMBOL_COUNT = 61,                     /* COUNT  */
  YYSYMBOL_VALUE = 62,                     /* VALUE  */
  YYSYMBOL_GT = 63,                        /* GT  */
  YYSYMBOL_GE = 64,                        /* GE  */
  YYSYMBOL_LT = 65,                        /* LT  */
  YYSYMBOL_LE = 66,                        /* LE  */
  YYSYMBOL_EQ = 67,                        /* EQ  */
  YYSYMBOL_NE = 68,                        /* NE  */
  YYSYMBOL_FLAGS = 69,                     /* FLAGS  */
  YYSYMBOL_HASFLAG = 70,                   /* HASFLAG  */
  YYSYMBOL_SETFLAG = 71,                   /* SETFLAG  */
  YYSYMBOL_ADDFLAG = 72,                   /* ADDFLAG  */
  YYSYMBOL_REMOVEFLAG = 73,                /* REMOVEFLAG  */
  YYSYMBOL_USER = 74,                      /* USER  */
  YYSYMBOL_DETAIL = 75,                    /* DETAIL  */
  YYSYMBOL_DATE = 76,                      /* DATE  */
  YYSYMBOL_CURRENTDATE = 77,               /* CURRENTDATE  */
  YYSYMBOL_ORIGINALZONE = 78,              /* ORIGINALZONE  */
  YYSYMBOL_ZONE = 79,                      /* ZONE  */
  YYSYMBOL_INDEX = 80,                     /* INDEX  */
  YYSYMBOL_LAST = 81,                      /* LAST  */
  YYSYMBOL_ADDHEADER = 82,                 /* ADDHEADER  */
  YYSYMBOL_DELETEHEADER = 83,              /* DELETEHEADER  */
  YYSYMBOL_REJCT = 84,                     /* REJCT  */
  YYSYMBOL_EREJECT = 85,                   /* EREJECT  */
  YYSYMBOL_OPTIONS = 86,                   /* OPTIONS  */
  YYSYMBOL_MESSAGE = 87,                   /* MESSAGE  */
  YYSYMBOL_IMPORTANCE = 88,                /* IMPORTANCE  */
  YYSYMBOL_VALIDNOTIFYMETHOD = 89,         /* VALIDNOTIFYMETHOD  */
  YYSYMBOL_NOTIFYMETHODCAPABILITY = 90,    /* NOTIFYMETHODCAPABILITY  */
  YYSYMBOL_NOTIFY = 91,                    /* NOTIFY  */
  YYSYMBOL_ENCODEURL = 92,                 /* ENCODEURL  */
  YYSYMBOL_LOW = 93,                       /* LOW  */
  YYSYMBOL_NORMAL = 94,                    /* NORMAL  */
  YYSYMBOL_HIGH = 95,                      /* HIGH  */
  YYSYMBOL_IHAVE = 96,                     /* IHAVE  */
  YYSYMBOL_ERROR = 97,                     /* ERROR  */
  YYSYMBOL_MAILBOXEXISTS = 98,             /* MAILBOXEXISTS  */
  YYSYMBOL_CREATE = 99,                    /* CREATE  */
  YYSYMBOL_METADATA = 100,                 /* METADATA  */
  YYSYMBOL_METADATAEXISTS = 101,           /* METADATAEXISTS  */
  YYSYMBOL_SERVERMETADATA = 102,           /* SERVERMETADATA  */
  YYSYMBOL_SERVERMETADATAEXISTS = 103,     /* SERVERMETADATAEXISTS  */
  YYSYMBOL_BYTIMEREL = 104,                /* BYTIMEREL  */
  YYSYMBOL_BYTIMEABS = 105,                /* BYTIMEABS  */
  YYSYMBOL_BYMODE = 106,                   /* BYMODE  */
  YYSYMBOL_BYTRACE = 107,                  /* BYTRACE  */
  YYSYMBOL_DSNNOTIFY = 108,                /* DSNNOTIFY  */
  YYSYMBOL_DSNRET = 109,                   /* DSNRET  */
  YYSYMBOL_VALIDEXTLIST = 110,             /* VALIDEXTLIST  */
  YYSYMBOL_LIST = 111,                     /* LIST  */
  YYSYMBOL_INCLUDE = 112,                  /* INCLUDE  */
  YYSYMBOL_OPTIONAL = 113,                 /* OPTIONAL  */
  YYSYMBOL_ONCE = 114,                     /* ONCE  */
  YYSYMBOL_RETURN = 115,                   /* RETURN  */
  YYSYMBOL_PERSONAL = 116,                 /* PERSONAL  */
  YYSYMBOL_GLOBAL = 117,                   /* GLOBAL  */
  YYSYMBOL_DUPLICATE = 118,                /* DUPLICATE  */
  YYSYMBOL_HEADER = 119,                   /* HEADER  */
  YYSYMBOL_UNIQUEID = 120,                 /* UNIQUEID  */
  YYSYMBOL_SPECIALUSEEXISTS = 121,         /* SPECIALUSEEXISTS  */
  YYSYMBOL_SPECIALUSE = 122,               /* SPECIALUSE  */
  YYSYMBOL_FCC = 123,                      /* FCC  */
  YYSYMBOL_MAILBOXID = 124,                /* MAILBOXID  */
  YYSYMBOL_MAILBOXIDEXISTS = 125,          /* MAILBOXIDEXISTS  */
  YYSYMBOL_SNOOZE = 126,                   /* SNOOZE  */
  YYSYMBOL_MAILBOX = 127,                  /* MAILBOX  */
  YYSYMBOL_ADDFLAGS = 128,                 /* ADDFLAGS  */
  YYSYMBOL_REMOVEFLAGS = 129,              /* REMOVEFLAGS  */
  YYSYMBOL_WEEKDAYS = 130,                 /* WEEKDAYS  */
  YYSYMBOL_TZID = 131,                     /* TZID  */
  YYSYMBOL_LOG = 132,                      /* LOG  */
  YYSYMBOL_JMAPQUERY = 133,                /* JMAPQUERY  */
  YYSYMBOL_PROCESSCAL = 134,               /* PROCESSCAL  */
  YYSYMBOL_ALLOWPUBLIC = 135,              /* ALLOWPUBLIC  */
  YYSYMBOL_INVITESONLY = 136,              /* INVITESONLY  */
  YYSYMBOL_UPDATESONLY = 137,              /* UPDATESONLY  */
  YYSYMBOL_DELETECANCELLED = 138,          /* DELETECANCELLED  */
  YYSYMBOL_ORGANIZERS = 139,               /* ORGANIZERS  */
  YYSYMBOL_CALENDARID = 140,               /* CALENDARID  */
  YYSYMBOL_OUTCOME = 141,                  /* OUTCOME  */
  YYSYMBOL_REASON = 142,                   /* REASON  */
  YYSYMBOL_PROCESSIMIP = 143,              /* PROCESSIMIP  */
  YYSYMBOL_IKEEP_TARGET = 144,             /* IKEEP_TARGET  */
  YYSYMBOL_145_ = 145,                     /* ';'  */
  YYSYMBOL_146_ = 146,                     /* '['  */
  YYSYMBOL_147_ = 147,                     /* ']'  */
  YYSYMBOL_148_ = 148,                     /* ','  */
  YYSYMBOL_149_ = 149,                     /* '{'  */
  YYSYMBOL_150_ = 150,                     /* '}'  */
  YYSYMBOL_151_ = 151,                     /* '('  */
  YYSYMBOL_152_ = 152,                     /* ')'  */
  YYSYMBOL_YYACCEPT = 153,                 /* $accept  */
  YYSYMBOL_start = 154,                    /* start  */
  YYSYMBOL_reqs = 155,                     /* reqs  */
  YYSYMBOL_commands = 156,                 /* commands  */
  YYSYMBOL_command = 157,                  /* command  */
  YYSYMBOL_optstringlist = 158,            /* optstringlist  */
  YYSYMBOL_stringlist = 159,               /* stringlist  */
  YYSYMBOL_strings = 160,                  /* strings  */
  YYSYMBOL_string1 = 161,                  /* string1  */
  YYSYMBOL_string = 162,                   /* string  */
  YYSYMBOL_require = 163,                  /* require  */
  YYSYMBOL_control = 164,                  /* control  */
  YYSYMBOL_thenelse = 165,                 /* thenelse  */
  YYSYMBOL_elsif = 166,                    /* elsif  */
  YYSYMBOL_block = 167,                    /* block  */
  YYSYMBOL_itags = 168,                    /* itags  */
  YYSYMBOL_location = 169,                 /* location  */
  YYSYMBOL_action = 170,                   /* action  */
  YYSYMBOL_171_1 = 171,                    /* $@1  */
  YYSYMBOL_172_2 = 172,                    /* $@2  */
  YYSYMBOL_ktags = 173,                    /* ktags  */
  YYSYMBOL_flags = 174,                    /* flags  */
  YYSYMBOL_ftags = 175,                    /* ftags  */
  YYSYMBOL_copy = 176,                     /* copy  */
  YYSYMBOL_create = 177,                   /* create  */
  YYSYMBOL_specialuse = 178,               /* specialuse  */
  YYSYMBOL_mailboxid = 179,                /* mailboxid  */
  YYSYMBOL_rtags = 180,                    /* rtags  */
  YYSYMBOL_delbytags = 181,                /* delbytags  */
  YYSYMBOL_dsntags = 182,                  /* dsntags  */
  YYSYMBOL_stags = 183,                    /* stags  */
  YYSYMBOL_mod40 = 184,                    /* mod40  */
  YYSYMBOL_mod30 = 185,                    /* mod30  */
  YYSYMBOL_mod20 = 186,                    /* mod20  */
  YYSYMBOL_mod15 = 187,                    /* mod15  */
  YYSYMBOL_mod10 = 188,                    /* mod10  */
  YYSYMBOL_vtags = 189,                    /* vtags  */
  YYSYMBOL_fcctags = 190,                  /* fcctags  */
  YYSYMBOL_flagaction = 191,               /* flagaction  */
  YYSYMBOL_flagtags = 192,                 /* flagtags  */
  YYSYMBOL_ahtags = 193,                   /* ahtags  */
  YYSYMBOL_dhtags = 194,                   /* dhtags  */
  YYSYMBOL_reject = 195,                   /* reject  */
  YYSYMBOL_ntags = 196,                    /* ntags  */
  YYSYMBOL_priority = 197,                 /* priority  */
  YYSYMBOL_sntags = 198,                   /* sntags  */
  YYSYMBOL_weekdaylist = 199,              /* weekdaylist  */
  YYSYMBOL_weekdays = 200,                 /* weekdays  */
  YYSYMBOL_weekday = 201,                  /* weekday  */
  YYSYMBOL_timelist = 202,                 /* timelist  */
  YYSYMBOL_times = 203,                    /* times  */
  YYSYMBOL_time1 = 204,                    /* time1  */
  YYSYMBOL_time = 205,                     /* time  */
  YYSYMBOL_caltags = 206,                  /* caltags  */
  YYSYMBOL_ikttags = 207,                  /* ikttags  */
  YYSYMBOL_testlist = 208,                 /* testlist  */
  YYSYMBOL_tests = 209,                    /* tests  */
  YYSYMBOL_test = 210,                     /* test  */
  YYSYMBOL_211_3 = 211,                    /* $@3  */
  YYSYMBOL_212_4 = 212,                    /* $@4  */
  YYSYMBOL_sizetag = 213,                  /* sizetag  */
  YYSYMBOL_htags = 214,                    /* htags  */
  YYSYMBOL_matchtype = 215,                /* matchtype  */
  YYSYMBOL_matchtag = 216,                 /* matchtag  */
  YYSYMBOL_relmatch = 217,                 /* relmatch  */
  YYSYMBOL_relation = 218,                 /* relation  */
  YYSYMBOL_listmatch = 219,                /* listmatch  */
  YYSYMBOL_comparator = 220,               /* comparator  */
  YYSYMBOL_collation = 221,                /* collation  */
  YYSYMBOL_indexext = 222,                 /* indexext  */
  YYSYMBOL_index = 223,                    /* index  */
  YYSYMBOL_atags = 224,                    /* atags  */
  YYSYMBOL_addrpart = 225,                 /* addrpart  */
  YYSYMBOL_addrparttag = 226,              /* addrparttag  */
  YYSYMBOL_subaddress = 227,               /* subaddress  */
  YYSYMBOL_etags = 228,                    /* etags  */
  YYSYMBOL_envtags = 229,                  /* envtags  */
  YYSYMBOL_btags = 230,                    /* btags  */
  YYSYMBOL_transform = 231,                /* transform  */
  YYSYMBOL_strtags = 232,                  /* strtags  */
  YYSYMBOL_hftags = 233,                   /* hftags  */
  YYSYMBOL_dttags = 234,                   /* dttags  */
  YYSYMBOL_zone = 235,                     /* zone  */
  YYSYMBOL_cdtags = 236,                   /* cdtags  */
  YYSYMBOL_methtags = 237,                 /* methtags  */
  YYSYMBOL_mtags = 238,                    /* mtags  */
  YYSYMBOL_duptags = 239,                  /* duptags  */
  YYSYMBOL_idtype = 240                    /* idtype  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  10
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   728

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  153
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  88
/* YYNRULES -- Number of rules.  */
#define YYNRULES  288
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  413

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   399


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     151,   152,     2,     2,   148,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,   145,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   146,     2,   147,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   149,     2,   150,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   368,   368,   369,   373,   374,   379,   380,   384,   385,
     386,   398,   399,   403,   404,   408,   409,   413,   420,   427,
     431,   432,   433,   434,   436,   440,   451,   452,   453,   457,
     458,   463,   464,   474,   484,   498,   499,   506,   507,   508,
     509,   510,   512,   515,   518,   521,   525,   526,   527,   528,
     530,   530,   533,   533,   536,   542,   546,   551,   571,   579,
     580,   581,   582,   583,   588,   605,   622,   647,   673,   677,
     678,   691,   699,   710,   732,   752,   764,   780,   792,   808,
     809,   819,   829,   839,   849,   863,   864,   867,   868,   871,
     872,   884,   895,   900,   908,   918,   933,   944,   956,   968,
     978,   989,   993,  1009,  1010,  1011,  1012,  1017,  1018,  1019,
    1024,  1025,  1045,  1046,  1060,  1064,  1065,  1066,  1067,  1072,
    1073,  1078,  1086,  1098,  1109,  1121,  1133,  1138,  1139,  1140,
    1145,  1151,  1162,  1163,  1164,  1166,  1183,  1200,  1211,  1225,
    1226,  1230,  1231,  1235,  1239,  1240,  1244,  1245,  1249,  1256,
    1261,  1268,  1278,  1300,  1323,  1341,  1353,  1371,  1389,  1405,
    1425,  1430,  1431,  1438,  1442,  1443,  1447,  1448,  1449,  1450,
    1451,  1452,  1458,  1467,  1470,  1472,  1475,  1477,  1481,  1488,
    1490,  1493,  1496,  1499,  1506,  1510,  1512,  1519,  1519,  1523,
    1530,  1530,  1534,  1542,  1549,  1551,  1558,  1565,  1572,  1577,
    1582,  1583,  1588,  1592,  1593,  1594,  1595,  1600,  1610,  1632,
    1633,  1634,  1635,  1648,  1649,  1654,  1655,  1656,  1657,  1658,
    1659,  1664,  1684,  1699,  1700,  1701,  1711,  1725,  1736,  1751,
    1770,  1774,  1775,  1776,  1777,  1778,  1783,  1798,  1799,  1800,
    1801,  1812,  1813,  1818,  1822,  1823,  1824,  1825,  1830,  1834,
    1835,  1840,  1844,  1854,  1867,  1868,  1873,  1874,  1879,  1883,
    1884,  1885,  1890,  1894,  1895,  1900,  1904,  1905,  1914,  1915,
    1916,  1921,  1938,  1942,  1943,  1944,  1949,  1954,  1955,  1960,
    1965,  1966,  1971,  1972,  1983,  1993,  2002,  2015,  2016
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "NUMBER", "STRING",
  "IF", "ELSIF", "ELSE", "REQUIRE", "STOP", "DISCARD", "KEEP", "FILEINTO",
  "REDIRECT", "ANYOF", "ALLOF", "EXISTS", "NOT", "SFALSE", "STRUE", "SIZE",
  "HEADERT", "ADDRESS", "ENVELOPE", "COMPARATOR", "OVER", "UNDER", "ALL",
  "LOCALPART", "DOMAIN", "IS", "CONTAINS", "MATCHES", "OCTET",
  "ASCIICASEMAP", "ASCIINUMERIC", "UNICODECASEMAP", "REGEX", "QUOTEREGEX",
  "COPY", "BODY", "RAW", "TEXT", "CONTENT", "ENVIRONMENT", "STRINGT",
  "SET", "LOWER", "UPPER", "LOWERFIRST", "UPPERFIRST", "QUOTEWILDCARD",
  "LENGTH", "VACATION", "DAYS", "SUBJECT", "FROM", "ADDRESSES", "MIME",
  "HANDLE", "SECONDS", "COUNT", "VALUE", "GT", "GE", "LT", "LE", "EQ",
  "NE", "FLAGS", "HASFLAG", "SETFLAG", "ADDFLAG", "REMOVEFLAG", "USER",
  "DETAIL", "DATE", "CURRENTDATE", "ORIGINALZONE", "ZONE", "INDEX", "LAST",
  "ADDHEADER", "DELETEHEADER", "REJCT", "EREJECT", "OPTIONS", "MESSAGE",
  "IMPORTANCE", "VALIDNOTIFYMETHOD", "NOTIFYMETHODCAPABILITY", "NOTIFY",
  "ENCODEURL", "LOW", "NORMAL", "HIGH", "IHAVE", "ERROR", "MAILBOXEXISTS",
  "CREATE", "METADATA", "METADATAEXISTS", "SERVERMETADATA",
  "SERVERMETADATAEXISTS", "BYTIMEREL", "BYTIMEABS", "BYMODE", "BYTRACE",
  "DSNNOTIFY", "DSNRET", "VALIDEXTLIST", "LIST", "INCLUDE", "OPTIONAL",
  "ONCE", "RETURN", "PERSONAL", "GLOBAL", "DUPLICATE", "HEADER",
  "UNIQUEID", "SPECIALUSEEXISTS", "SPECIALUSE", "FCC", "MAILBOXID",
  "MAILBOXIDEXISTS", "SNOOZE", "MAILBOX", "ADDFLAGS", "REMOVEFLAGS",
  "WEEKDAYS", "TZID", "LOG", "JMAPQUERY", "PROCESSCAL", "ALLOWPUBLIC",
  "INVITESONLY", "UPDATESONLY", "DELETECANCELLED", "ORGANIZERS",
  "CALENDARID", "OUTCOME", "REASON", "PROCESSIMIP", "IKEEP_TARGET", "';'",
  "'['", "']'", "','", "'{'", "'}'", "'('", "')'", "$accept", "start",
  "reqs", "commands", "command", "optstringlist", "stringlist", "strings",
  "string1", "string", "require", "control", "thenelse", "elsif", "block",
  "itags", "location", "action", "$@1", "$@2", "ktags", "flags", "ftags",
  "copy", "create", "specialuse", "mailboxid", "rtags", "delbytags",
  "dsntags", "stags", "mod40", "mod30", "mod20", "mod15", "mod10", "vtags",
  "fcctags", "flagaction", "flagtags", "ahtags", "dhtags", "reject",
  "ntags", "priority", "sntags", "weekdaylist", "weekdays", "weekday",
  "timelist", "times", "time1", "time", "caltags", "ikttags", "testlist",
  "tests", "test", "$@3", "$@4", "sizetag", "htags", "matchtype",
  "matchtag", "relmatch", "relation", "listmatch", "comparator",
  "collation", "indexext", "index", "atags", "addrpart", "addrparttag",
  "subaddress", "etags", "envtags", "btags", "transform", "strtags",
  "hftags", "dttags", "zone", "cdtags", "methtags", "mtags", "duptags",
  "idtype", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-346)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-18)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
      -5,    -2,    17,   399,    -5,  -346,    16,  -105,  -346,  -346,
    -346,   -85,   535,   -74,  -346,  -346,  -346,  -346,  -346,  -346,
    -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,    16,  -346,
     -67,  -346,    16,  -346,  -346,  -346,  -346,   281,  -346,   -62,
    -346,    16,  -346,  -121,  -346,  -346,  -346,  -346,  -127,  -127,
      -2,   535,  -346,  -346,    24,  -346,  -346,  -346,  -346,  -346,
    -346,  -346,  -346,  -346,    -2,  -346,    -2,    -2,  -346,    16,
    -346,    -2,    -2,  -346,    -2,    -2,    16,  -346,   -86,  -346,
      15,     3,   481,   614,   505,    12,   578,   136,   -60,     2,
    -346,     4,  -346,  -346,  -346,    19,  -346,  -346,    -2,  -346,
    -346,    16,   535,  -346,  -346,  -346,  -346,  -346,  -346,    84,
     150,   172,   473,   425,   402,   189,   271,   617,   306,  -346,
     402,  -346,  -346,  -346,    -2,  -346,  -346,  -346,   -38,  -346,
      -2,  -346,  -346,   304,    38,    -2,  -346,  -346,  -346,    16,
      16,  -346,  -346,  -346,  -346,  -346,  -346,    88,    16,    16,
    -346,    16,    16,  -346,  -346,  -346,  -346,  -346,  -346,  -346,
    -346,  -346,  -346,  -346,  -346,  -346,    16,  -346,  -346,  -346,
    -346,  -346,    95,    16,    16,    -2,  -346,    16,    98,    16,
    -346,  -346,  -346,  -346,  -346,  -346,  -346,    16,    74,  -346,
    -346,  -346,  -346,  -346,  -346,   101,  -346,  -346,    -2,  -346,
    -346,   100,  -346,  -346,  -346,    16,    -2,    16,   -61,  -346,
    -346,  -346,  -346,  -346,  -346,  -346,   -40,  -346,  -346,    16,
      -2,    -2,     1,    16,   113,  -346,  -346,  -346,  -346,  -346,
    -346,   458,   458,  -346,  -346,  -346,  -346,   -23,  -346,   -22,
     -19,  -346,    -2,  -346,  -346,  -346,  -346,  -346,  -346,  -346,
    -346,  -346,  -346,    -2,  -346,  -346,  -346,  -346,  -346,  -346,
    -346,    -2,  -346,  -346,  -346,  -346,  -346,  -346,    -2,  -346,
    -346,  -346,  -346,    -2,  -346,  -346,    -2,  -346,  -346,  -346,
      -2,  -346,  -346,  -346,    16,    16,  -346,  -346,  -346,  -346,
      -2,  -346,  -346,  -346,    16,  -346,  -346,   402,  -346,   402,
      16,   133,  -346,  -346,  -346,    16,  -346,  -346,   -13,   535,
     -86,  -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,
    -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,
    -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,
    -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,
    -346,  -346,  -346,  -346,  -346,  -346,   138,  -346,  -346,  -346,
     -82,  -346,    -2,  -346,  -346,  -346,  -346,    16,    16,    16,
      16,  -346,   535,  -346,  -346,  -346,  -346,  -346,  -346,  -346,
    -346,    -2,  -346,    -2,    16,  -346,  -346,    -2,  -346,  -346,
    -346,  -346,  -346,  -346,   -79,  -346,  -346,   113,  -346,  -346,
    -346,  -346,  -346,  -346,  -346,  -346,    -2,  -346,  -346,   138,
    -346,  -346,  -346
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int16 yydefact[] =
{
       4,     0,     0,     0,     4,    18,     0,     0,    13,    17,
       1,     0,     0,     0,    40,    55,    58,    68,    79,    93,
     107,   108,   109,   112,   114,   119,   120,   121,     0,    31,
       0,   130,     0,    50,    52,   160,     3,     0,     8,     0,
     110,     0,     5,     0,    15,    19,    10,   199,     0,     0,
       0,     0,   169,   170,     0,   202,   230,   243,   251,   248,
     258,   262,   265,   272,     0,   276,     0,     0,   187,     0,
     190,     0,     0,   282,     0,     0,     0,    20,     0,    21,
      37,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      24,     0,    48,   150,   150,     0,     7,     9,     0,    46,
      14,     0,     0,   166,   167,   171,   168,   200,   201,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   183,
       0,   185,   186,   279,     0,   279,   192,   193,   194,   195,
      17,   197,   198,     0,    26,     0,    56,    64,    65,     0,
       0,    38,    60,    59,    61,    62,    63,     0,     0,     0,
      76,     0,     0,    70,    39,    69,    71,    72,    90,    85,
      86,    87,    88,    89,    92,    91,     0,    80,    81,    82,
      83,    84,     0,     0,     0,     0,    99,     0,     0,     0,
      42,   104,   103,   105,   106,   101,   113,     0,     0,   209,
     210,   211,   212,   213,   214,     0,   229,   221,    11,   115,
     207,     0,   116,   117,   118,     0,     0,     0,     0,    47,
     126,    22,    34,    33,    35,    36,     0,    32,   149,     0,
       0,     0,     0,     0,     0,   132,   133,   134,    49,   144,
     148,    51,    53,    54,   161,   162,    43,   111,    16,     0,
     164,   172,     0,   203,   204,   205,   206,   227,   237,   238,
     239,   241,   242,     0,   232,   233,   234,   235,   231,   236,
     240,     0,   245,   246,   247,   244,   256,   257,     0,   176,
     254,   255,   252,     0,   249,   250,     0,   259,   260,   261,
     180,   263,   264,   267,     0,     0,   268,   269,   270,   266,
       0,   274,   275,   273,     0,   277,   278,     0,   189,     0,
       0,     0,   286,   287,   288,     0,   196,    30,     0,     0,
       0,    25,    57,    66,    67,    73,    74,    75,    77,    78,
      41,    94,    96,    97,    98,   100,    95,   102,    44,   223,
     224,   225,   226,   222,   228,    45,    12,   217,   218,   219,
     220,   215,   216,   208,   122,   125,   124,   127,   128,   129,
     123,    23,   131,   135,   136,   143,     0,   137,   139,   138,
       0,   146,     0,   151,   152,   153,   154,     0,     0,     0,
       0,   163,     0,   173,   174,   175,   253,   177,   178,   179,
     271,     0,   182,     0,     0,   280,   281,     0,   284,   285,
     283,    29,    27,    28,     0,   141,   145,     0,   155,   156,
     157,   158,   159,   165,   181,   184,     0,   191,   140,     0,
     147,   188,   142
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -346,  -346,   144,   -27,  -346,  -346,   -36,  -346,   146,   -28,
    -346,  -346,  -156,  -346,  -155,  -346,  -346,  -346,  -346,  -346,
    -346,    33,  -346,    75,   -72,   -66,   -44,  -346,  -346,  -346,
    -346,  -346,  -346,  -346,  -346,  -346,  -346,    69,  -346,  -346,
    -346,  -346,  -346,  -346,  -346,  -346,  -346,  -346,  -345,  -346,
    -346,   -64,  -239,    67,  -346,   120,  -201,   -50,  -346,  -346,
    -346,  -346,   597,  -346,  -346,  -346,   -15,   608,  -346,   -99,
      86,  -346,    61,  -346,  -346,  -346,  -346,  -346,  -346,  -346,
    -346,  -346,    57,  -346,  -346,    53,  -346,  -346
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,     2,     3,    36,    37,   335,     7,    43,     8,     9,
       4,    38,    77,   311,   134,    89,   217,    39,    93,    94,
      80,   181,    81,   143,   182,   183,   184,    82,   156,   157,
      83,   167,   168,   169,   170,   171,    84,   185,    40,    98,
      85,    86,    41,    87,   350,    91,   357,   394,   358,   228,
     360,   229,   230,   231,    95,   103,   239,    78,   123,   125,
     109,   110,   385,   200,   201,   343,   202,   386,   333,   246,
     247,   111,   258,   259,   260,   112,   114,   113,   272,   115,
     116,   117,   289,   118,   120,   297,   128,   305
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      88,   106,     5,     1,    92,   355,     5,     5,   218,   144,
      96,   395,   257,    99,   105,   145,     5,    10,   288,   225,
       5,   300,   301,     5,   102,   226,   100,   101,   119,   234,
     121,   122,   347,   348,   349,   126,   127,   146,   129,   131,
      45,   124,   137,   302,   309,   310,   130,   227,   132,   107,
     108,   235,   240,   141,   154,   166,   180,   187,   198,   209,
      46,   216,   236,   133,   412,   396,   397,   233,   408,   409,
     237,    79,   135,   238,   242,   253,   261,   269,    90,   276,
     280,   303,   304,    97,   135,   211,   273,   241,   298,   285,
     290,   315,   294,   186,   306,   244,   255,   263,   321,   312,
     278,   326,   138,   138,   334,   351,   308,   329,   330,   331,
     332,   313,   314,   136,   142,   212,   213,   218,   214,   215,
     316,   317,   -17,   318,   319,   139,   139,   140,   140,   372,
     371,   219,   220,   221,   222,   223,   389,   391,   320,   324,
       5,   139,   355,   140,     6,   322,   323,   356,    42,   325,
     224,   327,    44,   392,     5,   393,   210,   155,   410,   328,
     361,   232,   336,   337,   338,   339,   340,   341,   342,   104,
     345,   403,   204,   265,   188,   293,     5,   344,   299,   346,
     189,   190,   191,     0,   353,   354,     0,   192,     0,     0,
       0,   352,   205,     5,     0,   359,   188,     0,     0,   248,
     249,   250,   189,   190,   191,   135,   373,     0,     0,   192,
       0,   193,   194,   188,     0,     0,     0,   374,     0,   189,
     190,   191,   206,   207,   208,   375,   192,     0,     0,     0,
     195,   196,   376,   193,   194,   138,     0,   377,     0,     0,
     378,     0,     0,     0,   379,     0,   251,   252,     0,     0,
     193,   194,   195,   196,   382,     0,   380,   381,   139,   179,
     140,   197,     0,     0,     0,     0,   383,     0,     0,   384,
       0,   387,   388,     0,     0,     5,     0,   390,     0,     0,
       0,    -6,    11,   197,     0,     0,    12,     0,     0,     0,
      13,    14,    15,    16,    17,   188,     6,     0,     0,     0,
     197,   189,   190,   191,     0,    11,     0,     0,   192,    12,
       5,     0,     0,    13,    14,    15,    16,    17,     6,     0,
       0,     0,   240,     0,     0,     0,   398,    18,     0,     0,
     188,     0,   193,   194,    19,     6,   189,   190,   191,   399,
     400,   401,   402,   192,     0,   404,     0,   405,     0,     0,
      18,   407,    20,    21,    22,     0,   406,    19,     0,     0,
       0,     0,     0,    23,    24,    25,    26,   193,   194,     0,
     411,     0,    27,     0,     0,    20,    21,    22,    28,     0,
       0,     0,     0,     0,     0,   284,    23,    24,    25,    26,
       0,     0,     0,    29,     0,    27,    30,     0,     0,    -2,
      11,    28,     0,     0,    12,     0,     5,    31,    13,    14,
      15,    16,    17,    32,     0,    33,    29,     6,     0,    30,
       0,     0,     0,     0,    34,    35,   188,     0,     0,     5,
      31,    -6,   189,   190,   191,     0,    32,     0,    33,   192,
       0,     0,     0,     0,     0,    18,     0,    34,    35,   188,
       0,     0,    19,     0,   307,   189,   190,   191,     0,     0,
       0,     0,   192,   193,   194,     0,   266,   267,   268,     0,
      20,    21,    22,     0,     0,     0,     0,     5,     0,     0,
       0,    23,    24,    25,    26,     5,   193,   194,     0,     0,
      27,     0,     0,     0,     0,     0,    28,   188,     0,     0,
     248,   249,   250,   189,   190,   191,     0,     0,     0,     5,
     192,    29,     0,     0,    30,   362,     0,     0,     0,     0,
     137,     0,     0,     0,     0,    31,     0,     0,     0,     0,
       0,    32,     0,    33,   193,   194,    47,     0,     0,     0,
       0,     0,    34,    35,     0,     0,     0,   251,   252,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,   172,
     173,   174,   175,   176,   177,   178,     0,     0,     0,     0,
       0,     6,     0,     0,   135,    58,     0,     0,     0,    59,
      60,     0,     5,     0,   197,   147,   148,   149,   150,   151,
     152,     0,   153,   363,   364,   365,   366,   367,   368,   369,
     370,     0,   188,     0,   138,    61,     0,     0,   189,   190,
     191,    62,    63,     0,     0,   192,     0,     0,     5,     6,
       0,     5,     0,     0,    64,    65,     0,   139,   179,   140,
       0,    66,     0,    67,     0,    68,    69,    70,    71,   193,
     194,   188,     0,     0,     0,    72,     0,   189,   190,   191,
       0,     0,   158,    73,   192,     0,    74,     0,   195,   196,
      75,   159,   160,   161,   162,   163,   164,     0,    76,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   193,   194,
       0,     0,     0,   199,     0,     0,     0,     0,     0,   197,
       0,     0,     0,     0,   203,   283,   284,   195,   196,     0,
       0,     0,     0,     0,     0,     0,   165,   243,   254,   262,
     270,   274,   277,   281,   286,   291,     0,   295,   245,   256,
     264,   271,   275,   279,   282,   287,   292,     0,   296
};

static const yytype_int16 yycheck[] =
{
      28,    51,     4,     8,    32,     4,     4,     4,     4,    81,
      37,   356,   111,    41,    50,    81,     4,     0,   117,    91,
       4,    59,    60,     4,   151,    91,   147,   148,    64,    95,
      66,    67,    93,    94,    95,    71,    72,    81,    74,    75,
     145,    69,    39,    81,     6,     7,    74,    91,    76,    25,
      26,    95,   102,    81,    82,    83,    84,    85,    86,    87,
     145,    89,    98,   149,   409,   147,   148,    95,   147,   148,
      98,   145,    69,   101,   110,   111,   112,   113,   145,   115,
     116,   119,   120,   145,    69,   145,   114,     3,   124,   117,
     118,     3,   120,    81,   130,   110,   111,   112,     3,   135,
     115,     3,    99,    99,     3,   145,   133,    33,    34,    35,
      36,   139,   140,    80,    81,   113,   114,     4,   116,   117,
     148,   149,   145,   151,   152,   122,   122,   124,   124,   148,
     152,   127,   128,   129,   130,   131,     3,   150,   166,   175,
       4,   122,     4,   124,   146,   173,   174,   146,     4,   177,
     146,   179,     6,   309,     4,   310,    87,    82,   397,   187,
     224,    94,   198,    63,    64,    65,    66,    67,    68,    49,
     206,   372,    86,   112,    24,   118,     4,   205,   125,   207,
      30,    31,    32,    -1,   220,   221,    -1,    37,    -1,    -1,
      -1,   219,    56,     4,    -1,   223,    24,    -1,    -1,    27,
      28,    29,    30,    31,    32,    69,   242,    -1,    -1,    37,
      -1,    61,    62,    24,    -1,    -1,    -1,   253,    -1,    30,
      31,    32,    86,    87,    88,   261,    37,    -1,    -1,    -1,
      80,    81,   268,    61,    62,    99,    -1,   273,    -1,    -1,
     276,    -1,    -1,    -1,   280,    -1,    74,    75,    -1,    -1,
      61,    62,    80,    81,   290,    -1,   284,   285,   122,   123,
     124,   111,    -1,    -1,    -1,    -1,   294,    -1,    -1,   297,
      -1,   299,   300,    -1,    -1,     4,    -1,   305,    -1,    -1,
      -1,     0,     1,   111,    -1,    -1,     5,    -1,    -1,    -1,
       9,    10,    11,    12,    13,    24,   146,    -1,    -1,    -1,
     111,    30,    31,    32,    -1,     1,    -1,    -1,    37,     5,
       4,    -1,    -1,     9,    10,    11,    12,    13,   146,    -1,
      -1,    -1,   372,    -1,    -1,    -1,   362,    46,    -1,    -1,
      24,    -1,    61,    62,    53,   146,    30,    31,    32,   367,
     368,   369,   370,    37,    -1,   381,    -1,   383,    -1,    -1,
      46,   387,    71,    72,    73,    -1,   384,    53,    -1,    -1,
      -1,    -1,    -1,    82,    83,    84,    85,    61,    62,    -1,
     406,    -1,    91,    -1,    -1,    71,    72,    73,    97,    -1,
      -1,    -1,    -1,    -1,    -1,    79,    82,    83,    84,    85,
      -1,    -1,    -1,   112,    -1,    91,   115,    -1,    -1,     0,
       1,    97,    -1,    -1,     5,    -1,     4,   126,     9,    10,
      11,    12,    13,   132,    -1,   134,   112,   146,    -1,   115,
      -1,    -1,    -1,    -1,   143,   144,    24,    -1,    -1,     4,
     126,   150,    30,    31,    32,    -1,   132,    -1,   134,    37,
      -1,    -1,    -1,    -1,    -1,    46,    -1,   143,   144,    24,
      -1,    -1,    53,    -1,   150,    30,    31,    32,    -1,    -1,
      -1,    -1,    37,    61,    62,    -1,    41,    42,    43,    -1,
      71,    72,    73,    -1,    -1,    -1,    -1,     4,    -1,    -1,
      -1,    82,    83,    84,    85,     4,    61,    62,    -1,    -1,
      91,    -1,    -1,    -1,    -1,    -1,    97,    24,    -1,    -1,
      27,    28,    29,    30,    31,    32,    -1,    -1,    -1,     4,
      37,   112,    -1,    -1,   115,    57,    -1,    -1,    -1,    -1,
      39,    -1,    -1,    -1,    -1,   126,    -1,    -1,    -1,    -1,
      -1,   132,    -1,   134,    61,    62,     1,    -1,    -1,    -1,
      -1,    -1,   143,   144,    -1,    -1,    -1,    74,    75,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    54,
      55,    56,    57,    58,    59,    60,    -1,    -1,    -1,    -1,
      -1,   146,    -1,    -1,    69,    40,    -1,    -1,    -1,    44,
      45,    -1,     4,    -1,   111,   104,   105,   106,   107,   108,
     109,    -1,   111,   135,   136,   137,   138,   139,   140,   141,
     142,    -1,    24,    -1,    99,    70,    -1,    -1,    30,    31,
      32,    76,    77,    -1,    -1,    37,    -1,    -1,     4,   146,
      -1,     4,    -1,    -1,    89,    90,    -1,   122,   123,   124,
      -1,    96,    -1,    98,    -1,   100,   101,   102,   103,    61,
      62,    24,    -1,    -1,    -1,   110,    -1,    30,    31,    32,
      -1,    -1,    38,   118,    37,    -1,   121,    -1,    80,    81,
     125,    47,    48,    49,    50,    51,    52,    -1,   133,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    61,    62,
      -1,    -1,    -1,    86,    -1,    -1,    -1,    -1,    -1,   111,
      -1,    -1,    -1,    -1,    86,    78,    79,    80,    81,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    92,   110,   111,   112,
     113,   114,   115,   116,   117,   118,    -1,   120,   110,   111,
     112,   113,   114,   115,   116,   117,   118,    -1,   120
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     8,   154,   155,   163,     4,   146,   159,   161,   162,
       0,     1,     5,     9,    10,    11,    12,    13,    46,    53,
      71,    72,    73,    82,    83,    84,    85,    91,    97,   112,
     115,   126,   132,   134,   143,   144,   156,   157,   164,   170,
     191,   195,   155,   160,   161,   145,   145,     1,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    40,    44,
      45,    70,    76,    77,    89,    90,    96,    98,   100,   101,
     102,   103,   110,   118,   121,   125,   133,   165,   210,   145,
     173,   175,   180,   183,   189,   193,   194,   196,   162,   168,
     145,   198,   162,   171,   172,   207,   156,   145,   192,   162,
     147,   148,   151,   208,   208,   159,   210,    25,    26,   213,
     214,   224,   228,   230,   229,   232,   233,   234,   236,   159,
     237,   159,   159,   211,   162,   212,   159,   159,   239,   159,
     162,   159,   162,   149,   167,    69,   174,    39,    99,   122,
     124,   162,   174,   176,   177,   178,   179,   104,   105,   106,
     107,   108,   109,   111,   162,   176,   181,   182,    38,    47,
      48,    49,    50,    51,    52,    92,   162,   184,   185,   186,
     187,   188,    54,    55,    56,    57,    58,    59,    60,   123,
     162,   174,   177,   178,   179,   190,    81,   162,    24,    30,
      31,    32,    37,    61,    62,    80,    81,   111,   162,   215,
     216,   217,   219,   220,   223,    56,    86,    87,    88,   162,
     190,   145,   113,   114,   116,   117,   162,   169,     4,   127,
     128,   129,   130,   131,   146,   177,   178,   179,   202,   204,
     205,   206,   206,   162,   178,   179,   159,   162,   162,   209,
     210,     3,   159,   215,   219,   220,   222,   223,    27,    28,
      29,    74,    75,   159,   215,   219,   220,   222,   225,   226,
     227,   159,   215,   219,   220,   225,    41,    42,    43,   159,
     215,   220,   231,   162,   215,   220,   159,   215,   219,   220,
     159,   215,   220,    78,    79,   162,   215,   220,   222,   235,
     162,   215,   220,   235,   162,   215,   220,   238,   159,   238,
      59,    60,    81,   119,   120,   240,   159,   150,   156,     6,
       7,   166,   159,   162,   162,     3,   162,   162,   162,   162,
     162,     3,   162,   162,   159,   162,     3,   162,   162,    33,
      34,    35,    36,   221,     3,   158,   159,    63,    64,    65,
      66,    67,    68,   218,   162,   159,   162,    93,    94,    95,
     197,   145,   162,   159,   159,     4,   146,   199,   201,   162,
     203,   204,    57,   135,   136,   137,   138,   139,   140,   141,
     142,   152,   148,   159,   159,   159,   159,   159,   159,   159,
     162,   162,   159,   162,   162,   215,   220,   162,   162,     3,
     162,   150,   165,   167,   200,   201,   147,   148,   159,   162,
     162,   162,   162,   209,   159,   159,   162,   159,   147,   148,
     205,   159,   201
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_uint8 yyr1[] =
{
       0,   153,   154,   154,   155,   155,   156,   156,   157,   157,
     157,   158,   158,   159,   159,   160,   160,   161,   162,   163,
     164,   164,   164,   164,   164,   165,   166,   166,   166,   167,
     167,   168,   168,   168,   168,   169,   169,   170,   170,   170,
     170,   170,   170,   170,   170,   170,   170,   170,   170,   170,
     171,   170,   172,   170,   170,   173,   173,   174,   175,   175,
     175,   175,   175,   175,   176,   177,   178,   179,   180,   180,
     180,   180,   180,   181,   181,   181,   181,   182,   182,   183,
     183,   183,   183,   183,   183,   184,   184,   185,   185,   186,
     186,   187,   188,   189,   189,   189,   189,   189,   189,   189,
     189,   189,   190,   190,   190,   190,   190,   191,   191,   191,
     192,   192,   193,   193,   194,   194,   194,   194,   194,   195,
     195,   196,   196,   196,   196,   196,   196,   197,   197,   197,
     198,   198,   198,   198,   198,   198,   198,   198,   198,   199,
     199,   200,   200,   201,   202,   202,   203,   203,   204,   205,
     206,   206,   206,   206,   206,   206,   206,   206,   206,   206,
     207,   207,   207,   208,   209,   209,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   211,   210,   210,
     212,   210,   210,   210,   210,   210,   210,   210,   210,   210,
     213,   213,   214,   214,   214,   214,   214,   215,   215,   216,
     216,   216,   216,   217,   217,   218,   218,   218,   218,   218,
     218,   219,   220,   221,   221,   221,   221,   222,   223,   223,
     224,   224,   224,   224,   224,   224,   225,   226,   226,   226,
     226,   227,   227,   228,   228,   228,   228,   228,   229,   229,
     229,   230,   230,   230,   230,   230,   231,   231,   232,   232,
     232,   232,   233,   233,   233,   234,   234,   234,   234,   234,
     234,   235,   236,   236,   236,   236,   237,   237,   237,   238,
     238,   238,   239,   239,   239,   239,   239,   240,   240
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     2,     0,     2,     1,     2,     1,     2,
       2,     0,     1,     1,     3,     1,     3,     1,     1,     3,
       2,     2,     3,     4,     2,     3,     0,     2,     2,     3,
       2,     0,     2,     2,     2,     1,     1,     2,     3,     3,
       1,     4,     3,     3,     4,     4,     2,     3,     2,     3,
       0,     3,     0,     3,     3,     0,     2,     2,     0,     2,
       2,     2,     2,     2,     1,     1,     2,     2,     0,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     2,     0,
       2,     2,     2,     2,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     0,     3,     3,     3,     3,     3,     2,
       3,     2,     2,     1,     1,     1,     1,     1,     1,     1,
       0,     2,     0,     2,     0,     2,     2,     2,     2,     1,
       1,     0,     3,     3,     3,     3,     2,     1,     1,     1,
       0,     3,     2,     2,     2,     3,     3,     3,     3,     1,
       3,     1,     3,     1,     1,     3,     1,     3,     1,     1,
       0,     2,     2,     2,     2,     3,     3,     3,     3,     3,
       0,     2,     2,     3,     1,     3,     2,     2,     2,     1,
       1,     2,     3,     4,     4,     4,     3,     4,     4,     4,
       3,     5,     4,     2,     5,     2,     2,     0,     6,     3,
       0,     5,     2,     2,     2,     2,     3,     2,     2,     1,
       1,     1,     0,     2,     2,     2,     2,     1,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     1,     1,     1,     1,     1,     2,     1,
       0,     2,     2,     2,     2,     2,     1,     1,     1,     1,
       1,     1,     1,     0,     2,     2,     2,     2,     0,     2,
       2,     0,     2,     3,     2,     2,     1,     1,     0,     2,
       2,     2,     0,     2,     2,     0,     2,     2,     2,     2,
       2,     2,     0,     2,     2,     2,     0,     2,     2,     0,
       2,     2,     0,     3,     3,     3,     2,     1,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (sscript, YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, sscript); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, sieve_script_t *sscript)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (sscript);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, sieve_script_t *sscript)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep, sscript);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule, sieve_script_t *sscript)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)], sscript);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule, sscript); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, sieve_script_t *sscript)
{
  YY_USE (yyvaluep);
  YY_USE (sscript);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  switch (yykind)
    {
    case YYSYMBOL_STRING: /* STRING  */
#line 175 "sieve/sieve.y"
             { free(((*yyvaluep).sval));          }
#line 1959 "sieve/sieve.c"
        break;

    case YYSYMBOL_commands: /* commands  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 1965 "sieve/sieve.c"
        break;

    case YYSYMBOL_command: /* command  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 1971 "sieve/sieve.c"
        break;

    case YYSYMBOL_optstringlist: /* optstringlist  */
#line 174 "sieve/sieve.y"
             { strarray_free(((*yyvaluep).sl)); }
#line 1977 "sieve/sieve.c"
        break;

    case YYSYMBOL_stringlist: /* stringlist  */
#line 174 "sieve/sieve.y"
             { strarray_free(((*yyvaluep).sl)); }
#line 1983 "sieve/sieve.c"
        break;

    case YYSYMBOL_strings: /* strings  */
#line 174 "sieve/sieve.y"
             { strarray_free(((*yyvaluep).sl)); }
#line 1989 "sieve/sieve.c"
        break;

    case YYSYMBOL_string1: /* string1  */
#line 174 "sieve/sieve.y"
             { strarray_free(((*yyvaluep).sl)); }
#line 1995 "sieve/sieve.c"
        break;

    case YYSYMBOL_string: /* string  */
#line 175 "sieve/sieve.y"
             { free(((*yyvaluep).sval));          }
#line 2001 "sieve/sieve.c"
        break;

    case YYSYMBOL_control: /* control  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2007 "sieve/sieve.c"
        break;

    case YYSYMBOL_thenelse: /* thenelse  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2013 "sieve/sieve.c"
        break;

    case YYSYMBOL_elsif: /* elsif  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2019 "sieve/sieve.c"
        break;

    case YYSYMBOL_block: /* block  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2025 "sieve/sieve.c"
        break;

    case YYSYMBOL_itags: /* itags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2031 "sieve/sieve.c"
        break;

    case YYSYMBOL_action: /* action  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2037 "sieve/sieve.c"
        break;

    case YYSYMBOL_ktags: /* ktags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2043 "sieve/sieve.c"
        break;

    case YYSYMBOL_ftags: /* ftags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2049 "sieve/sieve.c"
        break;

    case YYSYMBOL_rtags: /* rtags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2055 "sieve/sieve.c"
        break;

    case YYSYMBOL_stags: /* stags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2061 "sieve/sieve.c"
        break;

    case YYSYMBOL_vtags: /* vtags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2067 "sieve/sieve.c"
        break;

    case YYSYMBOL_flagtags: /* flagtags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2073 "sieve/sieve.c"
        break;

    case YYSYMBOL_ahtags: /* ahtags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2079 "sieve/sieve.c"
        break;

    case YYSYMBOL_dhtags: /* dhtags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2085 "sieve/sieve.c"
        break;

    case YYSYMBOL_ntags: /* ntags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2091 "sieve/sieve.c"
        break;

    case YYSYMBOL_sntags: /* sntags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2097 "sieve/sieve.c"
        break;

    case YYSYMBOL_timelist: /* timelist  */
#line 176 "sieve/sieve.y"
             { arrayu64_free(((*yyvaluep).nl)); }
#line 2103 "sieve/sieve.c"
        break;

    case YYSYMBOL_times: /* times  */
#line 176 "sieve/sieve.y"
             { arrayu64_free(((*yyvaluep).nl)); }
#line 2109 "sieve/sieve.c"
        break;

    case YYSYMBOL_time1: /* time1  */
#line 176 "sieve/sieve.y"
             { arrayu64_free(((*yyvaluep).nl)); }
#line 2115 "sieve/sieve.c"
        break;

    case YYSYMBOL_caltags: /* caltags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2121 "sieve/sieve.c"
        break;

    case YYSYMBOL_ikttags: /* ikttags  */
#line 171 "sieve/sieve.y"
             { free_tree(((*yyvaluep).cl));     }
#line 2127 "sieve/sieve.c"
        break;

    case YYSYMBOL_testlist: /* testlist  */
#line 172 "sieve/sieve.y"
             { free_testlist(((*yyvaluep).testl)); }
#line 2133 "sieve/sieve.c"
        break;

    case YYSYMBOL_tests: /* tests  */
#line 172 "sieve/sieve.y"
             { free_testlist(((*yyvaluep).testl)); }
#line 2139 "sieve/sieve.c"
        break;

    case YYSYMBOL_test: /* test  */
#line 173 "sieve/sieve.y"
             { free_test(((*yyvaluep).test));     }
#line 2145 "sieve/sieve.c"
        break;

      default:
        break;
    }
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}






/*----------.
| yyparse.  |
`----------*/

int
yyparse (sieve_script_t *sscript)
{
/* Lookahead token kind.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

    /* Number of syntax errors so far.  */
    int yynerrs = 0;

    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex (&yylval, sscript);
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* start: reqs  */
#line 368 "sieve/sieve.y"
                                 { sscript->cmds = NULL; }
#line 2421 "sieve/sieve.c"
    break;

  case 3: /* start: reqs commands  */
#line 369 "sieve/sieve.y"
                                 { sscript->cmds = (yyvsp[0].cl); }
#line 2427 "sieve/sieve.c"
    break;

  case 7: /* commands: command commands  */
#line 380 "sieve/sieve.y"
                                 { (yyval.cl) = (yyvsp[-1].cl); (yyval.cl)->next = (yyvsp[0].cl); }
#line 2433 "sieve/sieve.c"
    break;

  case 10: /* command: error ';'  */
#line 386 "sieve/sieve.y"
                                 {
                                     struct buf buf = BUF_INITIALIZER;
                                     buf_printf(&buf, "%s: line %d",
                                                error_message(SIEVE_UNSUPP_EXT),
                                                sievelineno);
                                     sscript->support |= SIEVE_CAPA_IHAVE;
                                     (yyval.cl) = build_rej_err(sscript, B_ERROR,
                                                        buf_release(&buf));
                                 }
#line 2447 "sieve/sieve.c"
    break;

  case 11: /* optstringlist: %empty  */
#line 398 "sieve/sieve.y"
                                 { (yyval.sl) = strarray_new(); }
#line 2453 "sieve/sieve.c"
    break;

  case 14: /* stringlist: '[' strings ']'  */
#line 404 "sieve/sieve.y"
                                 { (yyval.sl) = (yyvsp[-1].sl); }
#line 2459 "sieve/sieve.c"
    break;

  case 16: /* strings: strings ',' string  */
#line 409 "sieve/sieve.y"
                                 { (yyval.sl) = (yyvsp[-2].sl); strarray_appendm((yyval.sl), (yyvsp[0].sval)); }
#line 2465 "sieve/sieve.c"
    break;

  case 17: /* string1: string  */
#line 413 "sieve/sieve.y"
                                 {
                                     (yyval.sl) = strarray_new();
                                     strarray_appendm((yyval.sl), (yyvsp[0].sval));
                                 }
#line 2474 "sieve/sieve.c"
    break;

  case 18: /* string: STRING  */
#line 420 "sieve/sieve.y"
                                 { (yyval.sval) = (yyvsp[0].sval); chk_match_vars(sscript, (yyval.sval)); }
#line 2480 "sieve/sieve.c"
    break;

  case 19: /* require: REQUIRE stringlist ';'  */
#line 427 "sieve/sieve.y"
                                 { check_reqs(sscript, (yyvsp[-1].sl)); }
#line 2486 "sieve/sieve.c"
    break;

  case 20: /* control: IF thenelse  */
#line 431 "sieve/sieve.y"
                                 { (yyval.cl) = (yyvsp[0].cl); }
#line 2492 "sieve/sieve.c"
    break;

  case 21: /* control: STOP ';'  */
#line 432 "sieve/sieve.y"
                                 { (yyval.cl) = new_command(B_STOP, sscript); }
#line 2498 "sieve/sieve.c"
    break;

  case 22: /* control: ERROR string ';'  */
#line 433 "sieve/sieve.y"
                                 { (yyval.cl) = build_rej_err(sscript, B_ERROR, (yyvsp[-1].sval)); }
#line 2504 "sieve/sieve.c"
    break;

  case 23: /* control: INCLUDE itags string ';'  */
#line 435 "sieve/sieve.y"
                                 { (yyval.cl) = build_include(sscript, (yyvsp[-2].cl), (yyvsp[-1].sval)); }
#line 2510 "sieve/sieve.c"
    break;

  case 24: /* control: RETURN ';'  */
#line 436 "sieve/sieve.y"
                                 { (yyval.cl) = new_command(B_RETURN, sscript); }
#line 2516 "sieve/sieve.c"
    break;

  case 25: /* thenelse: test block elsif  */
#line 440 "sieve/sieve.y"
                                 { 
                                     if ((yyvsp[-2].test)->ignore_err) {
                                         /* end of block - decrement counter */
                                         sscript->ignore_err--;
                                     }

                                     (yyval.cl) = new_if((yyvsp[-2].test), (yyvsp[-1].cl), (yyvsp[0].cl));
                                 }
#line 2529 "sieve/sieve.c"
    break;

  case 26: /* elsif: %empty  */
#line 451 "sieve/sieve.y"
                                 { (yyval.cl) = NULL; }
#line 2535 "sieve/sieve.c"
    break;

  case 27: /* elsif: ELSIF thenelse  */
#line 452 "sieve/sieve.y"
                                 { (yyval.cl) = (yyvsp[0].cl); }
#line 2541 "sieve/sieve.c"
    break;

  case 28: /* elsif: ELSE block  */
#line 453 "sieve/sieve.y"
                                 { (yyval.cl) = (yyvsp[0].cl); }
#line 2547 "sieve/sieve.c"
    break;

  case 29: /* block: '{' commands '}'  */
#line 457 "sieve/sieve.y"
                                 { (yyval.cl) = (yyvsp[-1].cl); }
#line 2553 "sieve/sieve.c"
    break;

  case 30: /* block: '{' '}'  */
#line 458 "sieve/sieve.y"
                                 { (yyval.cl) = NULL; }
#line 2559 "sieve/sieve.c"
    break;

  case 31: /* itags: %empty  */
#line 463 "sieve/sieve.y"
                                 { (yyval.cl) = new_command(B_INCLUDE, sscript); }
#line 2565 "sieve/sieve.c"
    break;

  case 32: /* itags: itags location  */
#line 464 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.inc.location != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_CONFLICTING_TAGS,
                                                      ":personal", ":location");
                                     }

                                     (yyval.cl)->u.inc.location = (yyvsp[0].nval);
                                 }
#line 2580 "sieve/sieve.c"
    break;

  case 33: /* itags: itags ONCE  */
#line 474 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.inc.once != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":once");
                                     }

                                     (yyval.cl)->u.inc.once = INC_ONCE_MASK;
                                 }
#line 2595 "sieve/sieve.c"
    break;

  case 34: /* itags: itags OPTIONAL  */
#line 484 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.inc.optional != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":optional");
                                     }

                                     (yyval.cl)->u.inc.optional = INC_OPTIONAL_MASK;
                                 }
#line 2610 "sieve/sieve.c"
    break;

  case 35: /* location: PERSONAL  */
#line 498 "sieve/sieve.y"
                                 { (yyval.nval) = B_PERSONAL; }
#line 2616 "sieve/sieve.c"
    break;

  case 36: /* location: GLOBAL  */
#line 499 "sieve/sieve.y"
                                 { (yyval.nval) = B_GLOBAL;   }
#line 2622 "sieve/sieve.c"
    break;

  case 37: /* action: KEEP ktags  */
#line 506 "sieve/sieve.y"
                                 { (yyval.cl) = build_keep(sscript, (yyvsp[0].cl)); }
#line 2628 "sieve/sieve.c"
    break;

  case 38: /* action: FILEINTO ftags string  */
#line 507 "sieve/sieve.y"
                                 { (yyval.cl) = build_fileinto(sscript, (yyvsp[-1].cl), (yyvsp[0].sval)); }
#line 2634 "sieve/sieve.c"
    break;

  case 39: /* action: REDIRECT rtags string  */
#line 508 "sieve/sieve.y"
                                 { (yyval.cl) = build_redirect(sscript, (yyvsp[-1].cl), (yyvsp[0].sval)); }
#line 2640 "sieve/sieve.c"
    break;

  case 40: /* action: DISCARD  */
#line 509 "sieve/sieve.y"
                                 { (yyval.cl) = new_command(B_DISCARD, sscript); }
#line 2646 "sieve/sieve.c"
    break;

  case 41: /* action: SET stags string string  */
#line 511 "sieve/sieve.y"
                                 { (yyval.cl) = build_set(sscript, (yyvsp[-2].cl), (yyvsp[-1].sval), (yyvsp[0].sval)); }
#line 2652 "sieve/sieve.c"
    break;

  case 42: /* action: VACATION vtags string  */
#line 512 "sieve/sieve.y"
                                 { (yyval.cl) = build_vacation(sscript, (yyvsp[-1].cl), (yyvsp[0].sval)); }
#line 2658 "sieve/sieve.c"
    break;

  case 43: /* action: flagaction flagtags stringlist  */
#line 516 "sieve/sieve.y"
                                 { (yyval.cl) = build_flag(sscript, (yyvsp[-1].cl), (yyvsp[0].sl)); }
#line 2664 "sieve/sieve.c"
    break;

  case 44: /* action: ADDHEADER ahtags string string  */
#line 519 "sieve/sieve.y"
                                 { (yyval.cl) = build_addheader(sscript,
                                                        (yyvsp[-2].cl), (yyvsp[-1].sval), (yyvsp[0].sval)); }
#line 2671 "sieve/sieve.c"
    break;

  case 45: /* action: DELETEHEADER dhtags string optstringlist  */
#line 522 "sieve/sieve.y"
                                 { (yyval.cl) = build_deleteheader(sscript,
                                                           (yyvsp[-2].cl), (yyvsp[-1].sval), (yyvsp[0].sl)); }
#line 2678 "sieve/sieve.c"
    break;

  case 46: /* action: reject string  */
#line 525 "sieve/sieve.y"
                                 { (yyval.cl) = build_rej_err(sscript, (yyvsp[-1].nval), (yyvsp[0].sval)); }
#line 2684 "sieve/sieve.c"
    break;

  case 47: /* action: NOTIFY ntags string  */
#line 526 "sieve/sieve.y"
                                 { (yyval.cl) = build_notify(sscript, (yyvsp[-1].cl), (yyvsp[0].sval)); }
#line 2690 "sieve/sieve.c"
    break;

  case 48: /* action: LOG string  */
#line 527 "sieve/sieve.y"
                                 { (yyval.cl) = build_log(sscript, (yyvsp[0].sval)); }
#line 2696 "sieve/sieve.c"
    break;

  case 49: /* action: SNOOZE sntags timelist  */
#line 528 "sieve/sieve.y"
                                 { (yyval.cl) = build_snooze(sscript, (yyvsp[-1].cl), (yyvsp[0].nl)); }
#line 2702 "sieve/sieve.c"
    break;

  case 50: /* $@1: %empty  */
#line 530 "sieve/sieve.y"
                      { legacy = 0; }
#line 2708 "sieve/sieve.c"
    break;

  case 51: /* action: PROCESSCAL $@1 caltags  */
#line 531 "sieve/sieve.y"
                                 { (yyval.cl) = build_cal(sscript, (yyvsp[0].cl)); }
#line 2714 "sieve/sieve.c"
    break;

  case 52: /* $@2: %empty  */
#line 533 "sieve/sieve.y"
                      { legacy = 1; }
#line 2720 "sieve/sieve.c"
    break;

  case 53: /* action: PROCESSIMIP $@2 caltags  */
#line 534 "sieve/sieve.y"
                                 { (yyval.cl) = build_cal(sscript, (yyvsp[0].cl)); }
#line 2726 "sieve/sieve.c"
    break;

  case 54: /* action: IKEEP_TARGET ikttags string  */
#line 537 "sieve/sieve.y"
                                 { (yyval.cl) = build_ikeep_target(sscript, (yyvsp[-1].cl), (yyvsp[0].sval)); }
#line 2732 "sieve/sieve.c"
    break;

  case 55: /* ktags: %empty  */
#line 542 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = new_command(B_KEEP, sscript);
                                     flags = &((yyval.cl)->u.k.flags);
                                 }
#line 2741 "sieve/sieve.c"
    break;

  case 57: /* flags: FLAGS stringlist  */
#line 551 "sieve/sieve.y"
                                 {
                                     /* **flags assigned by the calling rule */
                                     if (*flags != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":flags");
                                         strarray_free(*flags);
                                     }
                                     else if (!supported(SIEVE_CAPA_IMAP4FLAGS)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "imap4flags");
                                     }

                                     *flags = (yyvsp[0].sl);
                                 }
#line 2762 "sieve/sieve.c"
    break;

  case 58: /* ftags: %empty  */
#line 571 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = new_command(B_FILEINTO, sscript);
                                     copy = &((yyval.cl)->u.f.copy);
                                     flags = &((yyval.cl)->u.f.flags);
                                     create = &((yyval.cl)->u.f.create);
                                     specialuse = &((yyval.cl)->u.f.t.specialuse);
                                     mailboxid = &((yyval.cl)->u.f.t.mailboxid);
                                 }
#line 2775 "sieve/sieve.c"
    break;

  case 64: /* copy: COPY  */
#line 588 "sieve/sieve.y"
                                 {
                                     /* *copy assigned by the calling rule */
                                     if ((*copy)++) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":copy");
                                     }
                                     else if (!supported(SIEVE_CAPA_COPY)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "copy");
                                     }
                                 }
#line 2793 "sieve/sieve.c"
    break;

  case 65: /* create: CREATE  */
#line 605 "sieve/sieve.y"
                                {
                                     /* *create assigned by the calling rule */
                                     if ((*create)++) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":create");
                                     }
                                     else if (!supported(SIEVE_CAPA_MAILBOX)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "mailbox");
                                     }
                                 }
#line 2811 "sieve/sieve.c"
    break;

  case 66: /* specialuse: SPECIALUSE string  */
#line 622 "sieve/sieve.y"
                                 {
                                     /* **specialuse assigned by calling rule */
                                     if (*specialuse != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":specialuse");
                                         free(*specialuse);
                                     }
                                     else if (!supported(SIEVE_CAPA_SPECIAL_USE)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "special-use");
                                     }
                                     else if (*mailboxid != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_CONFLICTING_TAGS,
                                                      ":specialuse",
                                                      ":mailboxid");
                                     }

                                     *specialuse = (yyvsp[0].sval);
                                 }
#line 2838 "sieve/sieve.c"
    break;

  case 67: /* mailboxid: MAILBOXID string  */
#line 647 "sieve/sieve.y"
                                 {
                                     /* **mailboxid assigned by calling rule */
                                     if (*mailboxid != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":mailboxid");
                                         free(*mailboxid);
                                     }
                                     else if (!supported(SIEVE_CAPA_MAILBOXID)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "mailboxid");
                                     }
                                     else if (*specialuse != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_CONFLICTING_TAGS,
                                                      ":mailboxid",
                                                      ":specialuse");
                                     }

                                     *mailboxid = (yyvsp[0].sval);
                                 }
#line 2865 "sieve/sieve.c"
    break;

  case 68: /* rtags: %empty  */
#line 673 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = new_command(B_REDIRECT, sscript);
                                     copy = &((yyval.cl)->u.r.copy);
                                 }
#line 2874 "sieve/sieve.c"
    break;

  case 70: /* rtags: rtags LIST  */
#line 678 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.r.list++) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":list");
                                     }
                                     else if (!supported(SIEVE_CAPA_EXTLISTS)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "extlists");
                                     }
                                 }
#line 2892 "sieve/sieve.c"
    break;

  case 71: /* rtags: rtags delbytags  */
#line 691 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if (!supported(SIEVE_CAPA_REDIR_DELBY)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "redirect-deliverby");
                                     }
                                 }
#line 2905 "sieve/sieve.c"
    break;

  case 72: /* rtags: rtags dsntags  */
#line 699 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if (!supported(SIEVE_CAPA_REDIR_DSN)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "redirect-dsn");
                                     }
                                 }
#line 2918 "sieve/sieve.c"
    break;

  case 73: /* delbytags: BYTIMEREL NUMBER  */
#line 710 "sieve/sieve.y"
                                 {
                                     /* $0 refers to rtags */
                                     commandlist_t *c = (yyvsp[-2].cl);

                                     if (c->u.r.bytime != NULL) {
                                         if (isdigit(c->u.r.bytime[0])) {
                                             sieveerror_c(sscript,
                                                          SIEVE_CONFLICTING_TAGS,
                                                          ":bytimerelative",
                                                          ":bytimeabsolute");
                                         }
                                         else {
                                             sieveerror_c(sscript,
                                                          SIEVE_DUPLICATE_TAG,
                                                          ":bytimerelative");
                                         }
                                     }                                         

                                     struct buf buf = BUF_INITIALIZER;
                                     buf_printf(&buf, "+%d", (yyvsp[0].nval));
                                     c->u.r.bytime = buf_release(&buf);
                                 }
#line 2945 "sieve/sieve.c"
    break;

  case 74: /* delbytags: BYTIMEABS string  */
#line 732 "sieve/sieve.y"
                                 {
                                     /* $0 refers to rtags */
                                     commandlist_t *c = (yyvsp[-2].cl);

                                     if (c->u.r.bytime != NULL) {
                                         if (isdigit(c->u.r.bytime[0])) {
                                             sieveerror_c(sscript,
                                                          SIEVE_DUPLICATE_TAG,
                                                          ":bytimeabsolute");
                                         }
                                         else {
                                             sieveerror_c(sscript,
                                                          SIEVE_CONFLICTING_TAGS,
                                                          ":bytimeabsolute",
                                                          ":bytimerelative");
                                         }
                                     }

                                     c->u.r.bytime = (yyvsp[0].sval);
                                 }
#line 2970 "sieve/sieve.c"
    break;

  case 75: /* delbytags: BYMODE string  */
#line 752 "sieve/sieve.y"
                                 {
                                     /* $0 refers to rtags */
                                     commandlist_t *c = (yyvsp[-2].cl);

                                     if (c->u.r.bymode != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":bymode");
                                     }

                                     c->u.r.bymode = (yyvsp[0].sval);
                                 }
#line 2987 "sieve/sieve.c"
    break;

  case 76: /* delbytags: BYTRACE  */
#line 764 "sieve/sieve.y"
                                 {
                                     /* $0 refers to rtags */
                                     commandlist_t *c = (yyvsp[-1].cl);

                                     if (c->u.r.bytrace != 0) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":bytrace");
                                     }

                                     c->u.r.bytrace = 1;
                                 }
#line 3004 "sieve/sieve.c"
    break;

  case 77: /* dsntags: DSNNOTIFY string  */
#line 780 "sieve/sieve.y"
                                 {
                                     /* $0 refers to rtags */
                                     commandlist_t *c = (yyvsp[-2].cl);

                                     if (c->u.r.dsn_notify != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":notify");
                                     }                                         

                                     c->u.r.dsn_notify = (yyvsp[0].sval);
                                 }
#line 3021 "sieve/sieve.c"
    break;

  case 78: /* dsntags: DSNRET string  */
#line 792 "sieve/sieve.y"
                                 {
                                     /* $0 refers to rtags */
                                     commandlist_t *c = (yyvsp[-2].cl);

                                     if (c->u.r.dsn_ret != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":ret");
                                     }

                                     c->u.r.dsn_ret = (yyvsp[0].sval);
                                 }
#line 3038 "sieve/sieve.c"
    break;

  case 79: /* stags: %empty  */
#line 808 "sieve/sieve.y"
                                 { (yyval.cl) = new_command(B_SET, sscript); }
#line 3044 "sieve/sieve.c"
    break;

  case 80: /* stags: stags mod40  */
#line 809 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.s.modifiers & BFV_MOD40_MASK) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "precedence 40 modifier");
                                     }

                                     (yyval.cl)->u.s.modifiers |= (yyvsp[0].nval);
                                 }
#line 3059 "sieve/sieve.c"
    break;

  case 81: /* stags: stags mod30  */
#line 819 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.s.modifiers & BFV_MOD30_MASK) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "precedence 30 modifier");
                                     }

                                     (yyval.cl)->u.s.modifiers |= (yyvsp[0].nval);
                                 }
#line 3074 "sieve/sieve.c"
    break;

  case 82: /* stags: stags mod20  */
#line 829 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.s.modifiers & BFV_MOD20_MASK) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "precedence 20 modifier");
                                     }

                                     (yyval.cl)->u.s.modifiers |= (yyvsp[0].nval);
                                 }
#line 3089 "sieve/sieve.c"
    break;

  case 83: /* stags: stags mod15  */
#line 839 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.s.modifiers & BFV_MOD15_MASK) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "precedence 15 modifier");
                                     }

                                     (yyval.cl)->u.s.modifiers |= (yyvsp[0].nval);
                                 }
#line 3104 "sieve/sieve.c"
    break;

  case 84: /* stags: stags mod10  */
#line 849 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.s.modifiers & BFV_MOD10_MASK) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "precedence 10 modifier");
                                     }

                                     (yyval.cl)->u.s.modifiers |= (yyvsp[0].nval);
                                 }
#line 3119 "sieve/sieve.c"
    break;

  case 85: /* mod40: LOWER  */
#line 863 "sieve/sieve.y"
                                { (yyval.nval) = BFV_LOWER; }
#line 3125 "sieve/sieve.c"
    break;

  case 86: /* mod40: UPPER  */
#line 864 "sieve/sieve.y"
                                { (yyval.nval) = BFV_UPPER; }
#line 3131 "sieve/sieve.c"
    break;

  case 87: /* mod30: LOWERFIRST  */
#line 867 "sieve/sieve.y"
                                { (yyval.nval) = BFV_LOWERFIRST; }
#line 3137 "sieve/sieve.c"
    break;

  case 88: /* mod30: UPPERFIRST  */
#line 868 "sieve/sieve.y"
                                { (yyval.nval) = BFV_UPPERFIRST; }
#line 3143 "sieve/sieve.c"
    break;

  case 89: /* mod20: QUOTEWILDCARD  */
#line 871 "sieve/sieve.y"
                                { (yyval.nval) = BFV_QUOTEWILDCARD; }
#line 3149 "sieve/sieve.c"
    break;

  case 90: /* mod20: QUOTEREGEX  */
#line 872 "sieve/sieve.y"
                                { 
                                     if (!supported(SIEVE_CAPA_REGEX)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "regex");
                                     }

                                     (yyval.nval) = BFV_QUOTEREGEX;
                                 }
#line 3163 "sieve/sieve.c"
    break;

  case 91: /* mod15: ENCODEURL  */
#line 884 "sieve/sieve.y"
                                 { 
                                     if (!supported(SIEVE_CAPA_ENOTIFY)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "enotify");
                                     }

                                     (yyval.nval) = BFV_ENCODEURL;
                                 }
#line 3177 "sieve/sieve.c"
    break;

  case 92: /* mod10: LENGTH  */
#line 895 "sieve/sieve.y"
                                 { (yyval.nval) = BFV_LENGTH; }
#line 3183 "sieve/sieve.c"
    break;

  case 93: /* vtags: %empty  */
#line 900 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = new_command(B_VACATION, sscript);
                                     flags = &((yyval.cl)->u.v.fcc.flags);
                                     create = &((yyval.cl)->u.v.fcc.create);
                                     specialuse = &((yyval.cl)->u.v.fcc.t.specialuse);
                                     mailboxid = &((yyval.cl)->u.v.fcc.t.mailboxid);
                                     fccfolder = &((yyval.cl)->u.v.fcc.t.folder);
                                 }
#line 3196 "sieve/sieve.c"
    break;

  case 94: /* vtags: vtags DAYS NUMBER  */
#line 908 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.v.seconds != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":days");
                                     }

                                     (yyval.cl)->u.v.seconds = (yyvsp[0].nval) * DAY2SEC;
                                 }
#line 3211 "sieve/sieve.c"
    break;

  case 95: /* vtags: vtags SECONDS NUMBER  */
#line 918 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if (!supported(SIEVE_CAPA_VACATION_SEC)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "vacation-seconds");
                                     }
                                     if ((yyval.cl)->u.v.seconds != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":seconds");
                                     }

                                     (yyval.cl)->u.v.seconds = (yyvsp[0].nval);
                                 }
#line 3231 "sieve/sieve.c"
    break;

  case 96: /* vtags: vtags SUBJECT string  */
#line 933 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.v.subject != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":subject");
                                         free((yyval.cl)->u.v.subject);
                                     }

                                     (yyval.cl)->u.v.subject = (yyvsp[0].sval);
                                 }
#line 3247 "sieve/sieve.c"
    break;

  case 97: /* vtags: vtags FROM string  */
#line 944 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.v.from != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":from");
                                         free((yyval.cl)->u.v.from);
                                     }

                                     (yyval.cl)->u.v.from = (yyvsp[0].sval);
                                 }
#line 3263 "sieve/sieve.c"
    break;

  case 98: /* vtags: vtags ADDRESSES stringlist  */
#line 957 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.v.addresses != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":addresses");
                                         strarray_free((yyval.cl)->u.v.addresses);
                                     }

                                     (yyval.cl)->u.v.addresses = (yyvsp[0].sl);
                                 }
#line 3279 "sieve/sieve.c"
    break;

  case 99: /* vtags: vtags MIME  */
#line 968 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.v.mime != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":mime");
                                     }

                                     (yyval.cl)->u.v.mime = 1;
                                 }
#line 3294 "sieve/sieve.c"
    break;

  case 100: /* vtags: vtags HANDLE string  */
#line 978 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.v.handle != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":handle");
                                         free((yyval.cl)->u.v.handle);
                                     }

                                     (yyval.cl)->u.v.handle = (yyvsp[0].sval);
                                 }
#line 3310 "sieve/sieve.c"
    break;

  case 102: /* fcctags: FCC string  */
#line 993 "sieve/sieve.y"
                                 {
                                     /* **fccfolder assigned by the calling rule */
                                     if (*fccfolder != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":fcc");
                                         free(*fccfolder);
                                     }
                                     else if (!supported(SIEVE_CAPA_FCC)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "fcc");
                                     }

                                     *fccfolder = (yyvsp[0].sval);
                                 }
#line 3331 "sieve/sieve.c"
    break;

  case 107: /* flagaction: SETFLAG  */
#line 1017 "sieve/sieve.y"
                                 { (yyval.nval) = B_SETFLAG;    }
#line 3337 "sieve/sieve.c"
    break;

  case 108: /* flagaction: ADDFLAG  */
#line 1018 "sieve/sieve.y"
                                 { (yyval.nval) = B_ADDFLAG;    }
#line 3343 "sieve/sieve.c"
    break;

  case 109: /* flagaction: REMOVEFLAG  */
#line 1019 "sieve/sieve.y"
                                 { (yyval.nval) = B_REMOVEFLAG; }
#line 3349 "sieve/sieve.c"
    break;

  case 110: /* flagtags: %empty  */
#line 1024 "sieve/sieve.y"
                                 { (yyval.cl) = new_command((yyvsp[0].nval), sscript); }
#line 3355 "sieve/sieve.c"
    break;

  case 111: /* flagtags: flagtags string  */
#line 1025 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.fl.variable != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_ARG,
                                                      "variablename");
                                         free((yyval.cl)->u.fl.variable);
                                     }
                                     else if (!supported(SIEVE_CAPA_IMAP4FLAGS)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "imap4flags");
                                     }

                                     (yyval.cl)->u.fl.variable = (yyvsp[0].sval);
                                 }
#line 3376 "sieve/sieve.c"
    break;

  case 112: /* ahtags: %empty  */
#line 1045 "sieve/sieve.y"
                                 { (yyval.cl) = new_command(B_ADDHEADER, sscript); }
#line 3382 "sieve/sieve.c"
    break;

  case 113: /* ahtags: ahtags LAST  */
#line 1046 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.ah.index < 0) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":last");
                                     }

                                     (yyval.cl)->u.ah.index = -1;
                                 }
#line 3397 "sieve/sieve.c"
    break;

  case 114: /* dhtags: %empty  */
#line 1060 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = new_command(B_DELETEHEADER, sscript);
                                     ctags = &((yyval.cl)->u.dh.comp);
                                 }
#line 3406 "sieve/sieve.c"
    break;

  case 119: /* reject: REJCT  */
#line 1072 "sieve/sieve.y"
                                 { (yyval.nval) = B_REJECT;  }
#line 3412 "sieve/sieve.c"
    break;

  case 120: /* reject: EREJECT  */
#line 1073 "sieve/sieve.y"
                                 { (yyval.nval) = B_EREJECT; }
#line 3418 "sieve/sieve.c"
    break;

  case 121: /* ntags: %empty  */
#line 1078 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = new_command(B_ENOTIFY, sscript);
                                     flags = &((yyval.cl)->u.n.fcc.flags);
                                     create = &((yyval.cl)->u.n.fcc.create);
                                     specialuse = &((yyval.cl)->u.n.fcc.t.specialuse);
                                     mailboxid = &((yyval.cl)->u.n.fcc.t.mailboxid);
                                     fccfolder = &((yyval.cl)->u.n.fcc.t.folder);
                                 }
#line 3431 "sieve/sieve.c"
    break;

  case 122: /* ntags: ntags FROM string  */
#line 1086 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.n.from != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":from");
                                         free((yyval.cl)->u.n.from);
                                     }

                                     (yyval.cl)->u.n.from = (yyvsp[0].sval);
                                 }
#line 3447 "sieve/sieve.c"
    break;

  case 123: /* ntags: ntags IMPORTANCE priority  */
#line 1099 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.n.priority != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":importance");
                                     }

                                     (yyval.cl)->u.n.priority = (yyvsp[0].nval);
                                 }
#line 3462 "sieve/sieve.c"
    break;

  case 124: /* ntags: ntags MESSAGE string  */
#line 1109 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.n.message != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":message");
                                         free((yyval.cl)->u.n.message);
                                     }

                                     (yyval.cl)->u.n.message = (yyvsp[0].sval);
                                 }
#line 3478 "sieve/sieve.c"
    break;

  case 125: /* ntags: ntags OPTIONS stringlist  */
#line 1122 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.n.options != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":options");
                                         strarray_free((yyval.cl)->u.n.options);
                                     }

                                     (yyval.cl)->u.n.options = (yyvsp[0].sl);
                                 }
#line 3494 "sieve/sieve.c"
    break;

  case 127: /* priority: LOW  */
#line 1138 "sieve/sieve.y"
                                 { (yyval.nval) = B_LOW;    }
#line 3500 "sieve/sieve.c"
    break;

  case 128: /* priority: NORMAL  */
#line 1139 "sieve/sieve.y"
                                 { (yyval.nval) = B_NORMAL; }
#line 3506 "sieve/sieve.c"
    break;

  case 129: /* priority: HIGH  */
#line 1140 "sieve/sieve.y"
                                 { (yyval.nval) = B_HIGH;   }
#line 3512 "sieve/sieve.c"
    break;

  case 130: /* sntags: %empty  */
#line 1145 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = new_command(B_SNOOZE, sscript);
                                     create = &((yyval.cl)->u.sn.f.create);
                                     specialuse = &((yyval.cl)->u.sn.f.t.specialuse);
                                     mailboxid = &((yyval.cl)->u.sn.f.t.mailboxid);
                                 }
#line 3523 "sieve/sieve.c"
    break;

  case 131: /* sntags: sntags MAILBOX string  */
#line 1151 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.sn.f.t.folder != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":mailbox");
                                         free((yyval.cl)->u.sn.f.t.folder);
                                     }

                                     (yyval.cl)->u.sn.f.t.folder = (yyvsp[0].sval);
                                 }
#line 3539 "sieve/sieve.c"
    break;

  case 135: /* sntags: sntags ADDFLAGS stringlist  */
#line 1167 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.sn.addflags != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":addflags");
                                         free((yyval.cl)->u.sn.addflags);
                                     }
                                     else if (!supported(SIEVE_CAPA_IMAP4FLAGS)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "imap4flags");
                                     }

                                     (yyval.cl)->u.sn.addflags = (yyvsp[0].sl);
                                 }
#line 3560 "sieve/sieve.c"
    break;

  case 136: /* sntags: sntags REMOVEFLAGS stringlist  */
#line 1184 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.sn.removeflags != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":removeflags");
                                         free((yyval.cl)->u.sn.removeflags);
                                     }
                                     else if (!supported(SIEVE_CAPA_IMAP4FLAGS)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "imap4flags");
                                     }

                                     (yyval.cl)->u.sn.removeflags = (yyvsp[0].sl);
                                 }
#line 3581 "sieve/sieve.c"
    break;

  case 137: /* sntags: sntags WEEKDAYS weekdaylist  */
#line 1201 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.sn.days != 0) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":weekdays");
                                     }

                                     (yyval.cl)->u.sn.days = (yyvsp[0].nval);
                                 }
#line 3596 "sieve/sieve.c"
    break;

  case 138: /* sntags: sntags TZID string  */
#line 1211 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.sn.tzid != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":tzid");
                                         free((yyval.cl)->u.sn.tzid);
                                     }

                                     (yyval.cl)->u.sn.tzid = (yyvsp[0].sval);
                                 }
#line 3612 "sieve/sieve.c"
    break;

  case 140: /* weekdaylist: '[' weekdays ']'  */
#line 1226 "sieve/sieve.y"
                                 { (yyval.nval) = (yyvsp[-1].nval); }
#line 3618 "sieve/sieve.c"
    break;

  case 142: /* weekdays: weekdays ',' weekday  */
#line 1231 "sieve/sieve.y"
                                 { (yyval.nval) = (yyvsp[-2].nval) | (yyvsp[0].nval); }
#line 3624 "sieve/sieve.c"
    break;

  case 143: /* weekday: STRING  */
#line 1235 "sieve/sieve.y"
                                 { (yyval.nval) = verify_weekday(sscript, (yyvsp[0].sval)); }
#line 3630 "sieve/sieve.c"
    break;

  case 145: /* timelist: '[' times ']'  */
#line 1240 "sieve/sieve.y"
                                 { (yyval.nl) = (yyvsp[-1].nl); }
#line 3636 "sieve/sieve.c"
    break;

  case 147: /* times: times ',' time  */
#line 1245 "sieve/sieve.y"
                                 { (yyval.nl) = (yyvsp[-2].nl); arrayu64_add((yyval.nl), (yyvsp[0].nval)); }
#line 3642 "sieve/sieve.c"
    break;

  case 148: /* time1: time  */
#line 1249 "sieve/sieve.y"
                                 {
                                     (yyval.nl) = arrayu64_new();
                                     arrayu64_add((yyval.nl), (yyvsp[0].nval));
                                 }
#line 3651 "sieve/sieve.c"
    break;

  case 149: /* time: STRING  */
#line 1256 "sieve/sieve.y"
                                 { (yyval.nval) = verify_time(sscript, (yyvsp[0].sval)); }
#line 3657 "sieve/sieve.c"
    break;

  case 150: /* caltags: %empty  */
#line 1261 "sieve/sieve.y"
                                 {
                                     /* legacy assigned by the calling rule */
                                     (yyval.cl) = new_command(B_PROCESSCAL, sscript);
                                     if (legacy) {
                                         (yyval.cl)->u.cal.allow_public = 1;
                                     }
                                 }
#line 3669 "sieve/sieve.c"
    break;

  case 151: /* caltags: caltags ALLOWPUBLIC  */
#line 1268 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.cal.allow_public) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":allowpublic");
                                     }

                                     (yyval.cl)->u.cal.allow_public = 1;
                                 }
#line 3684 "sieve/sieve.c"
    break;

  case 152: /* caltags: caltags INVITESONLY  */
#line 1278 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.cal.invites_only) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":invitesonly");
                                     }
                                     else if ((yyval.cl)->u.cal.updates_only) {
                                         sieveerror_c(sscript,
                                                      SIEVE_CONFLICTING_TAGS,
                                                      ":invitesonly",
                                                      ":updatesonly");
                                     }
                                     else if ((yyval.cl)->u.cal.delete_cancelled) {
                                         sieveerror_c(sscript,
                                                      SIEVE_CONFLICTING_TAGS,
                                                      ":invitesonly",
                                                      ":deletecancelled");
                                     }

                                     (yyval.cl)->u.cal.invites_only = 1;
                                 }
#line 3711 "sieve/sieve.c"
    break;

  case 153: /* caltags: caltags UPDATESONLY  */
#line 1300 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.cal.updates_only) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":updatesonly");
                                     }
                                     else if ((yyval.cl)->u.cal.invites_only) {
                                         sieveerror_c(sscript,
                                                      SIEVE_CONFLICTING_TAGS,
                                                      ":invitesonly",
                                                      ":updatesonly");
                                     }
                                     else if ((yyval.cl)->u.cal.calendarid != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_CONFLICTING_TAGS,
                                                      ":updatesonly",
                                                      ":calendarid");
                                     }

                                     (yyval.cl)->u.cal.updates_only = 1;
                                 }
#line 3738 "sieve/sieve.c"
    break;

  case 154: /* caltags: caltags DELETECANCELLED  */
#line 1324 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-1].cl);
                                     if ((yyval.cl)->u.cal.delete_cancelled) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":deletecancelled");
                                     }
                                     else if ((yyval.cl)->u.cal.invites_only) {
                                         sieveerror_c(sscript,
                                                      SIEVE_CONFLICTING_TAGS,
                                                      ":invitesonly",
                                                      ":deletecancelled");
                                     }

                                     (yyval.cl)->u.cal.delete_cancelled = 1;
                                 }
#line 3759 "sieve/sieve.c"
    break;

  case 155: /* caltags: caltags ADDRESSES stringlist  */
#line 1342 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.cal.addresses != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":addresses");
                                         strarray_free((yyval.cl)->u.cal.addresses);
                                     }

                                     (yyval.cl)->u.cal.addresses = (yyvsp[0].sl);
                                 }
#line 3775 "sieve/sieve.c"
    break;

  case 156: /* caltags: caltags ORGANIZERS string  */
#line 1354 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.cal.organizers != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":organizers");
                                         free((yyval.cl)->u.cal.organizers);
                                     }
                                     else if (!supported(SIEVE_CAPA_EXTLISTS)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "extlists");
                                     }

                                     (yyval.cl)->u.cal.organizers = (yyvsp[0].sval);
                                 }
#line 3796 "sieve/sieve.c"
    break;

  case 157: /* caltags: caltags CALENDARID string  */
#line 1372 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.cal.calendarid != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":calendarid");
                                         free((yyval.cl)->u.cal.calendarid);
                                     }
                                     else if ((yyval.cl)->u.cal.updates_only) {
                                         sieveerror_c(sscript,
                                                      SIEVE_CONFLICTING_TAGS,
                                                      ":updatesonly",
                                                      ":calendarid");
                                     }

                                     (yyval.cl)->u.cal.calendarid = (yyvsp[0].sval);
                                 }
#line 3818 "sieve/sieve.c"
    break;

  case 158: /* caltags: caltags OUTCOME string  */
#line 1389 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.cal.outcome_var != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":outcome");
                                         free((yyval.cl)->u.cal.outcome_var);
                                     }
                                     else if (!supported(SIEVE_CAPA_VARIABLES)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "variables");
                                     }

                                     (yyval.cl)->u.cal.outcome_var = (yyvsp[0].sval);
                                 }
#line 3839 "sieve/sieve.c"
    break;

  case 159: /* caltags: caltags REASON string  */
#line 1405 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = (yyvsp[-2].cl);
                                     if ((yyval.cl)->u.cal.reason_var != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":reason");
                                         free((yyval.cl)->u.cal.reason_var);
                                     }
                                     else if (!supported(SIEVE_CAPA_VARIABLES)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "variables");
                                     }

                                     (yyval.cl)->u.cal.reason_var = (yyvsp[0].sval);
                                 }
#line 3860 "sieve/sieve.c"
    break;

  case 160: /* ikttags: %empty  */
#line 1425 "sieve/sieve.y"
                                 {
                                     (yyval.cl) = new_command(B_IKEEP_TARGET, sscript);
                                     specialuse = &((yyval.cl)->u.ikt.specialuse);
                                     mailboxid = &((yyval.cl)->u.ikt.mailboxid);
                                 }
#line 3870 "sieve/sieve.c"
    break;

  case 163: /* testlist: '(' tests ')'  */
#line 1438 "sieve/sieve.y"
                                 { (yyval.testl) = (yyvsp[-1].testl); }
#line 3876 "sieve/sieve.c"
    break;

  case 164: /* tests: test  */
#line 1442 "sieve/sieve.y"
                                 { (yyval.testl) = new_testlist((yyvsp[0].test), NULL); }
#line 3882 "sieve/sieve.c"
    break;

  case 165: /* tests: test ',' tests  */
#line 1443 "sieve/sieve.y"
                                 { (yyval.testl) = new_testlist((yyvsp[-2].test), (yyvsp[0].testl)); }
#line 3888 "sieve/sieve.c"
    break;

  case 166: /* test: ANYOF testlist  */
#line 1447 "sieve/sieve.y"
                                 { (yyval.test) = build_anyof(sscript, (yyvsp[0].testl)); }
#line 3894 "sieve/sieve.c"
    break;

  case 167: /* test: ALLOF testlist  */
#line 1448 "sieve/sieve.y"
                                 { (yyval.test) = build_allof(sscript, (yyvsp[0].testl)); }
#line 3900 "sieve/sieve.c"
    break;

  case 168: /* test: NOT test  */
#line 1449 "sieve/sieve.y"
                                 { (yyval.test) = build_not(sscript, (yyvsp[0].test));   }
#line 3906 "sieve/sieve.c"
    break;

  case 169: /* test: SFALSE  */
#line 1450 "sieve/sieve.y"
                                 { (yyval.test) = new_test(BC_FALSE, sscript); }
#line 3912 "sieve/sieve.c"
    break;

  case 170: /* test: STRUE  */
#line 1451 "sieve/sieve.y"
                                 { (yyval.test) = new_test(BC_TRUE, sscript);  }
#line 3918 "sieve/sieve.c"
    break;

  case 171: /* test: EXISTS stringlist  */
#line 1452 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_EXISTS, sscript);
                                     (yyval.test)->u.sl = (yyvsp[0].sl);
                                     (yyval.test)->nargs = bc_precompile((yyval.test)->args, "S",
                                                               (yyval.test)->u.sl);
                                 }
#line 3929 "sieve/sieve.c"
    break;

  case 172: /* test: SIZE sizetag NUMBER  */
#line 1458 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_SIZE, sscript);
                                     (yyval.test)->u.sz.t = (yyvsp[-1].nval);
                                     (yyval.test)->u.sz.n = (yyvsp[0].nval);
                                     (yyval.test)->nargs = bc_precompile((yyval.test)->args, "ii",
                                                               (yyval.test)->u.sz.t,
                                                               (yyval.test)->u.sz.n);
                                 }
#line 3942 "sieve/sieve.c"
    break;

  case 173: /* test: HEADERT htags stringlist stringlist  */
#line 1468 "sieve/sieve.y"
                                 { (yyval.test) = build_header(sscript, (yyvsp[-2].test), (yyvsp[-1].sl), (yyvsp[0].sl)); }
#line 3948 "sieve/sieve.c"
    break;

  case 174: /* test: ADDRESS atags stringlist stringlist  */
#line 1471 "sieve/sieve.y"
                                 { (yyval.test) = build_address(sscript, (yyvsp[-2].test), (yyvsp[-1].sl), (yyvsp[0].sl)); }
#line 3954 "sieve/sieve.c"
    break;

  case 175: /* test: ENVELOPE etags stringlist stringlist  */
#line 1473 "sieve/sieve.y"
                                 { (yyval.test) = build_envelope(sscript, (yyvsp[-2].test), (yyvsp[-1].sl), (yyvsp[0].sl)); }
#line 3960 "sieve/sieve.c"
    break;

  case 176: /* test: BODY btags stringlist  */
#line 1475 "sieve/sieve.y"
                                 { (yyval.test) = build_body(sscript, (yyvsp[-1].test), (yyvsp[0].sl)); }
#line 3966 "sieve/sieve.c"
    break;

  case 177: /* test: ENVIRONMENT envtags string stringlist  */
#line 1478 "sieve/sieve.y"
                                 { (yyval.test) = build_mbox_meta(sscript,
                                                        (yyvsp[-2].test), NULL, (yyvsp[-1].sval), (yyvsp[0].sl)); }
#line 3973 "sieve/sieve.c"
    break;

  case 178: /* test: STRINGT strtags stringlist stringlist  */
#line 1482 "sieve/sieve.y"
                                 { (yyval.test) = build_stringt(sscript, (yyvsp[-2].test), (yyvsp[-1].sl), (yyvsp[0].sl)); }
#line 3979 "sieve/sieve.c"
    break;

  case 179: /* test: HASFLAG hftags stringlist stringlist  */
#line 1489 "sieve/sieve.y"
                                 { (yyval.test) = build_hasflag(sscript, (yyvsp[-2].test), (yyvsp[-1].sl), (yyvsp[0].sl)); }
#line 3985 "sieve/sieve.c"
    break;

  case 180: /* test: HASFLAG hftags stringlist  */
#line 1491 "sieve/sieve.y"
                                 { (yyval.test) = build_hasflag(sscript, (yyvsp[-1].test), NULL, (yyvsp[0].sl)); }
#line 3991 "sieve/sieve.c"
    break;

  case 181: /* test: DATE dttags string string stringlist  */
#line 1494 "sieve/sieve.y"
                                 { (yyval.test) = build_date(sscript, (yyvsp[-3].test), (yyvsp[-2].sval), (yyvsp[-1].sval), (yyvsp[0].sl)); }
#line 3997 "sieve/sieve.c"
    break;

  case 182: /* test: CURRENTDATE cdtags string stringlist  */
#line 1497 "sieve/sieve.y"
                                 { (yyval.test) = build_date(sscript, (yyvsp[-2].test), NULL, (yyvsp[-1].sval), (yyvsp[0].sl)); }
#line 4003 "sieve/sieve.c"
    break;

  case 183: /* test: VALIDNOTIFYMETHOD stringlist  */
#line 1500 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_VALIDNOTIFYMETHOD, sscript);
                                     (yyval.test)->u.sl = (yyvsp[0].sl);
                                     (yyval.test)->nargs = bc_precompile((yyval.test)->args, "S",
                                                               (yyval.test)->u.sl);
                                 }
#line 4014 "sieve/sieve.c"
    break;

  case 184: /* test: NOTIFYMETHODCAPABILITY methtags string string stringlist  */
#line 1507 "sieve/sieve.y"
                                 { (yyval.test) = build_mbox_meta(sscript,
                                                        (yyvsp[-3].test), (yyvsp[-2].sval), (yyvsp[-1].sval), (yyvsp[0].sl)); }
#line 4021 "sieve/sieve.c"
    break;

  case 185: /* test: IHAVE stringlist  */
#line 1510 "sieve/sieve.y"
                                 { (yyval.test) = build_ihave(sscript, (yyvsp[0].sl)); }
#line 4027 "sieve/sieve.c"
    break;

  case 186: /* test: MAILBOXEXISTS stringlist  */
#line 1513 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_MAILBOXEXISTS, sscript);
                                     (yyval.test) = build_mbox_meta(sscript,
                                                          (yyval.test), NULL, NULL, (yyvsp[0].sl));
                                 }
#line 4037 "sieve/sieve.c"
    break;

  case 187: /* $@3: %empty  */
#line 1519 "sieve/sieve.y"
                   { bctype = BC_METADATA; }
#line 4043 "sieve/sieve.c"
    break;

  case 188: /* test: METADATA $@3 mtags string string stringlist  */
#line 1520 "sieve/sieve.y"
                                 { (yyval.test) = build_mbox_meta(sscript,
                                                        (yyvsp[-3].test), (yyvsp[-2].sval), (yyvsp[-1].sval), (yyvsp[0].sl)); }
#line 4050 "sieve/sieve.c"
    break;

  case 189: /* test: METADATAEXISTS string stringlist  */
#line 1524 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_METADATAEXISTS, sscript);
                                     (yyval.test) = build_mbox_meta(sscript,
                                                          (yyval.test), (yyvsp[-1].sval), NULL, (yyvsp[0].sl));
                                 }
#line 4060 "sieve/sieve.c"
    break;

  case 190: /* $@4: %empty  */
#line 1530 "sieve/sieve.y"
                         { bctype = BC_SERVERMETADATA; }
#line 4066 "sieve/sieve.c"
    break;

  case 191: /* test: SERVERMETADATA $@4 mtags string stringlist  */
#line 1531 "sieve/sieve.y"
                                 { (yyval.test) = build_mbox_meta(sscript,
                                                        (yyvsp[-2].test), NULL, (yyvsp[-1].sval), (yyvsp[0].sl)); }
#line 4073 "sieve/sieve.c"
    break;

  case 192: /* test: SERVERMETADATAEXISTS stringlist  */
#line 1535 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_SERVERMETADATAEXISTS,
                                                   sscript);
                                     (yyval.test) = build_mbox_meta(sscript,
                                                          (yyval.test), NULL, NULL, (yyvsp[0].sl));
                                 }
#line 4084 "sieve/sieve.c"
    break;

  case 193: /* test: VALIDEXTLIST stringlist  */
#line 1543 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_VALIDEXTLIST, sscript);
                                     (yyval.test)->u.sl = (yyvsp[0].sl);
                                     (yyval.test)->nargs = bc_precompile((yyval.test)->args, "S",
                                                               (yyval.test)->u.sl);
                                 }
#line 4095 "sieve/sieve.c"
    break;

  case 194: /* test: DUPLICATE duptags  */
#line 1549 "sieve/sieve.y"
                                 { (yyval.test) = build_duplicate(sscript, (yyvsp[0].test)); }
#line 4101 "sieve/sieve.c"
    break;

  case 195: /* test: SPECIALUSEEXISTS stringlist  */
#line 1552 "sieve/sieve.y"
                                 { 
                                     (yyval.test) = new_test(BC_SPECIALUSEEXISTS, sscript);
                                     (yyval.test) = build_mbox_meta(sscript,
                                                          (yyval.test), NULL, NULL, (yyvsp[0].sl));
                                 }
#line 4111 "sieve/sieve.c"
    break;

  case 196: /* test: SPECIALUSEEXISTS string stringlist  */
#line 1559 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_SPECIALUSEEXISTS, sscript);
                                     (yyval.test) = build_mbox_meta(sscript,
                                                          (yyval.test), (yyvsp[-1].sval), NULL, (yyvsp[0].sl));
                                 }
#line 4121 "sieve/sieve.c"
    break;

  case 197: /* test: MAILBOXIDEXISTS stringlist  */
#line 1566 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_MAILBOXIDEXISTS, sscript);
                                     (yyval.test) = build_mbox_meta(sscript,
                                                          (yyval.test), NULL, NULL, (yyvsp[0].sl));
                                 }
#line 4131 "sieve/sieve.c"
    break;

  case 198: /* test: JMAPQUERY string  */
#line 1572 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_JMAPQUERY, sscript);
                                     (yyval.test) = build_jmapquery(sscript, (yyval.test), (yyvsp[0].sval));
                                 }
#line 4140 "sieve/sieve.c"
    break;

  case 199: /* test: error  */
#line 1577 "sieve/sieve.y"
                                 { (yyval.test) = new_test(BC_FALSE, sscript); }
#line 4146 "sieve/sieve.c"
    break;

  case 200: /* sizetag: OVER  */
#line 1582 "sieve/sieve.y"
                                 { (yyval.nval) = B_OVER;  }
#line 4152 "sieve/sieve.c"
    break;

  case 201: /* sizetag: UNDER  */
#line 1583 "sieve/sieve.y"
                                 { (yyval.nval) = B_UNDER; }
#line 4158 "sieve/sieve.c"
    break;

  case 202: /* htags: %empty  */
#line 1588 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_HEADER, sscript);
                                     ctags = &((yyval.test)->u.hhs.comp);
                                 }
#line 4167 "sieve/sieve.c"
    break;

  case 207: /* matchtype: matchtag  */
#line 1600 "sieve/sieve.y"
                                 {
                                     /* *ctags assigned by the calling rule */
                                     if (ctags->match != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "match-type");
                                     }

                                     ctags->match = (yyvsp[0].nval);
                                 }
#line 4182 "sieve/sieve.c"
    break;

  case 208: /* matchtype: relmatch relation  */
#line 1611 "sieve/sieve.y"
                                 {
                                     if (ctags->match != B_COUNT &&
                                         ctags->match != B_VALUE &&
                                         !supported(SIEVE_CAPA_RELATIONAL)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "relational");
                                     }
                                     if (ctags->match != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "match-type");
                                     }

                                     ctags->match = (yyvsp[-1].nval);
                                     ctags->relation = (yyvsp[0].nval);
                                 }
#line 4204 "sieve/sieve.c"
    break;

  case 209: /* matchtag: IS  */
#line 1632 "sieve/sieve.y"
                                 { (yyval.nval) = B_IS;       }
#line 4210 "sieve/sieve.c"
    break;

  case 210: /* matchtag: CONTAINS  */
#line 1633 "sieve/sieve.y"
                                 { (yyval.nval) = B_CONTAINS; }
#line 4216 "sieve/sieve.c"
    break;

  case 211: /* matchtag: MATCHES  */
#line 1634 "sieve/sieve.y"
                                 { (yyval.nval) = B_MATCHES;  }
#line 4222 "sieve/sieve.c"
    break;

  case 212: /* matchtag: REGEX  */
#line 1635 "sieve/sieve.y"
                                 {
                                     if (!supported(SIEVE_CAPA_REGEX)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "regex");
                                     }

                                     (yyval.nval) = B_REGEX;
                                 }
#line 4236 "sieve/sieve.c"
    break;

  case 213: /* relmatch: COUNT  */
#line 1648 "sieve/sieve.y"
                                 { (yyval.nval) = B_COUNT; }
#line 4242 "sieve/sieve.c"
    break;

  case 214: /* relmatch: VALUE  */
#line 1649 "sieve/sieve.y"
                                 { (yyval.nval) = B_VALUE; }
#line 4248 "sieve/sieve.c"
    break;

  case 215: /* relation: EQ  */
#line 1654 "sieve/sieve.y"
                                 { (yyval.nval) = B_EQ; }
#line 4254 "sieve/sieve.c"
    break;

  case 216: /* relation: NE  */
#line 1655 "sieve/sieve.y"
                                 { (yyval.nval) = B_NE; }
#line 4260 "sieve/sieve.c"
    break;

  case 217: /* relation: GT  */
#line 1656 "sieve/sieve.y"
                                 { (yyval.nval) = B_GT; }
#line 4266 "sieve/sieve.c"
    break;

  case 218: /* relation: GE  */
#line 1657 "sieve/sieve.y"
                                 { (yyval.nval) = B_GE; }
#line 4272 "sieve/sieve.c"
    break;

  case 219: /* relation: LT  */
#line 1658 "sieve/sieve.y"
                                 { (yyval.nval) = B_LT; }
#line 4278 "sieve/sieve.c"
    break;

  case 220: /* relation: LE  */
#line 1659 "sieve/sieve.y"
                                 { (yyval.nval) = B_LE; }
#line 4284 "sieve/sieve.c"
    break;

  case 221: /* listmatch: LIST  */
#line 1664 "sieve/sieve.y"
                                 {
                                     /* *ctags assigned by the calling rule */
                                     if (ctags->match != B_LIST &&
                                         !supported(SIEVE_CAPA_EXTLISTS)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "extlists");
                                     }
                                     if (ctags->match != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "match-type");
                                     }

                                     ctags->match = B_LIST;
                                 }
#line 4305 "sieve/sieve.c"
    break;

  case 222: /* comparator: COMPARATOR collation  */
#line 1685 "sieve/sieve.y"
                                 {
                                     /* *ctags assigned by the calling rule */
                                     if (ctags->collation != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":comparator");
                                     }

                                     ctags->collation = (yyvsp[0].nval);
                                 }
#line 4320 "sieve/sieve.c"
    break;

  case 223: /* collation: OCTET  */
#line 1699 "sieve/sieve.y"
                                 { (yyval.nval) = B_OCTET;        }
#line 4326 "sieve/sieve.c"
    break;

  case 224: /* collation: ASCIICASEMAP  */
#line 1700 "sieve/sieve.y"
                                 { (yyval.nval) = B_ASCIICASEMAP; }
#line 4332 "sieve/sieve.c"
    break;

  case 225: /* collation: ASCIINUMERIC  */
#line 1701 "sieve/sieve.y"
                                 {
                                     if (!supported(SIEVE_CAPA_COMP_NUMERIC)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "comparator-"
                                                      "i;ascii-numeric");
                                     }

                                     (yyval.nval) = B_ASCIINUMERIC;
                                 }
#line 4347 "sieve/sieve.c"
    break;

  case 226: /* collation: UNICODECASEMAP  */
#line 1711 "sieve/sieve.y"
                                 {
                                     if (!supported(SIEVE_CAPA_COMP_UCASEMAP)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "comparator-"
                                                      "i;unicode-casemap");
                                     }

                                     (yyval.nval) = B_UNICODECASEMAP;
                                 }
#line 4362 "sieve/sieve.c"
    break;

  case 227: /* indexext: index  */
#line 1725 "sieve/sieve.y"
                                 {
                                     /* *ctags assigned by the calling rule */
                                     if (ctags->index != 0 &&
                                         !supported(SIEVE_CAPA_INDEX)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "index");
                                     }
                                 }
#line 4376 "sieve/sieve.c"
    break;

  case 228: /* index: INDEX NUMBER  */
#line 1736 "sieve/sieve.y"
                                 {
                                     /* *ctags assigned by the calling rule */
                                     if (ctags->index == INT_MIN) {
                                         /* parsed :last before :index */
                                         ctags->index = -(yyvsp[0].nval);
                                     }
                                     else if (ctags->index != 0) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":index");
                                     }
                                     else {
                                         ctags->index = (yyvsp[0].nval);
                                     }
                                 }
#line 4396 "sieve/sieve.c"
    break;

  case 229: /* index: LAST  */
#line 1751 "sieve/sieve.y"
                                 {
                                     if (ctags->index > 0) {
                                         ctags->index *= -1;
                                     }
                                     else if (ctags->index < 0) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":last");
                                     }
                                     else {
                                         /* special value to indicate that
                                            we parsed :last before :index */
                                         ctags->index = INT_MIN;
                                     }
                                 }
#line 4416 "sieve/sieve.c"
    break;

  case 230: /* atags: %empty  */
#line 1770 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_ADDRESS, sscript);
                                     ctags = &((yyval.test)->u.ae.comp);
                                 }
#line 4425 "sieve/sieve.c"
    break;

  case 236: /* addrpart: addrparttag  */
#line 1783 "sieve/sieve.y"
                                {
                                     /* $0 refers to a test_t* (ADDR/ENV)*/
                                     test_t *test = (yyvsp[-1].test);

                                     if (test->u.ae.addrpart != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "address-part");
                                     }

                                     test->u.ae.addrpart = (yyvsp[0].nval);
                                 }
#line 4442 "sieve/sieve.c"
    break;

  case 237: /* addrparttag: ALL  */
#line 1798 "sieve/sieve.y"
                                 { (yyval.nval) = B_ALL;       }
#line 4448 "sieve/sieve.c"
    break;

  case 238: /* addrparttag: LOCALPART  */
#line 1799 "sieve/sieve.y"
                                 { (yyval.nval) = B_LOCALPART; }
#line 4454 "sieve/sieve.c"
    break;

  case 239: /* addrparttag: DOMAIN  */
#line 1800 "sieve/sieve.y"
                                 { (yyval.nval) = B_DOMAIN;    }
#line 4460 "sieve/sieve.c"
    break;

  case 240: /* addrparttag: subaddress  */
#line 1801 "sieve/sieve.y"
                                 {
                                     if (!supported(SIEVE_CAPA_SUBADDRESS)) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MISSING_REQUIRE,
                                                      "subaddress");
                                     }
                                 }
#line 4472 "sieve/sieve.c"
    break;

  case 241: /* subaddress: USER  */
#line 1812 "sieve/sieve.y"
                                 { (yyval.nval) = B_USER;   }
#line 4478 "sieve/sieve.c"
    break;

  case 242: /* subaddress: DETAIL  */
#line 1813 "sieve/sieve.y"
                                 { (yyval.nval) = B_DETAIL; }
#line 4484 "sieve/sieve.c"
    break;

  case 243: /* etags: %empty  */
#line 1818 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_ENVELOPE, sscript);
                                     ctags = &((yyval.test)->u.ae.comp);
                                 }
#line 4493 "sieve/sieve.c"
    break;

  case 248: /* envtags: %empty  */
#line 1830 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_ENVIRONMENT, sscript);
                                     ctags = &((yyval.test)->u.mm.comp);
                                 }
#line 4502 "sieve/sieve.c"
    break;

  case 251: /* btags: %empty  */
#line 1840 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_BODY, sscript);
                                     ctags = &((yyval.test)->u.b.comp);
                                 }
#line 4511 "sieve/sieve.c"
    break;

  case 252: /* btags: btags transform  */
#line 1844 "sieve/sieve.y"
                                 {
                                     if ((yyval.test)->u.b.transform != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "transform");
                                     }

                                     (yyval.test)->u.b.transform = (yyvsp[0].nval);
                                 }
#line 4525 "sieve/sieve.c"
    break;

  case 253: /* btags: btags CONTENT stringlist  */
#line 1855 "sieve/sieve.y"
                                 {
                                     if ((yyval.test)->u.b.transform != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_MULTIPLE_TAGS,
                                                      "transform");
                                         strarray_free((yyval.test)->u.b.content_types);
                                     }

                                     (yyval.test)->u.b.transform = B_CONTENT;
                                     (yyval.test)->u.b.content_types = (yyvsp[0].sl);
                                 }
#line 4541 "sieve/sieve.c"
    break;

  case 256: /* transform: RAW  */
#line 1873 "sieve/sieve.y"
                                 { (yyval.nval) = B_RAW;  }
#line 4547 "sieve/sieve.c"
    break;

  case 257: /* transform: TEXT  */
#line 1874 "sieve/sieve.y"
                                 { (yyval.nval) = B_TEXT; }
#line 4553 "sieve/sieve.c"
    break;

  case 258: /* strtags: %empty  */
#line 1879 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_STRING, sscript);
                                     ctags = &((yyval.test)->u.hhs.comp);
                                 }
#line 4562 "sieve/sieve.c"
    break;

  case 262: /* hftags: %empty  */
#line 1890 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_HASFLAG, sscript);
                                     ctags = &((yyval.test)->u.hhs.comp);
                                 }
#line 4571 "sieve/sieve.c"
    break;

  case 265: /* dttags: %empty  */
#line 1900 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_DATE, sscript);
                                     ctags = &((yyval.test)->u.dt.comp);
                                 }
#line 4580 "sieve/sieve.c"
    break;

  case 267: /* dttags: dttags ORIGINALZONE  */
#line 1905 "sieve/sieve.y"
                                 {
                                     if ((yyval.test)->u.dt.zone.tag != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":originalzone");
                                     }

                                     (yyval.test)->u.dt.zone.tag = B_ORIGINALZONE;
                                 }
#line 4594 "sieve/sieve.c"
    break;

  case 271: /* zone: ZONE string  */
#line 1921 "sieve/sieve.y"
                                 {
                                     /* $0 refers to a test_t* ([CURRENT]DATE)*/
                                     test_t *test = (yyvsp[-2].test);

                                     if (test->u.dt.zone.tag != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":zone");
                                     }

                                     test->u.dt.zone.tag = B_TIMEZONE;
                                     test->u.dt.zone.offset = (yyvsp[0].sval);
                                 }
#line 4612 "sieve/sieve.c"
    break;

  case 272: /* cdtags: %empty  */
#line 1938 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_CURRENTDATE, sscript);
                                     ctags = &((yyval.test)->u.dt.comp);
                                 }
#line 4621 "sieve/sieve.c"
    break;

  case 276: /* methtags: %empty  */
#line 1949 "sieve/sieve.y"
                                 {
                                     (yyval.test) = new_test(BC_NOTIFYMETHODCAPABILITY,
                                                   sscript);
                                     ctags = &((yyval.test)->u.mm.comp);
                                 }
#line 4631 "sieve/sieve.c"
    break;

  case 279: /* mtags: %empty  */
#line 1960 "sieve/sieve.y"
                                 {
                                     /* bctype assigned by the calling rule */
                                     (yyval.test) = new_test(bctype, sscript);
                                     ctags = &((yyval.test)->u.mm.comp);
                                 }
#line 4641 "sieve/sieve.c"
    break;

  case 282: /* duptags: %empty  */
#line 1971 "sieve/sieve.y"
                                 { (yyval.test) = new_test(BC_DUPLICATE, sscript); }
#line 4647 "sieve/sieve.c"
    break;

  case 283: /* duptags: duptags idtype string  */
#line 1972 "sieve/sieve.y"
                                 {
                                     if ((yyval.test)->u.dup.idtype != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_CONFLICTING_TAGS,
                                                      ":header", ":uniqueid");
                                         free((yyval.test)->u.dup.idval);
                                     }

                                     (yyval.test)->u.dup.idtype = (yyvsp[-1].nval);
                                     (yyval.test)->u.dup.idval = (yyvsp[0].sval);
                                 }
#line 4663 "sieve/sieve.c"
    break;

  case 284: /* duptags: duptags HANDLE string  */
#line 1983 "sieve/sieve.y"
                                 {
                                     if ((yyval.test)->u.dup.handle != NULL) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":handle");
                                         free((yyval.test)->u.dup.handle);
                                     }

                                     (yyval.test)->u.dup.handle = (yyvsp[0].sval);
                                 }
#line 4678 "sieve/sieve.c"
    break;

  case 285: /* duptags: duptags SECONDS NUMBER  */
#line 1993 "sieve/sieve.y"
                                 {
                                     if ((yyval.test)->u.dup.seconds != -1) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":seconds");
                                     }

                                     (yyval.test)->u.dup.seconds = (yyvsp[0].nval);
                                 }
#line 4692 "sieve/sieve.c"
    break;

  case 286: /* duptags: duptags LAST  */
#line 2002 "sieve/sieve.y"
                                 {
                                     if ((yyval.test)->u.dup.last != 0) {
                                         sieveerror_c(sscript,
                                                      SIEVE_DUPLICATE_TAG,
                                                      ":last");
                                     }

                                     (yyval.test)->u.dup.last = 1;
                                 }
#line 4706 "sieve/sieve.c"
    break;

  case 287: /* idtype: HEADER  */
#line 2015 "sieve/sieve.y"
                                 { (yyval.nval) = B_HEADER;   }
#line 4712 "sieve/sieve.c"
    break;

  case 288: /* idtype: UNIQUEID  */
#line 2016 "sieve/sieve.y"
                                 { (yyval.nval) = B_UNIQUEID; }
#line 4718 "sieve/sieve.c"
    break;


#line 4722 "sieve/sieve.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (sscript, YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, sscript);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, sscript);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (sscript, YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, sscript);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, sscript);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 2020 "sieve/sieve.y"



/*
 * Yacc actions
 */

void yyerror(sieve_script_t *sscript, const char *msg)
{
    if (sscript->ignore_err) return;

    sscript->err++;
    if (sscript->interp.err) {
        sscript->interp.err(sievelineno, msg, sscript->interp.interp_context,
                            sscript->script_context);
    }
}


static void
__attribute__((format(printf, 2, 0)))
vsieveerror_f(sieve_script_t *sscript,
              const char *fmt, va_list args)
{
    buf_reset(&sscript->sieveerr);
    buf_vprintf(&sscript->sieveerr, fmt, args);
    yyerror(sscript, buf_cstring(&sscript->sieveerr));
}

void
__attribute__((format(printf, 2, 3)))
sieveerror_f(sieve_script_t *sscript, const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    vsieveerror_f(sscript, fmt, args);
    va_end(args);
}

void sieveerror_c(sieve_script_t *sscript, int code, ...)
{
    va_list args;

    va_start(args, code);
    vsieveerror_f(sscript, error_message(code), args);
    va_end(args);
}

/*
 * variable-ref        =  "${" [namespace] variable-name "}"
 * namespace           =  identifier "." *sub-namespace
 * sub-namespace       =  variable-name "."
 * variable-name       =  num-variable / identifier
 * num-variable        =  1*DIGIT
 * identifier          =  (ALPHA / "_") *(ALPHA / DIGIT / "_")
 */
static int find_variables(sieve_script_t *sscript, char *s, int find_one)
{
    char *p = s;

    if (!supported(SIEVE_CAPA_VARIABLES)) return !find_one;

    while ((p = strstr(p, "${"))) {
        long num = 0, is_id = 0;

        p += 2;  /* skip over beginning of variable-ref */

        do {
            if (isdigit(*p)) {
                /* possible num-variable - get value and skip over digits */
                num = strtol(p, &p, 10);
            }
            else if (!find_one) {
                /* validating match variables - ignoroe identifiers */
                break;
            }
            else if (isalpha(*p) || *p == '_') {
                /* possible identifier - skip over identifier chars */
                for (++p; isalnum(*p) || *p == '_'; p++);
                is_id = 1;
            }
            else {
                /* not a valid variable-name */
                break;
            }

            if (*p == '}') {
                /* end of variable-ref */
                if (find_one) return 1;

                /* validating match variables */
                if (!is_id && num > MAX_MATCH_VARS) {
                    sieveerror_f(sscript, "string '%s':"
                                 " match variable index > %u unsupported",
                                 s, MAX_MATCH_VARS);
                    return 0;
                }
            }

        } while (is_id && *p == '.' && *(++p));  /* (sub-)namespace */
    }

    return !find_one;
}

static int chk_match_vars(sieve_script_t *sscript, char *s)
{
    return find_variables(sscript, s, 0 /* find_one */);
}

static int contains_variable(sieve_script_t *sscript, char *s)
{
    return find_variables(sscript, s, 1 /* find_one */);
}

/*
 * Valid UTF-8 check (from RFC 2640 Annex B.1)
 *
 * The following routine checks if a byte sequence is valid UTF-8. This
 * is done by checking for the proper tagging of the first and following
 * bytes to make sure they conform to the UTF-8 format. It then checks
 * to assure that the data part of the UTF-8 sequence conforms to the
 * proper range allowed by the encoding. Note: This routine will not
 * detect characters that have not been assigned and therefore do not
 * exist.
 */
static int verify_utf8(sieve_script_t *sscript, char *s)
{
    const char *buf = s;
    const char *endbuf = s + strlen(s);
    unsigned char byte2mask = 0x00, c;
    int trailing = 0;  /* trailing (continuation) bytes to follow */

    while (buf != endbuf) {
        c = *buf++;
        if (trailing) {
            if ((c & 0xC0) == 0x80) {           /* Does trailing byte
                                                   follow UTF-8 format? */
                if (byte2mask) {                /* Need to check 2nd byte
                                                   for proper range? */
                    if (c & byte2mask)          /* Are appropriate bits set? */
                        byte2mask = 0x00;
                    else
                        break;
                }
                trailing--;
            }
            else
                break;
        }
        else {
            if ((c & 0x80) == 0x00)             /* valid 1 byte UTF-8 */
                continue;
            else if ((c & 0xE0) == 0xC0)        /* valid 2 byte UTF-8 */
                if (c & 0x1E) {                 /* Is UTF-8 byte
                                                   in proper range? */
                    trailing = 1;
                }
                else
                    break;
            else if ((c & 0xF0) == 0xE0) {      /* valid 3 byte UTF-8 */
                if (!(c & 0x0F)) {              /* Is UTF-8 byte
                                                   in proper range? */
                    byte2mask = 0x20;           /* If not, set mask
                                                   to check next byte */
                }
                trailing = 2;
            }
            else if ((c & 0xF8) == 0xF0) {      /* valid 4 byte UTF-8 */
                if (!(c & 0x07)) {              /* Is UTF-8 byte
                                                   in proper range? */
                    byte2mask = 0x30;           /* If not, set mask
                                                   to check next byte */
                }
                trailing = 3;
            }
            else if ((c & 0xFC) == 0xF8) {      /* valid 5 byte UTF-8 */
                if (!(c & 0x03)) {              /* Is UTF-8 byte
                                                   in proper range? */
                    byte2mask = 0x38;           /* If not, set mask
                                                   to check next byte */
                }
                trailing = 4;
            }
            else if ((c & 0xFE) == 0xFC) {      /* valid 6 byte UTF-8 */
                if (!(c & 0x01)) {              /* Is UTF-8 byte
                                                   in proper range? */
                    byte2mask = 0x3C;           /* If not, set mask
                                                   to check next byte */
                }
                trailing = 5;
            }
            else
                break;
        }
    }

    if ((buf != endbuf) || trailing) {
        sieveerror_f(sscript, "string '%s': not valid utf8", s);
        return 0;
    }

    return 1;
}

static int verify_stringlist(sieve_script_t *sscript, strarray_t *sa,
                             int (*verify)(sieve_script_t*, char *))
{
    int i;

    for (i = 0 ; i < strarray_size(sa) ; i++) {
        if (!verify(sscript, (char *) strarray_nth(sa, i))) return 0;
    }
    return 1;
}

#ifdef ENABLE_REGEX
static int verify_regexlist(sieve_script_t *sscript,
                            const strarray_t *sa, int collation)
{
    int i, ret = 0;
    int cflags = REG_EXTENDED | REG_NOSUB;

    /* support UTF8 comparisons */
#if defined HAVE_PCREPOSIX_H
    cflags |= REG_UTF8;
#elif defined HAVE_PCRE2POSIX_H
    cflags |= REG_UTF;
#endif

    if (collation == B_ASCIICASEMAP) {
        cflags |= REG_ICASE;
    }

    for (i = 0 ; !ret && i < strarray_size(sa) ; i++) {
        const char *s = strarray_nth(sa, i);
        regex_t reg = {0};

        /* Don't try to validate a regex that includes variables */
        if (supported(SIEVE_CAPA_VARIABLES) && strstr(s, "${")) continue;

        /* Check if the regex will compile */
        if ((ret = regcomp(&reg, s, cflags)) != 0) {
            size_t errbuf_size = regerror(ret, &reg, NULL, 0);

            buf_reset(&sscript->sieveerr);
            buf_ensure(&sscript->sieveerr, errbuf_size);
            (void) regerror(ret, &reg,
                            (char *) buf_base(&sscript->sieveerr),
                            errbuf_size);
            buf_truncate(&sscript->sieveerr, errbuf_size);
            yyerror(sscript, buf_cstring(&sscript->sieveerr));
        }

        regfree(&reg);
    }

    return (ret == 0);
}
#else

static int verify_regexlist(sieve_script_t *sscript __attribute__((unused)),
                            const strarray_t *sa __attribute__((unused)),
                            char *comp __attribute__((unused)))
{
    return 0;
}
#endif /* ENABLE_REGEX */

static int verify_patternlist(sieve_script_t *sscript,
                              strarray_t *sa, comp_t *c,
                              int (*verify)(sieve_script_t*, char *))
{
    if (verify && !verify_stringlist(sscript, sa, verify)) return 0;

    canon_comptags(c, sscript);

    return (c->match == B_REGEX) ?
        verify_regexlist(sscript, sa, c->collation) : 1;
}

static int verify_address(sieve_script_t *sscript, char *s)
{
    if (contains_variable(sscript, s)) return 1;

    YY_BUFFER_STATE buffer = addr_scan_string(s);
    int r = 1;

    sscript->addrerr[0] = '\0';    /* paranoia */
    if (addrparse(sscript)) {
        sieveerror_f(sscript, "address '%s': %s", s, sscript->addrerr);
        r = 0;
    }
    addr_delete_buffer(buffer);

    return r;
}

static int verify_mailbox(sieve_script_t *sscript, char *s)
{
    if (!verify_utf8(sscript, s)) {
        sieveerror_f(sscript, "mailbox '%s': not a valid mailbox", s);
        return 0;
    }

    return 1;
}

static int verify_header(sieve_script_t *sscript, char *hdr)
{
    char *h = hdr;

    while (*h) {
        /* field-name      =       1*ftext
           ftext           =       %d33-57 / %d59-126
           ; Any character except
           ;  controls, SP, and
           ;  ":". */
        if (!((*h >= 33 && *h <= 57) || (*h >= 59 && *h <= 126))) {
            sieveerror_f(sscript, "header '%s': not a valid header", hdr);
            return 0;
        }
        h++;
    }
    return 1;
}

static int verify_addrheader(sieve_script_t *sscript, char *hdr)
{
    const char **h, *hdrs[] = {
        "from", "sender", "reply-to",   /* RFC 5322 originator fields */
        "to", "cc", "bcc",              /* RFC 5322 destination fields */
        "message-id", "in-reply-to",    /* RFC 5322 identification fields */
        "references",
        "resent-from", "resent-sender", /* RFC 5322 resent fields */
        "resent-to", "resent-cc", "resent-bcc",
        "return-path",                  /* RFC 5322 trace fields */
        "disposition-notification-to",  /* RFC 8098 MDN request fields */
        "approved",                     /* RFC 5536 moderator/control fields */
        "delivered-to",                 /* non-standard (loop detection) */
        NULL
    };

    if (contains_variable(sscript, hdr)) return 1;

    if (!config_getswitch(IMAPOPT_RFC3028_STRICT))
        return verify_header(sscript, hdr);

    for (lcase(hdr), h = hdrs; *h; h++) {
        if (!strcmp(*h, hdr)) return 1;
    }

    sieveerror_f(sscript,
                 "header '%s': not a valid header for an address test", hdr);
    return 0;
}

static int verify_envelope(sieve_script_t *sscript, char *env)
{
    if (contains_variable(sscript, env)) return 1;

    lcase(env);
    if (!config_getswitch(IMAPOPT_RFC3028_STRICT) ||
        !strcmp(env, "from") || !strcmp(env, "to") || !strcmp(env, "auth")) {
        return 1;
    }

    sieveerror_f(sscript,
                 "env-part '%s': not a valid part for an envelope test", env);
    return 0;
}

static int verify_list(sieve_script_t *sscript, char *s)
{
    if (sscript->interp.isvalidlist &&
        sscript->interp.isvalidlist(sscript->interp.interp_context, s)
        != SIEVE_OK) {
        sieveerror_f(sscript, "list '%s': is not valid/supported", s);
        return 0;
    }

    return 1;
}

static int check_reqs(sieve_script_t *sscript, strarray_t *sa)
{
    char *s;
    struct buf *errs = &sscript->sieveerr;
    int ret = 1, sep = ':';

    buf_setcstr(errs, "Unsupported feature(s) in \"require\"");
    while ((s = strarray_shift(sa))) {
        if (!script_require(sscript, s)) {
            buf_printf(errs, "%c \"%s\"", sep, s);
            ret = 0;
            sep = ',';
        }
        free(s);
    }
    strarray_free(sa);

    if (ret == 0) yyerror(sscript, buf_cstring(&sscript->sieveerr));
    else if (supported(SIEVE_CAPA_IHAVE)) {
        /* mark all allowed extensions as supported */
        sscript->support |= (SIEVE_CAPA_ALL & ~SIEVE_CAPA_IHAVE_INCOMPAT);
    }

    encoded_char = supported(SIEVE_CAPA_ENCODED_CHAR);

    return ret;
}

/* take a format string and a variable list of arguments
   and populate the command arguments array */
static unsigned bc_precompile(cmdarg_t args[], const char *fmt, ...)
{
    va_list ap;
    unsigned n = 0;

    va_start(ap, fmt);
    for (n = 0; *fmt; fmt++, n++) {
        args[n].type = *fmt;

        switch (*fmt) {
        case 'i':
            args[n].u.i = va_arg(ap, int);
            break;
        case 's':
            args[n].u.s = va_arg(ap, const char *);
            break;
        case 'S':
            args[n].u.sa = va_arg(ap, const strarray_t *);
            break;
        case 'U':
            args[n].u.ua = va_arg(ap, const arrayu64_t *);
            break;
        case 't':
            args[n].u.t = va_arg(ap, const test_t *);
            break;
        case 'T':
            args[n].u.tl = va_arg(ap, const testlist_t *);
            break;
        case 'C': {
            /* Expand the comparator into its component parts */
            const comp_t *c = va_arg(ap, const comp_t *);

            args[n].type = AT_INT;
            args[n].u.i = c->match;
            args[++n].type = AT_INT;
            args[n].u.i = c->relation;
            args[++n].type = AT_INT;
            args[n].u.i = c->collation;
            break;
        }
        case 'Z': {
            /* Expand the zone into its component parts */
            const zone_t *z = va_arg(ap, const zone_t *);

            args[n].type = AT_INT;
            args[n].u.i = z->tag;

            if (z->tag == B_TIMEZONE) {
                args[++n].type = AT_STR;
                args[n].u.s = z->offset;
            }
            break;
        }
        default: assert(*fmt);
        }
    }
    va_end(ap);

    return n;
}

static commandlist_t *build_keep(sieve_script_t *sscript, commandlist_t *c)
{
    assert(c && c->type == B_KEEP);

    if (c->u.k.flags && !_verify_flaglist(c->u.k.flags)) {
        strarray_add(c->u.k.flags, "");
    }

    c->nargs = bc_precompile(c->args, "S", c->u.k.flags);

    return c;
}

static commandlist_t *build_fileinto(sieve_script_t *sscript,
                                     commandlist_t *c, char *folder)
{
    assert(c && c->type == B_FILEINTO);

    if (c->u.f.flags && !_verify_flaglist(c->u.f.flags)) {
        strarray_add(c->u.f.flags, "");
    }
    verify_mailbox(sscript, folder);
    c->u.f.t.folder = folder;

    c->nargs = bc_precompile(c->args, "ssiSis",
                             c->u.f.t.mailboxid,
                             c->u.f.t.specialuse,
                             c->u.f.create,
                             c->u.f.flags,
                             c->u.f.copy,
                             c->u.f.t.folder);

    return c;
}

static commandlist_t *build_redirect(sieve_script_t *sscript,
                                     commandlist_t *c, char *address)
{
    assert(c && c->type == B_REDIRECT);

    if (c->u.r.list) verify_list(sscript, address);
    else verify_address(sscript, address);

    /* Verify DELIVERBY values */
    if (c->u.r.bytime) {
        if (!supported(SIEVE_CAPA_VARIABLES)) {
            time_t t;

            if (c->u.r.bytime[0] != '+' &&
                time_from_iso8601(c->u.r.bytime, &t) == -1) {
                sieveerror_f(sscript,
                             "string '%s': not a valid DELIVERBY time value",
                             c->u.r.bytime);
            }
            if (c->u.r.bymode &&
                strcasecmp(c->u.r.bymode, "NOTIFY") &&
                strcasecmp(c->u.r.bymode, "RETURN")) {
                sieveerror_f(sscript,
                             "string '%s': not a valid DELIVERBY mode value",
                             c->u.r.bymode);
            }
        }
    }
    else if (c->u.r.bymode || c->u.r.bytrace) {
        sieveerror_c(sscript, SIEVE_MISSING_TAG,
                     ":bytimerelative OR :bytimeabsolute");
    }

    /* Verify DSN NOTIFY value(s) */
    if (c->u.r.dsn_notify && !supported(SIEVE_CAPA_VARIABLES)) {
        tok_t tok =
            TOK_INITIALIZER(c->u.r.dsn_notify, ",", TOK_TRIMLEFT|TOK_TRIMRIGHT);
        char *token;
        int never = 0;

        while ((token = tok_next(&tok))) {
            if (!strcasecmp(token, "NEVER")) never = 1;
            else if (never) {
                sieveerror_f(sscript,
                             "DSN NOTIFY value 'NEVER' MUST be used by itself");
                break;
            }
            else if (strcasecmp(token, "SUCCESS") &&
                     strcasecmp(token, "FAILURE") &&
                     strcasecmp(token, "DELAY")) {
                sieveerror_f(sscript,
                             "string '%s': not a valid DSN NOTIFY value",
                             token);
                break;
            }
        }
        tok_fini(&tok);
    }

    /* Verify DSN RET value */
    if (c->u.r.dsn_ret && !supported(SIEVE_CAPA_VARIABLES) &&
        strcasecmp(c->u.r.dsn_ret, "FULL") &&
        strcasecmp(c->u.r.dsn_ret, "HDRS")) {
        sieveerror_f(sscript, "string '%s': not a valid DSN RET value",
                     c->u.r.dsn_ret);
    }

    c->u.r.address = address;

    c->nargs = bc_precompile(c->args, "ssissiis",
                             c->u.r.bytime,
                             c->u.r.bymode,
                             c->u.r.bytrace,
                             c->u.r.dsn_notify,
                             c->u.r.dsn_ret,
                             c->u.r.list,
                             c->u.r.copy,
                             c->u.r.address);

    return c;
}

static int verify_identifier(sieve_script_t *sscript, char *s)
{
    /* identifier         = (ALPHA / "_") *(ALPHA / DIGIT / "_") */

    if (!is_identifier(s)) {
        sieveerror_f(sscript,
                     "string '%s': not a valid sieve identifier", s);
        return 0;
    }
    return 1;
}

static commandlist_t *build_set(sieve_script_t *sscript,
                                commandlist_t *c, char *variable, char *value)
{
    assert(c && c->type == B_SET);

    verify_identifier(sscript, variable);
    verify_utf8(sscript, value);

    c->u.s.variable = variable;
    c->u.s.value = value;

    c->nargs = bc_precompile(c->args, "iss",
                             c->u.s.modifiers,
                             c->u.s.variable,
                             c->u.s.value);

    return c;
}

static commandlist_t *build_vacation(sieve_script_t *sscript,
                                     commandlist_t *c, char *message)
{
    int min = sscript->interp.vacation->min_response;
    int max = sscript->interp.vacation->max_response;

    assert(c && c->type == B_VACATION);

    if (c->u.v.handle) verify_utf8(sscript, c->u.v.handle);
    if (c->u.v.subject) verify_utf8(sscript, c->u.v.subject);
    if (c->u.v.from) verify_address(sscript, c->u.v.from);
    if (c->u.v.addresses)
        verify_stringlist(sscript, c->u.v.addresses, verify_address);
    if (c->u.v.mime == -1) {
        verify_utf8(sscript, message);
        c->u.v.mime = 0;
    }
    if (c->u.v.fcc.t.folder) {
        verify_mailbox(sscript, c->u.v.fcc.t.folder);
        if (c->u.v.fcc.flags && !_verify_flaglist(c->u.v.fcc.flags)) {
            strarray_add(c->u.v.fcc.flags, "");
        }
    }
    else if (c->u.v.fcc.create || c->u.v.fcc.flags ||
             c->u.v.fcc.t.specialuse || c->u.v.fcc.t.mailboxid) {
        sieveerror_c(sscript, SIEVE_MISSING_TAG, ":fcc");
    }

    c->u.v.message = message;

    if (c->u.v.seconds == -1) c->u.v.seconds = 7 * DAY2SEC;
    if (c->u.v.seconds < min) c->u.v.seconds = min;
    if (c->u.v.seconds > max) c->u.v.seconds = max;

    c->nargs = bc_precompile(c->args,
                             c->u.v.fcc.t.folder ? "SssiisssiSss" : "Sssiisss",
                             c->u.v.addresses,
                             c->u.v.subject,
                             c->u.v.message,
                             c->u.v.seconds,
                             c->u.v.mime,
                             c->u.v.from,
                             c->u.v.handle,
                             c->u.v.fcc.t.folder,
                             c->u.v.fcc.create,
                             c->u.v.fcc.flags,
                             c->u.v.fcc.t.specialuse,
                             c->u.v.fcc.t.mailboxid);

    return c;
}

static commandlist_t *build_flag(sieve_script_t *sscript,
                                 commandlist_t *c, strarray_t *flags)
{
    assert(c && (c->type == B_SETFLAG ||
                 c->type == B_ADDFLAG ||
                 c->type == B_REMOVEFLAG));

    if (!_verify_flaglist(flags)) {
        strarray_add(flags, "");
    }
    c->u.fl.flags = flags;

    if (!c->u.fl.variable) c->u.fl.variable = xstrdup("");
    else if (!is_identifier(c->u.fl.variable)) {
        sieveerror_c(sscript, SIEVE_INVALID_VALUE, "variablename");
    }

    c->nargs = bc_precompile(c->args, "sS",
                             c->u.fl.variable,
                             c->u.fl.flags);

    return c;
}

static commandlist_t *build_addheader(sieve_script_t *sscript,
                                      commandlist_t *c, char *name, char *value)
{
    assert(c && c->type == B_ADDHEADER);

    verify_header(sscript, name);
    verify_utf8(sscript, value);

    if (c->u.ah.index == 0) c->u.ah.index = 1;
    c->u.ah.name = name;
    c->u.ah.value = value;

    c->nargs = bc_precompile(c->args, "iss",
                             c->u.ah.index,
                             c->u.ah.name,
                             c->u.ah.value);

    return c;
}

static commandlist_t *build_deleteheader(sieve_script_t *sscript,
                                         commandlist_t *c,
                                         char *name, strarray_t *values)
{
    assert(c && c->type == B_DELETEHEADER);

    if (!strcasecmp("Received", name) || !strcasecmp("Auto-Submitted", name)) {
        sieveerror_f(sscript,
                     "MUST NOT delete Received or Auto-Submitted headers");
    }
    else if (c->u.dh.comp.index == INT_MIN) {
        sieveerror_c(sscript, SIEVE_MISSING_TAG, ":index");
    }

    verify_header(sscript, name);
    verify_patternlist(sscript, values, &c->u.dh.comp, verify_utf8);

    c->u.dh.name = name;
    c->u.dh.values = values;

    c->nargs = bc_precompile(c->args, "iCsS",
                             c->u.dh.comp.index,
                             &c->u.dh.comp,
                             c->u.dh.name,
                             c->u.dh.values);

    return c;
}

static int verify_weekday(sieve_script_t *sscript, char *day)
{
    int n = day[0] - '0';

    if (n >= 0 && n <= 6 && day[1] == '\0') {
        return (1 << n);
    }

    sieveerror_f(sscript, "'%s': not a valid weekday for snooze", day);
    return 0;
}

static int verify_time(sieve_script_t *sscript, char *time)
{
    struct tm tm;
    int t = 0;
    char *r = strptime(time, "%T", &tm);

    if (r && *r == '\0') {
        t = 3600 * tm.tm_hour + 60 * tm.tm_min + tm.tm_sec;
    }
    else {
        sieveerror_f(sscript, "'%s': not a valid time for snooze", time);
    }

    free(time);  /* done with this string */

    return t;
}

static commandlist_t *build_snooze(sieve_script_t *sscript,
                                   commandlist_t *c, arrayu64_t *times)
{
    assert(c && c->type == B_SNOOZE);

    if (c->u.sn.f.t.folder) verify_mailbox(sscript, c->u.sn.f.t.folder);
    if (c->u.sn.addflags && !_verify_flaglist(c->u.sn.addflags)) {
        strarray_add(c->u.sn.addflags, "");
    }
    if (c->u.sn.removeflags && !_verify_flaglist(c->u.sn.removeflags)) {
        strarray_add(c->u.sn.removeflags, "");
    }
    if (!c->u.sn.days) c->u.sn.days = 0x7f; /* all days */

    /* Sort times earliest -> latest */
    arrayu64_sort(times, NULL/*ascending*/);
    c->u.sn.times = times;

    c->nargs = bc_precompile(c->args, "sssiSSisU",
                             c->u.sn.f.t.folder,
                             c->u.sn.f.t.mailboxid,
                             c->u.sn.f.t.specialuse,
                             c->u.sn.f.create,
                             c->u.sn.addflags,
                             c->u.sn.removeflags,
                             c->u.sn.days,
                             c->u.sn.tzid,
                             c->u.sn.times);

    return c;
}

static commandlist_t *build_rej_err(sieve_script_t *sscript,
                                    int t, char *message)
{
    commandlist_t *c;

    assert(t == B_REJECT || t == B_EREJECT || t == B_ERROR);

    verify_utf8(sscript, message);

    c = new_command(t, sscript);
    c->u.str = message;

    c->nargs = bc_precompile(c->args, "s", c->u.str);

    return c;
}

static commandlist_t *build_notify(sieve_script_t *sscript,
                                   commandlist_t *c, char *method)
{
    assert(c && c->type == B_ENOTIFY);

    if (c->u.n.fcc.t.folder) {
        verify_mailbox(sscript, c->u.n.fcc.t.folder);
        if (c->u.n.fcc.flags && !_verify_flaglist(c->u.n.fcc.flags)) {
            strarray_add(c->u.n.fcc.flags, "");
        }
    }
    else if (c->u.n.fcc.create || c->u.n.fcc.flags ||
             c->u.n.fcc.t.specialuse || c->u.n.fcc.t.mailboxid) {
        sieveerror_c(sscript, SIEVE_MISSING_TAG, ":fcc");
    }

    c->u.n.method = method;

    if (c->u.n.priority == -1) c->u.n.priority = B_NORMAL;
    if (!c->u.n.message) c->u.n.message = xstrdup("$from$: $subject$");

    c->nargs = bc_precompile(c->args, "ssSis",
                             c->u.n.method,
                             c->u.n.from,
                             c->u.n.options,
                             c->u.n.priority,
                             c->u.n.message);

    return c;
}

static commandlist_t *build_include(sieve_script_t *sscript,
                                    commandlist_t *c, char *script)
{
    assert(c && c->type == B_INCLUDE);

    if (strchr(script, '/')) {
        sieveerror_c(sscript, SIEVE_INVALID_VALUE, "script-name");
    }

    c->u.inc.script = script;
    if (c->u.inc.once == -1) c->u.inc.once = 0;
    if (c->u.inc.location == -1) c->u.inc.location = B_PERSONAL;
    if (c->u.inc.optional == -1) c->u.inc.optional = 0;

    c->nargs = bc_precompile(c->args, "is",
                             c->u.inc.location |
                                 (c->u.inc.once | c->u.inc.optional),
                             c->u.inc.script);

    return c;
}

static commandlist_t *build_log(sieve_script_t *sscript, char *text)
{
    commandlist_t *c;

    verify_utf8(sscript, text);

    c = new_command(B_LOG, sscript);
    c->u.l.text = text;

    c->nargs = bc_precompile(c->args, "s", c->u.l.text);

    return c;
}

static commandlist_t *build_cal(sieve_script_t *sscript, commandlist_t *c)
{
    unsigned flags = 0;

    assert(c && c->type == B_PROCESSCAL);

    if (c->u.cal.allow_public) flags |= CAL_ALLOWPUBLIC;
    if (c->u.cal.invites_only) flags |= CAL_INVITESONLY;
    if (c->u.cal.updates_only) flags |= CAL_UPDATESONLY;
    if (c->u.cal.delete_cancelled) flags |= CAL_DELETECANCELLED;

    if (c->u.cal.addresses)
        verify_stringlist(sscript, c->u.cal.addresses, verify_address);
    if (c->u.cal.organizers) verify_list(sscript, c->u.cal.organizers);
    if (c->u.cal.outcome_var) verify_identifier(sscript, c->u.cal.outcome_var);
    if (c->u.cal.reason_var) verify_identifier(sscript, c->u.cal.reason_var);
    
    c->nargs = bc_precompile(c->args, "iSssss",
                             flags,
                             c->u.cal.addresses,
                             c->u.cal.organizers,
                             c->u.cal.calendarid,
                             c->u.cal.outcome_var,
                             c->u.cal.reason_var);

    return c;
}

static commandlist_t *build_ikeep_target(sieve_script_t *sscript,
                                         commandlist_t *c, char *folder)
{
    assert(c && c->type == B_IKEEP_TARGET);

    verify_mailbox(sscript, folder);
    c->u.ikt.folder = folder;

    c->nargs = bc_precompile(c->args, "sss",
                             c->u.ikt.mailboxid,
                             c->u.ikt.specialuse,
                             c->u.ikt.folder);

    return c;
}

static test_t *build_anyof(sieve_script_t *sscript, testlist_t *tl)
{
    test_t *t;

    assert(tl);

    if (tl->next == NULL) {
        /* collapse single item list into a simple test */
        t = tl->t;
        free(tl);
    }
    else {
        test_t *fail = NULL, *maybe = NULL;

        /* create ANYOF test */
        t = new_test(BC_ANYOF, sscript);
        t->u.tl = tl;

        /* find first test that did/didn't set ignore_err */
        for ( ; tl && !fail && !maybe; tl = tl->next) {
            if (tl->t->ignore_err) {
                if (!fail) fail = tl->t;
            }
            else if (!maybe) maybe = tl->t;
        }

        if (fail) {
            if (maybe) {
                /* test may succeed - backout ignore_err */
                sscript->ignore_err = --fail->ignore_err;
            }
            else {
                /* test will fail - revert ignore_err to first value */
                sscript->ignore_err = t->ignore_err = fail->ignore_err;
            }
        }

        t->nargs = bc_precompile(t->args, "T", t->u.tl);
    }

    return t;
}

static test_t *build_allof(sieve_script_t *sscript, testlist_t *tl)
{
    test_t *t;

    assert(tl);

    if (tl->next == NULL) {
        /* collapse single item list into a simple test */
        t = tl->t;
        free(tl);
    }
    else {
        /* create ALLOF test */
        t = new_test(BC_ALLOF, sscript);
        t->u.tl = tl;

        /* find first test that set ignore_err and revert to that value */
        for ( ; tl; tl = tl->next) {
            if (tl->t->ignore_err) {
                sscript->ignore_err = t->ignore_err = tl->t->ignore_err;
                break;
            }
        }

        t->nargs = bc_precompile(t->args, "T", t->u.tl);
    }

    return t;
}

static test_t *build_not(sieve_script_t *sscript, test_t *t)
{
    test_t *n;

    assert(t);

    if (t->ignore_err) {
        /* test will succeed - backout ignore_err */
        sscript->ignore_err = --t->ignore_err;
    }

    n = new_test(BC_NOT, sscript);
    n->u.t = t;

    n->nargs = bc_precompile(n->args, "t", n->u.t);

    return n;
}

static test_t *build_hhs(sieve_script_t *sscript, test_t *t,
                         strarray_t *sl, strarray_t *pl)
{
    assert(t);

    verify_patternlist(sscript, pl, &t->u.hhs.comp, verify_utf8);

    t->u.hhs.sl = sl;
    t->u.hhs.pl = pl;

    t->nargs += bc_precompile(t->args + t->nargs, "CSS",
                              &t->u.hhs.comp,
                              t->u.hhs.sl,
                              t->u.hhs.pl);

    return t;
}

static test_t *build_header(sieve_script_t *sscript, test_t *t,
                            strarray_t *sl, strarray_t *pl)
{
    assert(t && t->type == BC_HEADER);

    if (t->u.hhs.comp.index == INT_MIN) {
        sieveerror_c(sscript, SIEVE_MISSING_TAG, ":index");
    }

    verify_stringlist(sscript, sl, verify_header);

    t->nargs = bc_precompile(t->args, "i", t->u.hhs.comp.index);

    return build_hhs(sscript, t, sl, pl);
}

static test_t *build_stringt(sieve_script_t *sscript, test_t *t,
                             strarray_t *sl, strarray_t *pl)
{
    assert(t && t->type == BC_STRING);

    verify_stringlist(sscript, sl, verify_utf8);

    return build_hhs(sscript, t, sl, pl);
}

static test_t *build_hasflag(sieve_script_t *sscript, test_t *t,
                             strarray_t *sl, strarray_t *pl)
{
    assert(t && t->type == BC_HASFLAG);

    if (sl) {
        if (!supported(SIEVE_CAPA_VARIABLES)) {
            sieveerror_c(sscript, SIEVE_MISSING_REQUIRE, "variables");
        }

        verify_stringlist(sscript, sl, verify_identifier);
    }

    return build_hhs(sscript, t, sl, pl);
}

static test_t *build_ae(sieve_script_t *sscript, test_t *t,
                        strarray_t *sl, strarray_t *pl)
{
    assert(t);

    verify_patternlist(sscript, pl, &t->u.ae.comp, NULL);

    if (t->u.ae.addrpart == -1) t->u.ae.addrpart = B_ALL;
    t->u.ae.sl = sl;
    t->u.ae.pl = pl;

    t->nargs += bc_precompile(t->args + t->nargs, "CiSS",
                              &t->u.ae.comp,
                              t->u.ae.addrpart,
                              t->u.ae.sl,
                              t->u.ae.pl);

    return t;
}

static test_t *build_address(sieve_script_t *sscript, test_t *t,
                             strarray_t *sl, strarray_t *pl)
{
    assert(t && t->type == BC_ADDRESS);

    if (t->u.ae.comp.index == INT_MIN) {
        sieveerror_c(sscript, SIEVE_MISSING_TAG, ":index");
    }

    verify_stringlist(sscript, sl, verify_addrheader);

    t->nargs = bc_precompile(t->args, "i", t->u.ae.comp.index);

    return build_ae(sscript, t, sl, pl);
}

static test_t *build_envelope(sieve_script_t *sscript, test_t *t,
                              strarray_t *sl, strarray_t *pl)
{
    assert(t && t->type == BC_ENVELOPE);

    verify_stringlist(sscript, sl, verify_envelope);

    return build_ae(sscript, t, sl, pl);
}

static test_t *build_body(sieve_script_t *sscript,
                          test_t *t, strarray_t *pl)
{
    assert(t && (t->type == BC_BODY));

    verify_patternlist(sscript, pl, &t->u.b.comp, verify_utf8);

    if (t->u.b.offset == -1) t->u.b.offset = 0;
    if (t->u.b.transform == -1) t->u.b.transform = B_TEXT;
    if (t->u.b.content_types == NULL) {
        t->u.b.content_types = strarray_new();
        strarray_append(t->u.b.content_types,
                        (t->u.b.transform == B_RAW) ? "" : "text");
    }
    t->u.b.pl = pl;

    t->nargs = bc_precompile(t->args, "CiiSS",
                             &t->u.b.comp,
                             t->u.b.transform,
                             t->u.b.offset,
                             t->u.b.content_types,
                             t->u.b.pl);

    return t;
}

static const struct {
    const char *name;
    unsigned bytecode;
} date_parts[] = {
    { "year",    B_YEAR    },
    { "month",   B_MONTH   },
    { "day",     B_DAY     },
    { "date",    B_DATE    },
    { "julian",  B_JULIAN  },
    { "hour",    B_HOUR    },
    { "minute",  B_MINUTE  },
    { "second",  B_SECOND  },
    { "time",    B_TIME    },
    { "iso8601", B_ISO8601 },
    { "std11",   B_STD11   },
    { "zone",    B_ZONE    },
    { "weekday", B_WEEKDAY },
    { NULL,      0         }
};

static int verify_date_part(sieve_script_t *sscript, char *part)
{
    int i;

    for (i = 0; date_parts[i].name && strcasecmp(date_parts[i].name, part); i++);

    if (!date_parts[i].name) {
        sieveerror_f(sscript, "invalid date-part '%s'", part);
    }

    return date_parts[i].bytecode;
}

static test_t *build_date(sieve_script_t *sscript,
                          test_t *t, char *hn, char *part, strarray_t *kl)
{
    assert(t && (t->type == BC_DATE || t->type == BC_CURRENTDATE));

    if (hn) verify_header(sscript, hn);
    verify_patternlist(sscript, kl, &t->u.dt.comp, NULL);

    if (t->u.dt.comp.index == 0) {
        t->u.dt.comp.index = 1;
    }
    else if (t->u.dt.comp.index == INT_MIN) {
        sieveerror_c(sscript, SIEVE_MISSING_TAG, ":index");
    }

    if (t->u.dt.zone.tag == -1) {
        t->u.dt.zone.tag = B_TIMEZONE;
    }

    t->u.dt.date_part = verify_date_part(sscript, part);
    free(part); /* done with this string */
    t->u.dt.header_name = hn;
    t->u.dt.kl = kl;

    if (t->type == BC_DATE) {
        t->nargs = bc_precompile(t->args, "iZCisS",
                                 t->u.dt.comp.index,
                                 &t->u.dt.zone,
                                 &t->u.dt.comp,
                                 t->u.dt.date_part,
                                 t->u.dt.header_name,
                                 t->u.dt.kl);
    }
    else {
        t->nargs = bc_precompile(t->args, "ZCiS",
                                 &t->u.dt.zone,
                                 &t->u.dt.comp,
                                 t->u.dt.date_part,
                                 t->u.dt.kl);
    }

    return t;
}

static test_t *build_ihave(sieve_script_t *sscript, strarray_t *sa)
{
    test_t *t;
    int i;

    t = new_test(BC_IHAVE, sscript);
    t->u.sl = sa;

    /* check if we support all listed extensions */
    for (i = 0; i < strarray_size(sa); i++) {
        unsigned long long capa = lookup_capability(strarray_nth(sa, i));

        if (!capa) {
            /* need to start ignoring errors immediately in case this ihave
               is part of a testlist with an unknown test later in the list */
            if (!t->ignore_err) t->ignore_err = ++sscript->ignore_err;
        }
        else if (capa & SIEVE_CAPA_IHAVE_INCOMPAT) {
            /* incompatible extension used in ihave - parse error */
            sscript->ignore_err = 0;
            sieveerror_c(sscript, SIEVE_IHAVE_INCOMPAT, strarray_nth(sa, i));
            break;
        }
    }

    t->nargs = bc_precompile(t->args, "S", t->u.sl);

    return t;
}

static test_t *build_mbox_meta(sieve_script_t *sscript,
                               test_t *t, char *extname,
                               char *keyname, strarray_t *keylist)
{
    assert(t);

    canon_comptags(&t->u.mm.comp, sscript);
    t->u.mm.extname = extname;
    t->u.mm.keyname = keyname;
    t->u.mm.keylist = keylist;

    switch (t->type) {
    case BC_MAILBOXEXISTS:
    case BC_MAILBOXIDEXISTS:
    case BC_SERVERMETADATAEXISTS:
        t->nargs = bc_precompile(t->args, "S",
                                 t->u.mm.keylist);
        break;

    case BC_METADATAEXISTS:
    case BC_SPECIALUSEEXISTS:
        t->nargs = bc_precompile(t->args, "sS",
                                 t->u.mm.extname,
                                 t->u.mm.keylist);
        break;

    case BC_SERVERMETADATA:
    case BC_ENVIRONMENT:
        t->nargs = bc_precompile(t->args, "CsS",
                                 &t->u.mm.comp,
                                 t->u.mm.keyname,
                                 t->u.mm.keylist);
        break;

    case BC_METADATA:
    case BC_NOTIFYMETHODCAPABILITY:
        t->nargs = bc_precompile(t->args, "CssS",
                                 &t->u.mm.comp,
                                 t->u.mm.extname,
                                 t->u.mm.keyname,
                                 t->u.mm.keylist);
        break;

    default:
        assert(0);
        break;
    }

    return t;
}

static test_t *build_duplicate(sieve_script_t *sscript, test_t *t)
{
    assert(t && t->type == BC_DUPLICATE);

    switch (t->u.dup.idtype) {
    case B_HEADER:
        verify_header(sscript, t->u.dup.idval);
        break;

    case B_UNIQUEID:
        verify_utf8(sscript, t->u.dup.idval);
        break;

    default:
        t->u.dup.idtype = B_HEADER;
        t->u.dup.idval = xstrdup("Message-ID");
        break;
    }

    if (!t->u.dup.handle) t->u.dup.handle = xstrdup("");
    else verify_utf8(sscript, t->u.dup.handle);

    if (t->u.dup.seconds == -1) t->u.dup.seconds = 7 * 86400; /* 7 days */

    t->nargs = bc_precompile(t->args, "issii",
                             t->u.dup.idtype,
                             t->u.dup.idval,
                             t->u.dup.handle,
                             t->u.dup.seconds,
                             t->u.dup.last);

    return t;
}

#ifdef WITH_JMAP
#include "imap/jmap_api.h"
#include "imap/jmap_mail_query_parse.h"

struct filter_rock {
    strarray_t *path;
    unsigned is_invalid;
};

static void filter_parser_invalid(const char *field, void *rock)
{
    struct filter_rock *frock = (struct filter_rock *) rock;

    if (!frock->is_invalid++) strarray_push(frock->path, field);
}

static void filter_parser_push_index(const char *field, size_t index,
                                     const char *name, void *rock)
{
    struct filter_rock *frock = (struct filter_rock *) rock;
    struct buf buf = BUF_INITIALIZER;

    if (!frock->is_invalid) {
        if (name) buf_printf(&buf, "%s[%zu:%s]", field, index, name);
        else buf_printf(&buf, "%s[%zu]", field, index);
        strarray_pushm(frock->path, buf_release(&buf));
    }
}

static void filter_parser_pop(void *rock)
{
    struct filter_rock *frock = (struct filter_rock *) rock;

    if (!frock->is_invalid) free(strarray_pop(frock->path));
}

static test_t *build_jmapquery(sieve_script_t *sscript, test_t *t, char *json)
{
    json_t *jquery;
    json_error_t jerr;

    assert(t && t->type == BC_JMAPQUERY);

    /* validate query */
    jquery = json_loads(json, 0, &jerr);
    if (jquery) {
        strarray_t path = STRARRAY_INITIALIZER;
        strarray_t capabilities = STRARRAY_INITIALIZER;
        struct filter_rock frock = { &path, 0 };
        jmap_email_filter_parse_ctx_t parse_ctx = {
            NULL,
            &filter_parser_invalid,
            &filter_parser_push_index,
            &filter_parser_pop,
            &capabilities,
            &frock
        };

        strarray_append(&capabilities, JMAP_URN_MAIL);
        strarray_append(&capabilities, JMAP_MAIL_EXTENSION);

        jmap_email_filter_parse(jquery, &parse_ctx);

        if (frock.is_invalid) {
            char *s = strarray_join(&path, "/");

            sieveerror_f(sscript, "invalid jmapquery argument: '%s'", s);
            free(s);
        }

        strarray_fini(&path);
        strarray_fini(&capabilities);
    }
    else {
        sieveerror_f(sscript, "invalid jmapquery format");
    }

    t->u.jquery = json_dumps(jquery, JSON_COMPACT);
    json_decref(jquery);

    free(json);  /* done with this string */

    t->nargs = bc_precompile(t->args, "s", t->u.jquery);

    return t;
}
#else
static test_t *build_jmapquery(sieve_script_t *sscript, test_t *t, char *json)
{
    sieveerror_c(sscript, SIEVE_UNSUPP_EXT, "vnd.cyrus.jmapquery");

    free(json);  /* done with this string */

    return t;
}
#endif /* WITH_JMAP */
