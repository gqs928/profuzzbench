[![Build Status](https://github.com/OpenSIPS/opensips/actions/workflows/main.yml/badge.svg?branch=master)](https://github.com/OpenSIPS/opensips/actions/workflows/main.yml?query=branch%3Amaster++)
[![Unit Tests](https://github.com/OpenSIPS/opensips/actions/workflows/unittests.yml/badge.svg?branch=master)](https://github.com/OpenSIPS/opensips/actions/workflows/unittests.yml?query=branch%3Amaster++)
[![OSS-Fuzz](https://github.com/OpenSIPS/opensips/actions/workflows/cifuzz.yml/badge.svg?branch=master)](https://github.com/OpenSIPS/opensips/actions/workflows/cifuzz.yml?query=branch%3Amaster++)
[![Cross Platform Builds](https://github.com/OpenSIPS/opensips/actions/workflows/multiarch.yml/badge.svg?branch=master)](https://github.com/OpenSIPS/opensips/actions/workflows/multiarch.yml?query=branch%3Amaster++)
[![RTP.io](https://github.com/OpenSIPS/opensips/actions/workflows/rtp.io.yml/badge.svg?branch=master)](https://github.com/OpenSIPS/opensips/actions/workflows/rtp.io.yml?query=branch%3Amaster++)
[![Coverity Scan Build Status](https://scan.coverity.com/projects/7580/badge.svg)](https://scan.coverity.com/projects/opensips-opensips)

# Welcome to OpenSIPS Project


## About

OpenSIPS is a GPL licensed SIP server implementation. It started as a fork of
Fokus Fraunhofer SIP Express Router (SER) project. OpenSIPS wants to be a more
open project, not only from license point of view, but more open as project
management, especially for external contributions.

OpenSIPS wants to overcome the development latency of current SER project,
to ensure a shorter path into a release for new added features.
OpenSIPS is a project maintained by OpenSIPS Solutions
           <http://www.opensips-solutions.com/>
by a team including core and main developers of SER project.


## Info
For information regarding the OpenSIPS installation, please see the [INSTALL](INSTALL)
file.

For current developers/contributors of this project, see the [CREDITS](CREDITS) and
[AUTHORS](AUTHORS) file. For complete license information, please see the [COPYING](COPYING) file.
For an overview of OpenSIPS modules, a [modules listing](https://www.opensips.org/Documentation/Modules)
is available on the opensips.org website.


## Docs

Documentation about each module can be found in the [README]() file in each
module directory. For online documentation, please see
           <https://opensips.org/Resources/Documentation>

For additional documentation, tutorials and examples please see also
           <https://opensips.org/Resources/DocsTutorials>



## Questions

For any question related to the OpenSIPS usage, please use the
           <users@lists.opensips.org>
public mailing list.

For questions regarding the development of OpenSIPS - like contributions, bug
reports, etc - please use the
           <devel@lists.opensips.org>
public mailing list.

For questions regarding businesses around OpenSIPS - like products,·
consultancy, trainings, etc - please use the
           <business@lists.opensips.org>
public mailing list.

Also there is a generic news mailing list where you can learn about what is·
new or important for the OpenSIPS project, about alerts and updates regarding
relaces and about events around the project.
           <news@lists.opensips.org>
