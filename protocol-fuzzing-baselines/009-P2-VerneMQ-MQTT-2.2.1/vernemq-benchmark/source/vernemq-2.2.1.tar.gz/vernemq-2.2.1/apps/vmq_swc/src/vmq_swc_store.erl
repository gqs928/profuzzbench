%% Copyright 2018 Octavo Labs AG Zurich Switzerland (https://octavolabs.com)
%% Copyright 2018-2024 Octavo Labs/VerneMQ (https://vernemq.com/)
%% and Individual Contributors.
%% Licensed under the Apache License, Version 2.0 (the "License");
%% you may not use this file except in compliance with the License.
%% You may obtain a copy of the License at
%%
%%     http://www.apache.org/licenses/LICENSE-2.0
%%
%% Unless required by applicable law or agreed to in writing, software
%% distributed under the License is distributed on an "AS IS" BASIS,
%% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%% See the License for the specific language governing permissions and
%% limitations under the License.

-module(vmq_swc_store).
-include_lib("kernel/include/logger.hrl").

-include("vmq_swc.hrl").
-behaviour(gen_server).

-export([
    start_link/1,
    write/3,
    write/4,
    write_batch/2,
    read/2,
    fold_values/4,
    subscribe/3,
    subscribe/4,
    dump/1,

    process_batch/2,

    lock/1,

    remote_sync_missing/3,
    rpc_sync_missing/3,

    remote_sync_missing_init/4,
    rpc_sync_missing_init/4,

    sync_repair/5,
    sync_repair_init/5,

    node_clock/1,
    remote_node_clock/2,
    rpc_node_clock/1,

    watermark/1,
    remote_watermark/2,
    rpc_watermark/1,

    update_watermark/3,
    jump_old_clocks/2,
    sanitize_old_local_entries/1,
    sanitize_old_local_entries_by_storename/1,
    do_gc/2,
    set_group_members/2,
    % testing
    node_clock_by_storename/1,
    get_nodeclock/1,
    get_dkm_by_storename/1,
    % testing
    watermark_by_storename/1,
    rpc_broadcast/3,
    % testing
    fix_watermark/2,
    % testing
    set_nodeclock/2,
    init_and_reset_dkm/1,
    set_init_sync_by_groupname/2,
    set_broadcast_by_groupname/2,
    get_init_sync/1,
    reset_iterator_by_groupname/1
]).

-export([
    init/1,
    handle_call/3,
    handle_cast/2,
    handle_info/2,
    terminate/2,
    code_change/3
]).

%% for testing only.
-export([set_broadcast/2]).

-record(state, {
    %id                :: peer(),
    id :: swc_id(),
    old_id :: swc_id(),
    mode,
    group,
    config :: config(),
    dotkeymap :: dotkeymap(),
    nodeclock :: nodeclock(),
    watermark :: watermark(),
    %peers             :: list(peer()),
    peers :: list(swc_id()),
    sync_lock,
    auto_gc :: boolean(),
    periodic_gc :: boolean(),
    subscriptions = #{} :: map(),
    broadcast_enabled :: boolean(),
    init_sync :: boolean(),
    iterator = undefined,
    pending_db_write = undefined,
    deferred_calls = [],
    db_write_seq = 0
}).

%-define(DBG_OP(Str, Format), io:format(Str, Format)).
-define(DBG_OP(_Str, _Format), ok).
-define(RETAIN_DB, {vmq, retain}).
-define(SUBSCRIBER_DB, {vmq, subscriber}).

start_link(#swc_config{store = StoreName} = Config) ->
    gen_server:start_link({local, StoreName}, ?MODULE, [Config], []).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Store API

-spec write(config(), key(), value()) -> ok.
write(Config, Key, Value) ->
    write(Config, Key, Value, swc_vv:new()).

-spec write(config(), key(), value(), context() | undefined) -> ok.
write(Config, Key, Value, Context) ->
    write_batch(Config, [{Key, Value, Context}]).

-spec write_batch(config(), [{key(), value(), context() | undefined}]) -> ok.
write_batch(Config, [{_Key, _Val, _Context} | _] = WriteOps) ->
    enqueue_op_sync(Config, {write, WriteOps}).

-spec read(config(), key()) -> {[value()], context()}.
read(Config, Key) ->
    SKey = sext:encode(Key),
    Obj0 = maybe_get_cached_object(Config, SKey),
    LocalClock = get_cached_node_clock(Config),
    Obj1 = swc_kv:fill(Obj0, LocalClock),
    Values = swc_kv:values(Obj1),
    Context = swc_kv:context(Obj1),
    {Values, Context}.

-spec fold_values(
    config(), fun((key(), {[value()], context()}, any()) -> any()), any(), key_prefix()
) -> any().
fold_values(Config, Fun, Acc, FullPrefix) ->
    LocalClock = get_cached_node_clock(Config),
    %% apparently 0 < '_'
    SFirstKey = sext:encode({FullPrefix, 0}),
    vmq_swc_db:fold(
        Config,
        ?DB_OBJ,
        fun(SKey, BValue, AccAcc) ->
            case sext:decode(SKey) of
                {FullPrefix, _Key} = PKey ->
                    Obj0 = binary_to_term(BValue),
                    Obj1 = swc_kv:fill(Obj0, LocalClock),
                    Values = swc_kv:values(Obj1),
                    Context = swc_kv:context(Obj1),
                    Fun(PKey, {Values, Context}, AccAcc);
                _ ->
                    stop
            end
        end,
        Acc,
        SFirstKey
    ).

-spec subscribe(
    config(),
    key_prefix(),
    fun(
        (
            {updated, key_prefix(), key_suffix(), [value()], [value()]}
            | {deleted, key_prefix(), key_suffix(), [value()]}
        ) -> any()
    )
) -> ok.
subscribe(#swc_config{} = Config, FullPrefix, ConvertFun) ->
    subscribe(Config, FullPrefix, ConvertFun, []).

-spec subscribe(
    config(),
    key_prefix(),
    fun(
        (
            {updated, key_prefix(), key_suffix(), [value()], [value()]}
            | {deleted, key_prefix(), key_suffix(), [value()]}
        ) -> any()
    ),
    list()
) -> ok.
subscribe(#swc_config{store = StoreName}, FullPrefix, ConvertFun, Opts) ->
    Pid = self(),
    subs_reg_upsert(StoreName, FullPrefix, Pid, ConvertFun, Opts),
    case whereis(StoreName) of
        undefined ->
            %% Store isn't running yet, need to retry.
            catch gen_server:cast(StoreName, {subscribe, FullPrefix, ConvertFun, Pid, Opts}),
            _ = spawn(fun() -> retry_subscribe(StoreName, FullPrefix, ConvertFun, Pid, Opts) end),
            ok;
        _ ->
            Res =
                catch gen_server:call(
                    StoreName, {subscribe, FullPrefix, ConvertFun, Pid, Opts}, 200
                ),
            case Res of
                ok ->
                    ok;
                _ ->
                    catch gen_server:cast(
                        StoreName, {subscribe, FullPrefix, ConvertFun, Pid, Opts}
                    ),
                    ok
            end
    end.

retry_subscribe(StoreName, FullPrefix, ConvertFun, Pid, Opts) ->
    retry_subscribe(StoreName, FullPrefix, ConvertFun, Pid, Opts, 40).

retry_subscribe(_StoreName, _FullPrefix, _ConvertFun, _Pid, _Opts, 0) ->
    ok;
retry_subscribe(StoreName, FullPrefix, ConvertFun, Pid, Opts, N) ->
    case whereis(StoreName) of
        undefined ->
            timer:sleep(50),
            retry_subscribe(StoreName, FullPrefix, ConvertFun, Pid, Opts, N - 1);
        _ ->
            Res =
                catch gen_server:call(
                    StoreName, {subscribe, FullPrefix, ConvertFun, Pid, Opts}, 200
                ),
            case Res of
                ok ->
                    ok;
                _ ->
                    catch gen_server:cast(
                        StoreName, {subscribe, FullPrefix, ConvertFun, Pid, Opts}
                    ),
                    ok
            end
    end.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Sync API, used by vmq_swc_exchange_fsm

-spec lock(config()) -> ok | {error, atom()}.
lock(#swc_config{store = StoreName}) ->
    gen_server:call(StoreName, {lock, self()}, fast_call_timeout()).

-spec remote_sync_missing(config(), peer(), [dot()]) -> [{db_key(), object()}] | {error, timeout}.
remote_sync_missing(
    #swc_config{group = SwcGroup, transport = TMod, peer = {OriginPeer, _Actor}}, RemotePeer, Dots
) ->
    TMod:rpc(
        SwcGroup, RemotePeer, ?MODULE, rpc_sync_missing, [OriginPeer, Dots], sync_call_timeout()
    ).

-spec rpc_sync_missing(peer(), [dot()], config()) -> [{db_key(), object()}].
rpc_sync_missing(OriginPeer, Dots, #swc_config{store = StoreName}) ->
    gen_server:call(StoreName, {sync_missing, OriginPeer, Dots}, sync_call_timeout()).

-spec remote_sync_missing_init(config(), peer(), integer(), db_key() | 'first') ->
    {'first', list()}
    | {'last', integer(), [object()]}
    | {db_key(), object()}
    | {error, timeout}.
remote_sync_missing_init(
    #swc_config{group = SwcGroup, transport = TMod, peer = {OriginPeer, _Actor}},
    RemotePeer,
    BatchSize,
    FirstKey
) ->
    TMod:rpc(
        SwcGroup,
        RemotePeer,
        ?MODULE,
        rpc_sync_missing_init,
        [OriginPeer, BatchSize, FirstKey],
        sync_call_timeout()
    ).

-spec rpc_sync_missing_init(peer(), integer(), db_key() | 'first', config()) ->
    {'first', list()}
    | {'last', integer(), [object()]}
    | {db_key(), object()}.
rpc_sync_missing_init(OriginPeer, BatchSize, FirstKey, #swc_config{store = StoreName}) ->
    gen_server:call(
        StoreName, {sync_missing_init, OriginPeer, BatchSize, FirstKey}, sync_call_timeout()
    ).

-spec sync_repair(
    config(), [{db_key(), object()}], peer(), nodeclock(), false | {true, watermark()}
) -> ok.
sync_repair(
    #swc_config{store = StoreName, peer = LocalNodeId},
    MissingObjects,
    RemotePeer,
    RemoteClock,
    LastBatch
) ->
    gen_server:call(
        StoreName,
        {sync_repair, LocalNodeId, RemotePeer, RemoteClock, MissingObjects, LastBatch},
        sync_call_timeout()
    ).

sync_repair_init(
    #swc_config{store = StoreName, peer = LocalNodeId},
    MissingObjects,
    RemotePeer,
    RemoteClock,
    LastBatch
) ->
    gen_server:call(
        StoreName,
        {sync_repair_init, LocalNodeId, RemotePeer, RemoteClock, MissingObjects, LastBatch},
        sync_call_timeout()
    ).

-spec node_clock(config()) -> nodeclock().
node_clock(#swc_config{store = StoreName}) ->
    gen_server:call(StoreName, get_node_clock, fast_call_timeout()).
node_clock_by_storename(StoreName) ->
    gen_server:call(StoreName, get_node_clock, fast_call_timeout()).
watermark_by_storename(StoreName) ->
    gen_server:call(StoreName, get_watermark, fast_call_timeout()).
set_nodeclock(StoreName, NodeClock) ->
    gen_server:call(StoreName, {set_node_clock, NodeClock}, infinity).

-spec remote_node_clock(config(), peer()) -> nodeclock() | {error, timeout}.
remote_node_clock(#swc_config{group = SwcGroup, transport = TMod}, RemotePeer) ->
    TMod:rpc(SwcGroup, RemotePeer, ?MODULE, rpc_node_clock, [], sync_call_timeout()).

-spec rpc_node_clock(config()) -> nodeclock().
rpc_node_clock(#swc_config{} = Config) ->
    node_clock(Config).

-spec watermark(config()) -> watermark().
watermark(Config) ->
    Watermark = get_watermark(Config),
    Watermark.

-spec remote_watermark(config(), peer()) -> watermark() | {error, timeout}.
remote_watermark(#swc_config{group = SwcGroup, transport = TMod}, RemotePeer) ->
    TMod:rpc(SwcGroup, RemotePeer, ?MODULE, rpc_watermark, [], sync_call_timeout()).

-spec rpc_watermark(config()) -> watermark().
rpc_watermark(#swc_config{} = Config) ->
    watermark(Config).

-spec update_watermark(config(), peer(), nodeclock()) -> ok.
update_watermark(#swc_config{store = StoreName, peer = Peer}, RemotePeer, RemoteNodeClock) ->
    gen_server:call(
        StoreName, {update_watermark, Peer, RemotePeer, RemoteNodeClock}, sync_call_timeout()
    ).

-spec rpc_broadcast(peer(), any(), config()) -> ok.
rpc_broadcast(FromPeer, Msg, #swc_config{store = StoreName} = _Config) ->
    gen_server:cast(StoreName, {swc_broadcast, FromPeer, Msg}).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Misc API

do_gc(StoreName, Node) ->
    gen_server:call({StoreName, Node}, do_gc, infinity).

dump(StoreName) ->
    gen_server:call(StoreName, dump, infinity).

process_batch(StoreName, Batch) ->
    gen_server:call(StoreName, {batch, Batch}, infinity).

set_broadcast(#swc_config{store = StoreName}, IsBroadcastEnabled) when
    is_boolean(IsBroadcastEnabled)
->
    gen_server:call(StoreName, {set_broadcast, IsBroadcastEnabled}).

set_group_members(#swc_config{store = StoreName}, Members) ->
    gen_server:cast(StoreName, {set_group_members, Members}).

jump_old_clocks(#swc_config{store = StoreName} = _Config, RemoteClock) ->
    gen_server:cast(StoreName, {jump_old_clocks, RemoteClock}).

sanitize_old_local_entries(#swc_config{store = StoreName} = _Config) ->
    gen_server:cast(StoreName, sanitize_old_local_entries).

sanitize_old_local_entries_by_storename(StoreName) ->
    gen_server:cast(StoreName, sanitize_old_local_entries).

init_and_reset_dkm(#swc_config{store = StoreName} = _Config) ->
    gen_server:cast(StoreName, init_dkm).

get_init_sync(#swc_config{group = Group} = _Config) ->
    persistent_term:get(init_sync_key(Group), true).

set_init_sync_by_groupname(Group, InitSync) when is_boolean(InitSync) ->
    StoreName = list_to_atom("vmq_swc_store_" ++ atom_to_list(Group)),
    Res = gen_server:call(StoreName, {set_init_sync, InitSync}, fast_call_timeout()),
    persistent_term:put(init_sync_key(Group), InitSync),
    Res.

set_broadcast_by_groupname(Group, IsBroadcastEnabled) when
    is_boolean(IsBroadcastEnabled)
->
    StoreName = list_to_atom("vmq_swc_store_" ++ atom_to_list(Group)),

    gen_server:call(StoreName, {set_broadcast, IsBroadcastEnabled}).

reset_iterator_by_groupname(Group) ->
    StoreName = list_to_atom("vmq_swc_store_" ++ atom_to_list(Group)),
    gen_server:call(StoreName, reset_itr).

get_dkm_by_storename(StoreName) ->
    gen_server:call(StoreName, get_dkm).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%% GEN_SERVER Callbacks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
init([
    #swc_config{group = Group, peer = SWC_ID, store = StoreName, r_o_w_cache = CacheName} = Config
]) ->
    process_flag(priority, high),
    StartSync = application:get_env(vmq_swc, sync_interval, {5000, 2500}),
    StartSync =/= 0 andalso erlang:send_after(1000, self(), sync),

    NodeClock = get_nodeclock(Config),
    NodeClock1 =
        case NodeClock of
            M when map_size(M) == 0 ->
                {1, NC} = swc_node:event(NodeClock, SWC_ID),
                NC;
            _ ->
                Entry = swc_node:get(SWC_ID, NodeClock),
                case Entry of
                    {0, N} -> swc_node:store_entry(SWC_ID, {1, N}, NodeClock);
                    _ -> NodeClock
                end
        end,

    Watermark = get_watermark(Config),

    DKM = init_dotkeymap(Config),
    case application:get_env(vmq_swc, periodic_gc, true) of
        true ->
            erlang:send_after(application:get_env(vmq_swc, gc_interval, 15000), self(), do_gc);
        false ->
            ignore
    end,

    %  IsBroadcastEnabled = application:get_env(vmq_swc, enable_broadcast, true),
    IsAutoGc = application:get_env(vmq_swc, auto_gc, true),
    IsPeriodicGc = application:get_env(vmq_swc, periodic_gc, true),
    Init1 =
        case application:get_env(vmq_swc, init_sync_procedure, false) of
            false ->
                true;
            true ->
                case vmq_swc_db:get(Config, default, <<"ISY">>, []) of
                    not_found -> false;
                    {ok, Res} -> binary_to_term(Res)
                end
        end,
    vmq_swc_group_coordinator:group_initialized(Group, Init1),
    persistent_term:put(init_sync_key(Group), Init1),
    IsBroadcastEnabled =
        case Init1 of
            false -> false;
            _ -> application:get_env(vmq_swc, enable_broadcast, true)
        end,

    ets:new(StoreName, [public, named_table, {read_concurrency, true}]),
    ets:new(CacheName, [public, named_table, {read_concurrency, true}]),
    % Members = vmq_swc_peer_service_manager:get_actors(),
    % {ok, LocalState} = vmq_swc_peer_service_manager:get_local_state(),

    % reset the entire watermark
    % NewWatermark = swc_watermark:reset_counters(NewWatermark0),
    % Members = vmq_swc_peer_service_manager:get_actors_and_peers(),

    vmq_swc_metrics:register_gauge(
        {swc_object_count, Group},
        fun() ->
            {
                [{group, atom_to_list(Group)}],
                <<"The number of replicated objects by this SWC group.">>,
                vmq_swc_dkm:info(DKM, object_count)
            }
        end
    ),
    vmq_swc_metrics:register_gauge(
        {swc_tombstone_count, Group},
        fun() ->
            {
                [{group, atom_to_list(Group)}],
                <<"The number of replicated tombstones by this SWC group.">>,
                vmq_swc_dkm:info(DKM, tombstone_count)
            }
        end
    ),
    vmq_swc_metrics:register_gauge(
        {swc_dotkeymap_memory, Group},
        fun() ->
            {
                [{group, atom_to_list(Group)}],
                <<"The number of words allocated to the SWC group dotkeymap.">>,
                vmq_swc_dkm:info(DKM, memory)
            }
        end
    ),
    % {ok, Actor} = vmq_swc_peer_service_manager:get_actor(),
    Members = vmq_swc_group_membership:get_members(Config),
    Members2 = vmq_swc_group_membership:swc_ids(Members),
    OLD_SWC_ID =
        case ets:lookup(swc_cluster_state, old_actor) of
            [] -> {node(), <<"initial">>};
            [{old_actor, OLD_SWC_Actor}] -> {node(), OLD_SWC_Actor}
        end,
    State0 = set_peers(Members2, #state{
        id = SWC_ID,
        old_id = OLD_SWC_ID,
        peers = [],
        group = Group,
        config = Config,
        dotkeymap = DKM,
        nodeclock = NodeClock1,
        watermark = Watermark,
        auto_gc = IsAutoGc,
        periodic_gc = IsPeriodicGc,
        broadcast_enabled = IsBroadcastEnabled,
        init_sync = Init1
    }),
    State1 = restore_subscriptions(StoreName, State0),
    {ok, State1}.

handle_call({lock, OwnerPid}, _From, #state{id = Id, sync_lock = SyncLock} = State0) ->
    {Peer, _Actor} = Id,
    case node(OwnerPid) == Peer of
        true when SyncLock == undefined ->
            MRef = monitor(process, OwnerPid),
            Lock = {OwnerPid, MRef},
            {reply, ok, State0#state{sync_lock = Lock}};
        true ->
            {reply, {error, already_locked}, State0};
        false ->
            {reply, {error, invalid_lock_request}, State0}
    end;
handle_call(get_node_clock, _From, #state{nodeclock = NodeClock} = State) ->
    {reply, NodeClock, State};
handle_call(get_watermark, _From, #state{watermark = Watermark} = State) ->
    {reply, Watermark, State};
handle_call(get_init_sync, _From, State) ->
    {reply, State#state.init_sync, State};
handle_call(
    Request, From, #state{pending_db_write = Pending, deferred_calls = Deferred} = State
) when
    Pending =/= undefined
->
    {noreply, State#state{deferred_calls = Deferred ++ [{call, Request, From}]}};
handle_call(
    {batch, Batch},
    _From,
    #state{
        config = Config,
        peers = Peers,
        id = Id,
        broadcast_enabled = IsBroadcastEnabled
    } = State0
) ->
    {Local, _} = Id,
    Peers1 = proplists:get_keys(Peers),
    {ReplicateObjects, DbOps, #state{nodeclock = NodeClock} = State1} =
        lists:foldl(
            fun({{CallerPid, CallerRef}, {write, WriteOps}}, Acc0) ->
                Acc1 =
                    lists:foldl(
                        fun(WriteOp, AccAcc0) ->
                            process_write_op(CallerPid, WriteOp, AccAcc0)
                        end,
                        Acc0,
                        WriteOps
                    ),
                CallerPid ! {CallerRef, ok},
                Acc1
            end,
            {[], [], State0},
            Batch
        ),
    case IsBroadcastEnabled of
        true ->
            #swc_config{group = SwcGroup, transport = TMod} = Config,
            lists:foreach(
                fun(Peer) ->
                    TMod:rpc_cast(SwcGroup, Peer, ?MODULE, rpc_broadcast, [
                        Local, lists:reverse(ReplicateObjects)
                    ])
                end,
                Peers1
            );
        _ ->
            ok
    end,
    UpdateNodeClock_DBOp = update_nodeclock_db_op(NodeClock),
    db_write(Config, [UpdateNodeClock_DBOp | DbOps]),
    r_o_w_cache_clear(Config),
    {reply, ok, cache_node_clock(State1)};
handle_call({subscribe, FullPrefix, ConvertFun, Pid}, _From, State0) ->
    State1 = upsert_subscription(FullPrefix, Pid, ConvertFun, [], State0),
    {reply, ok, State1};
handle_call({subscribe, FullPrefix, ConvertFun, Pid, Opts}, _From, State0) ->
    State1 = upsert_subscription(FullPrefix, Pid, ConvertFun, Opts, State0),
    {reply, ok, State1};
handle_call({sync_missing, _OriginPeer, Dots}, From, #state{config = Config} = State0) ->
    spawn_link(
        fun() ->
            Result =
                lists:filtermap(
                    fun(Dot) ->
                        DotKey = sext:encode(Dot),
                        case vmq_swc_db:get(Config, ?DB_DKM, DotKey) of
                            not_found ->
                                false;
                            {ok, SKey} ->
                                case vmq_swc_db:get(Config, ?DB_OBJ, SKey) of
                                    not_found ->
                                        %% the object was deleted in
                                        %% the past, replace it with
                                        %% an empty object which will
                                        %% become the delete-marker on
                                        %% the other node.
                                        {true, {SKey, swc_kv:add(swc_kv:new(), Dot, '$deleted')}};
                                    {ok, BObj} ->
                                        {true, {SKey, binary_to_term(BObj)}}
                                end
                        end
                    end,
                    Dots
                ),
            gen_server:reply(From, Result)
        end
    ),
    {noreply, State0};
handle_call(
    {sync_missing_init, OriginPeer, BatchSize, FirstKey},
    From,
    #state{
        config = Config
    } = State0
) ->
    TS1 = erlang:monotonic_time(millisecond),
    ?LOG_DEBUG("Sync missing Init requested from ~p~n", [OriginPeer]),
    BatchSizePlus = BatchSize + 1,
    spawn_link(
        fun() ->
            Result =
                case
                    vmq_swc_db:fold(
                        Config,
                        ?DB_OBJ,
                        fun(SKey, Obj, {Acc, N}) ->
                            case N of
                                BatchSizePlus -> stop;
                                _ -> {[{SKey, binary_to_term(Obj)} | Acc], N + 1}
                            end
                        end,

                        {[], 0},
                        FirstKey
                    )
                of
                    {[], 0} ->
                        {first, []};
                    {ObjsA, N} when is_integer(N) -> {last, N, ObjsA};
                    [{NextKey, _} | Objs] ->
                        TS2 = erlang:monotonic_time(millisecond),
                        ?LOG_DEBUG("Init Sync Batch TimeDiff ~p ~n", [TS2 - TS1]),
                        {NextKey, Objs}
                end,
            gen_server:reply(From, Result)
        end
    ),
    {noreply, State0};
handle_call(get_dkm, _From, #state{dotkeymap = DKM} = State) ->
    {reply, DKM, State};
handle_call({set_node_clock, NodeClock}, _From, #state{config = Config} = State) ->
    vmq_swc_db:put(Config, ?DB_DEFAULT, <<"BVV">>, term_to_binary(NodeClock)),
    {reply, ok, State#state{nodeclock = NodeClock}};
handle_call(reset_itr, _From, State) ->
    {reply, ok, State#state{iterator = undefined}};
handle_call(
    {update_watermark, _OriginPeer, RemotePeer, RemoteNodeClock},
    _From,
    #state{config = Config} = State0
) ->
    %{Node, Actor}, NodeClock, State0),
    Watermark = update_watermark_internal(RemotePeer, RemoteNodeClock, State0),
    UpdateWatermark_DBop = update_watermark_db_op(Watermark),
    db_write(Config, [UpdateWatermark_DBop]),
    {reply, ok, State0#state{watermark = Watermark}};
handle_call(
    {sync_repair, _OriginPeer, RemotePeer, RemoteNodeClock, MissingObjects, LastBatch},
    From,
    #state{config = Config} = State0
) ->
    {DbOps, State1} = sync_repair_db_ops(
        repair, RemotePeer, RemoteNodeClock, MissingObjects, LastBatch, State0
    ),
    {noreply, start_async_db_write(Config, DbOps, From, ok, cache_node_clock(State1))};
handle_call(
    {sync_repair_init, _OriginPeer, RemotePeer, RemoteNodeClock, MissingObjects, LastBatch},
    From,
    #state{config = Config, dotkeymap = _DKM} = State0
) ->
    ?LOG_DEBUG("Initial SYNC REPAIR running from RemotePeer ~p~n", [RemotePeer]),
    {DbOps, State1} = sync_repair_db_ops(
        init_repair, RemotePeer, RemoteNodeClock, MissingObjects, LastBatch, State0
    ),
    {noreply, start_async_db_write(Config, DbOps, From, ok, cache_node_clock(State1))};
handle_call(nodeclock, _, #state{nodeclock = NodeClock} = State) ->
    {reply, NodeClock, State};
handle_call(do_gc, _, #state{id = Id, nodeclock = NodeClock, config = Config} = State0) ->
    Watermark = update_watermark_internal(Id, NodeClock, State0),
    UpdateWatermark_DBop = update_watermark_db_op(Watermark),
    db_write(Config, [UpdateWatermark_DBop]),
    {reply, ok, incremental_gc(State0#state{watermark = Watermark})};
handle_call(dump, _, #state{config = Config} = State) ->
    {reply, dump_tables(Config), State};
handle_call(dump_dotkeymap, _, #state{dotkeymap = DKM} = State) ->
    {reply, vmq_swc_dkm:dump(DKM), State};
handle_call({set_broadcast, IsBroadcastEnabled}, _From, State) ->
    {reply, ok, State#state{broadcast_enabled = IsBroadcastEnabled}};
handle_call({set_init_sync, Synced}, _From, #state{group = Group} = State) ->
    persistent_term:put(init_sync_key(Group), Synced),
    {reply, ok, State#state{init_sync = Synced}};
handle_call(Request, From, State) ->
    ?LOG_ERROR("Replica ~p: Received invalid call ~p from ~p", [State#state.group, Request, From]),
    {reply, {error, wrong_request}, State}.

handle_cast(Request, #state{pending_db_write = Pending, deferred_calls = Deferred} = State) when
    Pending =/= undefined
->
    {noreply, State#state{deferred_calls = Deferred ++ [{cast, Request}]}};
handle_cast({set_group_members, UpdatedPeerList}, State) ->
    {noreply, set_peers(UpdatedPeerList, State)};
handle_cast(
    {swc_broadcast, FromPeer, Objects},
    #state{peers = Peers, config = Config, init_sync = InitSync} = State0
) ->
    Peers1 = proplists:get_keys(Peers),
    case lists:member(FromPeer, Peers1) of
        true ->
            case InitSync of
                false ->
                    {noreply, State0};
                true ->
                    {DbOps, #state{nodeclock = NodeClock} = State1} =
                        lists:foldl(
                            fun(Object, Acc) ->
                                process_replicate_op(Object, Acc)
                            end,
                            {[], State0},
                            Objects
                        ),
                    UpdateNodeClock_DBOp = update_nodeclock_db_op(NodeClock),
                    db_write(Config, [UpdateNodeClock_DBOp | DbOps]),
                    {noreply, cache_node_clock(State1)}
            end;
        false ->
            % drop broadcast
            ?LOG_DEBUG("Dropping SWC broadcast from Peer ~p~n", [FromPeer]),
            {noreply, State0}
    end;
handle_cast(
    {jump_old_clocks, RemoteClock},
    #state{config = Config, peers = Peers, nodeclock = LocalClock} = State
) ->
    RemoteIds = swc_node:ids(RemoteClock),
    OldIds = RemoteIds -- Peers,
    BasedRemoteClock = swc_node:base(RemoteClock),
    NewLocalClock = lists:foldl(
        fun(Id, Acc) ->
            Entry = swc_node:get(Id, BasedRemoteClock),
            swc_node:store_entry(Id, Entry, Acc)
        end,
        LocalClock,
        OldIds
    ),
    vmq_swc_db:put(Config, ?DB_DEFAULT, <<"BVV">>, term_to_binary(NewLocalClock)),
    State1 = State#state{nodeclock = NewLocalClock},
    {noreply, State1};
handle_cast(
    sanitize_old_local_entries,
    #state{config = Config, peers = Peers, nodeclock = LocalClock} = State
) ->
    Ids = swc_node:ids(LocalClock),
    OldIds = Ids -- Peers,
    % update the counters for the old ids from the remote
    % fold over the LocalClock
    NewLocalClock = lists:foldl(
        fun(Id, Acc) ->
            Entry = swc_node:get(Id, LocalClock),
            case Entry of
                {0, N} when is_integer(N) ->
                    swc_node:store_entry(Id, {1, 0}, Acc);
                _ ->
                    swc_node:store_entry(Id, Entry, Acc)
            end
        end,
        LocalClock,
        OldIds
    ),
    % update on disk, for the case when we have no events triggering on-disk DB update ops
    vmq_swc_db:put(Config, ?DB_DEFAULT, <<"BVV">>, term_to_binary(NewLocalClock)),
    State1 = State#state{nodeclock = NewLocalClock},
    {noreply, State1};
handle_cast(init_dkm, #state{config = Config} = State) ->
    DKM = init_dotkeymap(Config),
    {noreply, State#state{dotkeymap = DKM}};
handle_cast({subscribe, FullPrefix, ConvertFun, Pid}, State0) ->
    State1 = upsert_subscription(FullPrefix, Pid, ConvertFun, [], State0),
    {noreply, State1};
handle_cast({subscribe, FullPrefix, ConvertFun, Pid, Opts}, State0) ->
    State1 = upsert_subscription(FullPrefix, Pid, ConvertFun, Opts, State0),
    {noreply, State1};
handle_cast(Request, State) ->
    ?LOG_ERROR("Replica ~p: Received invalid cast ~p", [State#state.group, Request]),
    {noreply, State}.

handle_info(
    {async_db_write_done, Seq, Result},
    #state{pending_db_write = {Seq, MRef, _Pid, From, Reply}} = State
) ->
    demonitor(MRef, [flush]),
    case Result of
        ok ->
            gen_server:reply(From, Reply),
            {noreply, drain_deferred_calls(State#state{pending_db_write = undefined})};
        {error, Reason} ->
            ?LOG_ERROR("Replica ~p: async SWC store DB write failed due to ~p", [
                State#state.group, Reason
            ]),
            {stop, Reason, State#state{pending_db_write = undefined}}
    end;
handle_info(
    {'DOWN', MRef, process, Pid, Reason},
    #state{pending_db_write = {_Seq, MRef, Pid, From, _Reply}} = State
) ->
    gen_server:reply(From, {error, Reason}),
    ?LOG_ERROR("Replica ~p: async SWC store DB write worker exited due to ~p", [
        State#state.group, Reason
    ]),
    {stop, Reason, State#state{pending_db_write = undefined}};
handle_info({'DOWN', MRef, process, Pid, _Info}, #state{sync_lock = {Pid, MRef}} = State) ->
    {noreply, State#state{sync_lock = undefined}};
handle_info(Info, #state{pending_db_write = Pending, deferred_calls = Deferred} = State) when
    Pending =/= undefined
->
    {noreply, State#state{deferred_calls = Deferred ++ [{info, Info}]}};
handle_info({prune_leaving, Leaving}, #state{dotkeymap = DKM} = State) ->
    lists:map(fun(L) -> vmq_swc_dkm:enforce_prune_for_peer(DKM, L) end, Leaving),
    {noreply, State};
handle_info(do_gc, #state{id = Id, nodeclock = NodeClock, config = Config} = State0) ->
    Watermark = update_watermark_internal(Id, NodeClock, State0),
    UpdateWatermark_DBop = update_watermark_db_op(Watermark),
    db_write(Config, [UpdateWatermark_DBop]),
    State1 = incremental_gc(State0#state{watermark = Watermark}),
    erlang:send_after(application:get_env(vmq_swc, gc_interval, 15000), self(), do_gc),
    {noreply, State1};
handle_info({sync_with, Peer}, #state{config = Config} = State) ->
    %% only used for testing purposes
    vmq_swc_exchange_sup:start_exchange(
        Config, Peer, application:get_env(vmq_swc, sync_timeout, 60000)
    ),
    {noreply, State};
handle_info(sync, #state{config = Config, sync_lock = undefined, peers = Peers} = State) ->
    case random_peer(proplists:get_keys(Peers), fun(N) -> lists:member(N, nodes()) end) of
        {ok, SyncNode} ->
            vmq_swc_exchange_sup:start_exchange(
                Config, SyncNode, application:get_env(vmq_swc, sync_timeout, 60000)
            );
        {error, no_peer_available} ->
            ?LOG_DEBUG("Replica ~p: Can't initialize AE exchange due to no peer available", [
                State#state.group
            ]),
            ignore
    end,
    maybe_schedule_sync(),
    {noreply, State};
handle_info(sync, State) ->
    maybe_schedule_sync(),
    {noreply, State};
handle_info(Info, State) ->
    ?LOG_ERROR("Replica ~p: Received invalid info ~p", [State#state.group, Info]),
    {noreply, State}.

terminate(Reason, #state{watermark = Watermark, nodeclock = NodeClock}) ->
    ?LOG_DEBUG("Store terminating with NodeClock: ~p~n WaterMark: ~p for Reason ~p~n", [
        NodeClock, Watermark, Reason
    ]),
    ok.

code_change(_, _, State) ->
    {ok, State}.

%% INTERNAL

sync_call_timeout() ->
    application:get_env(vmq_swc, sync_timeout, 60000).

fast_call_timeout() ->
    application:get_env(vmq_swc, fast_call_timeout, 5000).

init_sync_key(Group) ->
    {?MODULE, init_sync, Group}.

start_async_db_write(Config, DbOps, From, Reply, #state{db_write_seq = Seq0} = State) ->
    Seq = Seq0 + 1,
    StorePid = self(),
    {Pid, MRef} = spawn_monitor(fun() ->
        Result =
            try
                db_write_batches(Config, DbOps)
            catch
                Class:Reason:Stack ->
                    {error, {Class, Reason, Stack}}
            end,
        StorePid ! {async_db_write_done, Seq, Result}
    end),
    State#state{pending_db_write = {Seq, MRef, Pid, From, Reply}, db_write_seq = Seq}.

drain_deferred_calls(#state{deferred_calls = []} = State) ->
    State;
drain_deferred_calls(#state{deferred_calls = [{call, Request, From} | Rest]} = State0) ->
    State1 = State0#state{deferred_calls = Rest},
    case handle_call(Request, From, State1) of
        {reply, Reply, State2} ->
            gen_server:reply(From, Reply),
            drain_deferred_calls(State2);
        {noreply, State2} ->
            State2
    end;
drain_deferred_calls(#state{deferred_calls = [{cast, Request} | Rest]} = State0) ->
    State1 = State0#state{deferred_calls = Rest},
    case handle_cast(Request, State1) of
        {noreply, State2} ->
            drain_deferred_calls(State2)
    end;
drain_deferred_calls(#state{deferred_calls = [{info, Info} | Rest]} = State0) ->
    State1 = State0#state{deferred_calls = Rest},
    case handle_info(Info, State1) of
        {noreply, State2} ->
            drain_deferred_calls(State2);
        {stop, Reason, State2} ->
            exit({async_db_write_deferred_info_failed, Reason, State2})
    end.

sync_repair_db_ops(RepairType, RemotePeer, RemoteNodeClock, MissingObjects, LastBatch, State0) ->
    RemoteActor = vmq_swc_peer_service_manager:get_actor_for_peer(RemotePeer),
    {DbOps, State1} = fill_strip_save_batch(MissingObjects, RemoteNodeClock, State0),
    case LastBatch of
        false ->
            UpdateNodeClock_DBop = update_nodeclock_db_op(State1#state.nodeclock),
            {[sync_repair_db_ops(RepairType, [UpdateNodeClock_DBop | DbOps])], State1};
        {true, RemoteWatermark} ->
            NodeClock0 = sync_clocks(
                {RemotePeer, RemoteActor}, RemoteNodeClock, State1#state.nodeclock
            ),
            Watermark = update_watermark_after_sync(
                State1#state.watermark,
                RemoteWatermark,
                State1#state.id,
                {RemotePeer, RemoteActor},
                NodeClock0,
                RemoteNodeClock
            ),
            UpdateNodeClock_DBop = update_nodeclock_db_op(NodeClock0),
            UpdateWatermark_DBop = update_watermark_db_op(Watermark),
            State2 = State1#state{watermark = Watermark, nodeclock = NodeClock0},
            RepairDbOps = sync_repair_db_ops(RepairType, [
                UpdateNodeClock_DBop, UpdateWatermark_DBop | DbOps
            ]),
            {GcDbOps, State3} = incremental_gc_db_ops(State2),
            {[RepairDbOps, GcDbOps], State3}
    end.

sync_repair_db_ops(repair, DbOps) ->
    lists:reverse(DbOps);
sync_repair_db_ops(init_repair, DbOps) ->
    DbOps.

db_write_batches(_Config, []) ->
    ok;
db_write_batches(Config, [DbOps | Rest]) ->
    ok = db_write(Config, DbOps),
    db_write_batches(Config, Rest).

set_peers(
    NewPeers,
    #state{id = Id, config = Config, nodeclock = LocalClock0, watermark = WM0} =
        State
) ->
    OldPeers = swc_node:ids(LocalClock0),
    AddedPeers = NewPeers -- OldPeers,
    LeftPeers = OldPeers -- NewPeers,
    MissingWatermarkPeers = NewPeers -- swc_watermark:peers(WM0),

    ?LOG_DEBUG("vmq_swc_store:set_peers/2: AddedPeers ~p~n", [AddedPeers]),
    ?LOG_DEBUG("vmq_swc_store:set_peers/2: LeftPeers ~p~n", [LeftPeers]),

    {NodeClock, Watermark} =
        case {AddedPeers, LeftPeers, MissingWatermarkPeers} of
            {[], [], []} ->
                {LocalClock0, WM0};
            _ ->
                %% Ensure the node clock contains all required peers
                %% Adding {Peer, 0} won't override an existing entry
                TmpClock0 = lists:foldl(
                    fun(Peer, AccClock) -> swc_node:add(AccClock, {Peer, 0}) end,
                    LocalClock0,
                    NewPeers
                ),

                {TmpClock0, fix_watermark(WM0, NewPeers)}
        end,
    case length(LeftPeers) of
        0 -> ignore;
        _ -> self() ! {prune_leaving, LeftPeers}
    end,
    UpdateWatermark_DBop = update_watermark_db_op(Watermark),
    UpdateNodeClock_DBop = update_nodeclock_db_op(NodeClock),

    db_write(Config, [UpdateWatermark_DBop, UpdateNodeClock_DBop]),
    cache_node_clock(State#state{
        nodeclock = NodeClock, watermark = Watermark, peers = NewPeers -- [Id]
    }).

% maybe_retire_peer(WM, OldID, NewID) ->
%     NewWatermark0 = swc_watermark:retire_peer(WM, OldID, NewID),
%     % reset the entire watermark
%     swc_watermark:reset_counters(NewWatermark0).
cache_node_clock(#state{config = #swc_config{store = StoreName}, nodeclock = NodeClock} = State) ->
    ets:insert(StoreName, {node_clock, NodeClock}),
    State.

get_cached_node_clock(#swc_config{store = StoreName}) ->
    [{_, NodeClock}] = ets:lookup(StoreName, node_clock),
    NodeClock.

maybe_get_cached_object(#swc_config{r_o_w_cache = CacheName} = Config, SKey) ->
    case ets:lookup(CacheName, SKey) of
        [] ->
            get_obj_for_key(Config, SKey);
        [{_, Obj}] ->
            Obj
    end.

r_o_w_cache_insert_object(#swc_config{r_o_w_cache = CacheName}, SKey, Obj) ->
    ets:insert(CacheName, {SKey, Obj}).

r_o_w_cache_clear(#swc_config{r_o_w_cache = CacheName}) ->
    ets:delete_all_objects(CacheName).

random_peer([], _Filter) ->
    {error, no_peer_available};
random_peer(Peers, FilterFun) ->
    FilteredPeers = lists:filter(FilterFun, Peers),
    case FilteredPeers of
        [] ->
            {error, no_peer_available};
        _ ->
            {ok, lists:nth(rand:uniform(length(FilteredPeers)), FilteredPeers)}
    end.

fix_watermark({_W, R} = Watermark, Peers) ->
    Watermark0 =
        lists:foldl(
            fun(Peer, WMAcc0) ->
                % This will reset all counters to zero
                WMAcc1 = swc_watermark:add_peer(WMAcc0, Peer, Peers),
                % set the reset counters to its old value,
                % new nodes will have a counter of '
                lists:foldl(
                    fun(P, A) ->
                        swc_watermark:update_cell(A, Peer, P, swc_watermark:get(Watermark, Peer, P))
                    end,
                    WMAcc1,
                    Peers
                )
            end,
            swc_watermark:new(),
            Peers
        ),
    {W1, _} = Watermark0,
    {W1, R}.

update_watermark_internal(RemoteNode, RemoteClock, #state{
    id = Id, watermark = Watermark0, nodeclock = NodeClock
}) ->
    % Store the knowledge the other node has about us
    % update my watermark with what I know, based on my node clock
    Watermark1 = swc_watermark:update_peer(Watermark0, Id, NodeClock),
    % update my watermark with what my peer knows, based on its node clock
    swc_watermark:update_peer(Watermark1, RemoteNode, RemoteClock).

update_watermark_after_sync(Watermark0, RemoteWatermark, Id, RemoteId, NodeClock, RemoteClock) ->
    % update my watermark with what I know, based on my node clock
    Watermark1 = maps:fold(
        fun(I, _, Acc) ->
            case I == Id of
                false -> Acc;
                true -> swc_watermark:update_peer(Acc, I, NodeClock)
            end
        end,
        Watermark0,
        NodeClock
    ),
    % update my watermark with what my peer knows, based on its node clock
    Watermark2 = maps:fold(
        fun(I, _, Acc) ->
            case I == RemoteId of
                false -> Acc;
                true -> swc_watermark:update_peer(Acc, I, RemoteClock)
            end
        end,
        Watermark1,
        RemoteClock
    ),
    % update the watermark to reflect what the asking peer has about its peers
    swc_watermark:left_join(Watermark2, RemoteWatermark).

sync_clocks(RemoteID, RemoteNodeClock0, NodeClock) ->
    % replace the current entry in the node clock for the responding clock with
    % the current knowledge it's receiving
    RemoteNodeClock1 = maps:filter(fun(Id, _) -> Id == RemoteID end, RemoteNodeClock0),
    OldNodes = maybe_find_old_nodes(NodeClock, RemoteNodeClock0),
    RemoteNodeClock2 =
        case OldNodes of
            [] -> RemoteNodeClock1;
            _ -> maps:merge(RemoteNodeClock1, maps:with(OldNodes, RemoteNodeClock0))
        end,
    % the merge will delete all entries, where the dot is {0,0}!
    swc_node:merge(NodeClock, RemoteNodeClock2).

fill_strip_save_batch(
    MissingObjects,
    RemoteNodeClock,
    #state{config = #swc_config{store = _StoreName} = Config, nodeclock = NodeClock0} = State0
) ->
    {NodeClock1, RealMissing} =
        lists:foldl(
            fun({SKey, Obj}, {NodeClockAcc0, AccRealMissing0} = Acc) ->
                % fill the object with the sending node clock
                FilledObj = swc_kv:fill(Obj, RemoteNodeClock),
                % get the local object corresponding to the received object and fill the causal history
                {D1, _} = Local = swc_kv:fill(get_obj_for_key(Config, SKey), NodeClock0),
                % synchronize / merge the remote and local object
                {D2, _} = Synced = swc_kv:sync(FilledObj, Local),
                % filter out the object that is not missing after all
                case (D1 =/= D2) orelse ((map_size(D1) == 0) andalso (map_size(D2) == 0)) of
                    true ->
                        % add each new dot to our node clock
                        NodeClockAcc1 = swc_kv:add(NodeClockAcc0, Synced),
                        MissingObj = {SKey, Synced, Local},
                        {NodeClockAcc1, [MissingObj | AccRealMissing0]};
                    false ->
                        Acc
                end
            end,
            {NodeClock0, []},
            MissingObjects
        ),
    % save the synced objects and strip their causal history
    State1 = State0#state{nodeclock = NodeClock1},
    FinalDBOps = strip_save_batch(RealMissing, [], State1, sync_resp, nil),
    {FinalDBOps, State1}.

strip_save_batch([], DBOps, _State, _DbgCategory, _OriginPid) ->
    DBOps;
strip_save_batch(
    [{SKey, Obj, OldObj} | Rest],
    DBOps0,
    #state{nodeclock = NodeClock, dotkeymap = DKM} = State,
    DbgCategory,
    OriginPid
) ->
    DBOps1 = add_object_to_log(State#state.dotkeymap, SKey, Obj, DBOps0),
    % remove unnecessary causality from the Obj, based on the current node clock
    {Values0, Context} = _StrippedObj0 = swc_kv:strip(Obj, NodeClock),
    Values1 = maps:filter(fun(_D, V) -> V =/= '$deleted' end, Values0),
    StrippedObj1 = {Values1, Context},
    % The resulting Obj is one of the following:
    % 0 - it has no value but has causal history -> it's a delete, but still must be persisted
    % 1 - it has no value and no causal history -> can be deleted
    % 2 - has values, with causal history -> it's a normal write and must be persisted
    % 3 - has values, but no causal history -> it's the final form for this write
    DBOps2 =
        case {map_size(Values1), map_size(Context)} of
            % case 1
            {0, C} when (C == 0) or (State#state.peers == []) ->
                vmq_swc_dkm:mark_for_gc(DKM, SKey),
                event(deleted, SKey, undefined, OldObj, State, OriginPid),
                [delete_obj_db_op(SKey, [DbgCategory, strip_save_batch]) | DBOps1];
            % case 0
            {0, _} ->
                vmq_swc_dkm:mark_for_gc(DKM, SKey),
                event(deleted, SKey, undefined, OldObj, State, OriginPid),
                [update_obj_db_op(SKey, StrippedObj1, [DbgCategory, strip_save_batch]) | DBOps1];
            % case 2 & 3
            _ ->
                event(updated, SKey, StrippedObj1, OldObj, State, OriginPid),
                [update_obj_db_op(SKey, StrippedObj1, [DbgCategory, strip_save_batch]) | DBOps1]
        end,
    strip_save_batch(Rest, DBOps2, State, DbgCategory, OriginPid).

event(Type, SKey, NewObj, OldObj, #state{subscriptions = Subscriptions}, OriginPid) ->
    {FullPrefix, Key} = sext:decode(SKey),
    OldValues = swc_kv:values(OldObj),
    SubsForPrefix = maps:get(FullPrefix, Subscriptions, #{}),
    maps:foreach(
        fun
            (Pid, _) when (FullPrefix == ?RETAIN_DB) andalso (Pid == OriginPid) ->
                %% When originator is vmq_retain_srv of this node, then the
                %% RETAIN_DB is already up-to-date. In this case we must skip the feedback notification event
                %% to prevent corrupting the RETAIN_DB. (= avoid overwriting possible newer updates)
                ok;
            (Pid, {ConvertFun, Opts}) when FullPrefix == ?SUBSCRIBER_DB, Type == deleted ->
                case skip_local_feedback(OriginPid, Opts) of
                    true ->
                        ok;
                    false ->
                        safe_deliver_event(Pid, ConvertFun, {deleted, FullPrefix, Key, OldValues})
                end;
            (Pid, {ConvertFun, Opts}) when FullPrefix == ?SUBSCRIBER_DB, Type == updated ->
                case skip_local_feedback(OriginPid, Opts) of
                    true ->
                        ok;
                    false ->
                        safe_deliver_event(
                            Pid,
                            ConvertFun,
                            {updated, FullPrefix, Key, OldValues, swc_kv:values(NewObj)}
                        )
                end;
            (Pid, {ConvertFun, _Opts}) when Type == deleted ->
                safe_deliver_event(Pid, ConvertFun, {deleted, FullPrefix, Key, OldValues});
            (Pid, {ConvertFun, _Opts}) when Type == updated ->
                safe_deliver_event(
                    Pid,
                    ConvertFun,
                    {updated, FullPrefix, Key, OldValues, swc_kv:values(NewObj)}
                );
            (Pid, ConvertFun) when Type == deleted ->
                safe_deliver_event(Pid, ConvertFun, {deleted, FullPrefix, Key, OldValues});
            (Pid, ConvertFun) when Type == updated ->
                safe_deliver_event(
                    Pid,
                    ConvertFun,
                    {updated, FullPrefix, Key, OldValues, swc_kv:values(NewObj)}
                )
        end,
        SubsForPrefix
    ).

skip_local_feedback(OriginPid, Opts) ->
    OriginPid =/= nil andalso proplists:get_value(skip_local_feedback, Opts, false) == true.

safe_deliver_event(Pid, ConvertFun, Event) ->
    try
        %% so that ConvertFun does not crash the store
        Pid ! ConvertFun(Event)
    catch
        Class:Reason:Stack ->
            ?LOG_WARNING(
                "swc_store event subscriber ~p failed with ~p:~p. dropping event", [
                    Pid, Class, Reason
                ]
            ),
            ?LOG_DEBUG("swc_store event subscriber ~p stacktrace: ~p", [Pid, Stack]),
            ok
    end.

subs_reg_key(StoreName, FullPrefix, Pid) ->
    {StoreName, FullPrefix, Pid}.

subs_reg_upsert(StoreName, FullPrefix, Pid, ConvertFun, Opts) ->
    try
        ets:insert(?SUBS_REGISTRY, {subs_reg_key(StoreName, FullPrefix, Pid), {ConvertFun, Opts}})
    catch
        Class:Reason ->
            ?LOG_WARNING(
                "swc_store failed to insert internal subscriber to ETS (~p/~p): store=~p prefix=~p pid=~p",
                [Class, Reason, StoreName, FullPrefix, Pid]
            ),
            ok
    end.

subs_reg_delete(StoreName, FullPrefix, Pid) ->
    try
        ets:delete(?SUBS_REGISTRY, subs_reg_key(StoreName, FullPrefix, Pid))
    catch
        Class:Reason ->
            ?LOG_WARNING(
                "swc_store failed to delete internal subscriber from ETS (~p/~p): store=~p prefix=~p pid=~p",
                [Class, Reason, StoreName, FullPrefix, Pid]
            ),
            ok
    end.

subs_reg_match_store(StoreName) ->
    try
        ets:match_object(?SUBS_REGISTRY, {{StoreName, '_', '_'}, '_'})
    catch
        Class:Reason ->
            ?LOG_WARNING(
                "swc_store failed to read internal subscriber from ETS (~p/~p): store=~p",
                [Class, Reason, StoreName]
            ),
            []
    end.

restore_subscriptions(StoreName, State0) ->
    Entries = subs_reg_match_store(StoreName),
    {Reg1, Dead} =
        lists:foldl(
            fun({{_Store, FullPrefix, Pid}, Subscription}, {Acc, DeadAcc}) ->
                case is_process_alive(Pid) of
                    true ->
                        PrefixMap0 = maps:get(FullPrefix, Acc, #{}),
                        PrefixMap1 = maps:put(
                            Pid, normalize_subscription(Subscription), PrefixMap0
                        ),
                        {maps:put(FullPrefix, PrefixMap1, Acc), DeadAcc};
                    false ->
                        {Acc, [{FullPrefix, Pid} | DeadAcc]}
                end
            end,
            {#{}, []},
            Entries
        ),
    lists:foreach(fun({FullPrefix, Pid}) -> subs_reg_delete(StoreName, FullPrefix, Pid) end, Dead),
    State0#state{subscriptions = Reg1}.

upsert_subscription(
    FullPrefix, Pid, ConvertFun, Opts, #state{config = #swc_config{store = StoreName}} = State0
) ->
    subs_reg_upsert(StoreName, FullPrefix, Pid, ConvertFun, Opts),
    Subs0 = State0#state.subscriptions,
    PrefixMap0 = maps:get(FullPrefix, Subs0, #{}),
    PrefixMap1 = maps:put(Pid, {ConvertFun, Opts}, PrefixMap0),
    Subs1 = maps:put(FullPrefix, PrefixMap1, Subs0),
    State0#state{subscriptions = Subs1}.

normalize_subscription({ConvertFun, Opts}) when is_function(ConvertFun), is_list(Opts) ->
    {ConvertFun, Opts};
normalize_subscription(ConvertFun) when is_function(ConvertFun) ->
    {ConvertFun, []}.

process_write_op(
    OriginPid,
    {Key, Value, MaybeContext},
    {AccReplicate0, AccDBOps0, #state{config = Config, id = Id, nodeclock = NodeClock0} = State0}
) ->
    % sext encode key
    SKey = sext:encode(Key),
    % get and fill the causal history of the local key
    DiskObj = swc_kv:fill(get_obj_for_key(Config, SKey), NodeClock0),

    Context =
        case MaybeContext of
            undefined ->
                swc_kv:context(DiskObj);
            _ ->
                MaybeContext
        end,

    % discard obsolete values wrt. the causal context
    DiscardObj = swc_kv:discard(DiskObj, Context),
    % generate a new dot for this write/delete and add it to the node clock
    {Counter, NodeClock1} = swc_node:event(NodeClock0, Id),
    % test if this is a delete; if not, add dot-value to the Obj
    NewObj =
        case Value of
            ?DELETED ->
                swc_kv:add(DiscardObj, {Id, Counter}, ?DELETED);
            _ ->
                swc_kv:add(DiscardObj, {Id, Counter}, Value)
        end,
    % save the new k/v and remove unnecessary causal information
    AccDBOps1 = strip_save_batch([{SKey, NewObj, DiskObj}], AccDBOps0, State0, write_op, OriginPid),
    AccReplicate1 = [{SKey, NewObj} | AccReplicate0],
    State1 = State0#state{nodeclock = NodeClock1},
    r_o_w_cache_insert_object(Config, SKey, NewObj),
    {AccReplicate1, AccDBOps1, State1}.

process_replicate_op(
    {SKey, Obj}, {AccDBOps0, #state{config = Config, nodeclock = NodeClock0} = State0}
) ->
    NodeClock1 = swc_kv:add(NodeClock0, Obj),
    State1 = State0#state{nodeclock = NodeClock1},
    % get and fill the causal history of the local key
    DiskObj = swc_kv:fill(get_obj_for_key(Config, SKey), NodeClock0),
    % synchronize both objects
    FinalObj = swc_kv:sync(Obj, DiskObj),
    % save the new object, while stripping the unnecessary causality
    AccDBOps1 = strip_save_batch([{SKey, FinalObj, DiskObj}], AccDBOps0, State0, replicate_op, nil),
    {AccDBOps1, State1}.

add_object_to_log(DKM, SKey, Obj, AccDbOps) ->
    {Dots, _} = Obj,
    maps:fold(
        fun(_Dot = {Id, Counter}, _, Acc) ->
            vmq_swc_dkm:insert(DKM, Id, Counter, SKey) ++ Acc
        end,
        AccDbOps,
        Dots
    ).

enqueue_op_sync(Config, Op) ->
    Ref = make_ref(),
    CallerRef = {self(), Ref},
    vmq_swc_store_batcher:add_to_batch(Config, {CallerRef, Op}),
    %% we'll monitor the store, as this is where the batched operation
    %% is being processed
    MRef = monitor(process, Config#swc_config.store),
    receive
        {Ref, Reply} ->
            demonitor(MRef),
            Reply;
        {'DOWN', MRef, process, _, Reason} ->
            {error, Reason}
    end.

-spec get_obj_for_key(config(), db_key()) -> object().
get_obj_for_key(Config, SKey) ->
    case vmq_swc_db:get(Config, ?DB_OBJ, SKey) of
        {ok, BObj} -> binary_to_term(BObj);
        not_found -> swc_kv:new()
    end.

incremental_gc(
    #state{config = Config} = State0
) ->
    {DBOps, State} = incremental_gc_db_ops(State0),
    db_write(Config, DBOps),
    State.

incremental_gc_db_ops(
    #state{watermark = Watermark, dotkeymap = DKM, nodeclock = NodeClock} = State
) ->
    {vmq_swc_dkm:prune(DKM, Watermark, [], NodeClock), State}.

% -spec remove_logs_for_peer(config(), dotkeymap(), peer()) -> ok.
% remove_logs_for_peer(Config, DKM, Peer) ->
%     DBOps = vmq_swc_dkm:prune_for_peer(DKM, Peer),
%     db_write(Config, DBOps).

-spec init_dotkeymap(config()) -> dotkeymap().
init_dotkeymap(Config) ->
    DKM = vmq_swc_dkm:init(),
    vmq_swc_db:fold(
        Config,
        ?DB_DKM,
        fun(LogKey, SKey, _Acc) ->
            {Id, Counter} = sext:decode(LogKey),
            _ = vmq_swc_dkm:insert(DKM, Id, Counter, SKey)
        end,
        ok
    ),
    vmq_swc_db:fold(
        Config,
        ?DB_OBJ,
        fun(SKey, BVal, _Acc) ->
            {Values, _} = binary_to_term(BVal),
            case map_size(Values) of
                % deleted
                0 ->
                    vmq_swc_dkm:mark_for_gc(DKM, SKey);
                _ ->
                    ignore
            end
        end,
        ok
    ),
    DKM.

dump_tables(Config) ->
    #{
        obj => dump_table(Config, ?DB_OBJ, fun(K) -> sext:decode(K) end, fun(V) ->
            binary_to_term(V)
        end),
        dkm => dump_table(Config, ?DB_DKM, fun(K) -> sext:decode(K) end, fun(V) ->
            sext:decode(V)
        end),
        default => dump_table(Config, ?DB_DEFAULT, fun(K) -> K end, fun(V) -> (V) end)
    }.

dump_table(Config, Type, KeyDecoder, ValDecoder) ->
    {NumItems, KeyBytes, DataBytes, Data} =
        vmq_swc_db:fold(
            Config,
            Type,
            fun(Key, Val, {N, KeySpaceSize, DataSize, Acc}) ->
                {N + 1, byte_size(Key) + KeySpaceSize, byte_size(Val) + DataSize, [
                    {KeyDecoder(Key), ValDecoder(Val)} | Acc
                ]}
            end,
            {0, 0, 0, []}
        ),
    #{n => NumItems, key_memory => KeyBytes, data_memory => DataBytes, data => Data}.

-spec update_obj_db_op(db_key(), object(), any()) -> db_op().
update_obj_db_op(SKey, Obj, _Category) ->
    ?DBG_OP("PUT Obj DB[~p] ~p~n", [_Category, SKey]),
    {?DB_OBJ, SKey, term_to_binary(Obj)}.

-spec delete_obj_db_op(db_key(), any()) -> db_op().
delete_obj_db_op(SKey, _Category) ->
    ?DBG_OP("DEL Obj DB[~p] ~p~n", [_Category, SKey]),
    {?DB_OBJ, SKey, ?DELETED}.

-spec update_nodeclock_db_op(nodeclock()) -> db_op().
update_nodeclock_db_op(NodeClock) ->
    {?DB_DEFAULT, <<"BVV">>, term_to_binary(NodeClock)}.

-spec update_watermark_db_op(watermark()) -> db_op().
update_watermark_db_op(Watermark) ->
    {?DB_DEFAULT, <<"KVV">>, term_to_binary(Watermark)}.

-spec get_nodeclock(config()) -> nodeclock().
get_nodeclock(Config) ->
    case vmq_swc_db:get(Config, ?DB_DEFAULT, <<"BVV">>) of
        {ok, BNodeClock} ->
            NodeClock = binary_to_term(BNodeClock),
            ?LOG_DEBUG("Loaded NodeClock fromDisk ~p~n", [NodeClock]),
            NodeClock;
        not_found ->
            NodeClock0 = swc_node:new(),
            NodeClock0
    end.

-spec get_watermark(config()) -> watermark().
get_watermark(Config) ->
    case vmq_swc_db:get(Config, ?DB_DEFAULT, <<"KVV">>) of
        {ok, BWatermark} -> binary_to_term(BWatermark);
        not_found -> swc_watermark:new()
    end.

-spec db_write(config(), list(db_op())) -> ok.
db_write(_Config, []) ->
    ok;
db_write(Config, DbOps) ->
    vmq_swc_db:put_many(Config, DbOps).

maybe_schedule_sync() ->
    case application:get_env(vmq_swc, sync_interval, {15000, 2500}) of
        0 -> ok;
        {FixedInt, RandInt} -> erlang:send_after(FixedInt + rand:uniform(RandInt), self(), sync)
    end.

maybe_find_old_nodes(NodeClock, RemoteNodeClock) ->
    LocalIds = maps:keys(NodeClock),
    RemoteIds = maps:keys(RemoteNodeClock),
    lists:subtract(RemoteIds, LocalIds).
