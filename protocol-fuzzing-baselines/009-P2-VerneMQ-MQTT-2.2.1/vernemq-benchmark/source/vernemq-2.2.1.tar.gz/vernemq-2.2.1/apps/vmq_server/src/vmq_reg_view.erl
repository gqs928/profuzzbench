%% Copyright 2018 Erlio GmbH Basel Switzerland (http://erl.io)
%% Copyright 2018-2024 Octavo Labs/VerneMQ (https://vernemq.com/)
%% and Individual Contributors.
%% Licensed under the Apache License, Version 2.0 (the "License");
%% you may not use this file except in compliance with the License.
%% You may obtain a copy of the License at
%%
%%     http://www.apache.org/licenses/LICENSE-2.0
%%
%% Unless required by applicable law or agreed to in writing, software
%% distributed under the License is distributed on an "AS IS" BASIS,
%% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%% See the License for the specific language governing permissions and
%% limitations under the License.

-module(vmq_reg_view).
-include("vmq_server.hrl").

-export([fold/5, update_subscriber/4, update_subscriber_changes/4]).

-callback fold(
    SubscriberId :: subscriber_id(),
    Topic :: topic(),
    FoldFun :: reg_view_fold_fun(),
    Accumulator :: any()
) -> any().
-callback update_subscriber(
    SubscriberId :: subscriber_id(),
    OldSubs :: vmq_subscriber:subs(),
    NewSubs :: vmq_subscriber:subs()
) -> ok.
-callback update_subscriber_changes(
    SubscriberId :: subscriber_id(),
    ToRemove :: vmq_subscriber:changes(),
    ToAdd :: vmq_subscriber:changes()
) -> ok.

fold(RegView, SubscriberId, Topic, FoldFun, Acc) ->
    RegView:fold(SubscriberId, Topic, FoldFun, Acc).

update_subscriber(RegView, SubscriberId, OldSubs, NewSubs) ->
    RegView:update_subscriber(SubscriberId, OldSubs, NewSubs).

update_subscriber_changes(RegView, SubscriberId, ToRemove, ToAdd) ->
    RegView:update_subscriber_changes(SubscriberId, ToRemove, ToAdd).
