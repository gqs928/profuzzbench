%% Copyright 2018 Erlio GmbH Basel Switzerland (http://erl.io)
%% Copyright 2018-2024 Octavo Labs/VerneMQ (https://vernemq.com/)
%% and Individual Contributors.
%% Licensed under the Apache License, Version 2.0 (the "License");
%% you may not use this file except in compliance with the License.
%% You may obtain a copy of the License at
%%
%%     http://www.apache.org/licenses/LICENSE-2.0
%%
%% Unless required by applicable law or agreed to in writing, software
%% distributed under the License is distributed on an "AS IS" BASIS,
%% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%% See the License for the specific language governing permissions and
%% limitations under the License.

-module(vmq_subscriber_db).
-include("vmq_server.hrl").

-export([
    store/2,
    read/1, read/2,
    fold/2,
    delete/1,
    subscribe_db_events/0,
    subscribe_db_events/1
]).

-define(SUBSCRIBER_DB, {vmq, subscriber}).
-define(TOMBSTONE, '$deleted').

-spec store(subscriber_id(), vmq_subscriber:subs()) -> ok.
store(SubscriberId, Subs) ->
    vmq_metadata:put(?SUBSCRIBER_DB, SubscriberId, Subs).

-spec read(subscriber_id()) -> undefined | vmq_subscriber:subs().
read(SubscriberId) ->
    read(SubscriberId, undefined).

-spec read(subscriber_id(), any()) -> any() | vmq_subscriber:subs().
read(SubscriberId, Default) ->
    case vmq_metadata:get(?SUBSCRIBER_DB, SubscriberId) of
        undefined -> Default;
        Subs -> Subs
    end.

-spec delete(subscriber_id()) -> ok.
delete(SubscriberId) ->
    vmq_metadata:delete(?SUBSCRIBER_DB, SubscriberId).

fold(FoldFun, Acc) ->
    vmq_metadata:fold(
        ?SUBSCRIBER_DB,
        fun
            ({_, ?TOMBSTONE}, AccAcc) -> AccAcc;
            ({SubscriberId, Subs}, AccAcc) -> FoldFun({SubscriberId, Subs}, AccAcc)
        end,
        Acc
    ).

subscribe_db_events() ->
    subscribe_db_events([]).

subscribe_db_events(Opts) ->
    vmq_metadata:subscribe(?SUBSCRIBER_DB, Opts),
    fun
        ({deleted, ?SUBSCRIBER_DB, _, Val}) when
            (Val == ?TOMBSTONE) or (Val == undefined)
        ->
            ignore;
        ({deleted, ?SUBSCRIBER_DB, SubscriberId, Subscriptions}) ->
            {delete, SubscriberId, Subscriptions};
        ({updated, ?SUBSCRIBER_DB, SubscriberId, OldVal, NewSubs}) when
            (OldVal == ?TOMBSTONE) or (OldVal == undefined)
        ->
            {update, SubscriberId, [], NewSubs};
        ({updated, ?SUBSCRIBER_DB, SubscriberId, OldSubs, NewSubs}) ->
            {update, SubscriberId, OldSubs, NewSubs};
        (_) ->
            ignore
    end.
