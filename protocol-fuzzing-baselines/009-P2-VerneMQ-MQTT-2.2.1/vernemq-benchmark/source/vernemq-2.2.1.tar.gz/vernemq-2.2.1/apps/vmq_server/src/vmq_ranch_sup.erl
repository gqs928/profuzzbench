%% Copyright 2018 Octavo Labs AG Basel Switzerland (http://octavolabs.com)
%% Copyright 2018-2024 Octavo Labs/VerneMQ (https://vernemq.com/)
%% and Individual Contributors.
%% Licensed under the Apache License, Version 2.0 (the "License");
%% you may not use this file except in compliance with the License.
%% You may obtain a copy of the License at
%%
%%     http://www.apache.org/licenses/LICENSE-2.0
%%
%% Unless required by applicable law or agreed to in writing, software
%% distributed under the License is distributed on an "AS IS" BASIS,
%% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%% See the License for the specific language governing permissions and
%% limitations under the License.
-module(vmq_ranch_sup).

-behaviour(supervisor).

%% API
-export([start_link/0, active_mqtt_connections/0]).

%% Supervisor callbacks
-export([init/1]).

-define(SERVER, ?MODULE).

%%%===================================================================
%%% API functions
%%%===================================================================

active_mqtt_connections() ->
    lists:foldl(
        fun
            % Unix sockets will also be counted under "mqtt"
            ({mqtt, _, _, _, _, _, Active, _}, {MQTT, WS}) ->
                {MQTT + Active, WS};
            ({mqtts, _, _, _, _, _, Active, _}, {MQTT, WS}) ->
                {MQTT + Active, WS};
            ({mqttws, _, _, _, _, _, _, All}, {MQTT, WS}) ->
                {MQTT, WS + All};
            ({mqttwss, _, _, _, _, _, _, All}, {MQTT, WS}) ->
                {MQTT, WS + All};
            (_, Sum) ->
                Sum
        end,
        {0, 0},
        vmq_ranch_config:listeners()
    ).

%%--------------------------------------------------------------------
%% @doc
%% Starts the supervisor
%% @end
%%--------------------------------------------------------------------
-spec start_link() ->
    {ok, Pid :: pid()}
    | {error, {already_started, Pid :: pid()}}
    | {error, {shutdown, term()}}
    | {error, term()}
    | ignore.
start_link() ->
    supervisor:start_link({local, ?SERVER}, ?MODULE, []).

%%%===================================================================
%%% Supervisor callbacks
%%%===================================================================

%%--------------------------------------------------------------------
%% @private
%% @doc
%% Whenever a supervisor is started using supervisor:start_link/[2,3],
%% this function is called by the new process to find out about
%% restart strategy, maximum restart intensity, and child
%% specifications.
%% @end
%%--------------------------------------------------------------------
-spec init(Args :: term()) ->
    {ok, {SupFlags :: supervisor:sup_flags(), [ChildSpec :: supervisor:child_spec()]}}
    | ignore.
init([]) ->
    SupFlags = #{
        strategy => one_for_one,
        intensity => 1,
        period => 5
    },

    ChildSpecs =
        [
            #{
                id => vmq_ranch_config,
                start => {vmq_ranch_config, start_link, []},
                restart => permanent,
                shutdown => 5000,
                type => worker,
                modules => [vmq_ranch_config]
            }

            %% TODO: Add ranch supervisor here after we've moved to
            %% Cowboy 2.0 and
        ],

    {ok, {SupFlags, ChildSpecs}}.

%%%===================================================================
%%% Internal functions
%%%===================================================================
