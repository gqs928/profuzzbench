// File created from src/hooks/dhcp/lease_cmds/lease_cmds_messages.mes

#ifndef LEASE_CMDS_MESSAGES_H
#define LEASE_CMDS_MESSAGES_H

#include <log/message_types.h>

extern const isc::log::MessageID LEASE_CMDS_ADD4;
extern const isc::log::MessageID LEASE_CMDS_ADD4_CONFLICT;
extern const isc::log::MessageID LEASE_CMDS_ADD4_FAILED;
extern const isc::log::MessageID LEASE_CMDS_ADD6;
extern const isc::log::MessageID LEASE_CMDS_ADD6_CONFLICT;
extern const isc::log::MessageID LEASE_CMDS_ADD6_FAILED;
extern const isc::log::MessageID LEASE_CMDS_BULK_APPLY6;
extern const isc::log::MessageID LEASE_CMDS_BULK_APPLY6_FAILED;
extern const isc::log::MessageID LEASE_CMDS_DEINIT_OK;
extern const isc::log::MessageID LEASE_CMDS_DEL4;
extern const isc::log::MessageID LEASE_CMDS_DEL4_FAILED;
extern const isc::log::MessageID LEASE_CMDS_DEL6;
extern const isc::log::MessageID LEASE_CMDS_DEL6_FAILED;
extern const isc::log::MessageID LEASE_CMDS_GET4_FAILED;
extern const isc::log::MessageID LEASE_CMDS_GET6_FAILED;
extern const isc::log::MessageID LEASE_CMDS_INIT_OK;
extern const isc::log::MessageID LEASE_CMDS_LEASE4_OFFER_FAILED;
extern const isc::log::MessageID LEASE_CMDS_LEASES4_COMMITTED_FAILED;
extern const isc::log::MessageID LEASE_CMDS_LEASES6_COMMITTED_CONFLICT;
extern const isc::log::MessageID LEASE_CMDS_LEASES6_COMMITTED_FAILED;
extern const isc::log::MessageID LEASE_CMDS_LEASES6_COMMITTED_LEASE_ERROR;
extern const isc::log::MessageID LEASE_CMDS_LOAD_ERROR;
extern const isc::log::MessageID LEASE_CMDS_PATH_SECURITY_WARNING;
extern const isc::log::MessageID LEASE_CMDS_RESEND_DDNS4;
extern const isc::log::MessageID LEASE_CMDS_RESEND_DDNS4_FAILED;
extern const isc::log::MessageID LEASE_CMDS_RESEND_DDNS6;
extern const isc::log::MessageID LEASE_CMDS_RESEND_DDNS6_FAILED;
extern const isc::log::MessageID LEASE_CMDS_UPDATE4;
extern const isc::log::MessageID LEASE_CMDS_UPDATE4_CONFLICT;
extern const isc::log::MessageID LEASE_CMDS_UPDATE4_FAILED;
extern const isc::log::MessageID LEASE_CMDS_UPDATE6;
extern const isc::log::MessageID LEASE_CMDS_UPDATE6_CONFLICT;
extern const isc::log::MessageID LEASE_CMDS_UPDATE6_FAILED;
extern const isc::log::MessageID LEASE_CMDS_WIPE4;
extern const isc::log::MessageID LEASE_CMDS_WIPE4_FAILED;
extern const isc::log::MessageID LEASE_CMDS_WIPE6;
extern const isc::log::MessageID LEASE_CMDS_WIPE6_FAILED;
extern const isc::log::MessageID SFLQ_POOL4_DEL;
extern const isc::log::MessageID SFLQ_POOL4_DEL_FAILED;
extern const isc::log::MessageID SFLQ_POOL4_GET_ALL;
extern const isc::log::MessageID SFLQ_POOL4_GET_ALL_FAILED;
extern const isc::log::MessageID SFLQ_POOL4_GET_BY_RANGE;
extern const isc::log::MessageID SFLQ_POOL4_GET_BY_RANGE_FAILED;
extern const isc::log::MessageID SFLQ_POOL4_GET_BY_SUBNET;
extern const isc::log::MessageID SFLQ_POOL4_GET_BY_SUBNET_FAILED;
extern const isc::log::MessageID SFLQ_POOL4_REBUILD;
extern const isc::log::MessageID SFLQ_POOL4_REBUILD_FAILED;
extern const isc::log::MessageID SFLQ_POOL6_DEL;
extern const isc::log::MessageID SFLQ_POOL6_DEL_FAILED;
extern const isc::log::MessageID SFLQ_POOL6_GET_ALL;
extern const isc::log::MessageID SFLQ_POOL6_GET_ALL_FAILED;
extern const isc::log::MessageID SFLQ_POOL6_GET_BY_RANGE;
extern const isc::log::MessageID SFLQ_POOL6_GET_BY_RANGE_FAILED;
extern const isc::log::MessageID SFLQ_POOL6_GET_BY_SUBNET;
extern const isc::log::MessageID SFLQ_POOL6_GET_BY_SUBNET_FAILED;
extern const isc::log::MessageID SFLQ_POOL6_REBUILD;
extern const isc::log::MessageID SFLQ_POOL6_REBUILD_FAILED;

#endif // LEASE_CMDS_MESSAGES_H
