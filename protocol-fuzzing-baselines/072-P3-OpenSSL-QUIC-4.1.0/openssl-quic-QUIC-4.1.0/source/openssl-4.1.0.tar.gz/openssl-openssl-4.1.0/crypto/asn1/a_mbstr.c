/*
 * Copyright 1999-2026 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the Apache License 2.0 (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#include <stdio.h>
#include "crypto/ctype.h"
#include "internal/cryptlib.h"
#include "internal/unicode.h"
#include <openssl/asn1.h>
#include <openssl/byteorder.h>

#include <crypto/asn1.h>

static int traverse_string(const unsigned char *p, int len, int inform,
    int (*rfunc)(uint32_t value, void *in),
    void *arg);
static int in_utf8(uint32_t value, void *arg);
static int out_utf8(uint32_t value, void *arg);
static int type_str(uint32_t value, void *arg);
static int cpy_asc(uint32_t value, void *arg);
static int cpy_bmp(uint32_t value, void *arg);
static int cpy_univ(uint32_t value, void *arg);
static int cpy_utf8(uint32_t value, void *arg);

/*
 * These functions take a string in UTF8, ASCII or multibyte form and a mask
 * of permissible ASN1 string types. It then works out the minimal type
 * (using the order Numeric < Printable < IA5 < T61 < BMP < Universal < UTF8)
 * and creates a string of the correct type with the supplied data. Yes this is
 * horrible: it has to be :-( The 'ncopy' form checks minimum and maximum
 * size limits too.
 */

int ASN1_mbstring_copy(ASN1_STRING **out, const unsigned char *in, int len,
    int inform, unsigned long mask)
{
    return ASN1_mbstring_ncopy(out, in, len, inform, mask, 0, 0);
}

int ASN1_mbstring_ncopy(ASN1_STRING **out, const unsigned char *in, int len,
    int inform, unsigned long mask_in,
    long minsize, long maxsize)
{
    int str_type;
    int ret;
    char free_out;
    int outform, outlen = 0;
    ASN1_STRING *dest;
    unsigned char *p;
    int nchar;
    uint32_t mask = (uint32_t)mask_in;
    int (*cpyfunc)(uint32_t, void *) = NULL;
    if (len == -1) {
        size_t len_s = strlen((const char *)in);

        if (len_s >= INT_MAX) {
            ERR_raise(ERR_LIB_ASN1, ASN1_R_STRING_TOO_LONG);
            return -1;
        }
        len = (int)len_s;
    }
    if (!mask)
        mask = DIRSTRING_TYPE;
    if (len < 0) {
        ERR_raise(ERR_LIB_ASN1, ERR_R_PASSED_INVALID_ARGUMENT);
        return -1;
    } else if (len >= INT_MAX) {
        ERR_raise(ERR_LIB_ASN1, ASN1_R_STRING_TOO_LONG);
        return -1;
    }

    /* First do a string check and work out the number of characters */
    switch (inform) {

    case MBSTRING_BMP:
        if (len & 1) {
            ERR_raise(ERR_LIB_ASN1, ASN1_R_INVALID_BMPSTRING_LENGTH);
            return -1;
        }
        nchar = len >> 1;
        break;

    case MBSTRING_UNIV:
        if (len & 3) {
            ERR_raise(ERR_LIB_ASN1, ASN1_R_INVALID_UNIVERSALSTRING_LENGTH);
            return -1;
        }
        nchar = len >> 2;
        break;

    case MBSTRING_UTF8:
        nchar = 0;
        /* This counts the characters and does utf8 syntax checking */
        ret = traverse_string(in, len, MBSTRING_UTF8, in_utf8, &nchar);
        if (ret < 0) {
            ERR_raise(ERR_LIB_ASN1, ASN1_R_INVALID_UTF8STRING);
            return -1;
        }
        break;

    case MBSTRING_ASC:
        nchar = len;
        break;

    default:
        ERR_raise(ERR_LIB_ASN1, ASN1_R_UNKNOWN_FORMAT);
        return -1;
    }

    if ((minsize > 0) && (nchar < minsize)) {
        ERR_raise_data(ERR_LIB_ASN1, ASN1_R_STRING_TOO_SHORT,
            "minsize=%ld", minsize);
        return -1;
    }

    if ((maxsize > 0) && (nchar > maxsize)) {
        ERR_raise_data(ERR_LIB_ASN1, ASN1_R_STRING_TOO_LONG,
            "maxsize=%ld", maxsize);
        return -1;
    }

    /* Now work out minimal type (if any) */
    if (traverse_string(in, len, inform, type_str, &mask) < 0) {
        ERR_raise(ERR_LIB_ASN1, ASN1_R_ILLEGAL_CHARACTERS);
        return -1;
    }

    /*
     * Now work out output format and string type.
     * These checks should be in sync with the checks in type_str.
     */
    outform = MBSTRING_ASC;
    if (mask & B_ASN1_NUMERICSTRING)
        str_type = V_ASN1_NUMERICSTRING;
    else if (mask & B_ASN1_PRINTABLESTRING)
        str_type = V_ASN1_PRINTABLESTRING;
    else if (mask & B_ASN1_IA5STRING)
        str_type = V_ASN1_IA5STRING;
    else if (mask & B_ASN1_T61STRING)
        str_type = V_ASN1_T61STRING;
    else if (mask & B_ASN1_BMPSTRING) {
        str_type = V_ASN1_BMPSTRING;
        outform = MBSTRING_BMP;
    } else if (mask & B_ASN1_UNIVERSALSTRING) {
        str_type = V_ASN1_UNIVERSALSTRING;
        outform = MBSTRING_UNIV;
    } else {
        str_type = V_ASN1_UTF8STRING;
        outform = MBSTRING_UTF8;
    }
    if (!out)
        return str_type;
    if (*out) {
        free_out = 0;
        dest = *out;
        ASN1_STRING_set0(dest, NULL, 0);
        dest->type = str_type;
    } else {
        free_out = 1;
        dest = ASN1_STRING_type_new(str_type);
        if (dest == NULL) {
            ERR_raise(ERR_LIB_ASN1, ERR_R_ASN1_LIB);
            return -1;
        }
        *out = dest;
    }
    /* If both the same type just copy across */
    if (inform == outform) {
        if ((p = OPENSSL_malloc((size_t)len + 1)) == NULL) {
            if (free_out) {
                ASN1_STRING_free(dest);
                *out = NULL;
            }
            return -1;
        }
        if (len > 0)
            memcpy(p, in, (size_t)len);
        p[len] = '\0';
        dest->data = p;
        dest->length = len;
        return str_type;
    }

    /* Work out how much space the destination will need */
    switch (outform) {
    case MBSTRING_ASC:
        outlen = nchar;
        cpyfunc = cpy_asc;
        break;

    case MBSTRING_BMP:
        if (nchar > INT_MAX / 2) {
            ERR_raise(ERR_LIB_ASN1, ASN1_R_STRING_TOO_LONG);
            if (free_out) {
                ASN1_STRING_free(dest);
                *out = NULL;
            }
            return -1;
        }
        outlen = nchar << 1;
        cpyfunc = cpy_bmp;
        break;

    case MBSTRING_UNIV:
        if (nchar > INT_MAX / 4) {
            ERR_raise(ERR_LIB_ASN1, ASN1_R_STRING_TOO_LONG);
            if (free_out) {
                ASN1_STRING_free(dest);
                *out = NULL;
            }
            return -1;
        }
        outlen = nchar << 2;
        cpyfunc = cpy_univ;
        break;

    case MBSTRING_UTF8:
        outlen = 0;
        ret = traverse_string(in, len, inform, out_utf8, &outlen);
        if (ret < 0) { /* error already raised in out_utf8() */
            if (free_out) {
                ASN1_STRING_free(dest);
                *out = NULL;
            }
            return -1;
        }
        cpyfunc = cpy_utf8;
        break;
    }
    if ((p = OPENSSL_malloc(outlen + 1)) == NULL) {
        if (free_out) {
            ASN1_STRING_free(dest);
            *out = NULL;
        }
        return -1;
    }
    dest->length = outlen;
    dest->data = p;
    p[outlen] = 0;
    traverse_string(in, len, inform, cpyfunc, &p);
    return str_type;
}

/*
 * This function traverses a string and passes the value of each character to
 * an optional function along with a void * argument.
 */

static int traverse_string(const unsigned char *p, int len, int inform,
    int (*rfunc)(uint32_t value, void *in),
    void *arg)
{
    uint32_t value;
    int ret;
    while (len) {
        if (inform == MBSTRING_ASC) {
            value = *p++;
            len--;
        } else if (inform == MBSTRING_BMP) {
            uint16_t tmp;
            p = OPENSSL_load_u16_be(&tmp, p);
            value = tmp;
            len -= 2;
        } else if (inform == MBSTRING_UNIV) {
            p = OPENSSL_load_u32_be(&value, p);
            len -= 4;
        } else {
            ret = ossl_utf8_getc_internal(p, len, &value);
            if (ret < 0)
                return -1;
            len -= ret;
            p += ret;
        }
        if (rfunc) {
            ret = rfunc(value, arg);
            if (ret <= 0)
                return ret;
        }
    }
    return 1;
}

/* Various utility functions for traverse_string */

/* Just count number of characters */

static int in_utf8(uint32_t value, void *arg)
{
    int *nchar;

    if (!is_unicode_valid(value))
        return -2;
    nchar = arg;
    (*nchar)++;
    return 1;
}

/* Determine size of output as a UTF8 String */

static int out_utf8(uint32_t value, void *arg)
{
    int *outlen, len;

    len = ossl_utf8_putc_internal(NULL, -1, value);
    if (len <= 0) {
        ERR_raise(ERR_LIB_ASN1, ASN1_R_INVALID_UTF8STRING);
        return len;
    }
    outlen = arg;
    if (*outlen >= INT_MAX - len) {
        ERR_raise(ERR_LIB_ASN1, ASN1_R_STRING_TOO_LONG);
        return -1;
    }
    *outlen += len;
    return 1;
}

/*
 * Determine the "type" of a string: check each character against a supplied
 * "mask".
 */

static int type_str(uint32_t value, void *arg)
{
    uint32_t usable_types = *((uint32_t *)arg);
    uint32_t types = usable_types;
    const int native = value > INT_MAX ? INT_MAX : ossl_fromascii(value);

    /*
     * Clear out all the types which are not checked later. If any of those
     * is present in the mask, then the UTF8 type will be added and checked
     * below.
     */
    types &= B_ASN1_NUMERICSTRING | B_ASN1_PRINTABLESTRING
        | B_ASN1_IA5STRING | B_ASN1_T61STRING | B_ASN1_BMPSTRING
        | B_ASN1_UNIVERSALSTRING | B_ASN1_UTF8STRING;

    /*
     * If any other types were in the input mask, they're effectively treated
     * as UTF8
     */
    if (types != usable_types)
        types |= B_ASN1_UTF8STRING;

    /*
     * These checks should be in sync with ASN1_mbstring_ncopy.
     */
    if ((types & B_ASN1_NUMERICSTRING) && !(ossl_isdigit(native) || native == ' '))
        types &= ~B_ASN1_NUMERICSTRING;
    if ((types & B_ASN1_PRINTABLESTRING) && !ossl_isasn1print(native))
        types &= ~B_ASN1_PRINTABLESTRING;
    if ((types & B_ASN1_IA5STRING) && !ossl_isascii(native))
        types &= ~B_ASN1_IA5STRING;
    if ((types & B_ASN1_T61STRING) && (value > 0xff))
        types &= ~B_ASN1_T61STRING;
    if ((types & B_ASN1_BMPSTRING) && (value > 0xffff))
        types &= ~B_ASN1_BMPSTRING;
    if ((types & B_ASN1_UTF8STRING) && !is_unicode_valid(value))
        types &= ~B_ASN1_UTF8STRING;
    if (!types)
        return -1;
    *((uint32_t *)arg) = types;
    return 1;
}

/* Copy one byte per character ASCII like strings */

static int cpy_asc(uint32_t value, void *arg)
{
    unsigned char **p, *q;
    p = arg;
    q = *p;
    *q = (unsigned char)value;
    (*p)++;
    return 1;
}

/* Copy two byte per character BMPStrings */

static int cpy_bmp(uint32_t value, void *arg)
{
    unsigned char **p, *q;
    p = arg;
    q = *p;
    *q++ = (unsigned char)((value >> 8) & 0xff);
    *q = (unsigned char)(value & 0xff);
    *p += 2;
    return 1;
}

/* Copy four byte per character UniversalStrings */

static int cpy_univ(uint32_t value, void *arg)
{
    unsigned char **p, *q;
    p = arg;
    q = *p;
    *q++ = (unsigned char)((value >> 24) & 0xff);
    *q++ = (unsigned char)((value >> 16) & 0xff);
    *q++ = (unsigned char)((value >> 8) & 0xff);
    *q = (unsigned char)(value & 0xff);
    *p += 4;
    return 1;
}

/* Copy to a UTF8String */

static int cpy_utf8(uint32_t value, void *arg)
{
    unsigned char **p;
    int ret;
    p = arg;
    /* We already know there is enough room so pass 0xff as the length */
    ret = ossl_utf8_putc_internal(*p, 0xff, value);
    if (ret < 0)
        return ret;
    *p += ret;
    return 1;
}
