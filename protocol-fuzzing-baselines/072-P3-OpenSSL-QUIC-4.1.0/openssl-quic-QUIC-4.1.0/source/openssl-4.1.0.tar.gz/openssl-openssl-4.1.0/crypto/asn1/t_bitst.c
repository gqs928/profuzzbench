/*
 * Copyright 1999-2026 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the Apache License 2.0 (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#include <stdio.h>
#include "internal/cryptlib.h"
#include <openssl/conf.h>
#include <openssl/x509v3.h>

#if !defined(OPENSSL_NO_DEPRECATED_4_1)
OSSL_BEGIN_ALLOW_DEPRECATED
int ASN1_BIT_STRING_name_print(BIO *out, ASN1_BIT_STRING *bs,
    BIT_STRING_BITNAME *tbl, int indent)
{
    BIT_STRING_BITNAME *bnam;
    char first = 1;
    int last_seen_bit = -1;

    if (BIO_printf(out, "%*s", indent, "") < 0)
        return 0;
    for (bnam = tbl; bnam->lname; bnam++) {
        /*
         * Skip duplicate entries for the same bit in the BIT_STRING_BITNAME
         * table. Those are aliases, but we only want to print the first entry
         * when converting to a string.
         */
        if (last_seen_bit == bnam->bitnum)
            continue;
        last_seen_bit = bnam->bitnum;

        if (ASN1_BIT_STRING_get_bit(bs, bnam->bitnum)) {
            if (!first)
                if (BIO_puts(out, ", ") < 1)
                    return 0;
            if (BIO_puts(out, bnam->lname) < 1)
                return 0;
            first = 0;
        }
    }
    if (BIO_puts(out, "\n") < 1)
        return 0;
    return 1;
}

int ASN1_BIT_STRING_set_asc(ASN1_BIT_STRING *bs, const char *name, int value,
    BIT_STRING_BITNAME *tbl)
{
    int bitnum;
    bitnum = ASN1_BIT_STRING_num_asc(name, tbl);
    if (bitnum < 0)
        return 0;
    if (bs) {
        if (!ASN1_BIT_STRING_set_bit(bs, bitnum, value))
            return 0;
    }
    return 1;
}

int ASN1_BIT_STRING_num_asc(const char *name, BIT_STRING_BITNAME *tbl)
{
    BIT_STRING_BITNAME *bnam;
    for (bnam = tbl; bnam->lname; bnam++) {
        if ((strcmp(bnam->sname, name) == 0)
            || (strcmp(bnam->lname, name) == 0))
            return bnam->bitnum;
    }
    return -1;
}
OSSL_END_ALLOW_DEPRECATED
#endif /* !defined(OPENSSL_NO_DEPRECATED_4_1) */
