%%%----------------------------------------------------------------------
%%%
%%% ejabberd, Copyright (C) 2002-2026   ProcessOne
%%%
%%% This program is free software; you can redistribute it and/or
%%% modify it under the terms of the GNU General Public License as
%%% published by the Free Software Foundation; either version 2 of the
%%% License, or (at your option) any later version.
%%%
%%% This program is distributed in the hope that it will be useful,
%%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
%%% General Public License for more details.
%%%
%%% You should have received a copy of the GNU General Public License along
%%% with this program; if not, write to the Free Software Foundation, Inc.,
%%% 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
%%%
%%%----------------------------------------------------------------------

-record(room_version,
        {id :: binary(),
         %% use the same field names as in Synapse
         enforce_key_validity :: boolean(),
         special_case_aliases_auth :: boolean(),
         strict_canonicaljson :: boolean(),
         limit_notifications_power_levels :: boolean(),
         knock_join_rule :: boolean(),
         restricted_join_rule :: boolean(),
         restricted_join_rule_fix :: boolean(),
         knock_restricted_join_rule :: boolean(),
         enforce_int_power_levels :: boolean(),
         implicit_room_creator :: boolean(),
         updated_redaction_rules :: boolean(),
         hydra :: boolean()
        }).
