%%%----------------------------------------------------------------------
%%% ejabberd, Copyright (C) 2002-2026   ProcessOne
%%%
%%% This program is free software; you can redistribute it and/or
%%% modify it under the terms of the GNU General Public License as
%%% published by the Free Software Foundation; either version 2 of the
%%% License, or (at your option) any later version.
%%%
%%% This program is distributed in the hope that it will be useful,
%%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
%%% General Public License for more details.
%%%
%%% You should have received a copy of the GNU General Public License along
%%% with this program; if not, write to the Free Software Foundation, Inc.,
%%% 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
%%%
%%%----------------------------------------------------------------------
-module(mod_pubsub_mnesia).

%% API
-export([init/3]).

-export([serialize/3]).

%%%===================================================================
%%% API
%%%===================================================================
init(Host, ServerHost, Opts) ->
    pubsub_index:init(Host, ServerHost, Opts).

%%%===================================================================
%%% Internal functions
%%%===================================================================

-spec serialize(binary(), non_neg_integer(), undefined | term()) ->
               {ok, [term()], term()} | {error, iolist()}.
 serialize(Host, BatchSize, Last) ->
     mod_pubsub:serialize_service(Host, BatchSize, Last).

