#!/bin/sh

echo "===== Remove old keytabs"

rm -f /var/lib/secret/kafka.keytab > /dev/null 2>&1
rm -f /var/lib/secret/rig.keytab > /dev/null 2>&1

rm -f /var/lib/secret/erlang.keytab > /dev/null 2>&1
rm -f /var/lib/secret/krb_authn_cli.keytab > /dev/null 2>&1

echo "===== Prepare log directory"

mkdir -p /var/log/kerberos || true

echo "===== Create realm"

kdb5_util -P emqx -r KDC.EMQX.NET create -s

echo "===== Add principals"

kadmin.local -w password -q "add_principal -randkey kafka/kafka-1.emqx.net@KDC.EMQX.NET"
kadmin.local -w password -q "add_principal -randkey kafka/kafka-2.emqx.net@KDC.EMQX.NET"
kadmin.local -w password -q "add_principal -randkey rig@KDC.EMQX.NET" 

# For Kerberos Authn
kadmin.local -w password -q "add_principal -randkey mqtt/erlang.emqx.net@KDC.EMQX.NET"
kadmin.local -w password -q "add_principal -randkey krb_authn_cli@KDC.EMQX.NET" 

echo "===== Create keytabs"

kadmin.local -w password -q "ktadd  -k /var/lib/secret/kafka.keytab -norandkey kafka/kafka-1.emqx.net@KDC.EMQX.NET "
kadmin.local -w password -q "ktadd  -k /var/lib/secret/kafka.keytab -norandkey kafka/kafka-2.emqx.net@KDC.EMQX.NET "
kadmin.local -w password -q "ktadd  -k /var/lib/secret/rig.keytab -norandkey rig@KDC.EMQX.NET "

# For Kerberos Authn
kadmin.local -w password -q "ktadd  -k /var/lib/secret/erlang.keytab -norandkey mqtt/erlang.emqx.net@KDC.EMQX.NET "
kadmin.local -w password -q "ktadd  -k /var/lib/secret/krb_authn_cli.keytab -norandkey krb_authn_cli@KDC.EMQX.NET "

# Test containers read these keytabs as non-root users.
# ktadd creates the keytabs with mode 0600 and owner root.
# The chown below runs only when DOCKER_USER is set, and a consumer
# can open a keytab before the chown runs or with a different uid.
# chmod keeps the keytabs readable for every consumer.
chmod a+r /var/lib/secret/*.keytab

echo "===== Dump logs"

for fn in /var/log/kerberos/* ; do
  echo "----- $fn"
  cat "$fn"
done

if [ -n "${DOCKER_USER}" ] && [ "${DOCKER_USER}" != "root" ] ; then
echo "===== Changing keytabs ownership"
chown "${DOCKER_USER}" /var/lib/secret/erlang.keytab
chown "${DOCKER_USER}" /var/lib/secret/kafka.keytab
chown "${DOCKER_USER}" /var/lib/secret/krb_authn_cli.keytab
chown "${DOCKER_USER}" /var/lib/secret/rig.keytab
ls -la /var/lib/secret
fi

echo "===== STARTING KDC"
/usr/sbin/krb5kdc -n
