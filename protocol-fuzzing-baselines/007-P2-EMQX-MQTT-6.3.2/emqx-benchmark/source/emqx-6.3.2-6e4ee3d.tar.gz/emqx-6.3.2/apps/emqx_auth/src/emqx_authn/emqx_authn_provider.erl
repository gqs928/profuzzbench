%%--------------------------------------------------------------------
%% Copyright (c) 2021-2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------

-module(emqx_authn_provider).

-type authenticator_id() :: emqx_authn_chains:authenticator_id().
-type config() :: emqx_authn_chains:config().
-type state() :: emqx_authn_chains:state().
-type extra() :: emqx_authn_chains:extra().
-type user_info() :: emqx_authn_chains:user_info().

-callback create(AuthenticatorID, Config) ->
    {ok, State}
    | {error, term()}
when
    AuthenticatorID :: authenticator_id(), Config :: config(), State :: state().

-callback update(Config, State) ->
    {ok, NewState}
    | {error, term()}
when
    Config :: config(), State :: state(), NewState :: state().

-callback authenticate(Credential, State) ->
    ignore
    | {ok, Extra}
    | {ok, Extra, AuthData}
    | {continue, AuthCache}
    | {continue, AuthData, AuthCache}
    | {error, term()}
when
    Credential :: map(),
    State :: state(),
    Extra :: extra(),
    AuthData :: binary(),
    AuthCache :: map().

-callback destroy(State) ->
    ok
when
    State :: state().

-callback import_users({PasswordType, Filename, FileData}, State) ->
    ok
    | {error, term()}
when
    PasswordType :: plain | hash,
    Filename :: prepared_user_list | binary(),
    FileData :: binary(),
    State :: state().

-callback add_user(UserInfo, State) ->
    {ok, User}
    | {error, term()}
when
    UserInfo :: user_info(), State :: state(), User :: user_info().

-callback delete_user(Namespace, UserID, State) ->
    ok
    | {error, term()}
when
    Namespace :: emqx_config:maybe_namespace(),
    UserID :: binary(),
    State :: state().

-callback update_user(Namespace, UserID, UserInfo, State) ->
    {ok, User}
    | {error, term()}
when
    Namespace :: emqx_config:maybe_namespace(),
    UserID :: binary(),
    UserInfo :: map(),
    State :: state(),
    User :: user_info().

-callback lookup_user(Namespace, UserID, State) ->
    {ok, User}
    | {error, term()}
when
    Namespace :: emqx_config:maybe_namespace(),
    UserID :: binary(),
    State :: state(),
    User :: user_info().

-callback list_users(QueryParams, State) ->
    %% Return type from `emqx_mgmt_api:node_query`
    {error, page_limit_invalid} | {error, atom(), term()} | #{meta := map(), data := [term()]}
when
    QueryParams :: map(),
    State :: state().

-optional_callbacks([
    import_users/2,
    add_user/2,
    delete_user/3,
    update_user/4,
    lookup_user/3,
    list_users/2
]).
