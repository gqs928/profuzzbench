%%--------------------------------------------------------------------
%% Copyright (c) 2020-2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------

-module(emqx_mqtt_protocol_v5_SUITE).

-compile(export_all).
-compile(nowarn_export_all).

-include_lib("emqx/include/emqx_mqtt.hrl").
-include_lib("emqx/include/emqx_cm.hrl").
-include_lib("emqx_utils/include/emqx_message.hrl").
-include_lib("emqx/include/asserts.hrl").
-include_lib("eunit/include/eunit.hrl").
-include_lib("snabbkaffe/include/snabbkaffe.hrl").
-include_lib("common_test/include/ct.hrl").

-ifndef(BUILD_WITHOUT_QUIC).
%% Please our CI
-include_lib("quicer/include/quicer.hrl").
-endif.

-import(lists, [nth/2]).

-define(TOPICS, [
    <<"TopicA">>,
    <<"TopicA/B">>,
    <<"Topic/C">>,
    <<"TopicA/C">>,
    <<"/TopicA">>
]).

-define(WILD_TOPICS, [
    <<"TopicA/+">>,
    <<"+/C">>,
    <<"#">>,
    <<"/#">>,
    <<"/+">>,
    <<"+/+">>,
    <<"TopicA/#">>
]).

all() ->
    [
        {group, tcp},
        {group, tcp_beam_framing},
        {group, tcp_socket},
        {group, ws},
        {group, quic}
    ].

groups() ->
    TCsQuic = [t_connect_clean_start_unresp_old_client],
    TCs = emqx_common_test_helpers:all(?MODULE) -- TCsQuic,
    [
        {tcp, [], TCs},
        {tcp_beam_framing, [], TCs},
        {tcp_socket, [], TCs},
        {ws, [], TCs},
        {quic, [], TCs ++ TCsQuic}
    ].

init_per_group(tcp, Config) ->
    Apps = emqx_cth_suite:start(
        [{emqx, """
            listeners.tcp.test {
                enable = true
                bind = 2883
                tcp_backend = gen_tcp
                parse_unit = chunk
            }
        """}],
        #{work_dir => emqx_cth_suite:work_dir(Config)}
    ),
    [
        {listener, {tcp, test}},
        {port, 2883},
        {conn_fun, connect},
        {group_apps, Apps}
        | Config
    ];
init_per_group(tcp_beam_framing, Config) ->
    Apps = emqx_cth_suite:start(
        [{emqx, """
            listeners.tcp.test {
                enable = true
                bind = 2884
                tcp_backend = gen_tcp
                parse_unit = frame
            }
        """}],
        #{work_dir => emqx_cth_suite:work_dir(Config)}
    ),
    [
        {listener, {tcp, test}},
        {port, 2884},
        {conn_fun, connect},
        {group_apps, Apps},
        {parse_unit, frame}
        | Config
    ];
init_per_group(tcp_socket, Config) ->
    Apps = emqx_cth_suite:start(
        [{emqx, """
            listeners.tcp.test {
                enable = true
                bind = 2885
                tcp_backend = socket
            }
        """}],
        #{work_dir => emqx_cth_suite:work_dir(Config)}
    ),
    [
        {listener, {tcp, test}},
        {port, 2885},
        {conn_fun, connect},
        {group_apps, Apps}
        | Config
    ];
init_per_group(quic, Config) ->
    Apps = emqx_cth_suite:start(
        [{emqx, "listeners.quic.test { enable = true, bind = 1884 }"}],
        #{work_dir => emqx_cth_suite:work_dir(Config)}
    ),
    [
        {listener, {quic, test}},
        {port, 1884},
        {conn_fun, quic_connect},
        {group_apps, Apps}
        | Config
    ];
init_per_group(ws, Config) ->
    Apps = emqx_cth_suite:start(
        [{emqx, "listeners.ws.test { enable = true, bind = 8888, max_connections = 100 }"}],
        #{work_dir => emqx_cth_suite:work_dir(Config)}
    ),
    [
        {listener, {ws, test}},
        {port, 8888},
        {conn_fun, ws_connect},
        {group_apps, Apps}
        | Config
    ].

end_per_group(_Group, Config) ->
    emqx_cth_suite:stop(?config(group_apps, Config)).

init_per_testcase(TestCase, Config) ->
    case erlang:function_exported(?MODULE, TestCase, 2) of
        true -> ?MODULE:TestCase(init, Config);
        _ -> Config
    end.

end_per_testcase(TestCase, Config) ->
    case erlang:function_exported(?MODULE, TestCase, 2) of
        true -> ?MODULE:TestCase('end', Config);
        false -> ok
    end,
    Config.

%%--------------------------------------------------------------------
%% Helpers
%%--------------------------------------------------------------------

client_info(Key, Client) ->
    proplists:get_value(Key, emqtt:info(Client), undefined).

receive_messages(Count) ->
    receive_messages(Count, []).

receive_messages(0, Msgs) ->
    Msgs;
receive_messages(Count, Msgs) ->
    receive
        {publish, Msg} ->
            receive_messages(Count - 1, [Msg | Msgs]);
        _Other ->
            receive_messages(Count, Msgs)
    after 1000 ->
        Msgs
    end.

receive_disconnect_reasoncode() ->
    receive
        {disconnected, ReasonCode, _} -> ReasonCode;
        _Other -> receive_disconnect_reasoncode()
    after 100 ->
        error("no disconnect packet")
    end.

waiting_client_process_exit(C) ->
    receive
        {'EXIT', C, Reason} -> Reason;
        _Oth -> error({got_another_message, _Oth})
    after 1000 -> error({waiting_timeout, C})
    end.

clean_retained(Topic, Config) ->
    ConnFun = ?config(conn_fun, Config),
    {ok, Clean} = emqtt:start_link([{clean_start, true} | Config]),
    {ok, _} = emqtt:ConnFun(Clean),
    {ok, _} = emqtt:publish(Clean, Topic, #{}, <<"">>, [{qos, ?QOS_1}, {retain, true}]),
    ok = emqtt:disconnect(Clean).

check_zone_config(ConfString) ->
    Fields = [{zone, hoconsc:mk(hoconsc:ref(emqx_schema, "zone"))}],
    Schema = #{roots => Fields},
    {ok, RawConf} = hocon:binary(unicode:characters_to_binary(ConfString)),
    {_, Conf} = emqx_config:check_config(Schema, #{<<"zone">> => RawConf}),
    maps:get(zone, Conf).

%%--------------------------------------------------------------------
%% Test Cases
%%--------------------------------------------------------------------

t_basic_test(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),
    {ok, C} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(C),
    {ok, _, [1]} = emqtt:subscribe(C, Topic, qos1),
    {ok, _, [2]} = emqtt:subscribe(C, Topic, qos2),
    {ok, _} = emqtt:publish(C, Topic, <<"qos 2">>, 2),
    {ok, _} = emqtt:publish(C, Topic, <<"qos 2">>, 2),
    {ok, _} = emqtt:publish(C, Topic, <<"qos 2">>, 2),
    ?assertEqual(3, length(receive_messages(3))),
    ok = emqtt:disconnect(C).

t_basic_large_packets(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(2, ?TOPICS),
    {ok, C} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(C),
    {ok, _, [1]} = emqtt:subscribe(C, Topic, qos1),
    {ok, _} = emqtt:publish(C, Topic, binary:copy(<<"PACKET">>, 20), 1),
    {ok, _} = emqtt:publish(C, Topic, binary:copy(<<"PACKET">>, 200), 1),
    {ok, _} = emqtt:publish(C, Topic, binary:copy(<<"PACKET">>, 2000), 1),
    {ok, _} = emqtt:publish(C, Topic, binary:copy(<<"PACKET">>, 20000), 1),
    ?assertEqual(4, length(receive_messages(4))),
    ok = emqtt:disconnect(C).

%%--------------------------------------------------------------------
%% Connection
%%--------------------------------------------------------------------

t_connect_clean_start(Config) ->
    ConnFun = ?config(conn_fun, Config),
    process_flag(trap_exit, true),
    {ok, Client1} = emqtt:start_link([
        {clientid, <<"t_connect_clean_start">>},
        {proto_ver, v5},
        {clean_start, true},
        %% Nonzero session expiry interval, so the session survives the
        %% takeover below. With interval 0 the session ends when the taken-over
        %% network connection closes (MQTT 5.0 3.1.2.11.2) and the new
        %% connection would get a fresh session (Session Present 0).
        {properties, #{'Session-Expiry-Interval' => 30}}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client1),
    %% [MQTT-3.1.2-4]
    ?assertEqual(0, client_info(session_present, Client1)),
    ok = emqtt:pause(Client1),
    {ok, Client2} = emqtt:start_link([
        {clientid, <<"t_connect_clean_start">>},
        {proto_ver, v5},
        {clean_start, false}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client2),
    %% [MQTT-3.1.2-5]
    ?assertEqual(1, client_info(session_present, Client2)),
    ?assertEqual(142, receive_disconnect_reasoncode()),
    waiting_client_process_exit(Client1),

    ok = emqtt:disconnect(Client2),
    waiting_client_process_exit(Client2),

    {ok, Client3} = emqtt:start_link([
        {clientid, <<"new_client">>},
        {proto_ver, v5},
        {clean_start, false}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client3),
    %% [MQTT-3.1.2-6]
    ?assertEqual(0, client_info(session_present, Client3)),
    ok = emqtt:disconnect(Client3),
    waiting_client_process_exit(Client3),

    process_flag(trap_exit, false).

-doc "A message queued for an offline session is dropped on resume once its Message-Expiry-Interval has elapsed.".
t_message_expiry_interval(Config) ->
    run_message_expiry_interval(Config, <<"exp">>, fun message_expiry_interval_exipred/5).

-doc "A message queued for an offline session is delivered on resume while still within its Message-Expiry-Interval.".
t_message_not_expiry_interval(Config) ->
    run_message_expiry_interval(Config, <<"noexp">>, fun message_expiry_interval_not_exipred/5).

%% Each QoS iteration uses a fresh set of clientids (tagged with the test name
%% and the QoS) so that no session/mqueue/subscription state leaks from one
%% iteration to the next, nor between the two expiry-interval tests. Reusing a
%% fixed clientid across iterations was racy: a resumed `Client-Verify` session
%% could carry stale queued state, and rapid reconnects of the same clientid
%% raced session takeover on slow CI.
run_message_expiry_interval(Config, Name, Fun) ->
    lists:foreach(
        fun(QoS) ->
            Tag = <<Name/binary, "-", (integer_to_binary(QoS))/binary>>,
            {CPublish, CControl} = message_expiry_interval_init(Config, Tag),
            Fun(Config, CPublish, CControl, QoS, Tag),
            emqtt:stop(CPublish),
            emqtt:stop(CControl)
        end,
        [0, 1, 2]
    ).

message_expiry_interval_init(Config, Tag) ->
    ConnFun = ?config(conn_fun, Config),
    ClientIdPublish = <<"Client-Publish-", Tag/binary>>,
    ClientIdVerify = <<"Client-Verify-", Tag/binary>>,
    ClientIdControl = <<"Client-Control-", Tag/binary>>,
    {ok, CPublish} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, ClientIdPublish},
        {clean_start, false},
        {properties, #{'Session-Expiry-Interval' => 360}}
        | Config
    ]),
    {ok, CVerify} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, ClientIdVerify},
        {clean_start, false},
        {properties, #{'Session-Expiry-Interval' => 360}}
        | Config
    ]),
    {ok, CControl} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, ClientIdControl},
        {clean_start, false},
        {properties, #{'Session-Expiry-Interval' => 360}}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(CPublish),
    {ok, _} = emqtt:ConnFun(CVerify),
    {ok, _} = emqtt:ConnFun(CControl),
    %% Subscribe and disconnect Client-Verify.
    emqtt:subscribe(CControl, <<"t/a">>, 1),
    emqtt:subscribe(CVerify, <<"t/a">>, 1),
    emqtt:stop(CVerify),
    %% Wait until the broker has fully processed Client-Verify's DISCONNECT and
    %% moved its (retained) session into the `disconnected` state before any
    %% message is published. Until then the channel is still `connected`, so a
    %% delivered QoS>0 message is placed into the session's inflight window
    %% instead of the mqueue. Inflight messages are replayed verbatim on resume,
    %% bypassing the mqueue's Message-Expiry-Interval check -- which made the
    %% expiry assertions race (most visibly for QoS=2, whose longer publish
    %% handshake widens the window).
    ?retry(
        100,
        20,
        begin
            Chans = [_ | _] = emqx_cm:lookup_channels(ClientIdVerify),
            [] = [C || C <- Chans, emqx_cm:is_channel_connected(C)]
        end
    ),
    {CPublish, CControl}.

message_expiry_interval_exipred(Config, CPublish, CControl, QoS, Tag) ->
    ConnFun = ?config(conn_fun, Config),
    ct:pal("~p ~p", [?FUNCTION_NAME, QoS]),
    %% Publish to t/a and wait for the message to expire.
    _ = emqtt:publish(
        CPublish,
        <<"t/a">>,
        #{'Message-Expiry-Interval' => 1},
        <<"this will be purged in 1s">>,
        [{qos, QoS}]
    ),
    %% CControl makes sure publish is already stored in broker.
    receive
        {publish, #{client_pid := CControl, topic := <<"t/a">>}} ->
            ok
    after 1000 ->
        ct:fail(should_receive_publish)
    end,
    %% Sleep well past Message-Expiry-Interval (1s) with wide margin so the
    %% wall-clock-based expiry check at session resume is not racy on slow CI.
    ct:sleep(2000),

    %% Resume the session for Client-Verify.
    {ok, CVerify} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, <<"Client-Verify-", Tag/binary>>},
        {clean_start, false},
        {properties, #{'Session-Expiry-Interval' => 360}}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(CVerify),

    %% Verify Client-Verify could not receive the publish message.
    receive
        {publish, #{client_pid := CVerify, topic := <<"t/a">>}} ->
            ct:fail(should_have_expired)
    after 300 ->
        ok
    end,
    emqtt:stop(CVerify).

message_expiry_interval_not_exipred(Config, CPublish, CControl, QoS, Tag) ->
    ConnFun = ?config(conn_fun, Config),
    ct:pal("~p ~p", [?FUNCTION_NAME, QoS]),
    %% Publish to t/a.
    _ = emqtt:publish(
        CPublish,
        <<"t/a">>,
        #{'Message-Expiry-Interval' => 20},
        <<"this will be purged in 20s">>,
        [{qos, QoS}]
    ),

    %% CControl makes sure publish is already stored in broker.
    receive
        {publish, #{client_pid := CControl, topic := <<"t/a">>}} ->
            ok
    after 1000 ->
        ct:fail(should_receive_publish)
    end,

    %% Wait for 1.2s and then resume the session for Client-Verify. The message
    %% should not expire because Message-Expiry-Interval = 20s.
    ct:sleep(1200),
    {ok, CVerify} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, <<"Client-Verify-", Tag/binary>>},
        {clean_start, false},
        {properties, #{'Session-Expiry-Interval' => 360}}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(CVerify),

    %% Verify Client-Verify could receive the publish message and the
    %% Message-Expiry-Interval is set. Use a generous receive window: the session
    %% resume + queued-message dispatch can take longer than a few hundred ms on
    %% a busy CI runner. A late (but present) delivery here is a pass, so a wider
    %% window only removes flakiness.
    receive
        {publish, #{
            client_pid := CVerify,
            topic := <<"t/a">>,
            properties := #{'Message-Expiry-Interval' := MsgExpItvl}
        }} when
            MsgExpItvl =< 20
        ->
            ok;
        {publish, _} = Msg ->
            ct:fail({incorrect_publish, Msg})
    after 2000 ->
        ct:fail(no_publish_received)
    end,
    emqtt:stop(CVerify).

-doc """
A live subscriber skips an expired message that was held in the mqueue by delivery
rate limiting.
""".
t_delivery_limited_queued_messages_expire(Config) ->
    {Type, Name} = ?config(listener, Config),
    ConnFun = ?config(conn_fun, Config),
    Topic = ~"t/delivery_limited_expired",
    SubscriberId = ~"delivery_limited_expired_sub",
    PublisherId = ~"delivery_limited_expired_pub",
    {ok, CPub} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, PublisherId}
        | Config
    ]),
    {ok, CSub} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, SubscriberId},
        {auto_ack, false}
        | Config
    ]),
    configure_delivery_limiters(Type, Name, ~"1/5s"),
    try
        {ok, _} = emqtt:ConnFun(CPub),
        {ok, _} = emqtt:ConnFun(CSub),
        {ok, _, [1]} = emqtt:subscribe(CSub, Topic, 1),

        publish_with_expiry(CPub, Topic, ~"1", ?QOS_1, 60),
        publish_with_expiry(CPub, Topic, ~"2", ?QOS_1, 2),
        publish_with_expiry(CPub, Topic, ~"3", ?QOS_1, 60),

        ct:sleep(3000),

        configure_delivery_limiters(Type, Name, ~"infinity"),

        {publish, Pub1} = ?assertReceive({publish, #{client_pid := CSub, topic := Topic}}),
        ok = emqtt:puback(CSub, maps:get(packet_id, Pub1)),
        {publish, Pub2} = ?assertReceive({publish, #{client_pid := CSub, topic := Topic}}),
        ?assertMatch(
            [
                #{payload := ~"1"},
                #{payload := ~"3"}
            ],
            [Pub1, Pub2]
        ),
        ?assertNotReceive({publish, #{client_pid := CSub}}, 3000)
    after
        emqtt:stop(CSub),
        emqtt:stop(CPub),
        configure_delivery_limiters(Type, Name, ~"infinity")
    end.

configure_delivery_limiters(Type, Name, MessagesRate) ->
    {ok, _} = emqx:update_config(
        [listeners, Type, Name],
        {update, #{<<"delivery_messages_rate">> => MessagesRate}}
    ).

publish_with_expiry(Publisher, Topic, Payload, QoS, ExpiryInterval) ->
    {ok, _} = emqtt:publish(
        Publisher,
        Topic,
        #{'Message-Expiry-Interval' => ExpiryInterval},
        Payload,
        [{qos, QoS}]
    ).

t_puback_not_lost_on_disconnect(Config) ->
    ConnFun = ?config(conn_fun, Config),
    %% Client with persistent in-mem session, subscribing to t/1, manual acking.
    {ok, C0} = emqtt:start_link([
        {clientid, <<"puback_not_lost">>},
        {proto_ver, v5},
        {auto_ack, false},
        {clean_start, false},
        {properties, #{'Session-Expiry-Interval' => 10000}}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(C0),
    {ok, _, [1]} = emqtt:subscribe(C0, <<"t/1">>, 1),
    %% Publish 100 messages to t/1.
    spawn_link(fun() ->
        lists:foreach(
            fun(I) ->
                Payload = integer_to_binary(I),
                Message = emqx_message:make(<<"from">>, 1, <<"t/1">>, Payload),
                emqx_broker:publish(Message)
            end,
            lists:seq(1, 100)
        )
    end),
    %% Receive the first message and acknowledge it, then disconnect.
    receive
        {publish, #{topic := <<"t/1">>, payload := <<"1">>, packet_id := PacketId}} ->
            emqtt:puback(C0, PacketId),
            %% Sync barrier: PINGREQ is read and processed by the broker in
            %% order after PUBACK, so receiving PINGRESP proves the PUBACK
            %% has been drained from the transport buffer and applied to the
            %% session before we tear down the socket.
            pong = emqtt:ping(C0),
            emqtt:disconnect(C0)
    after 1000 ->
        ct:fail("Message not received")
    end,
    %% Wait for the old channel to fully shut down before reconnecting.
    ?retry(100, 20, [] =:= emqx_cm:lookup_channels(<<"puback_not_lost">>)),
    %% Restore the session.
    {ok, C1} = emqtt:start_link([
        {clientid, <<"puback_not_lost">>},
        {proto_ver, v5},
        {auto_ack, true},
        {clean_start, false},
        {properties, #{'Session-Expiry-Interval' => 10000}}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(C1),
    %% Verify that the first message is not received, i.e. that our ack was not lost.
    Msgs1 = drain_messages_from(C1),
    ?assertEqual(99, length(Msgs1)),
    ?assertNot(lists:member(<<"1">>, Msgs1)),
    emqtt:stop(C1).

drain_messages_from(C) ->
    receive
        {publish, Msg = #{client_pid := C}} ->
            [Msg | drain_messages_from(C)]
    after 1000 ->
        []
    end.

-doc """
Lower Receive-Maximum on reconnect preserves inflight messages and blocks queued QoS1
until space is available.
""".
t_inflight_resize_on_reconnect(Config) ->
    ConnFun = ?config(conn_fun, Config),
    ClientId = atom_to_binary(?FUNCTION_NAME),
    Topic = <<ClientId/binary, "/q1">>,
    ClientOpts = [
        {proto_ver, v5},
        {clientid, ClientId},
        {auto_ack, false},
        {clean_start, false}
        | Config
    ],
    Props = #{
        %% Make the session persistent:
        'Session-Expiry-Interval' => 360,
        %% Allow up to 3 messages in-flight initially:
        'Receive-Maximum' => 3
    },
    {ok, C0} = emqtt:start_link([{properties, Props} | ClientOpts]),
    {ok, _} = emqtt:ConnFun(C0),
    {ok, _, [1]} = emqtt:subscribe(C0, Topic, 1),
    lists:foreach(
        fun(Payload) ->
            emqx_broker:publish(emqx_message:make(test, ?QOS_1, Topic, Payload))
        end,
        [<<"1">>, <<"2">>, <<"3">>]
    ),
    Initial = lists:reverse(receive_messages(3)),
    ?assertMatch(
        [
            #{client_pid := C0, payload := <<"1">>, dup := false},
            #{client_pid := C0, payload := <<"2">>, dup := false},
            #{client_pid := C0, payload := <<"3">>, dup := false}
        ],
        Initial
    ),
    ?assertMatch(
        #{inflight_max := 3, inflight_cnt := 3},
        maps:from_list(emqx_cth_broker:connection_stats(ClientId))
    ),

    ok = emqtt:disconnect(C0),

    {ok, C1} = emqtt:start_link([{properties, Props#{'Receive-Maximum' => 1}} | ClientOpts]),
    {ok, _} = emqtt:ConnFun(C1),
    ?assertEqual(1, client_info(session_present, C1)),
    Replayed = lists:reverse(receive_messages(3)),
    [PktId1, PktId2, PktId3] = [maps:get(packet_id, M) || M <- Initial],
    ?assertMatch(
        [
            #{packet_id := PktId1, client_pid := C1, payload := <<"1">>, dup := true},
            #{packet_id := PktId2, client_pid := C1, payload := <<"2">>, dup := true},
            #{packet_id := PktId3, client_pid := C1, payload := <<"3">>, dup := true}
        ],
        Replayed
    ),
    ?assertMatch(
        #{inflight_max := 1, inflight_cnt := 3},
        maps:from_list(emqx_cth_broker:connection_stats(ClientId))
    ),
    %% One more message goes into the mqueue:
    emqx_broker:publish(emqx_message:make(?MODULE, ?QOS_1, Topic, <<"4">>)),
    pong = emqtt:ping(C1),
    ?assertMatch(
        #{mqueue_len := 1},
        maps:from_list(emqx_cth_broker:connection_stats(ClientId))
    ),
    %% ACK 1 still leaves inflight above its new maximum:
    ok = emqtt:puback(C1, PktId1),
    pong = emqtt:ping(C1),
    ?assertMatch(
        #{inflight_cnt := 2, mqueue_len := 1},
        maps:from_list(emqx_cth_broker:connection_stats(ClientId))
    ),
    %% ACK 2 puts inflight at the new maximum, the queued message still waits:
    ok = emqtt:puback(C1, PktId2),
    pong = emqtt:ping(C1),
    ?assertMatch(
        #{inflight_cnt := 1, mqueue_len := 1},
        maps:from_list(emqx_cth_broker:connection_stats(ClientId))
    ),
    %% ACK 3 allows one more message to enter inflight:
    ok = emqtt:puback(C1, PktId3),
    {publish, #{client_pid := C1, payload := <<"4">>, packet_id := PktId4, dup := false}} =
        ?assertReceive({publish, #{client_pid := C1}}),
    ?assertMatch(
        #{inflight_cnt := 1, mqueue_len := 0},
        maps:from_list(emqx_cth_broker:connection_stats(ClientId))
    ),
    ok = emqtt:puback(C1, PktId4),
    pong = emqtt:ping(C1),
    ?assertMatch(
        #{inflight_cnt := 0, mqueue_len := 0},
        maps:from_list(emqx_cth_broker:connection_stats(ClientId))
    ),
    emqtt:stop(C1).

-doc """
An inflight (sent-but-unacked) QoS-1 message is retried at takeover even after
its Message-Expiry-Interval elapsed: per [MQTT-3.3.2-5], expiry only drops
messages whose onward delivery has not started.
""".
t_inflight_retried_after_expiry_on_takeover(Config) ->
    ConnFun = ?config(conn_fun, Config),
    ClientId = <<"inflight_retry_after_expiry">>,
    {ok, CPub} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, <<"inflight_retry_pub">>}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(CPub),
    %% Subscriber with a persistent in-mem session, manual acking so the broker
    %% keeps the delivered message in its inflight set awaiting PUBACK.
    {ok, C0} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, ClientId},
        {auto_ack, false},
        {clean_start, false},
        {properties, #{'Session-Expiry-Interval' => 360}}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(C0),
    {ok, _, [1]} = emqtt:subscribe(C0, <<"t/a">>, 1),
    %% Publish a QoS-1 message that expires in 1s.
    _ = emqtt:publish(
        CPub,
        <<"t/a">>,
        #{'Message-Expiry-Interval' => 1},
        <<"inflight, retried after expiry">>,
        [{qos, 1}]
    ),
    %% The message reaches the subscriber and enters the session inflight set;
    %% onward delivery has started, but we deliberately do NOT acknowledge it.
    {publish, #{client_pid := C0}} = ?assertReceive({publish, #{topic := <<"t/a">>}}),
    %% Disconnect (keep the session); the un-acked message stays in inflight.
    ok = emqtt:disconnect(C0),
    ?retry(100, 20, [] =:= emqx_cm:lookup_channels(ClientId)),
    %% Sleep well past Message-Expiry-Interval (1s) so the message is expired.
    ct:sleep(2000),
    %% Resume the session, triggering takeover/replay of the inflight set.
    {ok, C1} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, ClientId},
        {auto_ack, true},
        {clean_start, false},
        {properties, #{'Session-Expiry-Interval' => 360}}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(C1),
    %% Onward delivery had already started, so the message MUST still be retried
    %% (as a DUP) despite having expired.
    receive
        {publish, #{client_pid := C1, topic := <<"t/a">>, dup := Dup}} ->
            ?assertEqual(true, Dup)
    after 2000 ->
        ct:fail(inflight_message_not_retried)
    end,
    emqtt:stop(C1),
    emqtt:stop(CPub).

-ifndef(BUILD_WITHOUT_QUIC).
t_connect_clean_start_unresp_old_client(Config) ->
    ConnFun = ?config(conn_fun, Config),
    ClientID = atom_to_binary(?FUNCTION_NAME),
    process_flag(trap_exit, true),
    %% GIVEN: a client with clean_start=true
    {ok, Client1} = emqtt:start_link([
        {clientid, ClientID},
        {proto_ver, v5},
        {clean_start, true}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client1),
    %% [MQTT-3.1.2-4]
    ?assertEqual(0, client_info(session_present, Client1)),
    {ok, Client2} = emqtt:start_link([
        {clientid, ClientID},
        {proto_ver, v5},
        {clean_start, false},
        %% ensure fast close < 10ms
        {connect_timeout, 10}
        | Config
    ]),
    %% WHEN: the client became unresponsive
    close_quic_conn_silently(ConnFun, Client1),
    %% THEN: the new client should connect successfully in time < connect_timeout
    {ok, _} = emqtt:ConnFun(Client2),
    ok = emqtt:disconnect(Client2),
    ?assertReceive({'EXIT', Client1, _}),
    ?assertReceive({'EXIT', Client2, _}),
    ok.

close_quic_conn_silently(quic_connect, Client) ->
    %% simulate a unresponsive client that server doesn't know it is disconnected
    {quic, Conn, _Stream} = proplists:get_value(socket, emqtt:info(Client)),
    _ = quicer:shutdown_connection(Conn, ?QUIC_CONNECTION_SHUTDOWN_FLAG_SILENT, 0, 10),
    ok.
-endif.

t_connect_will_message(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),
    Payload = "will message",

    {ok, Client1} = emqtt:start_link([
        {proto_ver, v5},
        {clean_start, true},
        {will_flag, true},
        {will_topic, Topic},
        {will_payload, Payload}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client1),
    WillMsg = emqx_cth_broker:connection_info({channel, will_msg}, Client1),
    %% [MQTT-3.1.2-7]
    ?assertNotEqual(undefined, WillMsg),

    {ok, Client2} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client2),
    {ok, _, [2]} = emqtt:subscribe(Client2, Topic, qos2),

    %% [MQTT-3.14.2-1]
    ok = emqtt:disconnect(Client1, 4),
    [Msg | _] = receive_messages(1),
    %% [MQTT-3.1.2-8]
    ?assertEqual({ok, iolist_to_binary(Topic)}, maps:find(topic, Msg)),
    ?assertEqual({ok, iolist_to_binary(Payload)}, maps:find(payload, Msg)),
    ?assertEqual({ok, 0}, maps:find(qos, Msg)),
    ok = emqtt:disconnect(Client2),

    {ok, Client3} = emqtt:start_link([
        {proto_ver, v5},
        {clean_start, true},
        {will_flag, true},
        {will_topic, Topic},
        {will_payload, Payload}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client3),

    {ok, Client4} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client4),
    {ok, _, [2]} = emqtt:subscribe(Client4, Topic, qos2),
    ok = emqtt:disconnect(Client3),
    %% [MQTT-3.1.2-10]
    MsgRecv = receive_messages(1),
    ?assertEqual([], MsgRecv),
    ok = emqtt:disconnect(Client4).

t_batch_subscribe(init, Config) ->
    emqx_config:put_zone_conf(default, [authorization, enable], true),
    ok = meck:new(emqx_access_control, [non_strict, passthrough, no_history, no_link]),
    meck:expect(emqx_access_control, authorize, fun(_, _, _) -> deny end),
    Config;
t_batch_subscribe('end', _Config) ->
    emqx_config:put_zone_conf(default, [authorization, enable], false),
    meck:unload(emqx_access_control).

t_batch_subscribe(Config) ->
    ConnFun = ?config(conn_fun, Config),
    {ok, Client} = emqtt:start_link([{proto_ver, v5}, {clientid, <<"batch_test">>} | Config]),
    {ok, _} = emqtt:ConnFun(Client),
    {ok, _, [
        ?RC_NOT_AUTHORIZED,
        ?RC_NOT_AUTHORIZED,
        ?RC_NOT_AUTHORIZED
    ]} = emqtt:subscribe(Client, [
        {<<"t1">>, qos1},
        {<<"t2">>, qos2},
        {<<"t3">>, qos0}
    ]),
    {ok, _, [
        ?RC_NO_SUBSCRIPTION_EXISTED,
        ?RC_NO_SUBSCRIPTION_EXISTED,
        ?RC_NO_SUBSCRIPTION_EXISTED
    ]} = emqtt:unsubscribe(Client, [
        <<"t1">>,
        <<"t2">>,
        <<"t3">>
    ]),
    emqtt:disconnect(Client).

t_connect_will_retain(Config) ->
    ConnFun = ?config(conn_fun, Config),
    process_flag(trap_exit, true),
    Topic = nth(1, ?TOPICS),
    Payload = "will message",

    {ok, Client1} = emqtt:start_link([
        {proto_ver, v5},
        {clean_start, true},
        {will_flag, true},
        {will_topic, Topic},
        {will_payload, Payload},
        {will_retain, false}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client1),

    {ok, Client2} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client2),
    {ok, _, [2]} = emqtt:subscribe(Client2, #{}, [{Topic, [{rap, true}, {qos, 2}]}]),

    ok = emqtt:disconnect(Client1, 4),
    [Msg1 | _] = receive_messages(1),
    %% [MQTT-3.1.2-14]
    ?assertEqual({ok, false}, maps:find(retain, Msg1)),
    ok = emqtt:disconnect(Client2),

    {ok, Client3} = emqtt:start_link([
        {proto_ver, v5},
        {clean_start, true},
        {will_flag, true},
        {will_topic, Topic},
        {will_payload, Payload},
        {will_retain, true}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client3),

    {ok, Client4} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client4),
    {ok, _, [2]} = emqtt:subscribe(Client4, #{}, [{Topic, [{rap, true}, {qos, 2}]}]),

    ok = emqtt:disconnect(Client3, 4),
    [Msg2 | _] = receive_messages(1),
    %% [MQTT-3.1.2-15]
    ?assertEqual({ok, true}, maps:find(retain, Msg2)),
    ok = emqtt:disconnect(Client4),
    clean_retained(Topic, Config).

t_connect_emit_stats_timeout(init, Config) ->
    NewIdleTimeout = 1000,
    emqx_config:put_zone_conf(default, [mqtt, idle_timeout], NewIdleTimeout),
    ok = snabbkaffe:start_trace(),
    [{idle_timeout, NewIdleTimeout} | Config];
t_connect_emit_stats_timeout('end', _Config) ->
    snabbkaffe:stop(),
    emqx_config:put_zone_conf(default, [mqtt, idle_timeout], 15000),
    ok.

t_connect_emit_stats_timeout(Config) ->
    ConnFun = ?config(conn_fun, Config),
    IdleTimeout = ?config(idle_timeout, Config),
    {ok, Client} = emqtt:start_link([{proto_ver, v5}, {keepalive, 60} | Config]),
    {ok, _} = emqtt:ConnFun(Client),
    %% Poke the connection to ensure stats timer is armed.
    pong = emqtt:ping(Client),
    ?assertMatch(
        TRef when is_reference(TRef),
        emqx_cth_broker:connection_info(stats_timer, Client)
    ),
    ?block_until(#{?snk_kind := cancel_stats_timer}, IdleTimeout * 2, _BackInTime = 0),
    ?assertEqual(undefined, emqx_cth_broker:connection_info(stats_timer, Client)),
    ok = emqtt:disconnect(Client).

%% [MQTT-3.1.2-22]
t_connect_keepalive_timeout(Config) ->
    ConnFun = ?config(conn_fun, Config),
    %% Prevent the emqtt client bringing us down on the disconnect.
    process_flag(trap_exit, true),

    Keepalive = 2,

    {ok, Client} = emqtt:start_link([
        {proto_ver, v5},
        {keepalive, Keepalive}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client),
    emqtt:pause(Client),
    receive
        {disconnected, ReasonCode, _Channel} -> ?assertEqual(141, ReasonCode)
    after round(timer:seconds(Keepalive) * 2 * 1.5) ->
        error("keepalive timeout")
    end.

%% [MQTT-3.1.3-9]
%% !!!REFACTOR NEED:
%t_connect_will_delay_interval(Config) ->
%    process_flag(trap_exit, true),
%    Topic = nth(1, ?TOPICS),
%    Payload = "will message",
%
%    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
%    {ok, _} = emqtt:ConnFun(Client1),
%    {ok, _, [2]} = emqtt:subscribe(Client1, Topic, qos2),
%
%    {ok, Client2} = emqtt:start_link([
%                                        {clientid, <<"t_connect_will_delay_interval">>},
%                                        {proto_ver, v5},
%                                        {clean_start, true},
%                                        {will_flag, true},
%                                        {will_qos, 2},
%                                        {will_topic, Topic},
%                                        {will_payload, Payload},
%                                        {will_props, #{'Will-Delay-Interval' => 3}},
%                                        {properties, #{'Session-Expiry-Interval' => 7200}},
%                                        {keepalive, 2} | Config
%                                        ]),
%    {ok, _} = emqtt:ConnFun(Client2),
%    timer:sleep(50),
%    erlang:exit(Client2, kill),
%    timer:sleep(2000),
%    ?assertEqual(0, length(receive_messages(1))),
%    timer:sleep(5000),
%    ?assertEqual(1, length(receive_messages(1))),
%
%    {ok, Client3} = emqtt:start_link([
%                                        {clientid, <<"t_connect_will_delay_interval">>},
%                                        {proto_ver, v5},
%                                        {clean_start, true},
%                                        {will_flag, true},
%                                        {will_qos, 2},
%                                        {will_topic, Topic},
%                                        {will_payload, Payload},
%                                        {will_props, #{'Will-Delay-Interval' => 7200}},
%                                        {properties, #{'Session-Expiry-Interval' => 3}},
%                                        {keepalive, 2} | Config
%                                        ]),
%    {ok, _} = emqtt:ConnFun(Client3),
%    timer:sleep(50),
%    erlang:exit(Client3, kill),
%
%    timer:sleep(2000),
%    ?assertEqual(0, length(receive_messages(1))),
%    timer:sleep(5000),
%    ?assertEqual(1, length(receive_messages(1))),
%
%    ok = emqtt:disconnect(Client1),
%
%    receive {'EXIT', _, _} -> ok
%    after 100 -> ok
%    end,
%    process_flag(trap_exit, false).

%% [MQTT-3.1.4-3]
t_connect_duplicate_clientid(Config) ->
    ConnFun = ?config(conn_fun, Config),
    process_flag(trap_exit, true),
    %% generate fresh clientid on each run to avoid throttling
    N = erlang:unique_integer(),
    ClientId = <<"t_connect_duplicate_clientid", (integer_to_binary(N))/binary>>,
    {ok, Client1} = emqtt:start_link([
        {clientid, ClientId},
        {proto_ver, v5}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client1),
    {ok, Client2} = emqtt:start_link([
        {clientid, ClientId},
        {proto_ver, v5}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client2),
    ?assertEqual(142, receive_disconnect_reasoncode()),
    waiting_client_process_exit(Client1),

    ok = emqtt:disconnect(Client2),
    waiting_client_process_exit(Client2),
    process_flag(trap_exit, false).

%%--------------------------------------------------------------------
%% Connack
%%--------------------------------------------------------------------

t_connack_session_present(Config) ->
    ConnFun = ?config(conn_fun, Config),
    %% generate fresh clientid on each run to avoid throttling
    N = erlang:unique_integer(),
    ClientId = <<"t_connect_duplicate_clientid", (integer_to_binary(N))/binary>>,
    {ok, Client1} = emqtt:start_link([
        {clientid, ClientId},
        {proto_ver, v5},
        {properties, #{'Session-Expiry-Interval' => 7200}},
        {clean_start, true}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client1),
    %% [MQTT-3.2.2-2]
    ?assertEqual(0, client_info(session_present, Client1)),
    ok = emqtt:disconnect(Client1),

    {ok, Client2} = emqtt:start_link([
        {clientid, ClientId},
        {proto_ver, v5},
        {properties, #{'Session-Expiry-Interval' => 7200}},
        {clean_start, false}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client2),
    %% [[MQTT-3.2.2-3]]
    ?assertEqual(1, client_info(session_present, Client2)),
    ok = emqtt:disconnect(Client2).

t_connack_max_qos_allowed(init, Config) ->
    Config;
t_connack_max_qos_allowed('end', _Config) ->
    emqx_config:put_zone_conf(default, [mqtt, max_qos_allowed], 2),
    ok.

t_connack_max_qos_allowed(Config) ->
    ConnFun = ?config(conn_fun, Config),
    process_flag(trap_exit, true),
    Topic = nth(1, ?TOPICS),

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% max_qos_allowed = 0
    MaxQoSAllowed0 = 0,
    emqx_config:put_zone_conf(default, [mqtt, max_qos_allowed], MaxQoSAllowed0),

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, Connack1} = emqtt:ConnFun(Client1),
    %% [MQTT-3.2.2-9]
    ?assertEqual(0, maps:get('Maximum-QoS', Connack1)),

    %% [MQTT-3.2.2-10]
    %% [MQTT-3.8.4-7]
    {ok, _, [MaxQoSAllowed0]} = emqtt:subscribe(Client1, Topic, ?QOS_0),
    {ok, _, [MaxQoSAllowed0]} = emqtt:subscribe(Client1, Topic, ?QOS_1),
    {ok, _, [MaxQoSAllowed0]} = emqtt:subscribe(Client1, Topic, ?QOS_2),

    %% [MQTT-3.2.2-11]
    ?assertMatch(
        {error, {disconnected, 155, _}},
        emqtt:publish(Client1, Topic, <<"Unsupported Qos 1">>, qos1)
    ),
    ?assertEqual(155, receive_disconnect_reasoncode()),
    waiting_client_process_exit(Client1),

    {ok, Client2} = emqtt:start_link([
        {proto_ver, v5},
        {will_flag, true},
        {will_topic, Topic},
        {will_payload, <<"Unsupported Qos">>},
        {will_qos, 2}
        | Config
    ]),
    {error, Connack2} = emqtt:ConnFun(Client2),
    %% [MQTT-3.2.2-12]
    ?assertMatch({qos_not_supported, _}, Connack2),
    waiting_client_process_exit(Client2),

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% max_qos_allowed = 1
    MaxQoSAllowed1 = 1,
    emqx_config:put_zone_conf(default, [mqtt, max_qos_allowed], MaxQoSAllowed1),

    {ok, Client3} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, Connack3} = emqtt:ConnFun(Client3),
    %% [MQTT-3.2.2-9]
    ?assertEqual(1, maps:get('Maximum-QoS', Connack3)),

    %% [MQTT-3.2.2-10]
    %% [MQTT-3.8.4-7]
    {ok, _, [?QOS_0]} = emqtt:subscribe(Client3, Topic, ?QOS_0),
    {ok, _, [MaxQoSAllowed1]} = emqtt:subscribe(Client3, Topic, ?QOS_1),
    {ok, _, [MaxQoSAllowed1]} = emqtt:subscribe(Client3, Topic, ?QOS_2),

    %% [MQTT-3.2.2-11]
    ?assertMatch(
        {error, {disconnected, 155, _}},
        emqtt:publish(Client3, Topic, <<"Unsupported Qos 2">>, qos2)
    ),
    ?assertEqual(155, receive_disconnect_reasoncode()),
    waiting_client_process_exit(Client3),

    {ok, Client4} = emqtt:start_link([
        {proto_ver, v5},
        {will_flag, true},
        {will_topic, Topic},
        {will_payload, <<"Unsupported Qos">>},
        {will_qos, 2}
        | Config
    ]),
    {error, Connack4} = emqtt:ConnFun(Client4),
    %% [MQTT-3.2.2-12]
    ?assertMatch({qos_not_supported, _}, Connack4),
    waiting_client_process_exit(Client4),

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% max_qos_allowed = 2
    MaxQoSAllowed2 = 2,
    emqx_config:put_zone_conf(default, [mqtt, max_qos_allowed], MaxQoSAllowed2),

    {ok, Client5} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, Connack5} = emqtt:ConnFun(Client5),
    %% [MQTT-3.2.2-9]
    ?assertEqual(undefined, maps:get('Maximum-QoS', Connack5, undefined)),

    {ok, _, [?QOS_0]} = emqtt:subscribe(Client5, Topic, ?QOS_0),
    {ok, _, [?QOS_1]} = emqtt:subscribe(Client5, Topic, ?QOS_1),
    {ok, _, [?QOS_2]} = emqtt:subscribe(Client5, Topic, ?QOS_2),

    ok = emqtt:disconnect(Client5),
    waiting_client_process_exit(Client5),

    process_flag(trap_exit, false).

t_connack_assigned_clientid(Config) ->
    ConnFun = ?config(conn_fun, Config),
    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    %%  [MQTT-3.2.2-16]
    ?assert(is_binary(client_info(clientid, Client1))),
    ok = emqtt:disconnect(Client1).

t_connack_client_id_unavailable(Config) ->
    ConnFun = ?config(conn_fun, Config),
    ClientId = atom_to_binary(?FUNCTION_NAME),
    %% Simulate the race the throttle protects against: a local channel
    %% just exited, its CHAN_CONN_TAB row is still present (cm pool hasn't
    %% drained the cleanup yet), and the same client tries to reconnect.
    %% We bypass emqx_cm:register_channel/3 to keep no monitor on DeadPid
    %% so the cm pool never drains, and the throttle stays firing for the
    %% duration of the test.
    DeadPid = spawn(fun() -> exit(normal) end),
    true = ets:insert(?CHAN_CONN_TAB, #chan_conn{
        pid = DeadPid, mod = emqx_connection, clientid = ClientId
    }),
    ok = emqx_cm_registry:register_channel({ClientId, DeadPid}),
    WillTopic = iolist_to_binary([atom_to_binary(?FUNCTION_NAME), "/will"]),
    NotWillMsg = #message{topic = WillTopic, payload = <<"NotWillMsg">>},
    Opts = [
        {proto_ver, v5},
        {clientid, ClientId},
        {will_flag, true},
        {will_topic, WillTopic},
        {will_payload, <<"WillMsg">>}
        | Config
    ],
    emqx_broker:subscribe(WillTopic),
    try
        {ok, Client} = emqtt:start_link(Opts),
        unlink(Client),
        {error, ConnAck} = emqtt:ConnFun(Client),
        ?assertMatch(
            {server_busy, #{
                'Reason-String' := <<"THROTTLED">>
            }},
            ConnAck
        )
    after
        ok = emqx_cm_registry:unregister_channel({ClientId, DeadPid}),
        true = ets:delete(?CHAN_CONN_TAB, DeadPid)
    end,
    %% Assert no will message is published for server_busy CONNACK reason
    emqx_broker:publish(NotWillMsg),
    ?assertReceive({deliver, WillTopic, #message{payload = <<"NotWillMsg">>}}, 1000),
    ?assertNotReceive({deliver, WillTopic, #message{payload = <<"WillMsg">>}}, 100),
    emqx_broker:subscriber_down(self()),
    ok.

%%--------------------------------------------------------------------
%% Publish
%%--------------------------------------------------------------------

t_publish_rap(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    {ok, _, [2]} = emqtt:subscribe(Client1, #{}, [{Topic, [{rap, true}, {qos, 2}]}]),
    {ok, _} = emqtt:publish(
        Client1,
        Topic,
        #{},
        <<"retained message">>,
        [{qos, ?QOS_1}, {retain, true}]
    ),
    [Msg1 | _] = receive_messages(1),
    %% [MQTT-3.3.1-12]
    ?assertEqual(true, maps:get(retain, Msg1)),
    ok = emqtt:disconnect(Client1),

    {ok, Client2} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client2),
    {ok, _, [2]} = emqtt:subscribe(Client2, #{}, [{Topic, [{rap, false}, {qos, 2}]}]),
    {ok, _} = emqtt:publish(
        Client2,
        Topic,
        #{},
        <<"retained message">>,
        [{qos, ?QOS_1}, {retain, true}]
    ),
    [Msg2 | _] = receive_messages(1),
    %% [MQTT-3.3.1-13]
    ?assertEqual(false, maps:get(retain, Msg2)),
    ok = emqtt:disconnect(Client2),

    clean_retained(Topic, Config).

t_publish_wildtopic(Config) ->
    ConnFun = ?config(conn_fun, Config),
    process_flag(trap_exit, true),
    Topic = nth(1, ?WILD_TOPICS),

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    ok = emqtt:publish(Client1, Topic, <<"error topic">>),
    ?assertEqual(144, receive_disconnect_reasoncode()),
    waiting_client_process_exit(Client1),

    process_flag(trap_exit, false).

t_publish_payload_format_indicator(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),
    Properties = #{'Payload-Format-Indicator' => 233},

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    {ok, _, [2]} = emqtt:subscribe(Client1, Topic, qos2),
    ok = emqtt:publish(Client1, Topic, Properties, <<"Payload Format Indicator">>, [{qos, ?QOS_0}]),
    [Msg1 | _] = receive_messages(1),
    %% [MQTT-3.3.2-6]
    ?assertEqual(Properties, maps:get(properties, Msg1)),
    ok = emqtt:disconnect(Client1).

t_publish_topic_alias(Config) ->
    ConnFun = ?config(conn_fun, Config),
    process_flag(trap_exit, true),
    Topic = nth(1, ?TOPICS),

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    ok = emqtt:publish(Client1, Topic, #{'Topic-Alias' => 0}, <<"Topic-Alias">>, [{qos, ?QOS_0}]),
    %% [MQTT-3.3.2-8]
    ?assertEqual(148, receive_disconnect_reasoncode()),
    waiting_client_process_exit(Client1),

    {ok, Client2} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client2),
    {ok, _, [2]} = emqtt:subscribe(Client2, Topic, qos2),
    ok = emqtt:publish(
        Client2,
        Topic,
        #{'Topic-Alias' => 233},
        <<"Topic-Alias">>,
        [{qos, ?QOS_0}]
    ),
    ok = emqtt:publish(
        Client2,
        <<"">>,
        #{'Topic-Alias' => 233},
        <<"Topic-Alias">>,
        [{qos, ?QOS_0}]
    ),
    %% [MQTT-3.3.2-12]
    ?assertEqual(2, length(receive_messages(2))),
    ok = emqtt:disconnect(Client2),
    waiting_client_process_exit(Client2),

    process_flag(trap_exit, false).

t_publish_response_topic(Config) ->
    ConnFun = ?config(conn_fun, Config),
    process_flag(trap_exit, true),
    Topic = nth(1, ?TOPICS),

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    ok = emqtt:publish(
        Client1,
        Topic,
        #{'Response-Topic' => nth(1, ?WILD_TOPICS)},
        <<"Response-Topic">>,
        [{qos, ?QOS_0}]
    ),
    %% [MQTT-3.3.2-14]
    ?assertEqual(130, receive_disconnect_reasoncode()),
    waiting_client_process_exit(Client1),

    process_flag(trap_exit, false).

t_publish_properties(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),
    Properties = #{
        %% [MQTT-3.3.2-15]
        'Response-Topic' => Topic,
        %% [MQTT-3.3.2-16]
        'Correlation-Data' => <<"233">>,
        %% [MQTT-3.3.2-18]
        'User-Property' => [{<<"a">>, <<"2333">>}],
        %% [MQTT-3.3.2-20]
        'Content-Type' => <<"2333">>
    },

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    {ok, _, [2]} = emqtt:subscribe(Client1, Topic, qos2),
    ok = emqtt:publish(Client1, Topic, Properties, <<"Publish Properties">>, [{qos, ?QOS_0}]),
    [Msg1 | _] = receive_messages(1),
    %% [MQTT-3.3.2-16]
    ?assertEqual(Properties, maps:get(properties, Msg1)),
    ok = emqtt:disconnect(Client1).

t_subscription_filter(init, Config) ->
    OldMode = emqx:get_config([mqtt, subscription_message_filter], disable),
    [{old_subscription_message_filter, OldMode} | Config];
t_subscription_filter('end', Config) ->
    emqx_config:put(
        [mqtt, subscription_message_filter], ?config(old_subscription_message_filter, Config)
    ).

-doc """
Verify subscription message filtering against MQTT 5 User-Property values when
the feature is enabled, and verify that `?` remains part of the plain topic
filter when the feature is disabled.
""".
t_subscription_filter(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = <<"subscription/filter/topic">>,
    WildcardTopic = <<"subscription/filter/wildcard/topic">>,
    PlainTopic = <<"subscription/filter/plain?location=roomA">>,
    emqx_config:put([mqtt, subscription_message_filter], enable),

    {ok, Sub} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Sub),
    {ok, Pub} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Pub),
    {ok, _, [?QOS_1]} = emqtt:subscribe(
        Sub, <<"subscription/filter/topic?location=roomA&value>25">>, qos1
    ),
    ok = emqtt:publish(
        Pub,
        Topic,
        #{'User-Property' => [{<<"location">>, <<"roomB">>}, {<<"value">>, <<"30">>}]},
        <<"miss">>,
        [{qos, ?QOS_0}]
    ),
    ok = emqtt:publish(
        Pub,
        Topic,
        #{'User-Property' => [{<<"location">>, <<"roomA">>}, {<<"value">>, <<"26">>}]},
        <<"match">>,
        [{qos, ?QOS_0}]
    ),
    [Matched] = receive_messages(2),
    ?assertEqual(<<"match">>, maps:get(payload, Matched)),
    ok = emqtt:disconnect(Sub),

    {ok, WildcardSub} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(WildcardSub),
    {ok, _, [?QOS_1]} = emqtt:subscribe(
        WildcardSub, <<"subscription/filter/#?location=roomA&value>25">>, qos1
    ),
    ok = emqtt:publish(
        Pub,
        WildcardTopic,
        #{'User-Property' => [{<<"location">>, <<"roomB">>}, {<<"value">>, <<"30">>}]},
        <<"wildcard-miss">>,
        [{qos, ?QOS_0}]
    ),
    ok = emqtt:publish(
        Pub,
        WildcardTopic,
        #{'User-Property' => [{<<"location">>, <<"roomA">>}, {<<"value">>, <<"26">>}]},
        <<"wildcard-match">>,
        [{qos, ?QOS_0}]
    ),
    [WildcardMatched] = receive_messages(2),
    ?assertEqual(<<"wildcard-match">>, maps:get(payload, WildcardMatched)),
    ok = emqtt:disconnect(WildcardSub),

    {ok, QueueSub} = emqtt:start_link([{proto_ver, v5} | Config]),
    unlink(QueueSub),
    {ok, _} = emqtt:ConnFun(QueueSub),
    ?assertMatch(
        {'EXIT', {{shutdown, {disconnected, ?RC_TOPIC_FILTER_INVALID, _}}, _}},
        catch emqtt:subscribe(QueueSub, <<"$queue/subscription/filter/topic?location=roomA">>, qos1)
    ),

    {ok, QueueAliasSub} = emqtt:start_link([{proto_ver, v5} | Config]),
    unlink(QueueAliasSub),
    {ok, _} = emqtt:ConnFun(QueueAliasSub),
    ?assertMatch(
        {'EXIT', {{shutdown, {disconnected, ?RC_TOPIC_FILTER_INVALID, _}}, _}},
        catch emqtt:subscribe(
            QueueAliasSub, <<"$q/subscription/filter/topic?location=roomA">>, qos1
        )
    ),

    {ok, StreamSub} = emqtt:start_link([{proto_ver, v5} | Config]),
    unlink(StreamSub),
    {ok, _} = emqtt:ConnFun(StreamSub),
    ?assertMatch(
        {'EXIT', {{shutdown, {disconnected, ?RC_TOPIC_FILTER_INVALID, _}}, _}},
        catch emqtt:subscribe(
            StreamSub, <<"$stream/subscription/filter/topic?location=roomA">>, qos1
        )
    ),

    {ok, StreamAliasSub} = emqtt:start_link([{proto_ver, v5} | Config]),
    unlink(StreamAliasSub),
    {ok, _} = emqtt:ConnFun(StreamAliasSub),
    ?assertMatch(
        {'EXIT', {{shutdown, {disconnected, ?RC_TOPIC_FILTER_INVALID, _}}, _}},
        catch emqtt:subscribe(
            StreamAliasSub, <<"$s/subscription/filter/topic?location=roomA">>, qos1
        )
    ),

    emqx_config:put([mqtt, subscription_message_filter], disable),
    {ok, PlainSub} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(PlainSub),
    {ok, _, [?QOS_1]} = emqtt:subscribe(PlainSub, PlainTopic, qos1),
    ok = emqtt:publish(Pub, PlainTopic, #{}, <<"plain">>, [{qos, ?QOS_0}]),
    [PlainMatched] = receive_messages(1),
    ?assertEqual(<<"plain">>, maps:get(payload, PlainMatched)),
    ok = emqtt:disconnect(PlainSub),
    ok = emqtt:disconnect(Pub).

t_subscription_filter_authz(init, Config) ->
    OldMode = emqx:get_config([mqtt, subscription_message_filter], disable),
    emqx_config:put_zone_conf(default, [authorization, enable], true),
    [{old_subscription_message_filter, OldMode} | Config];
t_subscription_filter_authz('end', Config) ->
    emqx_config:put(
        [mqtt, subscription_message_filter], ?config(old_subscription_message_filter, Config)
    ),
    emqx_config:put_zone_conf(default, [authorization, enable], false).

-doc """
Verify that authorization checks use the base topic (without filter expression)
when subscription message filter is enabled, and that `?` remains part of the
topic for authorization purposes when the feature is disabled.
""".
t_subscription_filter_authz(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = <<"foo/bar">>,
    FilteredTopic = <<"foo/bar?v=1">>,

    %% --- filter enabled ---
    emqx_config:put([mqtt, subscription_message_filter], enable),

    %% Deny foo/bar: both foo/bar and foo/bar?v=1 should be denied
    ok = meck:new(emqx_access_control, [non_strict, passthrough, no_history, no_link]),
    meck:expect(emqx_access_control, authorize, fun(_, _, T) ->
        case T of
            <<"foo/bar">> -> deny;
            _ -> allow
        end
    end),
    {ok, C1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(C1),
    {ok, _, [?RC_NOT_AUTHORIZED]} = emqtt:subscribe(C1, Topic, qos1),
    {ok, _, [?RC_NOT_AUTHORIZED]} = emqtt:subscribe(C1, FilteredTopic, qos1),
    ok = emqtt:disconnect(C1),
    meck:unload(emqx_access_control),

    %% Allow foo/bar: both foo/bar and foo/bar?v=1 should be allowed
    ok = meck:new(emqx_access_control, [non_strict, passthrough, no_history, no_link]),
    meck:expect(emqx_access_control, authorize, fun(_, _, T) ->
        case T of
            <<"foo/bar">> -> allow;
            _ -> deny
        end
    end),
    {ok, C2} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(C2),
    {ok, _, [?RC_GRANTED_QOS_1]} = emqtt:subscribe(C2, Topic, qos1),
    {ok, _, [?RC_GRANTED_QOS_1]} = emqtt:subscribe(C2, FilteredTopic, qos1),
    ok = emqtt:disconnect(C2),
    meck:unload(emqx_access_control),

    %% --- filter disabled ---
    emqx_config:put([mqtt, subscription_message_filter], disable),

    %% Deny foo/bar: foo/bar denied, but foo/bar?v=1 is a different topic so allowed
    ok = meck:new(emqx_access_control, [non_strict, passthrough, no_history, no_link]),
    meck:expect(emqx_access_control, authorize, fun(_, _, T) ->
        case T of
            <<"foo/bar">> -> deny;
            _ -> allow
        end
    end),
    {ok, C3} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(C3),
    {ok, _, [?RC_NOT_AUTHORIZED]} = emqtt:subscribe(C3, Topic, qos1),
    {ok, _, [?RC_GRANTED_QOS_1]} = emqtt:subscribe(C3, FilteredTopic, qos1),
    ok = emqtt:disconnect(C3),
    meck:unload(emqx_access_control),

    %% Allow foo/bar: foo/bar allowed, but foo/bar?v=1 is a different topic so denied
    ok = meck:new(emqx_access_control, [non_strict, passthrough, no_history, no_link]),
    meck:expect(emqx_access_control, authorize, fun(_, _, T) ->
        case T of
            <<"foo/bar">> -> allow;
            _ -> deny
        end
    end),
    {ok, C4} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(C4),
    {ok, _, [?RC_GRANTED_QOS_1]} = emqtt:subscribe(C4, Topic, qos1),
    {ok, _, [?RC_NOT_AUTHORIZED]} = emqtt:subscribe(C4, FilteredTopic, qos1),
    ok = emqtt:disconnect(C4),
    meck:unload(emqx_access_control).

t_publish_overlapping_subscriptions(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),
    Properties = #{'Subscription-Identifier' => 2333},

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    {ok, _, [1]} = emqtt:subscribe(Client1, Properties, nth(1, ?WILD_TOPICS), qos1),
    {ok, _, [0]} = emqtt:subscribe(Client1, Properties, nth(3, ?WILD_TOPICS), qos0),
    {ok, _} = emqtt:publish(
        Client1,
        Topic,
        #{},
        <<"t_publish_overlapping_subscriptions">>,
        [{qos, ?QOS_2}]
    ),

    [Msg1 | _] = receive_messages(2),
    %% [MQTT-3.3.4-2]
    ?assert(maps:get(qos, Msg1) < 2),
    %% [MQTT-3.3.4-3]
    ?assertEqual(Properties, maps:get(properties, Msg1)),
    ok = emqtt:disconnect(Client1).

%%--------------------------------------------------------------------
%% Subsctibe
%%--------------------------------------------------------------------

t_subscribe_topic_alias(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic1 = nth(1, ?TOPICS),
    Topic2 = nth(2, ?TOPICS),
    {ok, Client1} = emqtt:start_link([
        {proto_ver, v5},
        {properties, #{'Topic-Alias-Maximum' => 1}}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client1),
    {ok, _, [2]} = emqtt:subscribe(Client1, Topic1, qos2),
    {ok, _, [2]} = emqtt:subscribe(Client1, Topic2, qos2),

    ok = emqtt:publish(Client1, Topic1, #{}, <<"Topic-Alias">>, [{qos, ?QOS_0}]),
    [Msg1] = receive_messages(1),
    ?assertEqual({ok, #{'Topic-Alias' => 1}}, maps:find(properties, Msg1)),
    ?assertEqual({ok, Topic1}, maps:find(topic, Msg1)),

    ok = emqtt:publish(Client1, Topic1, #{}, <<"Topic-Alias">>, [{qos, ?QOS_0}]),
    [Msg2] = receive_messages(1),
    ?assertEqual({ok, #{'Topic-Alias' => 1}}, maps:find(properties, Msg2)),
    ?assertEqual({ok, <<>>}, maps:find(topic, Msg2)),

    ok = emqtt:publish(Client1, Topic2, #{}, <<"Topic-Alias">>, [{qos, ?QOS_0}]),
    [Msg3] = receive_messages(1),
    ?assertEqual({ok, #{}}, maps:find(properties, Msg3)),
    ?assertEqual({ok, Topic2}, maps:find(topic, Msg3)),

    ok = emqtt:disconnect(Client1).

-doc """
A client whose `Topic Alias Maximum` is absent or 0 is never sent a topic alias
[MQTT-3.1.2-27].
""".
t_subscribe_no_topic_alias(Config) ->
    %% Client omits `Topic Alias Maximum`, so it defaults to 0.
    ok = check_no_topic_alias_sent(#{}, Config),
    %% Client sends `Topic Alias Maximum` = 0 explicitly.
    ok = check_no_topic_alias_sent(#{'Topic-Alias-Maximum' => 0}, Config).

check_no_topic_alias_sent(ConnProps, Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),
    {ok, Client} = emqtt:start_link([
        {proto_ver, v5},
        {properties, ConnProps}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Client),
    {ok, _, [0]} = emqtt:subscribe(Client, Topic, qos0),
    %% Publish twice: an alias is only assigned on the first delivery to a topic,
    %% and reused (with an empty topic name) on the following ones.
    lists:foreach(
        fun(N) ->
            Payload = integer_to_binary(N),
            ok = emqtt:publish(Client, Topic, #{}, Payload, [{qos, ?QOS_0}]),
            [Msg] = receive_messages(1),
            ?assertEqual(Payload, maps:get(payload, Msg)),
            %% [MQTT-3.1.2-27]
            ?assertEqual(#{}, maps:get(properties, Msg, #{})),
            ?assertEqual(Topic, maps:get(topic, Msg))
        end,
        [1, 2]
    ),
    ok = emqtt:disconnect(Client).

t_subscribe_no_local(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    {ok, _, [2]} = emqtt:subscribe(Client1, #{}, [{Topic, [{nl, true}, {qos, 2}]}]),

    {ok, Client2} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client2),
    {ok, _, [2]} = emqtt:subscribe(Client2, #{}, [{Topic, [{nl, true}, {qos, 2}]}]),

    ok = emqtt:publish(Client1, Topic, <<"t_subscribe_no_local">>, 0),
    %% [MQTT-3.8.3-3]
    ?assertEqual(1, length(receive_messages(2))),
    ok = emqtt:disconnect(Client1).

t_subscribe_no_local_mixed(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),
    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),

    {ok, Client2} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client2),

    %% Given tow clients and  client1 subscribe to topic with 'no local' set to true
    {ok, _, [2]} = emqtt:subscribe(Client1, #{}, [{Topic, [{nl, true}, {qos, 2}]}]),

    %% When mixed publish traffic are sent from both clients (Client1 sent 6 and Client2 sent 2)
    CB = {fun emqtt:sync_publish_result/3, [self(), async_res]},
    ok = emqtt:publish_async(Client1, Topic, <<"t_subscribe_no_local_mixed1">>, 0, CB),
    ok = emqtt:publish_async(Client2, Topic, <<"t_subscribe_no_local_mixed2">>, 0, CB),
    ok = emqtt:publish_async(Client1, Topic, <<"t_subscribe_no_local_mixed3">>, 0, CB),
    ok = emqtt:publish_async(Client1, Topic, <<"t_subscribe_no_local_mixed4">>, 0, CB),
    ok = emqtt:publish_async(Client1, Topic, <<"t_subscribe_no_local_mixed5">>, 0, CB),
    ok = emqtt:publish_async(Client2, Topic, <<"t_subscribe_no_local_mixed6">>, 0, CB),
    ok = emqtt:publish_async(Client1, Topic, <<"t_subscribe_no_local_mixed7">>, 0, CB),
    ok = emqtt:publish_async(Client1, Topic, <<"t_subscribe_no_local_mixed8">>, 0, CB),
    [
        receive
            {async_res, Res} -> ?assertEqual(ok, Res)
        end
     || _ <- lists:seq(1, 8)
    ],

    %% Then only two messages from clients 2 are received
    PubRecvd = receive_messages(9),
    ct:pal("~p", [PubRecvd]),
    ?assertEqual(2, length(PubRecvd)),
    ok = emqtt:disconnect(Client1),
    ok = emqtt:disconnect(Client2).

t_subscribe_actions(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),
    Properties = #{'Subscription-Identifier' => 2333},

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    {ok, _, [2]} = emqtt:subscribe(Client1, Properties, Topic, qos2),
    {ok, _, [1]} = emqtt:subscribe(Client1, Properties, Topic, qos1),
    {ok, _} = emqtt:publish(Client1, Topic, <<"t_subscribe_actions">>, 2),
    [Msg1 | _] = receive_messages(1),
    %% [MQTT-3.8.4-3] [MQTT-3.8.4-8]
    ?assertEqual(1, maps:get(qos, Msg1)),
    %% [MQTT-3.8.4-5] [MQTT-3.8.4-6] [MQTT-3.8.4-7]
    {ok, _, [2, 2]} = emqtt:subscribe(Client1, [
        {nth(1, ?TOPICS), qos2},
        {nth(2, ?TOPICS), qos2}
    ]),
    ok = emqtt:disconnect(Client1).

t_subscribe_max_qos_allowed(init, Config) ->
    Config;
t_subscribe_max_qos_allowed('end', _Config) ->
    emqx_config:put_zone_conf(default, [], check_zone_config(_Default = "")).

t_subscribe_max_qos_allowed(Config) ->
    ConnFun = ?config(conn_fun, Config),

    #{mqtt := MQTTConf} = check_zone_config(
        "mqtt {"
        "\n max_qos_allowed = 2"
        "\n subscription_max_qos_rules = ["
        "\n   { topic { equals = \"t\" }, qos = 1 }"
        "\n   { topic { matches = \"glob/+/#\" }, qos = 0 }"
        "\n ] }"
    ),

    emqx_config:put_zone_conf(default, [mqtt], MQTTConf),

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),

    ?assertMatch(
        {ok, _, [?RC_GRANTED_QOS_1]},
        emqtt:subscribe(Client1, <<"t">>, ?QOS_2)
    ),
    ?assertMatch(
        {ok, _, [
            ?RC_GRANTED_QOS_0,
            ?RC_GRANTED_QOS_2
        ]},
        emqtt:subscribe(Client1, #{}, [
            {<<"glob/sub/topic/#">>, [{qos, 1}]},
            {<<"t/+">>, [{qos, 2}]}
        ])
    ),

    ok = emqtt:disconnect(Client1).

%%--------------------------------------------------------------------
%% Unsubsctibe Unsuback
%%--------------------------------------------------------------------

t_unsubscribe(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic1 = nth(1, ?TOPICS),
    Topic2 = nth(2, ?TOPICS),

    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    {ok, _, [2]} = emqtt:subscribe(Client1, Topic1, qos2),
    %% [MQTT-3.10.4-4]
    {ok, _, [0]} = emqtt:unsubscribe(Client1, Topic1),
    %% [MQTT-3.10.4-5]
    {ok, _, [17]} = emqtt:unsubscribe(Client1, <<"noExistTopic">>),

    {ok, _, [2, 2]} = emqtt:subscribe(Client1, [{Topic1, qos2}, {Topic2, qos2}]),
    %% [[MQTT-3.10.4-6]]  [MQTT-3.11.3-1]  [MQTT-3.11.3-2]
    {ok, _, [0, 0, 17]} = emqtt:unsubscribe(Client1, [Topic1, Topic2, <<"noExistTopic">>]),
    ok = emqtt:disconnect(Client1).

%%--------------------------------------------------------------------
%% Pingreq
%%--------------------------------------------------------------------

t_pingreq(Config) ->
    ConnFun = ?config(conn_fun, Config),
    {ok, Client1} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client1),
    %% [MQTT-3.12.4-1]
    pong = emqtt:ping(Client1),
    ok = emqtt:disconnect(Client1).

%%--------------------------------------------------------------------
%% Shared Subscriptions
%%--------------------------------------------------------------------

t_shared_subscriptions_client_terminates_when_qos_eq_2(init, Config) ->
    ok = meck:new(emqtt, [non_strict, passthrough, no_history, no_link]),
    Config;
t_shared_subscriptions_client_terminates_when_qos_eq_2('end', _Config) ->
    catch meck:unload(emqtt).

t_shared_subscriptions_client_terminates_when_qos_eq_2(Config) ->
    ConnFun = ?config(conn_fun, Config),
    process_flag(trap_exit, true),
    emqx_config:put([broker, shared_dispatch_ack_enabled], true),

    Topic = nth(1, ?TOPICS),
    SharedTopic = list_to_binary("$share/sharename/" ++ binary_to_list(<<"TopicA">>)),

    CRef = counters:new(1, [atomics]),
    meck:expect(
        emqtt,
        connected,
        fun
            (cast, {?PUBLISH_PACKET(?QOS_2, _PacketId), _Via}, _State) ->
                ok = counters:add(CRef, 1, 1),
                {stop, {shutdown, for_testing}};
            (Arg1, ARg2, Arg3) ->
                meck:passthrough([Arg1, ARg2, Arg3])
        end
    ),

    {ok, Sub1} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, <<"sub_client_1">>},
        {keepalive, 5}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Sub1),
    {ok, _, [2]} = emqtt:subscribe(Sub1, SharedTopic, qos2),

    {ok, Sub2} = emqtt:start_link([
        {proto_ver, v5},
        {clientid, <<"sub_client_2">>},
        {keepalive, 5}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(Sub2),
    {ok, _, [2]} = emqtt:subscribe(Sub2, SharedTopic, qos2),

    {ok, Pub} = emqtt:start_link([{proto_ver, v5}, {clientid, <<"pub_client">>} | Config]),
    {ok, _} = emqtt:ConnFun(Pub),
    {ok, _} = emqtt:publish(
        Pub,
        Topic,
        <<"t_shared_subscriptions_client_terminates_when_qos_eq_2">>,
        2
    ),

    receive
        {'EXIT', _, {shutdown, for_testing}} ->
            ok
    after 1000 ->
        ct:fail("disconnected timeout")
    end,

    ?assertEqual(1, counters:get(CRef, 1)),
    process_flag(trap_exit, false).

t_share_subscribe_no_local(Config) ->
    ConnFun = ?config(conn_fun, Config),
    process_flag(trap_exit, true),
    ShareTopic = <<"$share/sharename/TopicA">>,

    {ok, Client} = emqtt:start_link([{proto_ver, v5} | Config]),
    {ok, _} = emqtt:ConnFun(Client),
    %% MQTT-5.0 [MQTT-3.8.3-4] and [MQTT-4.13.1-1] (Disconnect)
    case catch emqtt:subscribe(Client, #{}, [{ShareTopic, [{nl, true}, {qos, 1}]}]) of
        {'EXIT', {Reason, _Stk}} ->
            ?assertEqual({shutdown, {disconnected, ?RC_PROTOCOL_ERROR, #{}}}, Reason)
    end,
    process_flag(trap_exit, false).

t_CONNECT_packet_too_large(init, Config) ->
    MaxSize = 1024,
    #{mqtt := MQTTConf} = check_zone_config(
        "mqtt {" ++
            "\n max_packet_size = " ++ integer_to_list(MaxSize) ++
            "\n}"
    ),
    emqx_config:put_zone_conf(default, [mqtt], MQTTConf),
    [{max_size, MaxSize} | Config];
t_CONNECT_packet_too_large('end', _Config) ->
    emqx_config:put_zone_conf(default, [], check_zone_config(_Default = "")).

t_CONNECT_packet_too_large(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),
    MaxSize = ?config(max_size, Config),
    Payload = lists:duplicate(MaxSize, $a),
    {ok, ClientPid} = emqtt:start_link([
        {proto_ver, v5},
        {clean_start, true},
        {will_flag, true},
        {will_topic, Topic},
        {will_payload, Payload}
        | Config
    ]),
    unlink(ClientPid),
    try
        ?assertMatch({error, _}, emqtt:ConnFun(ClientPid))
    catch
        exit:{normal, W} when ConnFun =:= quic_connect ->
            %% TODO: fix quic_connect to return error
            ?assertMatch({gen_statem, call, _}, W)
    end.

t_PUBLISH_packet_too_large(init, Config) ->
    MaxSize = 1024,
    #{mqtt := MQTTConf} = check_zone_config(
        "mqtt {" ++
            "\n max_packet_size = " ++ integer_to_list(MaxSize) ++
            "\n}"
    ),
    emqx_config:put_zone_conf(default, [mqtt], MQTTConf),
    [{max_size, MaxSize} | Config];
t_PUBLISH_packet_too_large('end', _Config) ->
    emqx_config:put_zone_conf(default, [], check_zone_config(_Default = "")).

t_PUBLISH_packet_too_large(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = nth(1, ?TOPICS),
    MaxSize = ?config(max_size, Config),
    Payload = lists:duplicate(MaxSize, $a),
    {ok, ClientPid} = emqtt:start_link([
        {proto_ver, v5},
        {clean_start, true}
        | Config
    ]),
    unlink(ClientPid),
    monitor(process, ClientPid),
    {ok, _} = emqtt:ConnFun(ClientPid),
    case ?config(parse_unit, Config) of
        frame ->
            ?assertMatch(
                {error, tcp_closed},
                emqtt:publish(ClientPid, Topic, Payload, 1)
            );
        _ ->
            ?assertMatch(
                {error, {disconnected, ?RC_PACKET_TOO_LARGE, _}},
                emqtt:publish(ClientPid, Topic, Payload, 1)
            ),
            ?assertReceive(
                {'DOWN', _Ref, process, ClientPid,
                    {shutdown, {disconnected, ?RC_PACKET_TOO_LARGE, _}}},
                1000
            )
    end,
    ok.

t_deliver_packet_too_large(Config) ->
    ConnFun = ?config(conn_fun, Config),
    Topic = <<"TopicA">>,
    MaxSize = 1024,
    {ok, ClientPid} = emqtt:start_link([
        {proto_ver, v5},
        {clean_start, true},
        {properties, #{'Maximum-Packet-Size' => MaxSize}}
        | Config
    ]),
    {ok, _} = emqtt:ConnFun(ClientPid),
    %% Delivery larger than 1 KiB should be silently discarded:
    {ok, _, [?RC_GRANTED_QOS_1]} = emqtt:subscribe(ClientPid, Topic, ?QOS_1),
    Payload = lists:duplicate(MaxSize, $X),
    Message = emqx_message:make(<<?MODULE_STRING>>, ?QOS_1, Topic, Payload),
    ?assertMatch([{_, _, {ok, 1}}], emqx_broker:publish(Message)),
    ?assertNotReceive({publish, #{topic := Topic}}),
    %% Verify stats were updated:
    ?assertMatch(
        #{'send_msg.dropped.too_large' := 1},
        maps:from_list(emqx_cth_broker:connection_stats(ClientPid))
    ),
    %% Cleanup:
    ok = emqtt:disconnect(ClientPid).
