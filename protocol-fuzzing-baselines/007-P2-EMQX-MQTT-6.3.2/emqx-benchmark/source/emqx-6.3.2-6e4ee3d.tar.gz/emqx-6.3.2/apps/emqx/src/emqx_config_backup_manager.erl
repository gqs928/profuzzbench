%%--------------------------------------------------------------------
%% Copyright (c) 2025-2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------
-module(emqx_config_backup_manager).

-behaviour(gen_server).

-include("logger.hrl").

%% API
-export([
    start_link/0,

    backup_and_write/2
]).

%% Internal API (tests, debug)
-export([
    flush/0
]).

%% `gen_server' API
-export([
    init/1,
    terminate/2,

    handle_call/3,
    handle_cast/2,
    handle_info/2
]).

%%------------------------------------------------------------------------------
%% Type declarations
%%------------------------------------------------------------------------------

-define(MAX_KEEP_BACKUP_CONFIGS, 10).

-define(backup, backup).
-define(backup_tref, backup_tref).

%% Calls/Casts/Infos
-record(backup, {contents :: iodata(), filename :: file:filename()}).
-record(flush_backup, {}).

%%------------------------------------------------------------------------------
%% API
%%------------------------------------------------------------------------------

-spec start_link() -> gen_server:start_ret().
start_link() ->
    gen_server:start_link({local, ?MODULE}, ?MODULE, [], []).

-spec backup_and_write(file:filename(), iodata()) ->
    ok | {error, #{filename := file:filename(), reason := term()}}.
backup_and_write(DestFilename, NewContents) ->
    _ = filelib:ensure_dir(DestFilename),
    TmpFilename = DestFilename ++ ".tmp",
    case write_and_sync(TmpFilename, NewContents) of
        ok ->
            backup_and_replace(DestFilename, TmpFilename);
        {error, Reason} ->
            log_save_error(TmpFilename, Reason),
            _ = file:delete(TmpFilename),
            {error, #{filename => DestFilename, reason => Reason}}
    end.

%% Sync the staged file to disk before it is renamed over the destination,
%% so a power loss right after the rename cannot leave a truncated config file.
write_and_sync(Filename, Contents) ->
    case file:open(Filename, [write, binary, raw]) of
        {ok, Fd} ->
            Result =
                maybe
                    ok ?= file:write(Fd, Contents),
                    file:sync(Fd)
                end,
            _ = file:close(Fd),
            Result;
        {error, Reason} ->
            {error, Reason}
    end.

log_save_error(Filename, Reason) ->
    ?SLOG(error, #{
        msg => "failed_to_save_conf_file",
        hint =>
            "The updated cluster config is not saved on this node, please check the file system. "
            "Common causes: the file or its directory is read-only, owned by another user, "
            "is a Docker bind-mount of a single file (rename returns ebusy), "
            "or the file has the immutable attribute set (rename returns eperm).",
        filename => Filename,
        reason => Reason
    }).

%%------------------------------------------------------------------------------
%% Internal API
%%------------------------------------------------------------------------------

%% For tests/debugging
flush() ->
    gen_server:call(?MODULE, #flush_backup{}).

%%------------------------------------------------------------------------------
%% `gen_server' API
%%------------------------------------------------------------------------------

init(_) ->
    process_flag(trap_exit, true),
    State = #{
        ?backup => undefined,
        ?backup_tref => undefined
    },
    {ok, State}.

terminate(_Reason, State) ->
    handle_flush_backup(State).

handle_call(#flush_backup{}, _From, State0) ->
    State = handle_flush_backup(State0),
    {reply, ok, State};
handle_call(Call, _From, State) ->
    {reply, {error, {unknown_call, Call}}, State}.

handle_cast(#backup{contents = Contents, filename = DestFilename}, State0) ->
    State = handle_backup_request(State0, Contents, DestFilename),
    {noreply, State};
handle_cast(_Cast, State) ->
    {noreply, State}.

handle_info(#flush_backup{}, State0) ->
    State = handle_flush_backup(State0),
    {noreply, State};
handle_info(_Info, State) ->
    {noreply, State}.

%%------------------------------------------------------------------------------
%% Internal fns
%%------------------------------------------------------------------------------

handle_backup_request(#{?backup := {_DestFilename, _OlderContents}} = State, _, _) ->
    %% Older contents already enqueued
    State;
handle_backup_request(#{?backup := undefined} = State0, OldContents, DestFilename) ->
    State = State0#{?backup := {DestFilename, OldContents}},
    ensure_backup_timer(State).

handle_flush_backup(#{?backup := undefined} = State) ->
    %% Impossible, except if flush provoked manually
    State;
handle_flush_backup(#{?backup := {DestFilename, OldContents}} = State0) ->
    dump_backup(DestFilename, OldContents),
    State0#{?backup_tref := undefined, ?backup := undefined}.

ensure_backup_timer(#{?backup_tref := undefined} = State0) ->
    Timeout = emqx:get_config([config_backup_interval]),
    TRef = erlang:send_after(Timeout, self(), #flush_backup{}),
    State0#{?backup_tref := TRef};
ensure_backup_timer(State) ->
    State.

backup_and_replace(DestFilename, TmpFilename) ->
    case file:read_file(DestFilename) of
        {ok, OriginalContents} ->
            gen_server:cast(?MODULE, #backup{filename = DestFilename, contents = OriginalContents}),
            do_rename(TmpFilename, DestFilename);
        {error, enoent} ->
            %% not created yet
            do_rename(TmpFilename, DestFilename);
        {error, Reason} ->
            %% Backup is best-effort: skip this backup generation,
            %% but still persist the new config.
            ?SLOG(warning, #{
                msg => "failed_to_read_current_conf_file",
                filename => DestFilename,
                reason => Reason
            }),
            do_rename(TmpFilename, DestFilename)
    end.

do_rename(TmpFilename, DestFilename) ->
    case file:rename(TmpFilename, DestFilename) of
        ok ->
            ok;
        {error, Reason} ->
            log_save_error(DestFilename, Reason),
            _ = file:delete(TmpFilename),
            {error, #{filename => DestFilename, reason => Reason}}
    end.

dump_backup(DestFilename, OldContents) ->
    BackupFilename = DestFilename ++ "." ++ now_time() ++ ".bak",
    case file:write_file(BackupFilename, OldContents) of
        ok ->
            ok = prune_backup_files(DestFilename);
        {error, Reason} ->
            ?SLOG(warning, #{
                msg => "failed_to_backup_conf_file",
                filename => BackupFilename,
                reason => Reason
            }),
            ok
    end.

prune_backup_files(Path) ->
    Files0 = filelib:wildcard(Path ++ ".*"),
    Re = "\\.[0-9]{4}\\.[0-9]{2}\\.[0-9]{2}\\.[0-9]{2}\\.[0-9]{2}\\.[0-9]{2}\\.[0-9]{3}\\.bak$",
    Files = lists:filter(fun(F) -> re:run(F, Re) =/= nomatch end, Files0),
    Sorted = lists:reverse(lists:sort(Files)),
    {_Keeps, Deletes} = lists:split(min(?MAX_KEEP_BACKUP_CONFIGS, length(Sorted)), Sorted),
    lists:foreach(
        fun(F) ->
            case file:delete(F) of
                ok ->
                    ok;
                {error, Reason} ->
                    ?SLOG(warning, #{
                        msg => "failed_to_delete_backup_conf_file",
                        filename => F,
                        reason => Reason
                    }),
                    ok
            end
        end,
        Deletes
    ).

%% @private This is the same human-readable timestamp format as
%% hocon-cli generated app.<time>.config file name.
now_time() ->
    Ts = os:system_time(millisecond),
    {{Y, M, D}, {HH, MM, SS}} = calendar:system_time_to_local_time(Ts, millisecond),
    Res = io_lib:format(
        "~0p.~2..0b.~2..0b.~2..0b.~2..0b.~2..0b.~3..0b",
        [Y, M, D, HH, MM, SS, Ts rem 1000]
    ),
    lists:flatten(Res).
