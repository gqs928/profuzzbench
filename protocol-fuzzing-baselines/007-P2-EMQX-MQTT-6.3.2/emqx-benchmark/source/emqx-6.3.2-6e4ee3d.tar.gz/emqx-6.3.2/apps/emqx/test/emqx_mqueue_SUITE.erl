%%--------------------------------------------------------------------
%% Copyright (c) 2017-2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------

-module(emqx_mqueue_SUITE).

-compile(export_all).
-compile(nowarn_export_all).

-include_lib("emqx/include/emqx.hrl").
-include_lib("emqx/include/emqx_mqtt.hrl").

-include_lib("proper/include/proper.hrl").
-include_lib("eunit/include/eunit.hrl").

-define(Q, emqx_mqueue).

all() -> emqx_common_test_helpers:all(?MODULE).

-doc "Selective extraction preserves retained messages and queue accounting.".
t_out_qos0(_) ->
    Q0 = ?Q:init(#{max_len => 0, store_qos0 => true}),
    {empty, Q0} = ?Q:out_qos0(Q0),
    Q1Msg = #message{qos = 1, payload = <<"one">>},
    Q2Msg = #message{qos = 2, payload = <<"two">>},
    Q0Msg1 = #message{qos = 0, payload = <<"first">>, timestamp = 123, extra = #{keep => true}},
    Q0Msg2 = #message{qos = 0, payload = <<"second">>},
    {undefined, Q1} = ?Q:in(Q1Msg, Q0),
    {empty, Q1} = ?Q:out_qos0(Q1),
    {undefined, Q2} = ?Q:in(Q0Msg1, Q1),
    {undefined, Q3} = ?Q:in(Q2Msg, Q2),
    {undefined, Q4} = ?Q:in(Q0Msg2, Q3),
    {{value, Q0Msg1}, Q5} = ?Q:out_qos0(Q4),
    {{value, Q0Msg2}, Q6} = ?Q:out_qos0(Q5),
    {empty, Q6} = ?Q:out_qos0(Q6),
    assert_qos_counts(0, 2, Q6),
    ?assertEqual(6, ?Q:payload_bytes(Q6)),
    ?assertEqual(0, ?Q:dropped(Q6)),
    {{value, Q1Msg}, Q7} = ?Q:out(Q6),
    {{value, Q2Msg}, Q8} = ?Q:out(Q7),
    {empty, Q8} = ?Q:out_qos0(Q8).

-doc "Extraction stops at a priority without QoS0 and preserves state across attempted credit rotation.".
t_out_qos0_stops_at_priority(_) ->
    Q0 = ?Q:init(#{
        max_len => 0,
        store_qos0 => true,
        priorities => #{<<"high">> => 2, <<"middle">> => 1, <<"low">> => 0},
        shift_multiplier => 1
    }),
    MsgHigh = #message{qos = 1, topic = <<"high">>, payload = <<"high">>},
    MsgMid = #message{qos = 1, topic = <<"middle">>, payload = <<"middle">>},
    MsgLowQ0 = #message{qos = 0, topic = <<"low">>, payload = <<"low">>},
    MsgHighQ0 = #message{qos = 0, topic = <<"high">>, payload = <<"zero">>},
    {undefined, Q1} = ?Q:in(MsgHigh, Q0),
    {undefined, Q2} = ?Q:in(MsgMid, Q1),
    {undefined, Q3} = ?Q:in(MsgLowQ0, Q2),
    %% With credit undefined, stop at high without searching for low QoS0.
    {empty, Q3} = ?Q:out_qos0(Q3),
    {undefined, Q4} = ?Q:in(MsgHighQ0, Q3),
    {{value, MsgHighQ0}, Q5} = ?Q:out_qos0(Q4),
    %% With credit still positive, stop without consuming credit or changing the queue.
    {empty, Q5} = ?Q:out_qos0(Q5),
    %% Use the remaining two high-priority credits.
    {undefined, Q6} = ?Q:in(MsgHighQ0, Q5),
    {undefined, Q7} = ?Q:in(MsgHighQ0, Q6),
    {{value, MsgHighQ0}, Q8} = ?Q:out_qos0(Q7),
    {{value, MsgHighQ0}, Q9} = ?Q:out_qos0(Q8),
    %% With credit exhausted, attempt rotation to middle, then restore the original
    %% queue because middle has no QoS0. Do not continue searching at low.
    {empty, Q9} = ?Q:out_qos0(Q9),
    %% Ordinary dequeue still rotates from high to middle after the failed extraction.
    {{value, MsgMid}, Q10} = ?Q:out(Q9),
    %% After ordinary dequeue advances the priority, low QoS0 becomes extractable.
    {{value, MsgLowQ0}, Q11} = ?Q:out_qos0(Q10),
    {{value, MsgHigh}, Q12} = ?Q:out(Q11),
    ?assert(?Q:is_empty(Q12)).

-doc "Successful extraction consumes priority credits and uses normal rotation.".
t_out_qos0_priority_credit(_) ->
    Q0 = ?Q:init(#{
        max_len => 0,
        store_qos0 => true,
        priorities => #{<<"high">> => 1, <<"low">> => 0},
        shift_multiplier => 1
    }),
    MsgQ1H = #message{qos = 1, topic = <<"high">>, payload = <<>>},
    MsgQ0H1 = #message{qos = 0, topic = <<"high">>, payload = <<"1">>},
    MsgQ0H2 = #message{qos = 0, topic = <<"high">>, payload = <<"2">>},
    MsgQ0L = #message{qos = 0, topic = <<"low">>, payload = <<"low">>},
    Q1 = lists:foldl(
        fun(Msg, Q) ->
            {undefined, NQ} = ?Q:in(Msg, Q),
            NQ
        end,
        Q0,
        [MsgQ1H, MsgQ0H1, MsgQ0H2, MsgQ0L]
    ),
    {{value, MsgQ0H1}, Q2} = ?Q:out_qos0(Q1),
    {{value, MsgQ0H2}, Q3} = ?Q:out_qos0(Q2),
    {{value, MsgQ0L}, Q4} = ?Q:out_qos0(Q3),
    assert_qos_counts(0, 1, Q4).

t_info(_) ->
    Q = ?Q:init(#{max_len => 5, store_qos0 => true}),
    true = ?Q:info(store_qos0, Q),
    5 = ?Q:info(max_len, Q),
    0 = ?Q:info(len, Q),
    0 = ?Q:info(dropped, Q),
    #{
        store_qos0 := true,
        max_len := 5,
        len := 0,
        dropped := 0
    } = ?Q:info(Q).

t_in(_) ->
    Opts = #{max_len => 5, store_qos0 => true},
    Q = ?Q:init(Opts),
    ?assert(?Q:is_empty(Q)),
    {_, Q1} = ?Q:in(#message{payload = <<>>}, Q),
    ?assertEqual(1, ?Q:len(Q1)),
    {_, Q2} = ?Q:in(#message{qos = 1, payload = <<>>}, Q1),
    ?assertEqual(2, ?Q:len(Q2)),
    {_, Q3} = ?Q:in(#message{qos = 2, payload = <<>>}, Q2),
    {_, Q4} = ?Q:in(#message{payload = <<>>}, Q3),
    {_, Q5} = ?Q:in(#message{payload = <<>>}, Q4),
    ?assertEqual(5, ?Q:len(Q5)).

t_export_import_timestamps(_) ->
    Opts = #{max_len => 10, store_qos0 => true, priorities => #{<<"high">> => 10}},
    Messages = [
        #message{
            qos = 0,
            topic = <<"low">>,
            payload = <<"first">>,
            extra = #{mqueue_insert_ts => 10, other_metadata => preserved}
        },
        #message{
            qos = 1,
            topic = <<"high">>,
            payload = <<"second">>,
            extra = #{mqueue_insert_ts => 20}
        },
        #message{
            qos = 1,
            topic = <<"low">>,
            payload = <<"third">>,
            extra = #{mqueue_insert_ts => 30}
        }
    ],
    Enqueue = fun(Msg, Q) ->
        {undefined, Q1} = ?Q:in(Msg, Q),
        Q1
    end,
    Original = lists:foldl(Enqueue, ?Q:init(Opts), Messages),
    [First, Second, Third] = Messages,
    Exported = [Second, First, Third],
    ?assertEqual(Exported, ?Q:export(Original)),
    Imported = lists:foldl(Enqueue, ?Q:init(Opts), ?Q:export(Original)),
    ?assertEqual(Exported, ?Q:export(Imported)),
    ?assertEqual(?Q:to_list(Original), ?Q:to_list(Imported)),
    %% A cursor obtained before transfer still resumes at the same message.
    {[_, _], #{position := Pos}} = ?Q:query(Original, #{limit => 2}),
    ?assertEqual(
        ?Q:query(Original, #{limit => 1, position => Pos}),
        ?Q:query(Imported, #{limit => 1, position => Pos})
    ),
    ?assert(
        lists:all(
            fun(#message{extra = Extra}) -> not maps:is_key(mqueue_insert_ts, Extra) end,
            ?Q:to_list(Imported)
        )
    ).

t_in_qos0(_) ->
    Opts = #{max_len => 5, store_qos0 => false},
    Q = ?Q:init(Opts),
    false = ?Q:in(#message{qos = 0, payload = <<>>}, Q),
    assert_qos_counts(0, 0, Q),
    ?assertEqual(0, ?Q:payload_bytes(Q)).

t_qos_counts_disabled(_) ->
    Q = ?Q:init(#{max_len => 2, store_qos0 => false}),
    {undefined, Q1} = ?Q:in(#message{qos = 1, payload = <<"first">>}, Q),
    {undefined, Q2} = ?Q:in(#message{qos = 2, payload = <<"second">>}, Q1),
    {#message{qos = 1}, Q3} = ?Q:in(#message{qos = 1, payload = <<"third">>}, Q2),
    assert_qos_counts(0, 2, Q3),
    Filtered = ?Q:filter(fun(#message{qos = QoS}) -> QoS =:= 1 end, Q3),
    assert_qos_counts(0, 1, Filtered),
    ?assertEqual(5, ?Q:payload_bytes(Filtered)),
    {{value, #message{qos = 1}}, Drained} = ?Q:out(Filtered),
    Empty = ?Q:filter(fun(_) -> false end, Q3),
    assert_qos_counts(0, 0, Drained),
    assert_qos_counts(0, 0, Empty),
    lists:foreach(
        fun(MQ) ->
            ?assertEqual(false, ?Q:info(store_qos0, MQ)),
            ?assertEqual(false, ?Q:in(#message{qos = 0, payload = <<>>}, MQ))
        end,
        [Q, Q1, Q2, Q3, Filtered, Drained, Empty]
    ).

t_qos_counts(_) ->
    Q = ?Q:init(#{max_len => 2, store_qos0 => true}),
    assert_qos_counts(0, 0, Q),
    {undefined, Q1} = ?Q:in(#message{qos = 0, payload = <<"first">>}, Q),
    assert_qos_counts(1, 0, Q1),
    {undefined, Q2} = ?Q:in(#message{qos = 1, payload = <<"second">>}, Q1),
    assert_qos_counts(1, 1, Q2),
    %% Replacing QoS0 with QoS0 does not change either count.
    {#message{qos = 0, payload = <<"first">>}, Q3} =
        ?Q:in(#message{qos = 0, payload = <<"third">>}, Q2),
    assert_qos_counts(1, 1, Q3),
    %% QoS2 evicts the queued QoS0.
    {#message{qos = 0, payload = <<"third">>}, Q4} =
        ?Q:in(#message{qos = 2, payload = <<"fourth">>}, Q3),
    assert_qos_counts(0, 2, Q4),
    %% An incoming QoS0 is itself evicted when the queue only contains QoS1/2.
    {#message{qos = 0}, Q5} = ?Q:in(#message{qos = 0, payload = <<"fifth">>}, Q4),
    assert_qos_counts(0, 2, Q5),
    {#message{qos = 1, payload = <<"second">>}, Q6} =
        ?Q:in(#message{qos = 1, payload = <<"sixth">>}, Q5),
    assert_qos_counts(0, 2, Q6),
    {{value, #message{qos = 2}}, Q7} = ?Q:out(Q6),
    assert_qos_counts(0, 1, Q7),
    {{value, #message{qos = 1}}, Q8} = ?Q:out(Q7),
    assert_qos_counts(0, 0, Q8),
    {undefined, Q9} = ?Q:in(#message{qos = 0, payload = <<>>}, Q8),
    assert_qos_counts(1, 0, Q9),
    {{value, #message{qos = 0}}, Q10} = ?Q:out(Q9),
    assert_qos_counts(0, 0, Q10),
    ?assertEqual(true, ?Q:info(store_qos0, Q10)),
    {empty, Q10} = ?Q:out(Q10).

t_qos_counts_priorities(_) ->
    Q = ?Q:init(#{
        max_len => 3,
        store_qos0 => true,
        priorities => #{<<"high">> => 1, <<"low">> => 0},
        shift_multiplier => 1
    }),
    {undefined, Q1} = ?Q:in(#message{qos = 1, topic = <<"high">>, payload = <<"1">>}, Q),
    {undefined, Q2} = ?Q:in(#message{qos = 0, topic = <<"high">>, payload = <<"0">>}, Q1),
    {undefined, Q3} = ?Q:in(#message{qos = 2, topic = <<"high">>, payload = <<"2">>}, Q2),
    {undefined, Q4} = ?Q:in(#message{qos = 0, topic = <<"low">>, payload = <<"0">>}, Q3),
    assert_qos_counts(2, 2, Q4),
    ?assertEqual(Q4, ?Q:filter(fun(_) -> true end, Q4)),
    OnlyQoS0 = ?Q:filter(fun(#message{qos = QoS}) -> QoS =:= 0 end, Q4),
    assert_qos_counts(2, 0, OnlyQoS0),
    ?assertEqual(2, ?Q:payload_bytes(OnlyQoS0)),
    OnlyQoS12 = ?Q:filter(fun(#message{qos = QoS}) -> QoS =/= 0 end, Q4),
    assert_qos_counts(0, 2, OnlyQoS12),
    ?assertEqual(2, ?Q:payload_bytes(OnlyQoS12)),
    Empty = ?Q:filter(fun(_) -> false end, Q4),
    assert_qos_counts(0, 0, Empty),
    ?assertEqual(0, ?Q:payload_bytes(Empty)),
    ?assertEqual(true, ?Q:info(store_qos0, Empty)),
    {undefined, Refilled} = ?Q:in(#message{qos = 0, payload = <<>>}, Empty),
    assert_qos_counts(1, 0, Refilled),
    %% Exercise initial priority selection, credit consumption and rotation.
    {{value, #message{qos = 1}}, Q5} = ?Q:out(Q4),
    assert_qos_counts(2, 1, Q5),
    {{value, #message{qos = 0, topic = <<"high">>}}, Q6} = ?Q:out(Q5),
    assert_qos_counts(1, 1, Q6),
    {{value, #message{qos = 0, topic = <<"low">>}}, Q7} = ?Q:out(Q6),
    assert_qos_counts(0, 1, Q7),
    {{value, #message{qos = 2}}, Q8} = ?Q:out(Q7),
    assert_qos_counts(0, 0, Q8).

assert_qos_counts(NumQoS0, NumQoS12, Q) ->
    ?assertEqual(NumQoS0, ?Q:num_qos0(Q)),
    ?assertEqual(NumQoS12, ?Q:num_qos12(Q)),
    ?assertEqual(NumQoS0 + NumQoS12, ?Q:len(Q)),
    ?assertEqual(NumQoS0 + NumQoS12 =:= 0, ?Q:is_empty(Q)).

t_out(_) ->
    Opts = #{max_len => 5, store_qos0 => true},
    Q = ?Q:init(Opts),
    {empty, Q} = ?Q:out(Q),
    {_, Q1} = ?Q:in(#message{payload = <<"x">>}, Q),
    ?assertEqual(1, ?Q:payload_bytes(Q1)),
    {Value, Q2} = ?Q:out(Q1),
    ?assertEqual(0, ?Q:len(Q2)),
    ?assertEqual(0, ?Q:payload_bytes(Q2)),
    ?assertEqual({value, #message{payload = <<"x">>}}, Value).

t_payload_bytes_tracks_payload(_) ->
    Q0 = ?Q:init(#{max_len => 3, store_qos0 => true}),
    Msg1 = #message{qos = 1, payload = <<"one">>},
    Msg2 = #message{qos = 1, payload = <<"three">>},
    {_, Q1} = ?Q:in(Msg1, Q0),
    ?assertEqual(emqx_message:payload_size(Msg1), ?Q:payload_bytes(Q1)),
    {_, Q2} = ?Q:in(Msg2, Q1),
    ?assertEqual(
        emqx_message:payload_size(Msg1) + emqx_message:payload_size(Msg2),
        ?Q:payload_bytes(Q2)
    ),
    {{value, _}, Q3} = ?Q:out(Q2),
    ?assertEqual(emqx_message:payload_size(Msg2), ?Q:payload_bytes(Q3)).

t_simple_mqueue(_) ->
    Opts = #{max_len => 3, store_qos0 => false},
    Q = ?Q:init(Opts),
    ?assertEqual(3, ?Q:max_len(Q)),
    ?assert(?Q:is_empty(Q)),
    {_, Q1} = ?Q:in(#message{qos = 1, payload = <<"1">>}, Q),
    {_, Q2} = ?Q:in(#message{qos = 1, payload = <<"2">>}, Q1),
    {_, Q3} = ?Q:in(#message{qos = 1, payload = <<"3">>}, Q2),
    {_, Q4} = ?Q:in(#message{qos = 1, payload = <<"4">>}, Q3),
    ?assertEqual(3, ?Q:len(Q4)),
    {{value, Msg}, Q5} = ?Q:out(Q4),
    ?assertEqual(<<"2">>, Msg#message.payload),
    ?assertEqual([{len, 2}, {max_len, 3}, {dropped, 1}], ?Q:stats(Q5)).

t_infinity_simple_mqueue(_) ->
    Opts = #{max_len => 0, store_qos0 => false},
    Q = ?Q:init(Opts),
    ?assert(?Q:is_empty(Q)),
    ?assertEqual(0, ?Q:max_len(Q)),
    Qx = lists:foldl(
        fun(I, AccQ) ->
            {_, NewQ} = ?Q:in(#message{qos = 1, payload = iolist_to_binary([I])}, AccQ),
            NewQ
        end,
        Q,
        lists:seq(1, 255)
    ),
    ?assertEqual(255, ?Q:len(Qx)),
    ?assertEqual([{len, 255}, {max_len, 0}, {dropped, 0}], ?Q:stats(Qx)),
    {{value, V}, _Qy} = ?Q:out(Qx),
    ?assertEqual(<<1>>, V#message.payload).

t_priority_mqueue(_) ->
    Opts = #{
        max_len => 3,
        priorities =>
            #{
                <<"t1">> => 1,
                <<"t2">> => 2,
                <<"t3">> => 3
            },
        store_qos0 => false
    },
    Q = ?Q:init(Opts),
    ?assertEqual(3, ?Q:max_len(Q)),
    ?assert(?Q:is_empty(Q)),
    {_, Q1} = ?Q:in(#message{qos = 1, topic = <<"t2">>, payload = <<>>}, Q),
    {_, Q2} = ?Q:in(#message{qos = 1, topic = <<"t1">>, payload = <<>>}, Q1),
    {_, Q3} = ?Q:in(#message{qos = 1, topic = <<"t3">>, payload = <<>>}, Q2),
    ?assertEqual(3, ?Q:len(Q3)),
    {_, Q4} = ?Q:in(#message{qos = 1, topic = <<"t2">>, payload = <<>>}, Q3),
    ?assertEqual(4, ?Q:len(Q4)),
    {_, Q5} = ?Q:in(#message{qos = 1, topic = <<"t2">>, payload = <<>>}, Q4),
    ?assertEqual(5, ?Q:len(Q5)),
    {_, Q6} = ?Q:in(#message{qos = 1, topic = <<"t2">>, payload = <<>>}, Q5),
    ?assertEqual(5, ?Q:len(Q6)),
    {{value, _Msg}, Q7} = ?Q:out(Q6),
    ?assertEqual(4, ?Q:len(Q7)).

t_priority_mqueue_conservation(_) ->
    true = proper:quickcheck(conservation_prop()).

t_priority_order(_) ->
    Opts = #{
        max_len => 5,
        shift_multiplier => 1,
        priorities =>
            #{
                <<"t1">> => 0,
                <<"t2">> => 1,
                <<"t3">> => 2
            },
        store_qos0 => false
    },
    Messages = [
        {Topic, Message}
     || Topic <- [<<"t1">>, <<"t2">>, <<"t3">>],
        Message <- lists:seq(1, 10)
    ],
    Q = lists:foldl(
        fun({Topic, Message}, Q) ->
            element(
                2,
                ?Q:in(
                    #message{topic = Topic, qos = 1, payload = integer_to_binary(Message)},
                    Q
                )
            )
        end,
        ?Q:init(Opts),
        Messages
    ),
    ?assertMatch(
        [
            {<<"t3">>, <<"6">>},
            {<<"t3">>, <<"7">>},
            {<<"t3">>, <<"8">>},

            {<<"t2">>, <<"6">>},
            {<<"t2">>, <<"7">>},

            {<<"t1">>, <<"6">>},

            {<<"t3">>, <<"9">>},
            {<<"t3">>, <<"10">>},

            {<<"t2">>, <<"8">>},

            %% Note: for performance reasons we don't reset the
            %% counter when we run out of messages with the
            %% current prio, so next is t1:
            {<<"t1">>, <<"7">>},

            {<<"t2">>, <<"9">>},
            {<<"t2">>, <<"10">>},

            {<<"t1">>, <<"8">>},
            {<<"t1">>, <<"9">>},
            {<<"t1">>, <<"10">>}
        ],
        drain(Q)
    ).

t_priority_order2(_) ->
    Opts = #{
        max_len => 5,
        shift_multiplier => 2,
        priorities =>
            #{
                <<"t1">> => -1,
                <<"t2">> => 0
            },
        store_qos0 => false
    },
    Messages = [
        {Topic, Message}
     || Topic <- [<<"t1">>, <<"t2">>],
        Message <- lists:seq(1, 10)
    ],
    Q = lists:foldl(
        fun({Topic, Message}, Q) ->
            element(
                2,
                ?Q:in(
                    #message{topic = Topic, qos = 1, payload = integer_to_binary(Message)},
                    Q
                )
            )
        end,
        ?Q:init(Opts),
        Messages
    ),
    ?assertMatch(
        [
            {<<"t2">>, <<"6">>},
            {<<"t2">>, <<"7">>},
            {<<"t2">>, <<"8">>},
            {<<"t2">>, <<"9">>},

            {<<"t1">>, <<"6">>},
            {<<"t1">>, <<"7">>},

            {<<"t2">>, <<"10">>},

            {<<"t1">>, <<"8">>},
            {<<"t1">>, <<"9">>},
            {<<"t1">>, <<"10">>}
        ],
        drain(Q)
    ).

t_infinity_priority_mqueue(_) ->
    Opts = #{
        max_len => 0,
        priorities =>
            #{
                <<"t">> => 1,
                <<"t1">> => 2
            },
        store_qos0 => false
    },
    Q = ?Q:init(Opts),
    ?assertEqual(0, ?Q:max_len(Q)),
    Qx = lists:foldl(
        fun(I, AccQ) ->
            {undefined, AccQ1} = ?Q:in(
                #message{topic = <<"t1">>, qos = 1, payload = iolist_to_binary([I])}, AccQ
            ),
            {undefined, AccQ2} = ?Q:in(
                #message{topic = <<"t">>, qos = 1, payload = iolist_to_binary([I])}, AccQ1
            ),
            AccQ2
        end,
        Q,
        lists:seq(1, 255)
    ),
    ?assertEqual(510, ?Q:len(Qx)),
    ?assertEqual([{len, 510}, {max_len, 0}, {dropped, 0}], ?Q:stats(Qx)).

%%TODO: fixme later
t_length_priority_mqueue(_) ->
    Opts = #{
        max_len => 2,
        store_qos0 => false
    },
    Q = ?Q:init(Opts),
    2 = ?Q:max_len(Q),
    {_, Q1} = ?Q:in(#message{topic = <<"x">>, qos = 1, payload = <<1>>}, Q),
    {_, Q2} = ?Q:in(#message{topic = <<"x">>, qos = 1, payload = <<2>>}, Q1),
    {_, Q3} = ?Q:in(#message{topic = <<"y">>, qos = 1, payload = <<3>>}, Q2),
    {_, Q4} = ?Q:in(#message{topic = <<"y">>, qos = 1, payload = <<4>>}, Q3),
    ?assertEqual(2, ?Q:len(Q4)),
    {{value, _Val}, Q5} = ?Q:out(Q4),
    ?assertEqual(1, ?Q:len(Q5)).

t_dropped(_) ->
    Q = ?Q:init(#{max_len => 1, store_qos0 => true}),
    Msg1 = emqx_message:make(<<"t1">>, <<"payload">>),
    Msg2 = emqx_message:make(<<"t2">>, <<"payload">>),
    {undefined, Q1} = ?Q:in(Msg1, Q),
    {Dropped, Q2} = ?Q:in(Msg2, Q1),
    ?assertMatch(#message{topic = <<"t1">>}, Dropped),
    ?assertEqual(1, ?Q:dropped(Q2)).

t_dropped_qos0_first(_) ->
    Opts = #{max_len => 3, store_qos0 => true},
    Q0 = ?Q:init(Opts),
    Msg1 = emqx_message:make(?MODULE, ?QOS_1, ~"t", ~"qos1-1"),
    Msg2 = emqx_message:make(?MODULE, ?QOS_0, ~"t", ~"qos0-2"),
    Msg3 = emqx_message:make(?MODULE, ?QOS_1, ~"t", ~"qos1-3"),
    Msg4 = emqx_message:make(?MODULE, ?QOS_1, ~"t", ~"qos1-4"),
    {undefined, Q1} = ?Q:in(Msg1, Q0),
    {undefined, Q2} = ?Q:in(Msg2, Q1),
    {undefined, Q3} = ?Q:in(Msg3, Q2),
    {Dropped, Q4} = ?Q:in(Msg4, Q3),
    ?assertEqual(<<"qos0-2">>, emqx_message:payload(Dropped)),
    ?assertEqual(1, ?Q:dropped(Q4)),
    ?assertEqual(3, ?Q:len(Q4)),
    ?assertEqual(
        [{~"t", ~"qos1-1"}, {~"t", ~"qos1-3"}, {~"t", ~"qos1-4"}],
        drain(Q4)
    ).

t_dropped_incoming_qos0_first(_) ->
    Opts = #{max_len => 3, store_qos0 => true},
    Q0 = ?Q:init(Opts),
    Msg1 = emqx_message:make(?MODULE, ?QOS_1, ~"t", ~"qos1-1"),
    Msg2 = emqx_message:make(?MODULE, ?QOS_1, ~"t", ~"qos1-2"),
    Msg3 = emqx_message:make(?MODULE, ?QOS_2, ~"t", ~"qos2-3"),
    Msg4 = emqx_message:make(?MODULE, ?QOS_0, ~"t", ~"qos0-4"),
    {undefined, Q1} = ?Q:in(Msg1, Q0),
    {undefined, Q2} = ?Q:in(Msg2, Q1),
    {undefined, Q3} = ?Q:in(Msg3, Q2),
    {Dropped, Q4} = ?Q:in(Msg4, Q3),
    ?assertEqual(<<"qos0-4">>, emqx_message:payload(Dropped)),
    ?assertEqual(1, ?Q:dropped(Q4)),
    ?assertEqual(3, ?Q:len(Q4)),
    ?assertEqual(
        [{~"t", ~"qos1-1"}, {~"t", ~"qos1-2"}, {~"t", ~"qos2-3"}],
        drain(Q4)
    ).

t_query(_) ->
    EmptyQ = ?Q:init(#{max_len => 500, store_qos0 => true}),
    ?assertEqual({[], #{position => none, start => none}}, ?Q:query(EmptyQ, #{limit => 50})),
    RandPos = {erlang:system_time(nanosecond), 0},
    ?assertEqual(
        {[], #{position => RandPos, start => none}},
        ?Q:query(EmptyQ, #{position => RandPos, limit => 50})
    ),
    ?assertEqual(
        {[], #{position => none, start => none}},
        ?Q:query(EmptyQ, #{continuation => none, limit => 50})
    ),

    Q = lists:foldl(
        fun(Seq, QAcc) ->
            Msg = emqx_message:make(<<"t">>, integer_to_binary(Seq)),
            {_, QAcc1} = ?Q:in(Msg, QAcc),
            QAcc1
        end,
        EmptyQ,
        lists:seq(1, 114)
    ),

    {LastPos, LastStart} = lists:foldl(
        fun(PageSeq, {Pos, PrevStart}) ->
            Limit = 10,
            PagerParams = #{position => Pos, limit => Limit},
            {Page, #{position := NextPos, start := Start}} = ?Q:query(Q, PagerParams),
            ?assertEqual(10, length(Page)),
            ExpFirstPayload = integer_to_binary(PageSeq * Limit - Limit + 1),
            ExpLastPayload = integer_to_binary(PageSeq * Limit),
            FirstMsg = lists:nth(1, Page),
            LastMsg = lists:nth(10, Page),
            ?assertEqual(ExpFirstPayload, emqx_message:payload(FirstMsg)),
            ?assertEqual(ExpLastPayload, emqx_message:payload(LastMsg)),
            %% start value must not change as Mqueue is not modified during traversal
            NextStart =
                case PageSeq of
                    1 ->
                        ?assertEqual({mqueue_ts(FirstMsg), 0}, Start),
                        Start;
                    _ ->
                        ?assertEqual(PrevStart, Start),
                        PrevStart
                end,
            {NextPos, NextStart}
        end,
        {none, none},
        lists:seq(1, 11)
    ),

    {LastPartialPage, #{position := FinalPos} = LastMeta} = ?Q:query(Q, #{
        position => LastPos, limit => 10
    }),
    LastMsg = lists:nth(4, LastPartialPage),
    ?assertEqual(4, length(LastPartialPage)),
    ?assertEqual(<<"111">>, emqx_message:payload(lists:nth(1, LastPartialPage))),
    ?assertEqual(<<"114">>, emqx_message:payload(LastMsg)),
    ?assertEqual(#{position => {mqueue_ts(LastMsg), 0}, start => LastStart}, LastMeta),
    ?assertEqual(
        {[], #{start => LastStart, position => FinalPos}},
        ?Q:query(Q, #{position => FinalPos, limit => 10})
    ),

    {LargePage, LargeMeta} = ?Q:query(Q, #{position => none, limit => 1000}),
    ?assertEqual(114, length(LargePage)),
    ?assertEqual(<<"1">>, emqx_message:payload(hd(LargePage))),
    ?assertEqual(<<"114">>, emqx_message:payload(lists:last(LargePage))),
    ?assertEqual(#{start => LastStart, position => FinalPos}, LargeMeta),

    {FullPage, FullMeta} = ?Q:query(Q, #{position => none, limit => 114}),
    ?assertEqual(LargePage, FullPage),
    ?assertEqual(LargeMeta, FullMeta),

    {_, Q1} = emqx_mqueue:out(Q),
    {PageAfterRemove, #{start := StartAfterRemove}} = ?Q:query(Q1, #{position => none, limit => 10}),
    ?assertEqual(<<"2">>, emqx_message:payload(hd(PageAfterRemove))),
    ?assertEqual(StartAfterRemove, {mqueue_ts(hd(PageAfterRemove)), 0}).

t_query_with_priorities(_) ->
    Priorities = #{<<"t/infinity">> => infinity, <<"t/10">> => 10, <<"t/5">> => 5},
    EmptyQ = ?Q:init(#{max_len => 500, store_qos0 => true, priorities => Priorities}),

    ?assertEqual({[], #{position => none, start => none}}, ?Q:query(EmptyQ, #{limit => 50})),
    RandPos = {erlang:system_time(nanosecond), 0},
    ?assertEqual(
        {[], #{position => RandPos, start => none}},
        ?Q:query(EmptyQ, #{position => RandPos, limit => 50})
    ),
    ?assertEqual(
        {[], #{position => none, start => none}},
        ?Q:query(EmptyQ, #{continuation => none, limit => 50})
    ),

    {Q, ExpMsgsAcc} = lists:foldl(
        fun(Topic, {QAcc, MsgsAcc}) ->
            {TopicQ, TopicMsgs} =
                lists:foldl(
                    fun(Seq, {TopicQAcc, TopicMsgsAcc}) ->
                        Payload = <<Topic/binary, "_", (integer_to_binary(Seq))/binary>>,
                        Msg = emqx_message:make(Topic, Payload),
                        {_, TopicQAcc1} = ?Q:in(Msg, TopicQAcc),
                        {TopicQAcc1, [Msg | TopicMsgsAcc]}
                    end,
                    {QAcc, []},
                    lists:seq(1, 10)
                ),
            {TopicQ, [lists:reverse(TopicMsgs) | MsgsAcc]}
        end,
        {EmptyQ, []},
        [<<"t/test">>, <<"t/5">>, <<"t/infinity">>, <<"t/10">>]
    ),

    %% Manual resorting from the highest to the lowest priority
    [ExpMsgsPrio0, ExpMsgsPrio5, ExpMsgsPrioInf, ExpMsgsPrio10] = lists:reverse(ExpMsgsAcc),
    ExpMsgs = ExpMsgsPrioInf ++ ExpMsgsPrio10 ++ ExpMsgsPrio5 ++ ExpMsgsPrio0,
    {AllMsgs, #{start := StartPos, position := Pos}} = ?Q:query(Q, #{position => none, limit => 40}),
    ?assertEqual(40, length(AllMsgs)),
    ?assertEqual(ExpMsgs, with_empty_extra(AllMsgs)),
    FirstMsg = hd(AllMsgs),
    LastMsg = lists:last(AllMsgs),
    ?assertEqual(<<"t/infinity_1">>, emqx_message:payload(FirstMsg)),
    ?assertEqual(StartPos, {mqueue_ts(FirstMsg), infinity}),
    ?assertEqual(<<"t/test_10">>, emqx_message:payload(LastMsg)),
    ?assertMatch({_, 0}, Pos),
    ?assertEqual(Pos, {mqueue_ts(LastMsg), mqueue_prio(LastMsg)}),

    Pos5 = {mqueue_ts(lists:nth(5, AllMsgs)), mqueue_prio(lists:nth(5, AllMsgs))},
    LastInfPos = {mqueue_ts(lists:nth(10, AllMsgs)), mqueue_prio(lists:nth(5, AllMsgs))},

    {MsgsPrioInfTo10, #{start := StartPos, position := PosPrio10Msg5}} = ?Q:query(Q, #{
        position => Pos5, limit => 10
    }),
    ?assertEqual(10, length(MsgsPrioInfTo10)),
    ?assertEqual(<<"t/infinity_6">>, emqx_message:payload(hd(MsgsPrioInfTo10))),
    ?assertEqual(<<"t/10_5">>, emqx_message:payload(lists:last(MsgsPrioInfTo10))),
    ?assertEqual(PosPrio10Msg5, {
        mqueue_ts(lists:last(MsgsPrioInfTo10)), mqueue_prio(lists:last(MsgsPrioInfTo10))
    }),

    {MsgsPrioInfTo5, #{start := StartPos, position := PosPrio5Msg5}} = ?Q:query(Q, #{
        position => Pos5, limit => 20
    }),
    ?assertEqual(20, length(MsgsPrioInfTo5)),
    ?assertEqual(<<"t/infinity_6">>, emqx_message:payload(hd(MsgsPrioInfTo5))),
    ?assertEqual(<<"t/5_5">>, emqx_message:payload(lists:last(MsgsPrioInfTo5))),
    ?assertEqual(PosPrio5Msg5, {
        mqueue_ts(lists:last(MsgsPrioInfTo5)), mqueue_prio(lists:last(MsgsPrioInfTo5))
    }),

    {MsgsPrio10, #{start := StartPos, position := PosPrio10}} = ?Q:query(Q, #{
        position => LastInfPos, limit => 10
    }),
    ?assertEqual(ExpMsgsPrio10, with_empty_extra(MsgsPrio10)),
    ?assertEqual(10, length(MsgsPrio10)),
    ?assertEqual(<<"t/10_1">>, emqx_message:payload(hd(MsgsPrio10))),
    ?assertEqual(<<"t/10_10">>, emqx_message:payload(lists:last(MsgsPrio10))),
    ?assertEqual(PosPrio10, {mqueue_ts(lists:last(MsgsPrio10)), mqueue_prio(lists:last(MsgsPrio10))}),

    {MsgsPrio10To5, #{start := StartPos, position := _}} = ?Q:query(Q, #{
        position => LastInfPos, limit => 20
    }),
    ?assertEqual(ExpMsgsPrio10 ++ ExpMsgsPrio5, with_empty_extra(MsgsPrio10To5)).

conservation_prop() ->
    ?FORALL(
        {Priorities, Messages},
        ?LET(
            Priorities,
            topic_priorities(),
            {Priorities, messages(Priorities)}
        ),
        try
            Opts = #{
                max_len => 0,
                priorities => maps:from_list(Priorities),
                store_qos0 => false
            },
            %% Put messages in
            Q1 = lists:foldl(
                fun({Topic, Message}, Q) ->
                    element(2, ?Q:in(#message{topic = Topic, qos = 1, payload = Message}, Q))
                end,
                ?Q:init(Opts),
                Messages
            ),
            %% Collect messages
            Got = lists:sort(drain(Q1)),
            Expected = lists:sort(Messages),
            case Expected =:= Got of
                true ->
                    true;
                false ->
                    ct:pal("Mismatch: expected ~p~nGot ~p~n", [Expected, Got]),
                    false
            end
        catch
            EC:Err:Stack ->
                ct:pal("Error: ~p", [{EC, Err, Stack}]),
                false
        end
    ).

%% Proper generators:

topic(Priorities) ->
    {Topics, _} = lists:unzip(Priorities),
    oneof(Topics).

topic_priorities() ->
    non_empty(list({binary(), priority()})).

priority() ->
    oneof([integer(), infinity]).

messages(Topics) ->
    list({topic(Topics), binary()}).

%% Internal functions:

drain(Q) ->
    case ?Q:out(Q) of
        {empty, _} ->
            [];
        {{value, #message{topic = T, payload = P}}, Q1} ->
            [{T, P} | drain(Q1)]
    end.

mqueue_ts(#message{extra = #{mqueue_insert_ts := Ts}}) -> Ts.
mqueue_prio(#message{extra = #{mqueue_priority := Prio}}) -> Prio.

with_empty_extra(Msgs) ->
    [M#message{extra = #{}} || M <- Msgs].
