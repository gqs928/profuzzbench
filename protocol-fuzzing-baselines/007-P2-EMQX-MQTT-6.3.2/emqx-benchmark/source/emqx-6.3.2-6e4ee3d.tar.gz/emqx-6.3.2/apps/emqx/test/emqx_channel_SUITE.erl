%%--------------------------------------------------------------------
%% Copyright (c) 2019-2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------

-module(emqx_channel_SUITE).

-compile(export_all).
-compile(nowarn_export_all).

-include_lib("emqx/include/emqx.hrl").
-include_lib("emqx/include/emqx_mqtt.hrl").
-include_lib("eunit/include/eunit.hrl").
-include_lib("emqx/include/asserts.hrl").
-include_lib("common_test/include/ct.hrl").
-include_lib("emqx/include/emqx_hooks.hrl").

-import(emqx_common_test_helpers, [on_exit/1]).

all() ->
    emqx_common_test_helpers:all(?MODULE).

%%--------------------------------------------------------------------
%% CT Callbacks
%%--------------------------------------------------------------------

init_per_suite(Config) ->
    %% Authz
    Apps = emqx_cth_suite:start(
        [
            {emqx, #{
                override_env => [{boot_modules, [broker]}]
            }}
        ],
        #{work_dir => emqx_cth_suite:work_dir(Config)}
    ),
    %% Set up limiters for default listener
    ok = emqx_limiter:create_listener_limiters('tcp:default', #{}),

    %% Set up limiters for a listener with tight message rate limit
    DefaultConf = emqx_config:get_listener_conf(tcp, default, []),
    emqx_config:put_listener_conf(tcp, low_message_rate, [], DefaultConf),
    {ok, MessagesRate} = emqx_limiter_schema:to_rate("1/s"),
    ok = emqx_limiter:create_listener_limiters('tcp:low_message_rate', #{
        messages_rate => MessagesRate
    }),

    %% Set up limiters for a listener with tight byte rate limit
    emqx_config:put_listener_conf(tcp, low_byte_rate, [], DefaultConf),
    {ok, BytesRate} = emqx_limiter_schema:to_rate("7/s"),
    ok = emqx_limiter:create_listener_limiters('tcp:low_byte_rate', #{
        bytes_rate => BytesRate
    }),
    [{suite_apps, Apps} | Config].

end_per_suite(Config) ->
    ok = emqx_cth_suite:stop(?config(suite_apps, Config)).

init_per_testcase(TestCase, TCConfig) ->
    case internal_subscribe_test_profile(TestCase) of
        undefined -> ok;
        Profile -> emqx_common_test_helpers:set_security_profile(Profile)
    end,
    %% Authz Meck
    ok = meck:new(emqx_access_control, [passthrough, no_history, no_link]),
    ok = meck:expect(emqx_access_control, authorize, fun(_, _, _) -> allow end),
    %% CM Meck
    ok = meck:new(emqx_cm, [passthrough, no_history, no_link]),
    ok = meck:expect(emqx_cm, mark_channel_connected, fun(_) -> ok end),
    ok = meck:expect(emqx_cm, mark_channel_disconnected, fun(_) -> ok end),
    %% Broker Meck
    ok = meck:new(emqx_broker, [passthrough, no_history, no_link]),
    %% Session Meck
    ok = meck:new(emqx_session, [passthrough, no_history, no_link]),
    %% Ban
    ok = meck:new(emqx_banned, [passthrough, no_history, no_link]),
    ok = meck:expect(emqx_banned, check, fun(_ConnInfo) -> false end),
    TCConfig.

end_per_testcase(_TestCase, _TCConfig) ->
    emqx_hooks:del('message.ingress', {?MODULE, message_ingress}),
    meck:unload([
        emqx_access_control,
        emqx_session,
        emqx_broker,
        emqx_cm,
        emqx_banned
    ]),
    emqx_common_test_helpers:clear_security_profile(),
    emqx_common_test_helpers:call_janitor(),
    ok.

internal_subscribe_test_profile(t_internal_subscribe_bypasses_checks_in_legacy) ->
    "legacy";
internal_subscribe_test_profile(t_internal_subscribe_checks_authz_and_runs_hook) ->
    "hardened";
internal_subscribe_test_profile(t_internal_subscribe_checks_caps) ->
    "hardened";
internal_subscribe_test_profile(t_handle_info_subscribe_honors_disconnect_deny_action) ->
    "hardened";
internal_subscribe_test_profile(_) ->
    undefined.

%%--------------------------------------------------------------------
%% Test cases for channel info/stats/caps
%%--------------------------------------------------------------------

-doc """
The stored channel info carries a `clientinfo` without the fields derivable from
`conninfo`, while the channel's own `clientinfo` keeps them all.
""".
t_chan_info(_) ->
    WillMsg = emqx_message:make(<<"clientid">>, <<"will">>, <<"payload">>),
    Channel = channel(#{
        will_msg => WillMsg,
        session => session(#{subscriptions => #{<<"t">> => ?DEFAULT_SUBOPTS}})
    }),
    #{
        conn_state := connected,
        clientinfo := Stored,
        conninfo := ConnInfo,
        session := SessionInfo
    } = Info = emqx_channel:info(Channel),
    %% `info/1` omits the attributes that grow with client input.
    ?assertNot(maps:is_key(will_msg, Info)),
    ?assertNot(maps:is_key(conn_props, ConnInfo)),
    ?assertNot(maps:is_key(subscriptions, SessionInfo)),
    %% The session attributes are the ones the channel info table's readers use; the
    %% counters come from the stats element of the same table row.
    ?assertMatch(
        #{created_at := _, is_persistent := _, impl := emqx_session_mem}, SessionInfo
    ),
    ?assertEqual([created_at, impl, is_persistent], lists:sort(maps:keys(SessionInfo))),
    %% `info/2` still reads them from the channel.
    ?assertEqual(emqx_message:to_map(WillMsg), emqx_channel:info(will_msg, Channel)),
    ?assertMatch(#{conn_props := #{}}, emqx_channel:info(conninfo, Channel)),
    ?assertMatch(
        #{<<"t">> := _}, emqx_channel:info({session, subscriptions}, Channel)
    ),
    ?assertMatch(
        #{
            zone := default,
            listener := 'tcp:default',
            protocol := mqtt,
            clientid := <<"clientid">>,
            username := <<"username">>,
            is_superuser := false,
            is_bridge := false,
            mountpoint := undefined
        },
        Stored
    ),
    ?assertEqual(
        maps:without([peerhost, peerport, peername, sockport], clientinfo()),
        Stored
    ),
    %% Hooks, authn and authz receive the channel's own clientinfo.
    ?assertEqual(clientinfo(), emqx_channel:info(clientinfo, Channel)).

-doc """
`info/1` drops the `clientinfo` fields derivable from `conninfo`, and
`restore_derivable_peer_fields/2` puts back exactly those, so that a channel rebuilt
from a stored info map carries the `clientinfo` the connection had.
""".
t_restore_derivable_peer_fields(_) ->
    #{conninfo := ConnInfo, clientinfo := Stored} = emqx_channel:info(channel()),
    ?assertEqual(
        clientinfo(),
        emqx_channel:restore_derivable_peer_fields(Stored, ConnInfo)
    ),
    %% With nothing to derive from, the clientinfo is returned as is.
    ?assertEqual(Stored, emqx_channel:restore_derivable_peer_fields(Stored, #{})).

t_chan_caps(_) ->
    ?assertMatch(
        #{
            exclusive_subscription := false,
            max_packet_size := 1048576,
            max_clientid_len := 65535,
            max_qos_allowed := 2,
            max_topic_alias := 65535,
            max_topic_levels := Level,
            retain_available := true,
            shared_subscription := true,
            wildcard_subscription := true
        } when is_integer(Level),
        emqx_channel:caps(channel())
    ).

%%--------------------------------------------------------------------
%% Test cases for channel handle_in
%%--------------------------------------------------------------------

t_handle_in_connect_packet_success(_) ->
    IdleChannel = channel(#{conn_state => idle}),
    {continue,
        [
            {event, {set_namespace, _}},
            {event, connected},
            {connack, ?CONNACK_PACKET(?RC_SUCCESS, 0, _)}
        ],
        Channel} =
        emqx_channel:handle_in(?CONNECT_PACKET(connpkt()), IdleChannel),
    ClientInfo = emqx_channel:info(clientinfo, Channel),
    ?assertMatch(
        #{
            clientid := <<"clientid">>,
            username := <<"username">>
        },
        ClientInfo
    ),
    ?assertEqual(connected, emqx_channel:info(conn_state, Channel)).

t_handle_in_connect_reject_will_retain_when_retain_unavailable(_) ->
    OldRetainAvailable = emqx_config:get_zone_conf(default, [mqtt, retain_available]),
    emqx_config:put_zone_conf(default, [mqtt, retain_available], false),
    try
        ConnPkt = (connpkt())#mqtt_packet_connect{
            proto_ver = ?MQTT_PROTO_V5,
            will_flag = true,
            will_retain = true
        },
        {shutdown, retain_not_supported, ?CONNACK_PACKET(?RC_RETAIN_NOT_SUPPORTED, 0, _), _} =
            emqx_channel:handle_in(?CONNECT_PACKET(ConnPkt), channel(#{conn_state => idle}))
    after
        emqx_config:put_zone_conf(default, [mqtt, retain_available], OldRetainAvailable)
    end.

t_handle_in_unexpected_connect_packet(_) ->
    Channel = emqx_channel:set_field(conn_state, connected, channel()),
    Packet = ?DISCONNECT_PACKET(?RC_PROTOCOL_ERROR),
    {ok, [{outgoing, Packet}, {close, protocol_error}], Channel} =
        emqx_channel:handle_in(?CONNECT_PACKET(connpkt()), Channel).

t_handle_in_extended_reauthentication(_) ->
    try
        {ok, Agent} = emqx_utils_agent:start_link({stop, ok}),
        emqx_hooks:add(
            'client.authenticate',
            {?MODULE, authenticate_continue, [self(), Agent]},
            ?HP_HIGHEST
        ),
        %% First, the client is connected with a session.  Channel state is connected.
        Properties = #{
            'Authentication-Method' => <<"auth_method">>,
            'Authentication-Data' => <<"auth_data">>
        },
        Channel0 = channel(#{conn_state => idle}),
        ConnPkt0 = connpkt(),
        ConnPkt1 = ConnPkt0#mqtt_packet_connect{
            proto_ver = ?MQTT_PROTO_V5,
            clean_start = false,
            properties = Properties
        },
        PacketIn0 = ?CONNECT_PACKET(ConnPkt1),
        {continue,
            [
                {event, {set_namespace, _}},
                {event, connected},
                {connack, ?CONNACK_PACKET(?RC_SUCCESS, 0, _)}
            ],
            Channel1} =
            emqx_channel:handle_in(PacketIn0, Channel0),
        %% Then, client triggers reauthentication.  Channel state becomes
        %% reauthenticating.  The authentication backend returns `{continue, _}`.
        ok = emqx_utils_agent:set(Agent, {stop, {continue, #{}}}),
        PacketIn1 = ?AUTH_PACKET(?RC_RE_AUTHENTICATE, Properties),
        {ok,
            [
                {event, {set_namespace, _}},
                {outgoing, ?AUTH_PACKET(?RC_CONTINUE_AUTHENTICATION)}
            ],
            Channel2} =
            emqx_channel:handle_in(PacketIn1, Channel1),
        ?assertEqual(reauthenticating, emqx_channel:info(conn_state, Channel2)),
        %% Now, the client continues the auth process.  It should not takeover the session
        %% from itself.
        ok = emqx_utils_agent:set(Agent, {stop, ok}),
        PacketIn2 = ?AUTH_PACKET(?RC_CONTINUE_AUTHENTICATION, Properties),
        {ok,
            [
                {event, {set_namespace, _}},
                {outgoing, ?AUTH_PACKET(?RC_SUCCESS)}
            ],
            _Channel3} =
            emqx_channel:handle_in(PacketIn2, Channel2),
        ok
    after
        ok = emqx_hooks:del('client.authenticate', {?MODULE, authenticate_continue})
    end.

-doc """
A client that connects with enhanced authentication and does not advertise a
`Topic Alias Maximum` must not be sent any topic alias [MQTT-3.1.2-27].
""".
t_handle_in_extended_auth_no_topic_alias(_) ->
    try
        {ok, Agent} = emqx_utils_agent:start_link({stop, {continue, #{}}}),
        emqx_hooks:add(
            'client.authenticate',
            {?MODULE, authenticate_continue, [self(), Agent]},
            ?HP_HIGHEST
        ),
        %% CONNECT starts the enhanced authentication exchange.  It carries no
        %% `Topic-Alias-Maximum`, so the default of 0 applies.
        Properties = #{
            'Authentication-Method' => <<"auth_method">>,
            'Authentication-Data' => <<"auth_data">>
        },
        ConnPkt = (connpkt())#mqtt_packet_connect{
            proto_ver = ?MQTT_PROTO_V5,
            properties = Properties
        },
        {ok, [_, {outgoing, ?AUTH_PACKET(?RC_CONTINUE_AUTHENTICATION)}], Channel1} =
            emqx_channel:handle_in(?CONNECT_PACKET(ConnPkt), channel(#{conn_state => idle})),
        %% The client completes the exchange with an AUTH packet.
        ok = emqx_utils_agent:set(Agent, {stop, ok}),
        {continue, [_, _, {connack, ?CONNACK_PACKET(?RC_SUCCESS, 0, _)}], Channel} =
            emqx_channel:handle_in(
                ?AUTH_PACKET(?RC_CONTINUE_AUTHENTICATION, Properties), Channel1
            ),
        ?assertMatch(#{outbound := 0}, emqx_channel:info(alias_maximum, Channel)),
        Packet = #mqtt_packet{variable = #mqtt_packet_publish{topic_name = <<"t">>}},
        {PackedPacket, _} = emqx_channel:packing_alias(Packet, Channel),
        ?assertEqual(Packet, PackedPacket)
    after
        ok = emqx_hooks:del('client.authenticate', {?MODULE, authenticate_continue})
    end.

t_handle_in_unexpected_packet(_) ->
    Channel = emqx_channel:set_field(conn_state, idle, channel()),
    Packet = ?DISCONNECT_PACKET(?RC_PROTOCOL_ERROR),
    {ok, [{outgoing, Packet}, {close, protocol_error}], Channel} =
        emqx_channel:handle_in(?PUBLISH_PACKET(?QOS_0), Channel).

t_handle_in_publish_with_subscription_identifier(_) ->
    Channel = channel(#{conn_state => connected}),
    Publish = ?PUBLISH_PACKET(
        ?QOS_1, <<"topic">>, 1, #{'Subscription-Identifier' => 1}, <<"payload">>
    ),
    Packet = ?DISCONNECT_PACKET(?RC_PROTOCOL_ERROR),
    {ok, [{outgoing, Packet}, {close, protocol_error}], Channel} =
        emqx_channel:handle_in(Publish, Channel).

% t_handle_in_connect_auth_failed(_) ->
%     ConnPkt = #mqtt_packet_connect{
%                                 proto_name  = <<"MQTT">>,
%                                 proto_ver   = ?MQTT_PROTO_V5,
%                                 is_bridge   = false,
%                                 clean_start = true,
%                                 keepalive   = 30,
%                                 properties  = #{
%                                             'Authentication-Method' => <<"failed_auth_method">>,
%                                             'Authentication-Data' => <<"failed_auth_data">>
%                                             },
%                                 clientid    = <<"clientid">>,
%                                 username    = <<"username">>
%                                 },
%     {shutdown, not_authorized, ?CONNACK_PACKET(?RC_NOT_AUTHORIZED), _} =
%         emqx_channel:handle_in(?CONNECT_PACKET(ConnPkt), channel(#{conn_state => idle})).

t_handle_in_continue_auth(_) ->
    Properties = #{
        'Authentication-Method' => <<"failed_auth_method">>,
        'Authentication-Data' => <<"failed_auth_data">>
    },

    Channel1 = channel(#{conn_state => connected}),
    {ok, [{outgoing, ?DISCONNECT_PACKET(?RC_PROTOCOL_ERROR)}, {close, protocol_error}], Channel1} =
        emqx_channel:handle_in(?AUTH_PACKET(?RC_CONTINUE_AUTHENTICATION, Properties), Channel1),

    Channel2 = channel(#{conn_state => connecting}),
    ConnInfo = emqx_channel:info(conninfo, Channel2),
    Channel3 = emqx_channel:set_field(conninfo, ConnInfo#{conn_props => Properties}, Channel2),

    {continue,
        [
            {event, {set_namespace, _}},
            {event, connected},
            {connack, ?CONNACK_PACKET(?RC_SUCCESS)}
        ],
        _} =
        emqx_channel:handle_in(
            ?AUTH_PACKET(?RC_CONTINUE_AUTHENTICATION, Properties), Channel3
        ).

t_handle_in_re_auth(_) ->
    Properties = #{
        'Authentication-Method' => <<"failed_auth_method">>,
        'Authentication-Data' => <<"failed_auth_data">>
    },
    {ok,
        [
            {outgoing, ?DISCONNECT_PACKET(?RC_BAD_AUTHENTICATION_METHOD)},
            {close, bad_authentication_method}
        ],
        _} =
        emqx_channel:handle_in(
            ?AUTH_PACKET(?RC_RE_AUTHENTICATE, Properties),
            channel()
        ),
    {ok,
        [
            {outgoing, ?DISCONNECT_PACKET(?RC_BAD_AUTHENTICATION_METHOD)},
            {close, bad_authentication_method}
        ],
        _} =
        emqx_channel:handle_in(
            ?AUTH_PACKET(?RC_RE_AUTHENTICATE, Properties),
            channel(#{conninfo => #{proto_ver => ?MQTT_PROTO_V5, conn_props => undefined}})
        ),

    Channel1 = channel(),
    ConnInfo = emqx_channel:info(conninfo, Channel1),
    Channel2 = emqx_channel:set_field(conninfo, ConnInfo#{conn_props => Properties}, Channel1),

    {ok,
        [
            {event, {set_namespace, _}},
            {outgoing, ?AUTH_PACKET(?RC_SUCCESS)}
        ],
        _} =
        emqx_channel:handle_in(
            ?AUTH_PACKET(?RC_RE_AUTHENTICATE, Properties), Channel2
        ).

t_handle_in_qos0_publish(_) ->
    ok = meck:expect(emqx_broker, publish, fun(_) -> [] end),
    Channel = channel(#{conn_state => connected}),
    Publish = ?PUBLISH_PACKET(?QOS_0, <<"topic">>, undefined, <<"payload">>),
    {ok, _NChannel} = emqx_channel:handle_in(Publish, Channel).

t_handle_in_qos1_publish(_) ->
    ok = meck:expect(emqx_broker, publish, fun(_) -> [] end),
    Publish = ?PUBLISH_PACKET(?QOS_1, <<"topic">>, 1, <<"payload">>),
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_NO_MATCHING_SUBSCRIBERS)}, _Channel} =
        emqx_channel:handle_in(Publish, channel(#{conn_state => connected})).

t_handle_in_qos2_publish(_) ->
    ok = meck:expect(emqx_broker, publish, fun(_) -> [{node(), <<"topic">>, {ok, 1}}] end),
    Channel = channel(#{conn_state => connected, session => session()}),
    %% waiting limiter server
    timer:sleep(200),
    Publish1 = ?PUBLISH_PACKET(?QOS_2, <<"topic">>, 1, <<"payload">>),
    {ok, {outgoing, ?PUBREC_PACKET(1, ?RC_SUCCESS)}, Channel1} =
        emqx_channel:handle_in(Publish1, Channel),
    ok = meck:expect(emqx_broker, publish, fun(_) -> [] end),
    Publish2 = ?PUBLISH_PACKET(?QOS_2, <<"topic">>, 2, <<"payload">>),
    {ok, {outgoing, ?PUBREC_PACKET(2, ?RC_NO_MATCHING_SUBSCRIBERS)}, Channel2} =
        emqx_channel:handle_in(Publish2, Channel1),
    ?assertEqual(2, proplists:get_value(awaiting_rel_cnt, emqx_channel:stats(Channel2))).

t_handle_in_qos2_publish_with_error_return(_) ->
    ok = meck:expect(emqx_broker, publish, fun(_) -> [] end),
    Session = session(#{max_awaiting_rel => 2, awaiting_rel => #{1 => 1}}),
    Channel = channel(#{conn_state => connected, session => Session}),
    %% waiting limiter server
    timer:sleep(200),
    M1 = emqx_metrics:val_global('messages.dropped.receive_maximum'),
    Publish1 = ?PUBLISH_PACKET(?QOS_2, <<"topic">>, 1, <<"payload">>),
    {ok, {outgoing, ?PUBREC_PACKET(1, ?RC_PACKET_IDENTIFIER_IN_USE)}, Channel} =
        emqx_channel:handle_in(Publish1, Channel),
    Publish2 = ?PUBLISH_PACKET(?QOS_2, <<"topic">>, 2, <<"payload">>),
    {ok, {outgoing, ?PUBREC_PACKET(2, ?RC_NO_MATCHING_SUBSCRIBERS)}, Channel1} =
        emqx_channel:handle_in(Publish2, Channel),
    Publish3 = ?PUBLISH_PACKET(?QOS_2, <<"topic">>, 3, <<"payload">>),
    {ok,
        [
            {outgoing, ?DISCONNECT_PACKET(?RC_RECEIVE_MAXIMUM_EXCEEDED)},
            {close, receive_maximum_exceeded}
        ],
        Channel1} =
        emqx_channel:handle_in(Publish3, Channel1),
    ?assertEqual(M1 + 1, emqx_metrics:val_global('messages.dropped.receive_maximum')).

t_handle_in_puback_ok(_) ->
    Msg = emqx_message:make(<<"t">>, <<"payload">>),
    ok = meck:expect(
        emqx_session,
        puback,
        fun(_, _PacketId, _ReasonCode, [congested], Session) -> {ok, Msg, [], Session} end
    ),
    Channel = channel(#{conn_state => connected, conn_flags => [congested]}),
    {ok, _NChannel} = emqx_channel:handle_in(?PUBACK_PACKET(1, ?RC_SUCCESS), Channel).

t_handle_in_puback_id_in_use(_) ->
    ok = meck:expect(
        emqx_session,
        puback,
        fun(_, _, _ReasonCode, _Flags, _Session) ->
            {error, ?RC_PACKET_IDENTIFIER_IN_USE}
        end
    ),
    {ok, _Channel} = emqx_channel:handle_in(?PUBACK_PACKET(1, ?RC_SUCCESS), channel()).
% ?assertEqual(#{puback_in => 1}, emqx_channel:info(pub_stats, Channel)).

t_handle_in_puback_id_not_found(_) ->
    ok = meck:expect(
        emqx_session,
        puback,
        fun(_, _, _ReasonCode, _Flags, _Session) ->
            {error, ?RC_PACKET_IDENTIFIER_NOT_FOUND}
        end
    ),
    {ok, _Channel} = emqx_channel:handle_in(?PUBACK_PACKET(1, ?RC_SUCCESS), channel()).

t_bad_receive_maximum(_) ->
    mock_cm_open_session(),
    emqx_config:put_zone_conf(default, [mqtt, response_information], test),
    C1 = channel(#{conn_state => idle}),
    {shutdown, protocol_error, _, _} =
        emqx_channel:handle_in(
            ?CONNECT_PACKET(connpkt(#{'Receive-Maximum' => 0})),
            C1
        ).

t_override_client_receive_maximum(_) ->
    mock_cm_open_session(),
    emqx_config:put_zone_conf(default, [mqtt, response_information], test),
    emqx_config:put_zone_conf(default, [mqtt, max_inflight], 0),
    C1 = channel(#{conn_state => idle}),
    ClientCapacity = 2,
    {_Continue, [{event, {set_namespace, _}}, {event, connected}, _ConnAck], C2} =
        emqx_channel:handle_in(
            ?CONNECT_PACKET(connpkt(#{'Receive-Maximum' => ClientCapacity})),
            C1
        ),
    ConnInfo = emqx_channel:info(conninfo, C2),
    ?assertEqual(ClientCapacity, maps:get(receive_maximum, ConnInfo)).

t_handle_in_pubrec_ok(_) ->
    Msg = emqx_message:make(test, ?QOS_2, <<"t">>, <<"payload">>),
    ok = meck:expect(emqx_session, pubrec, fun(_, _, Session) -> {ok, Msg, Session} end),
    Channel = channel(#{conn_state => connected}),
    {ok, {outgoing, ?PUBREL_PACKET(1, ?RC_SUCCESS)}, _Channel1} =
        emqx_channel:handle_in(?PUBREC_PACKET(1, ?RC_SUCCESS), Channel).

t_handle_in_pubrec_id_in_use(_) ->
    ok = meck:expect(
        emqx_session,
        pubrec,
        fun(_, _, _Session) ->
            {error, ?RC_PACKET_IDENTIFIER_IN_USE}
        end
    ),
    {ok, {outgoing, ?PUBREL_PACKET(1, ?RC_PACKET_IDENTIFIER_IN_USE)}, _Channel} =
        emqx_channel:handle_in(?PUBREC_PACKET(1, ?RC_SUCCESS), channel()).

t_handle_in_pubrec_id_not_found(_) ->
    ok = meck:expect(
        emqx_session,
        pubrec,
        fun(_, _, _Session) ->
            {error, ?RC_PACKET_IDENTIFIER_NOT_FOUND}
        end
    ),
    {ok, {outgoing, ?PUBREL_PACKET(1, ?RC_PACKET_IDENTIFIER_NOT_FOUND)}, _Channel} =
        emqx_channel:handle_in(?PUBREC_PACKET(1, ?RC_SUCCESS), channel()).

t_handle_in_pubrel_ok(_) ->
    ok = meck:expect(emqx_session, pubrel, fun(_, _, Session) -> {ok, Session} end),
    Channel = channel(#{conn_state => connected}),
    {ok, {outgoing, ?PUBCOMP_PACKET(1, ?RC_SUCCESS)}, _Channel1} =
        emqx_channel:handle_in(?PUBREL_PACKET(1, ?RC_SUCCESS), Channel).

t_handle_in_pubrel_not_found_error(_) ->
    ok = meck:expect(
        emqx_session,
        pubrel,
        fun(_, _PacketId, _Session) ->
            {error, ?RC_PACKET_IDENTIFIER_NOT_FOUND}
        end
    ),
    {ok, {outgoing, ?PUBCOMP_PACKET(1, ?RC_PACKET_IDENTIFIER_NOT_FOUND)}, _Channel} =
        emqx_channel:handle_in(?PUBREL_PACKET(1, ?RC_SUCCESS), channel()).

t_handle_in_pubrel_not_found_bounded_log(_) ->
    %% A flood of PUBREL packets with an unknown Packet Identifier must not
    %% produce warning-level log output: the event is recorded by the
    %% packets.pubrel.missed counter and logged at info instead. A fresh
    %% channel has an empty session, so every PUBREL is not_found.
    Send = fun() ->
        {ok, {outgoing, ?PUBCOMP_PACKET(1, ?RC_PACKET_IDENTIFIER_NOT_FOUND)}, _} =
            emqx_channel:handle_in(?PUBREL_PACKET(1, ?RC_SUCCESS), channel())
    end,
    assert_ack_flood_bounded_log(Send, "pubrel_packetId_not_found").

t_handle_in_puback_not_found_bounded_log(_) ->
    %% Same as the PUBREL case for PUBACK. A PUBACK with an unknown Packet
    %% Identifier is ignored (no reply), so the only per-packet output is the
    %% log, which must not be at warning level.
    Send = fun() ->
        {ok, _} = emqx_channel:handle_in(?PUBACK_PACKET(1, ?RC_SUCCESS), channel())
    end,
    assert_ack_flood_bounded_log(Send, "puback_packetId_not_found").

%% Send N acknowledgement packets with an unknown Packet Identifier and assert
%% that MsgStr is logged at debug only: zero reports at warning and info levels,
%% N reports at debug level.
assert_ack_flood_bounded_log(Send, MsgStr) ->
    N = 100,
    Flood = fun() -> lists:foreach(fun(_) -> Send() end, lists:seq(1, N)) end,
    IsMsg = fun(#{msg := Msg}) -> Msg =:= MsgStr end,
    Count = fun(Level) ->
        length(lists:filter(IsMsg, emqx_cth_log_capture:capture(Level, Flood)))
    end,
    ?assertEqual(0, Count(warning)),
    ?assertEqual(0, Count(info)),
    ?assertEqual(N, Count(debug)).

t_handle_in_pubcomp_ok(_) ->
    ok = meck:expect(
        emqx_session,
        pubcomp,
        fun(_, _, _ReasonCode, [congested], Session) ->
            {ok, [], Session}
        end
    ),
    Channel = channel(#{conn_state => connected, conn_flags => [congested]}),
    {ok, _Channel} = emqx_channel:handle_in(?PUBCOMP_PACKET(1, ?RC_SUCCESS), Channel).

t_handle_in_pubcomp_not_found_error(_) ->
    ok = meck:expect(
        emqx_session,
        pubcomp,
        fun(_, _PacketId, _ReasonCode, _Flags, _Session) ->
            {error, ?RC_PACKET_IDENTIFIER_NOT_FOUND}
        end
    ),
    Channel = channel(#{conn_state => connected}),
    {ok, _Channel1} = emqx_channel:handle_in(?PUBCOMP_PACKET(1, ?RC_SUCCESS), Channel).

t_handle_in_subscribe(_) ->
    ok = meck:expect(
        emqx_session,
        subscribe,
        fun(_, _, _, Session) -> {ok, Session} end
    ),
    Channel = channel(#{conn_state => connected}),
    TopicFilters = [{<<"+">>, ?DEFAULT_SUBOPTS}],
    Subscribe = ?SUBSCRIBE_PACKET(1, #{}, TopicFilters),
    Replies = [{outgoing, ?SUBACK_PACKET(1, [?QOS_0])}, {event, updated}],
    {ok, Replies, _Chan} = emqx_channel:handle_in(Subscribe, Channel).

t_handle_in_unsubscribe(_) ->
    ok = meck:expect(
        emqx_session,
        unsubscribe,
        fun(_, _, _, Session) ->
            {ok, Session}
        end
    ),
    Channel = channel(#{conn_state => connected}),
    {ok, [{outgoing, ?UNSUBACK_PACKET(1)}, {event, updated}], _Chan} =
        emqx_channel:handle_in(?UNSUBSCRIBE_PACKET(1, #{}, [<<"+">>]), Channel).

t_handle_in_pingreq(_) ->
    {ok, {outgoing, ?PACKET(?PINGRESP)}, _Channel} =
        emqx_channel:handle_in(?PACKET(?PINGREQ), channel()).

t_handle_in_disconnect(_) ->
    Packet = ?DISCONNECT_PACKET(?RC_SUCCESS),
    Channel = channel(#{conn_state => connected}),
    {ok, {close, normal}, Channel1} = emqx_channel:handle_in(Packet, Channel),
    ?assertEqual(undefined, emqx_channel:info(will_msg, Channel1)).

t_handle_in_auth(_) ->
    Channel = channel(#{conn_state => connected}),
    Packet = ?DISCONNECT_PACKET(?RC_PROTOCOL_ERROR),
    {ok, [{outgoing, Packet}, {close, protocol_error}], Channel} =
        emqx_channel:handle_in(?AUTH_PACKET(), Channel).

t_handle_in_frame_error(_) ->
    IdleChannelV5 = channel(#{conn_state => idle}),
    ?assertMatch(
        {shutdown, #{shutdown_count := bad_subqos, reason := bad_subqos}, _Chan},
        emqx_channel:handle_in({frame_error, bad_subqos}, IdleChannelV5)
    ),
    %% no CONNACK packet for v4
    ?assertMatch(
        {shutdown, #{shutdown_count := frame_too_large, cause := frame_too_large}, _Chan},
        emqx_channel:handle_in(
            {frame_error, #{cause => frame_too_large}}, v4(IdleChannelV5)
        )
    ),

    ConnectingChan = channel(#{conn_state => connecting}),
    ConnackPacket = ?CONNACK_PACKET(?RC_PACKET_TOO_LARGE),
    ?assertMatch(
        {shutdown,
            #{
                shutdown_count := frame_too_large,
                cause := frame_too_large,
                limit := 100,
                received := 101
            },
            ConnackPacket, _},
        emqx_channel:handle_in(
            {frame_error, #{cause => frame_too_large, received => 101, limit => 100}},
            ConnectingChan
        )
    ),

    DisconnectPacket = ?DISCONNECT_PACKET(?RC_PACKET_TOO_LARGE),
    ConnectedChan = channel(#{conn_state => connected}),
    ?assertMatch(
        {ok, [{outgoing, DisconnectPacket}, {close, frame_too_large}], _},
        emqx_channel:handle_in({frame_error, #{cause => frame_too_large}}, ConnectedChan)
    ),
    %% Any other frame error on an established connection closes under the
    %% single `frame_error' kind, never under a client-derived name.
    MalformedPacket = ?DISCONNECT_PACKET(?RC_MALFORMED_PACKET),
    ?assertMatch(
        {ok, [{outgoing, MalformedPacket}, {close, frame_error}], _},
        emqx_channel:handle_in(
            {frame_error, #{cause => invalid_property_code, property_code => 16#2B}},
            channel(#{conn_state => connected})
        )
    ),
    DisconnectedChan = channel(#{conn_state => disconnected}),
    {ok, DisconnectedChan} =
        emqx_channel:handle_in({frame_error, #{cause => frame_too_large}}, DisconnectedChan).

t_handle_in_expected_packet(_) ->
    Packet = ?DISCONNECT_PACKET(?RC_PROTOCOL_ERROR),
    {ok, [{outgoing, Packet}, {close, protocol_error}], _Chan} =
        emqx_channel:handle_in(packet, channel()).

t_process_connect(_) ->
    mock_cm_open_session(),
    {continue,
        [
            {event, {set_namespace, _}},
            {event, connected},
            {connack, ?CONNACK_PACKET(?RC_SUCCESS)}
        ],
        _Chan} =
        emqx_channel:post_process_connect(#{}, channel(#{conn_state => idle})).

t_process_publish_qos0(_) ->
    ok = meck:expect(emqx_broker, publish, fun(_) -> [] end),
    Publish = ?PUBLISH_PACKET(?QOS_0, <<"t">>, 1, <<"payload">>),
    {ok, _Channel} = emqx_channel:process_publish(Publish, channel()).

t_process_publish_qos1(_) ->
    ok = meck:expect(emqx_broker, publish, fun(_) -> [] end),
    Publish = ?PUBLISH_PACKET(?QOS_1, <<"t">>, 1, <<"payload">>),
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_NO_MATCHING_SUBSCRIBERS)}, _Channel} =
        emqx_channel:process_publish(Publish, channel()).

%% Verify that ingress hook can effectively change a message that
%% is passed to authorization and then published
t_process_publish_message_ingress(_) ->
    TestPid = self(),
    ok = emqx_hooks:put(
        'message.ingress', {?MODULE, message_ingress, []}, ?HP_HIGHEST
    ),
    ok = meck:expect(emqx_access_control, authorize, fun(AuthzContext, Action, Topic) ->
        TestPid ! {authorized, AuthzContext, Action, Topic},
        allow
    end),
    ok = meck:expect(emqx_broker, publish, fun(Msg) ->
        TestPid ! {published, Msg},
        []
    end),
    Publish = ?PUBLISH_PACKET(?QOS_1, <<"source">>, 1, <<"payload">>),
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_NO_MATCHING_SUBSCRIBERS)}, _Channel} =
        emqx_channel:process_publish(Publish, channel()),
    receive
        {authorized, AuthzContext, #{qos := ?QOS_1, retain := false}, <<"target">>} ->
            ?assertMatch(#{clientid := <<"clientid">>}, AuthzContext)
    after 1000 ->
        ct:fail(authorization_not_called_with_prepared_publish)
    end,
    receive
        {published, Msg} ->
            ?assertEqual(?QOS_1, emqx_message:qos(Msg)),
            ?assertEqual(<<"target">>, emqx_message:topic(Msg)),
            ?assertEqual(false, emqx_message:get_flag(retain, Msg)),
            ?assertEqual(value, emqx_message:get_header(ingress, Msg))
    after 1000 ->
        ct:fail(prepared_message_not_published)
    end.

t_process_publish_message_ingress_error(_) ->
    OldDenyAction = emqx:get_config([authorization, deny_action], ignore),
    {ok, _} = emqx:update_config([authorization, deny_action], ignore),
    on_exit(fun() ->
        {ok, _} = emqx:update_config([authorization, deny_action], OldDenyAction)
    end),
    ok = emqx_hooks:put(
        'message.ingress', {?MODULE, message_ingress_error, []}, ?HP_HIGHEST
    ),
    on_exit(fun() ->
        emqx_hooks:del('message.ingress', {?MODULE, message_ingress_error})
    end),
    ok = meck:expect(emqx_broker, publish, fun(_) -> ct:fail(message_was_published) end),
    Publish = ?PUBLISH_PACKET(?QOS_1, <<"source">>, 1, <<"payload">>),
    ?assertMatch(
        {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_NOT_AUTHORIZED)}, _},
        emqx_channel:process_publish(Publish, channel())
    ).

t_process_subscribe(_) ->
    ok = meck:expect(emqx_session, subscribe, fun(_, _, _, Session) -> {ok, Session} end),
    TopicFilters = [TopicFilter = {<<"+">>, ?DEFAULT_SUBOPTS}],
    {[{TopicFilter, ?RC_SUCCESS}], _Channel} =
        emqx_channel:post_process_subscribe(TopicFilters, channel()).

t_process_unsubscribe(_) ->
    ok = meck:expect(emqx_session, unsubscribe, fun(_, _, _, Session) -> {ok, Session} end),
    TopicFilters = [{<<"+">>, ?DEFAULT_SUBOPTS}],
    {[?RC_SUCCESS], _Channel} = emqx_channel:post_process_unsubscribe(TopicFilters, #{}, channel()).

t_quota_qos0(_) ->
    timer:sleep(1200),
    ok = meck:expect(emqx_broker, publish, fun(_) -> [{node(), <<"topic">>, {ok, 4}}] end),
    Chann = channel(
        clientinfo(#{listener => 'tcp:low_message_rate'}),
        #{conn_state => connected},
        #{listener => {tcp, low_message_rate}}
    ),
    Pub = ?PUBLISH_PACKET(?QOS_0, <<"topic">>, undefined, <<"payload">>),

    Metric = 'messages.dropped.quota_exceeded',
    M1 = emqx_metrics:val_global(Metric),
    ParentMetric = 'messages.dropped',
    M2 = emqx_metrics:val_global(ParentMetric),
    {ok, Chann1} = emqx_channel:handle_in(Pub, Chann),
    {ok, Chann2} = emqx_channel:handle_in(Pub, Chann1),
    ?assertEqual(M1 + 1, emqx_metrics:val_global(Metric)),
    ?assertEqual(M2 + 1, emqx_metrics:val_global(ParentMetric)),
    timer:sleep(1200),
    {ok, _} = emqx_channel:handle_in(Pub, Chann2),
    %% No longer exceeds quota
    ?assertEqual(M1 + 1, emqx_metrics:val_global(Metric)),
    ?assertEqual(M2 + 1, emqx_metrics:val_global(ParentMetric)),
    ok.

t_quota_qos1(_) ->
    timer:sleep(1200),
    ok = meck:expect(emqx_broker, publish, fun(_) -> [{node(), <<"topic">>, {ok, 4}}] end),
    Chann = channel(
        clientinfo(#{listener => 'tcp:low_message_rate'}),
        #{conn_state => connected},
        #{listener => {tcp, low_message_rate}}
    ),
    Pub = ?PUBLISH_PACKET(?QOS_1, <<"topic">>, 1, <<"payload">>),
    %% Quota per connections
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_SUCCESS)}, Chann1} =
        emqx_channel:handle_in(Pub, Chann),
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_QUOTA_EXCEEDED)}, Chann2} =
        emqx_channel:handle_in(Pub, Chann1),
    timer:sleep(1200),
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_SUCCESS)}, Chann3} =
        emqx_channel:handle_in(Pub, Chann2),
    %% Quota in overall
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_QUOTA_EXCEEDED)}, _} =
        emqx_channel:handle_in(Pub, Chann3),
    ok.

t_quota_qos2(_) ->
    timer:sleep(1200),
    ok = meck:expect(emqx_broker, publish, fun(_) -> [{node(), <<"topic">>, {ok, 4}}] end),
    Chann = channel(
        clientinfo(#{listener => 'tcp:low_message_rate'}),
        #{conn_state => connected},
        #{listener => {tcp, low_message_rate}}
    ),
    Pub1 = ?PUBLISH_PACKET(?QOS_2, <<"topic">>, 1, <<"payload">>),
    Pub2 = ?PUBLISH_PACKET(?QOS_2, <<"topic">>, 2, <<"payload">>),
    Pub3 = ?PUBLISH_PACKET(?QOS_2, <<"topic">>, 3, <<"payload">>),
    Pub4 = ?PUBLISH_PACKET(?QOS_2, <<"topic">>, 4, <<"payload">>),
    %% Quota per connections
    {ok, {outgoing, ?PUBREC_PACKET(1, ?RC_SUCCESS)}, Chann1} =
        emqx_channel:handle_in(Pub1, Chann),
    {ok, {outgoing, ?PUBREC_PACKET(2, ?RC_QUOTA_EXCEEDED)}, Chann2} =
        emqx_channel:handle_in(Pub2, Chann1),
    timer:sleep(1200),
    {ok, {outgoing, ?PUBREC_PACKET(3, ?RC_SUCCESS)}, Chann3} =
        emqx_channel:handle_in(Pub3, Chann2),
    %% Quota in overall
    {ok, {outgoing, ?PUBREC_PACKET(4, ?RC_QUOTA_EXCEEDED)}, _} =
        emqx_channel:handle_in(Pub4, Chann3),
    ok.

t_quota_bytes(_) ->
    timer:sleep(1200),
    ok = meck:expect(emqx_broker, publish, fun(_) -> [{node(), <<"topic">>, {ok, 4}}] end),
    Chann = channel(
        clientinfo(#{listener => 'tcp:low_byte_rate'}),
        #{conn_state => connected},
        #{listener => {tcp, low_byte_rate}}
    ),
    Pub = ?PUBLISH_PACKET(?QOS_1, <<"topic">>, 1, <<"payload">>),
    %% Quota per connections
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_SUCCESS)}, Chann1} =
        emqx_channel:handle_in(Pub, Chann),
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_QUOTA_EXCEEDED)}, Chann2} =
        emqx_channel:handle_in(Pub, Chann1),
    timer:sleep(1200),
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_SUCCESS)}, Chann3} =
        emqx_channel:handle_in(Pub, Chann2),
    %% Quota in overall
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_QUOTA_EXCEEDED)}, _} =
        emqx_channel:handle_in(Pub, Chann3),
    ok.

-doc "A channel without a limiter container keeps none while only non-consuming packets arrive.".
t_quota_lazy_stays_absent(_) ->
    Chann = channel(#{conn_state => connected, quota => undefined}),
    {ok, {outgoing, ?PACKET(?PINGRESP)}, Chann1} =
        emqx_channel:handle_in(?PACKET(?PINGREQ), Chann),
    ?assertEqual(undefined, emqx_channel:info(quota, Chann1)).

-doc "Publish builds the limiter container on first use and the limit applies.".
t_quota_lazy_build_on_publish(_) ->
    timer:sleep(1200),
    ok = meck:expect(emqx_broker, publish, fun(_) -> [{node(), <<"topic">>, {ok, 4}}] end),
    Chann = channel(
        clientinfo(#{listener => 'tcp:low_message_rate'}),
        #{conn_state => connected, quota => undefined},
        #{listener => {tcp, low_message_rate}}
    ),
    ?assertEqual(undefined, emqx_channel:info(quota, Chann)),
    Pub = ?PUBLISH_PACKET(?QOS_1, <<"topic">>, 1, <<"payload">>),
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_SUCCESS)}, Chann1} =
        emqx_channel:handle_in(Pub, Chann),
    ?assertNotEqual(undefined, emqx_channel:info(quota, Chann1)),
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_QUOTA_EXCEEDED)}, _} =
        emqx_channel:handle_in(Pub, Chann1),
    ok.

-doc "A rate limit configured after connect applies to a channel that built its container lazily.".
t_quota_lazy_hot_update(_) ->
    ListenerId = 'tcp:lazy_hot_update',
    DefaultConf = emqx_config:get_listener_conf(tcp, default, []),
    emqx_config:put_listener_conf(tcp, lazy_hot_update, [], DefaultConf),
    ok = emqx_limiter:create_listener_limiters(ListenerId, #{}),
    try
        ok = meck:expect(emqx_broker, publish, fun(_) -> [{node(), <<"topic">>, {ok, 4}}] end),
        Chann = channel(
            clientinfo(#{listener => ListenerId}),
            #{conn_state => connected, quota => undefined},
            #{listener => {tcp, lazy_hot_update}}
        ),
        Pub = ?PUBLISH_PACKET(?QOS_1, <<"topic">>, 1, <<"payload">>),
        %% No limit configured: both publishes pass and no container is built.
        {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_SUCCESS)}, Chann1} =
            emqx_channel:handle_in(Pub, Chann),
        ?assertEqual(undefined, emqx_channel:info(quota, Chann1)),
        {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_SUCCESS)}, Chann2} =
            emqx_channel:handle_in(Pub, Chann1),
        ?assertEqual(undefined, emqx_channel:info(quota, Chann2)),
        %% Configure a tight rate at runtime; the limit must apply without reconnect.
        {ok, MessagesRate} = emqx_limiter_schema:to_rate("1/s"),
        ok = emqx_limiter:update_listener_limiters(ListenerId, #{messages_rate => MessagesRate}),
        timer:sleep(1200),
        {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_SUCCESS)}, Chann3} =
            emqx_channel:handle_in(Pub, Chann2),
        ?assertNotEqual(undefined, emqx_channel:info(quota, Chann3)),
        {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_QUOTA_EXCEEDED)}, _} =
            emqx_channel:handle_in(Pub, Chann3),
        ok
    after
        emqx_limiter:delete_listener_limiters(ListenerId)
    end.

-doc "Subscribing without any finite channel limit builds no limiter container.".
t_quota_stays_absent_on_subscribe(_) ->
    ok = meck:expect(
        emqx_session,
        subscribe,
        fun(_, _, _, Session) -> {ok, Session} end
    ),
    Chann = channel(#{conn_state => connected, quota => undefined}),
    TopicFilters = [{<<"+">>, ?DEFAULT_SUBOPTS}],
    Subscribe = ?SUBSCRIBE_PACKET(1, #{}, TopicFilters),
    Replies = [{outgoing, ?SUBACK_PACKET(1, [?QOS_0])}, {event, updated}],
    {ok, Replies, Chann1} = emqx_channel:handle_in(Subscribe, Chann),
    ?assertEqual(undefined, emqx_channel:info(quota, Chann1)).

t_mount_will_msg(_) ->
    Self = self(),
    ClientInfo = clientinfo(#{mountpoint => <<"prefix/">>}),
    Msg = emqx_message:make(test, <<"will_topic">>, <<"will_payload">>),
    Channel = channel(#{clientinfo => ClientInfo, will_msg => Msg}),

    ok = meck:expect(emqx_broker, publish, fun(M) -> Self ! {pub, M} end),

    {shutdown, kicked, ok, ?DISCONNECT_PACKET(?RC_ADMINISTRATIVE_ACTION), _} = emqx_channel:handle_call(
        kick, Channel
    ),
    receive
        {pub, #message{topic = <<"prefix/will_topic">>}} -> ok
    after 200 -> exit(will_message_not_published_or_not_correct)
    end.

%%--------------------------------------------------------------------
%% Test cases for handle_deliver
%%--------------------------------------------------------------------

t_handle_deliver(_) ->
    Msg0 = emqx_message:make(test, ?QOS_1, <<"t1">>, <<"qos1">>),
    Msg1 = emqx_message:make(test, ?QOS_2, <<"t2">>, <<"qos2">>),
    Delivers = [{deliver, <<"+">>, Msg0}, {deliver, <<"+">>, Msg1}],
    {ok, {outgoing, Packets}, _Ch} = emqx_channel:handle_deliver(Delivers, channel()),
    ?assertEqual([?QOS_1, ?QOS_2], [emqx_packet:qos(Pkt) || Pkt <- Packets]).

t_handle_deliver_nl(_) ->
    ClientInfo = clientinfo(#{clientid => <<"clientid">>}),
    Session = session(ClientInfo, #{subscriptions => #{<<"t1">> => #{nl => 1}}}),
    Channel = channel(#{clientinfo => ClientInfo, session => Session}),
    Msg = emqx_message:make(<<"clientid">>, ?QOS_1, <<"t1">>, <<"qos1">>),
    NMsg = emqx_message:set_flag(nl, Msg),
    {ok, _} = emqx_channel:handle_deliver([{deliver, <<"t1">>, NMsg}], Channel).

%%--------------------------------------------------------------------
%% Test cases for handle_out
%%--------------------------------------------------------------------

t_handle_out_publish(_) ->
    Channel = channel(#{conn_state => connected}),
    Pub0 = {undefined, emqx_message:make(<<"t">>, <<"qos0">>)},
    Pub1 = {1, emqx_message:make(<<"c">>, ?QOS_1, <<"t">>, <<"qos1">>)},
    {ok, {outgoing, Packets}, _NChannel} =
        emqx_channel:handle_out(publish, [Pub0, Pub1], Channel),
    ?assertEqual(2, length(Packets)).

t_handle_out_publish_1(_) ->
    Msg = emqx_message:make(<<"clientid">>, ?QOS_1, <<"t">>, <<"payload">>),
    {ok, {outgoing, ?PUBLISH_PACKET(?QOS_1, <<"t">>, 1, <<"payload">>)}, _Chan} =
        emqx_channel:handle_out(publish, [{1, Msg}], channel()).

t_handle_out_connack_success(_) ->
    {continue,
        [
            {event, {set_namespace, _}},
            {event, connected},
            {connack, ?CONNACK_PACKET(?RC_SUCCESS, 0, _)}
        ],
        Channel} =
        emqx_channel:handle_out(connack, {?RC_SUCCESS, 0, #{}}, channel()),
    ?assertEqual(connected, emqx_channel:info(conn_state, Channel)).

t_handle_out_connack_response_information(_) ->
    mock_cm_open_session(),
    emqx_config:put_zone_conf(default, [mqtt, response_information], <<"test">>),
    IdleChannel = channel(#{conn_state => idle}),
    {continue,
        [
            {event, {set_namespace, _}},
            {event, connected},
            {connack, ?CONNACK_PACKET(?RC_SUCCESS, 0, #{'Response-Information' := <<"test">>})}
        ],
        _} = emqx_channel:handle_in(
        ?CONNECT_PACKET(connpkt(#{'Request-Response-Information' => 1})),
        IdleChannel
    ).

t_handle_out_connack_not_response_information(_) ->
    mock_cm_open_session(),
    emqx_config:put_zone_conf(default, [mqtt, response_information], test),
    IdleChannel = channel(#{conn_state => idle}),
    {continue,
        [
            {event, {set_namespace, _}},
            {event, connected},
            {connack, ?CONNACK_PACKET(?RC_SUCCESS, 0, AckProps)}
        ],
        _} =
        emqx_channel:handle_in(
            ?CONNECT_PACKET(connpkt(#{'Request-Response-Information' => 0})),
            IdleChannel
        ),
    ?assertEqual(false, maps:is_key('Response-Information', AckProps)).

t_handle_out_connack_failure(_) ->
    {shutdown, not_authorized, ?CONNACK_PACKET(?RC_NOT_AUTHORIZED), _Chan} =
        emqx_channel:handle_out(connack, ?RC_NOT_AUTHORIZED, channel()).

t_handle_out_puback(_) ->
    Channel = channel(#{conn_state => connected}),
    {ok, {outgoing, ?PUBACK_PACKET(1, ?RC_SUCCESS)}, _NChannel} =
        emqx_channel:handle_out(puback, {1, ?RC_SUCCESS}, Channel).

t_handle_out_pubrec(_) ->
    Channel = channel(#{conn_state => connected}),
    {ok, {outgoing, ?PUBREC_PACKET(1, ?RC_SUCCESS)}, _NChannel} =
        emqx_channel:handle_out(pubrec, {1, ?RC_SUCCESS}, Channel).

t_handle_out_pubrel(_) ->
    Channel = channel(#{conn_state => connected}),
    {ok, {outgoing, ?PUBREL_PACKET(1)}, Channel1} =
        emqx_channel:handle_out(pubrel, {1, ?RC_SUCCESS}, Channel),
    {ok, {outgoing, ?PUBREL_PACKET(2, ?RC_SUCCESS)}, _Channel2} =
        emqx_channel:handle_out(pubrel, {2, ?RC_SUCCESS}, Channel1).

t_handle_out_pubcomp(_) ->
    {ok, {outgoing, ?PUBCOMP_PACKET(1, ?RC_SUCCESS)}, _Channel} =
        emqx_channel:handle_out(pubcomp, {1, ?RC_SUCCESS}, channel()).

t_handle_out_suback(_) ->
    Replies = [{outgoing, ?SUBACK_PACKET(1, [?QOS_2])}, {event, updated}],
    {ok, Replies, _Chan} = emqx_channel:handle_out(suback, {1, [?QOS_2]}, channel()).

t_handle_out_unsuback(_) ->
    Replies = [{outgoing, ?UNSUBACK_PACKET(1, [?RC_SUCCESS])}, {event, updated}],
    {ok, Replies, _Chan} = emqx_channel:handle_out(unsuback, {1, [?RC_SUCCESS]}, channel()).

t_handle_out_disconnect(_) ->
    Packet = ?DISCONNECT_PACKET(?RC_SUCCESS),
    {ok, [{outgoing, Packet}, {close, normal}], _Chan} =
        emqx_channel:handle_out(disconnect, ?RC_SUCCESS, channel()).

t_handle_out_unexpected(_) ->
    {ok, _Channel} = emqx_channel:handle_out(unexpected, <<"data">>, channel()).

%%--------------------------------------------------------------------
%% Test cases for handle_call
%%--------------------------------------------------------------------

t_handle_call_kick(_) ->
    Channelv5 = channel(),
    Channelv4 = v4(Channelv5),
    {shutdown, kicked, ok, _} = emqx_channel:handle_call(kick, Channelv4),
    {shutdown, kicked, ok, ?DISCONNECT_PACKET(?RC_ADMINISTRATIVE_ACTION), _} = emqx_channel:handle_call(
        kick, Channelv5
    ),

    DisconnectedChannelv5 = channel(#{conn_state => disconnected}),
    DisconnectedChannelv4 = v4(DisconnectedChannelv5),

    {shutdown, kicked, ok, _} = emqx_channel:handle_call(kick, DisconnectedChannelv5),
    {shutdown, kicked, ok, _} = emqx_channel:handle_call(kick, DisconnectedChannelv4).

t_handle_kicked_publish_will_msg(_) ->
    Self = self(),
    ok = meck:expect(emqx_broker, publish, fun(M) -> Self ! {pub, M} end),

    ClientId = test,
    WillTopic = <<"will_topic">>,
    WillPayload = <<"will_payload">>,
    Msg = emqx_message:make(ClientId, WillTopic, WillPayload),

    {shutdown, kicked, ok, ?DISCONNECT_PACKET(?RC_ADMINISTRATIVE_ACTION), _} = emqx_channel:handle_call(
        kick, channel(#{will_msg => Msg})
    ),
    receive
        {pub, RecMsg} ->
            ?assertEqual(ClientId, RecMsg#message.from, #{msg => Msg}),
            ?assertEqual(WillTopic, RecMsg#message.topic, #{msg => Msg}),
            ?assertEqual(WillPayload, RecMsg#message.payload, #{msg => Msg}),
            ok
    after 5_000 ->
        ct:pal("expected message: ~p", [Msg]),
        ct:pal("~p mailbox: ~p", [?LINE, process_info(self(), messages)]),
        exit(will_message_not_published)
    end.

t_handle_call_discard(_) ->
    Packet = ?DISCONNECT_PACKET(?RC_SESSION_TAKEN_OVER),
    {shutdown, discarded, ok, Packet, _Channel} =
        emqx_channel:handle_call(discard, channel()).

t_handle_call_takeover_begin(_) ->
    %% The default test channel has session expiry interval 0: its session
    %% ends at the takeover, so the channel shuts down without replying.
    Packet = ?DISCONNECT_PACKET(?RC_SESSION_TAKEN_OVER),
    {shutdown, takenover, noreply, Packet, _Chan0} =
        emqx_channel:handle_call({takeover, 'begin'}, channel()),
    %% With a nonzero expiry interval the session is handed over.
    Channel = channel(),
    ConnInfo = emqx_channel:info(conninfo, Channel),
    NChannel = emqx_channel:set_field(
        conninfo, ConnInfo#{expiry_interval => 60000}, Channel
    ),
    {reply, _Session, _Chan} = emqx_channel:handle_call({takeover, 'begin'}, NChannel).

t_handle_call_takeover_end(_) ->
    ok = meck:expect(emqx_broker, unsubscribe, fun(_) -> ok end),
    %% The session must outlive the takeover for there to be anything to hand
    %% over: with the default expiry interval 0 the channel shuts down at
    %% `begin' instead of replying.
    Chan00 = channel(),
    ConnInfo = emqx_channel:info(conninfo, Chan00),
    Chan0 = emqx_channel:set_field(conninfo, ConnInfo#{expiry_interval => 60000}, Chan00),
    {reply, _, Chan1} =
        emqx_channel:handle_call({takeover, 'begin'}, Chan0),
    {shutdown, takenover, [], _, _Chan} =
        emqx_channel:handle_call({takeover, 'end'}, Chan1).

t_handle_call_takeover_kick(_) ->
    Packet = ?DISCONNECT_PACKET(?RC_SESSION_TAKEN_OVER),
    {shutdown, takenover, ok, Packet, _Chan} =
        emqx_channel:handle_call(takeover_kick, channel()).

t_handle_call_unexpected(_) ->
    {reply, ignored, _Chan} = emqx_channel:handle_call(unexpected_req, channel()).

%%--------------------------------------------------------------------
%% Test cases for handle_info
%%--------------------------------------------------------------------

t_handle_info_subscribe(_) ->
    ok = meck:expect(emqx_session, subscribe, fun(_, _, _, Session) -> {ok, Session} end),
    {ok, _Chan} = emqx_channel:handle_info({subscribe, topic_filters()}, channel()).

t_internal_subscribe_bypasses_checks_in_legacy(_) ->
    TestPid = self(),
    ok = meck:expect(emqx_access_control, authorize, fun(_, _, _) ->
        TestPid ! authorization_checked,
        deny
    end),
    ok = meck:expect(emqx_session, subscribe, fun(_, Topic, _, Session) ->
        TestPid ! {subscribed, Topic},
        {ok, Session}
    end),
    ok = emqx_hooks:add(
        'client.subscribe', {?MODULE, on_client_subscribe, [TestPid]}, ?HP_HIGHEST
    ),
    on_exit(fun() ->
        emqx_hooks:del('client.subscribe', {?MODULE, on_client_subscribe})
    end),
    {ok, _Channel} = emqx_channel:handle_info(
        {subscribe, [{<<"legacy">>, ?DEFAULT_SUBOPTS}]}, channel()
    ),
    ?assertReceive({subscribed, <<"legacy">>}),
    ?assertNotReceive(authorization_checked),
    ?assertNotReceive({client_subscribe, _, _}).

t_internal_subscribe_checks_authz_and_runs_hook(_) ->
    TestPid = self(),
    ClientId = atom_to_binary(?FUNCTION_NAME),
    AllowedTopic = <<"regular/allowed">>,
    DeniedTopic = <<"regular/denied">>,
    AllowedSharedTopic = <<"shared/allowed">>,
    DeniedSharedTopic = <<"shared/denied">>,
    AllowedShare = #share{group = <<"group">>, topic = AllowedSharedTopic},
    AllowedTopics = [AllowedTopic, AllowedShare],
    on_exit(fun() ->
        emqx_hooks:del('client.subscribe', {?MODULE, on_client_subscribe})
    end),
    ok = meck:expect(emqx_access_control, authorize, fun
        (_, _, Denied) when Denied =:= DeniedTopic; Denied =:= DeniedSharedTopic -> deny;
        (_, _, _) -> allow
    end),
    ok = emqx_hooks:add(
        'client.subscribe', {?MODULE, on_client_subscribe, [TestPid]}, ?HP_HIGHEST
    ),
    TopicFilters = [
        {AllowedTopic, ?DEFAULT_SUBOPTS},
        {DeniedTopic, ?DEFAULT_SUBOPTS},
        {<<"$share/group/", AllowedSharedTopic/binary>>, ?DEFAULT_SUBOPTS},
        {<<"$share/group/", DeniedSharedTopic/binary>>, ?DEFAULT_SUBOPTS}
    ],
    ListenerId = 'tcp:default',
    ok = emqx_listeners:start_listener(ListenerId),
    on_exit(fun() ->
        emqx_listeners:stop_listener(ListenerId),
        emqx_limiter:create_listener_limiters(ListenerId, #{})
    end),
    {ok, Client} = emqtt:start_link(#{clientid => ClientId}),
    {ok, _} = emqtt:connect(Client),
    [ChannelPid] = emqx_cm:lookup_channels(ClientId),
    ChannelPid ! {subscribe, TopicFilters},
    {client_subscribe, #{}, HookTopicFilters} = ?assertReceive(
        {client_subscribe, #{}, _}, 1_000
    ),
    ok = snabbkaffe_diff:assert_lists_eq(
        AllowedTopics,
        [Topic || {Topic, _SubOpts} <- HookTopicFilters]
    ),
    snabbkaffe_diff:assert_lists_eq(
        lists:sort(AllowedTopics),
        channel_subscriptions(ClientId)
    ),
    emqtt:disconnect(Client).

t_internal_subscribe_checks_caps(_) ->
    ClientId = atom_to_binary(?FUNCTION_NAME),
    SimpleTopic = <<"simple">>,
    WildcardTopic = <<"wildcard/#">>,
    OldValue = emqx_config:get_zone_conf(default, [mqtt, wildcard_subscription]),
    on_exit(fun() ->
        emqx_config:put_zone_conf(default, [mqtt, wildcard_subscription], OldValue)
    end),
    emqx_config:put_zone_conf(default, [mqtt, wildcard_subscription], false),
    ListenerId = 'tcp:default',
    ok = emqx_listeners:start_listener(ListenerId),
    on_exit(fun() ->
        emqx_listeners:stop_listener(ListenerId),
        emqx_limiter:create_listener_limiters(ListenerId, #{})
    end),
    {ok, Client} = emqtt:start_link(#{clientid => ClientId}),
    {ok, _} = emqtt:connect(Client),
    [ChannelPid] = emqx_cm:lookup_channels(ClientId),
    ChannelPid !
        {subscribe, [
            {SimpleTopic, ?DEFAULT_SUBOPTS},
            {WildcardTopic, ?DEFAULT_SUBOPTS}
        ]},
    snabbkaffe_diff:assert_lists_eq(
        [SimpleTopic],
        channel_subscriptions(ClientId)
    ),
    emqtt:disconnect(Client).

t_handle_info_subscribe_honors_disconnect_deny_action(_) ->
    OldDenyAction = emqx:get_config([authorization, deny_action], ignore),
    {ok, _} = emqx:update_config([authorization, deny_action], disconnect),
    on_exit(fun() ->
        {ok, _} = emqx:update_config([authorization, deny_action], OldDenyAction)
    end),
    ok = meck:expect(emqx_access_control, authorize, fun(_, _, _) -> deny end),
    ?assertMatch(
        {ok, [{outgoing, ?DISCONNECT_PACKET(?RC_NOT_AUTHORIZED)}, {close, not_authorized}], _},
        emqx_channel:handle_info(
            {subscribe, [{<<"deny">>, ?DEFAULT_SUBOPTS}]}, channel()
        )
    ).

t_handle_info_force_subscribe_bypasses_checks_and_hooks(_) ->
    TestPid = self(),
    ok = meck:expect(emqx_access_control, authorize, fun(_, _, _) -> deny end),
    ok = meck:expect(emqx_session, subscribe, fun(_, Topic, _, Session) ->
        TestPid ! {subscribed, Topic},
        {ok, Session}
    end),
    ok = emqx_hooks:add(
        'client.subscribe', {?MODULE, on_client_subscribe, [TestPid]}, ?HP_HIGHEST
    ),
    on_exit(fun() ->
        emqx_hooks:del('client.subscribe', {?MODULE, on_client_subscribe})
    end),
    {ok, _Channel} = emqx_channel:handle_info(
        {force_subscribe, [{<<"forced">>, ?DEFAULT_SUBOPTS}]}, channel()
    ),
    ?assertReceive({subscribed, <<"forced">>}),
    ?assertNotReceive({client_subscribe, _, _}).

t_handle_info_unsubscribe(_) ->
    ok = meck:expect(emqx_session, unsubscribe, fun(_, _, _, Session) -> {ok, Session} end),
    {ok, _Chan} = emqx_channel:handle_info({unsubscribe, topic_filters()}, channel()).

t_handle_info_sock_closed(_) ->
    Channel = channel(#{conn_state => disconnected}),
    {ok, Channel} = emqx_channel:handle_info({sock_closed, reason}, Channel).

%%--------------------------------------------------------------------
%% Test cases for handle_timeout
%%--------------------------------------------------------------------

-define(CUSTOM_TIMER_TIMEOUT_LONG, 500).
-define(CUSTOM_TIMER_TIMEOUT, 100).
-define(CUSTOM_TIMER_TIMEOUT_SHORT, 20).

t_handle_timeout_keepalive(_) ->
    TRef = make_ref(),
    Channel = emqx_channel:set_field(timers, #{keepalive => TRef}, channel()),
    {ok, _Chan} = emqx_channel:handle_timeout(make_ref(), {keepalive, 10}, Channel).

-doc "Delivery retries retransmit unacknowledged messages, rearm the timer, and stop after PUBACK.".
t_handle_timeout_retry_delivery(_) ->
    Session = session(#{retry_interval => ?CUSTOM_TIMER_TIMEOUT_SHORT}),
    Channel = channel(#{session => Session, alias_maximum => #{outbound => 0}}),
    Msg = emqx_message:make(test, ?QOS_1, <<"t">>, <<"payload">>),
    {ok, {outgoing, ?PUBLISH_PACKET(?QOS_1, <<"t">>, PacketId, <<"payload">>)}, Chan1} =
        emqx_channel:handle_deliver([{deliver, <<"t">>, Msg}], Channel),
    Timer = {emqx_session, retry_delivery},
    TRef1 = maps:get(Timer, emqx_channel:info(timers, Chan1)),
    ?assertReceive({timeout, TRef1, Timer}),
    {ok, {outgoing, Retry}, Chan2} = emqx_channel:handle_timeout(TRef1, Timer, Chan1),
    ?assertMatch(?PUBLISH_PACKET(?QOS_1, <<"t">>, PacketId, <<"payload">>), Retry),
    ?assertMatch(#mqtt_packet{header = #mqtt_packet_header{dup = true}}, Retry),
    TRef2 = maps:get(Timer, emqx_channel:info(timers, Chan2)),
    ?assertNotEqual(TRef1, TRef2),
    {ok, Chan3} = emqx_channel:handle_in(?PUBACK_PACKET(PacketId), Chan2),
    ?assertEqual(0, emqx_channel:info({session, inflight_cnt}, Chan3)),
    ?assertReceive({timeout, TRef2, Timer}),
    {ok, Chan4} = emqx_channel:handle_timeout(TRef2, Timer, Chan3),
    ?assertNot(maps:is_key(Timer, emqx_channel:info(timers, Chan4))).

t_handle_timeout_expire_awaiting_rel(_) ->
    TRef = make_ref(),
    Channel = emqx_channel:set_field(timers, #{expire_awaiting_rel => TRef}, channel()),
    {ok, _Chan} = emqx_channel:handle_timeout(TRef, expire_awaiting_rel, Channel).

t_handle_timeout_expire_session(_) ->
    TRef = make_ref(),
    Channel = emqx_channel:set_field(timers, #{expire_session => TRef}, channel()),
    {shutdown, expired, _Chan} = emqx_channel:handle_timeout(TRef, expire_session, Channel).

t_handle_timeout_will_message(_) ->
    {ok, _Chan} = emqx_channel:handle_timeout(make_ref(), will_message, channel()).

t_handle_custom_timers(_) ->
    Channel = channel(#{
        conn_state => connected,
        conn_flags => [],
        session => {?MODULE, #{}}
    }),
    %% Sets `signal1` timer:
    {ok, Chan1} = emqx_channel:handle_signal(
        {connection, congested, #{retry => ?CUSTOM_TIMER_TIMEOUT}},
        Channel
    ),
    %% Sets `signal2` timer:
    {ok, Chan2} = emqx_channel:handle_signal(
        {connection, decongested, #{retry => ?CUSTOM_TIMER_TIMEOUT_LONG}},
        Chan1
    ),
    %% Changing timeout is ignored for `set_timer`:
    {ok, Chan3} = emqx_channel:handle_signal(
        {connection, congested, #{retry => ?CUSTOM_TIMER_TIMEOUT_LONG}},
        Chan2
    ),
    {timeout, T1Ref, T1Msg} =
        ?assertReceive({timeout, _, {emqx_session, signal1}}, ?CUSTOM_TIMER_TIMEOUT * 2),
    %% Sets `msg1` timer:
    {ok, {outgoing, ?PUBLISH_PACKET(0, <<"a/b">>, 1, <<"1">>)}, Chan4} =
        emqx_channel:handle_timeout(T1Ref, T1Msg, Chan3),
    %% Resets `msg1` timer to a shorter timeout:
    {ok, {outgoing, ?PUBLISH_PACKET(0, <<"c/d">>, 2, <<"2">>)}, Chan5} =
        emqx_channel:handle_timeout(make_ref(), {emqx_session, retry_delivery}, Chan4),
    {timeout, T2Ref, T2Msg} =
        ?assertReceive({timeout, _, {emqx_session, msg1}}, ?CUSTOM_TIMER_TIMEOUT_SHORT * 2),
    %% Clears `signal2` timer:
    {ok, _Chan} = emqx_channel:handle_timeout(T2Ref, T2Msg, Chan5),
    ?assertNotReceive({timeout, _, _}, ?CUSTOM_TIMER_TIMEOUT_LONG * 2).

%%--------------------------------------------------------------------
%% Mocked session module
%%--------------------------------------------------------------------

handle_signal(_ClientInfo, {connection, congested, #{retry := Timeout}}, {?MODULE, Session}) ->
    Effect = {set_timer, signal1, Timeout},
    {Effect, [], {?MODULE, Session}};
handle_signal(_ClientInfo, {connection, decongested, #{retry := Timeout}}, {?MODULE, Session}) ->
    Effect = {set_timer, signal2, Timeout},
    {Effect, [], {?MODULE, Session}}.

info(created_at, {?MODULE, _Session}) ->
    0.

handle_timeout(_ClientInfo, signal1, [congested], {?MODULE, Session}) ->
    Msg = emqx_message:make(<<"a/b">>, <<"1">>),
    Effect = {reset_timer, msg1, ?CUSTOM_TIMER_TIMEOUT_LONG},
    {Effect, [{1, Msg}], {?MODULE, Session}};
handle_timeout(_ClientInfo, retry_delivery, [congested], {?MODULE, Session}) ->
    Msg = emqx_message:make(<<"c/d">>, <<"2">>),
    Effect = {reset_timer, msg1, ?CUSTOM_TIMER_TIMEOUT_SHORT},
    {Effect, [{2, Msg}], {?MODULE, Session}};
handle_timeout(_ClientInfo, msg1, [congested], {?MODULE, Session}) ->
    Effect = {reset_timer, signal2, infinity},
    {Effect, [], {?MODULE, Session}}.

%%--------------------------------------------------------------------
%% Test cases for internal functions
%%--------------------------------------------------------------------

t_enrich_conninfo(_) ->
    {ok, _Chan} = emqx_channel:enrich_conninfo(connpkt(), channel()).

t_enrich_client(_) ->
    {ok, _ConnPkt, _Chan} = emqx_channel:enrich_client(connpkt(), channel()).

t_auth_connect(_) ->
    {ok, _, _Chan} = emqx_channel:process_authenticate(?CONNECT_PACKET(connpkt()), channel()).

t_process_alias(_) ->
    Publish = #mqtt_packet_publish{topic_name = <<>>, properties = #{'Topic-Alias' => 1}},
    Channel = emqx_channel:set_field(topic_aliases, #{inbound => #{1 => <<"t">>}}, channel()),
    {ok, #mqtt_packet{variable = #mqtt_packet_publish{topic_name = <<"t">>}}, _Chan} =
        emqx_channel:process_alias(#mqtt_packet{variable = Publish}, Channel).

t_process_alias_inexistent_alias(_) ->
    Publish = #mqtt_packet_publish{topic_name = <<>>, properties = #{'Topic-Alias' => 1}},
    Channel = channel(),
    ?assertEqual(
        {error, ?RC_PROTOCOL_ERROR},
        emqx_channel:process_alias(#mqtt_packet{variable = Publish}, Channel)
    ).

t_packing_alias(_) ->
    Packet1 = #mqtt_packet{
        variable = #mqtt_packet_publish{
            topic_name = <<"x">>,
            properties = #{'User-Property' => [{<<"k">>, <<"v">>}]}
        }
    },
    Packet2 = #mqtt_packet{variable = #mqtt_packet_publish{topic_name = <<"y">>}},
    Channel = emqx_channel:set_field(alias_maximum, #{outbound => 1}, channel()),

    {RePacket1, NChannel1} = emqx_channel:packing_alias(Packet1, Channel),
    ?assertEqual(
        #mqtt_packet{
            variable = #mqtt_packet_publish{
                topic_name = <<"x">>,
                properties = #{
                    'Topic-Alias' => 1,
                    'User-Property' => [{<<"k">>, <<"v">>}]
                }
            }
        },
        RePacket1
    ),

    {RePacket2, NChannel2} = emqx_channel:packing_alias(Packet1, NChannel1),
    ?assertEqual(
        #mqtt_packet{
            variable = #mqtt_packet_publish{
                topic_name = <<>>,
                properties = #{
                    'Topic-Alias' => 1,
                    'User-Property' => [{<<"k">>, <<"v">>}]
                }
            }
        },
        RePacket2
    ),

    {RePacket3, _} = emqx_channel:packing_alias(Packet2, NChannel2),
    ?assertEqual(
        #mqtt_packet{variable = #mqtt_packet_publish{topic_name = <<"y">>, properties = #{}}},
        RePacket3
    ),

    ?assertMatch(
        {#mqtt_packet{variable = #mqtt_packet_publish{topic_name = <<"z">>}}, _},
        emqx_channel:packing_alias(
            #mqtt_packet{variable = #mqtt_packet_publish{topic_name = <<"z">>}},
            channel()
        )
    ).

t_packing_alias_inexistent_alias(_) ->
    Publish = #mqtt_packet_publish{topic_name = <<>>, properties = #{'Topic-Alias' => 1}},
    Channel = channel(),
    Packet = #mqtt_packet{variable = Publish},
    ExpectedChannel = emqx_channel:set_field(
        topic_aliases,
        #{
            inbound => #{},
            outbound => #{<<>> => 1}
        },
        Channel
    ),
    ?assertEqual(
        {Packet, ExpectedChannel},
        emqx_channel:packing_alias(Packet, Channel)
    ).

t_check_pub_authz(_) ->
    emqx_config:put_zone_conf(default, [authorization, enable], true),
    Msg = emqx_message:make(?MODULE, ?QOS_0, <<"t">>, <<"payload">>),
    ?assertMatch(
        {ok, Msg, _},
        emqx_channel:check_pub_authz(Msg, channel())
    ).

t_check_pub_alias(_) ->
    Publish = #mqtt_packet_publish{topic_name = <<>>, properties = #{'Topic-Alias' => 1}},
    Channel = emqx_channel:set_field(alias_maximum, #{inbound => 10}, channel()),
    ok = emqx_channel:check_pub_alias(#mqtt_packet{variable = Publish}, Channel).

message_ingress(
    #{authz_ctx := #{clientid := <<"clientid">>}},
    Msg = #message{topic = <<"source">>}
) ->
    {ok, emqx_message:set_header(ingress, value, Msg#message{topic = <<"target">>})}.

message_ingress_error(_Ctx, _Msg) ->
    {stop, {error, ingress_denied}}.

t_check_sub_authzs(_) ->
    emqx_config:put_zone_conf(default, [authorization, enable], true),
    TopicFilter = {<<"t">>, ?DEFAULT_SUBOPTS},
    SubPkt = ?SUBSCRIBE_PACKET(1, #{}, [TopicFilter]),
    Operation = emqx_channel:subscribe_operation(SubPkt),
    Channel = channel(),
    ?assertMatch({ok, _, Channel}, emqx_channel:check_sub_authzs(Operation, Channel)).

t_parse_raw_topic_filters_subscription_filter_enabled(_) ->
    OldMode = emqx_config:get_zone_conf(default, [mqtt, subscription_message_filter], disable),
    emqx_config:put_zone_conf(default, [mqtt, subscription_message_filter], enable),
    try
        [{<<"t">>, SubOpts}] = emqx_channel:parse_raw_topic_filters(
            [{<<"t?location=roomA&value>25">>, ?DEFAULT_SUBOPTS}],
            channel()
        ),
        ?assertMatch(
            #{
                sub_filter_enabled := true,
                sub_filter_raw := <<"location=roomA&value>25">>,
                sub_filter_source := <<"t?location=roomA&value>25">>,
                sub_filter_ast := [{eq, <<"location">>, <<"roomA">>}, {gt, <<"value">>, 25.0}]
            },
            SubOpts
        ),
        [{#share{group = <<"g">>, topic = <<"t">>}, SharedSubOpts}] = emqx_channel:parse_raw_topic_filters(
            [{<<"$share/g/t?location=roomA">>, ?DEFAULT_SUBOPTS}],
            channel()
        ),
        ?assertMatch(
            #{
                sub_filter_enabled := true,
                sub_filter_raw := <<"location=roomA">>,
                sub_filter_source := <<"$share/g/t?location=roomA">>,
                sub_filter_ast := [{eq, <<"location">>, <<"roomA">>}]
            },
            SharedSubOpts
        ),
        [{<<"test/#">>, MultiWildcardSubOpts}] = emqx_channel:parse_raw_topic_filters(
            [{<<"test/#?location=roomA">>, ?DEFAULT_SUBOPTS}],
            channel()
        ),
        ?assertMatch(
            #{
                sub_filter_enabled := true,
                sub_filter_raw := <<"location=roomA">>,
                sub_filter_source := <<"test/#?location=roomA">>,
                sub_filter_ast := [{eq, <<"location">>, <<"roomA">>}]
            },
            MultiWildcardSubOpts
        ),
        [{<<"test/+">>, SingleWildcardSubOpts}] = emqx_channel:parse_raw_topic_filters(
            [{<<"test/+?location=roomA">>, ?DEFAULT_SUBOPTS}],
            channel()
        ),
        ?assertMatch(
            #{
                sub_filter_enabled := true,
                sub_filter_raw := <<"location=roomA">>,
                sub_filter_source := <<"test/+?location=roomA">>,
                sub_filter_ast := [{eq, <<"location">>, <<"roomA">>}]
            },
            SingleWildcardSubOpts
        ),
        [{<<"t">>, #{}}] = emqx_channel:parse_raw_topic_filters([<<"t?location=roomA">>], channel())
    after
        emqx_config:put_zone_conf(default, [mqtt, subscription_message_filter], OldMode)
    end.

t_parse_raw_topic_filters_subscription_filter_disabled(_) ->
    OldMode = emqx_config:get_zone_conf(default, [mqtt, subscription_message_filter], disable),
    emqx_config:put_zone_conf(default, [mqtt, subscription_message_filter], disable),
    try
        [{<<"t?location=roomA">>, SubOpts}] = emqx_channel:parse_raw_topic_filters(
            [{<<"t?location=roomA">>, ?DEFAULT_SUBOPTS}],
            channel()
        ),
        ?assertNot(maps:is_key(sub_filter_ast, SubOpts)),
        [{#share{group = <<"g">>, topic = <<"t?location=roomA">>}, SharedSubOpts}] =
            emqx_channel:parse_raw_topic_filters(
                [{<<"$share/g/t?location=roomA">>, ?DEFAULT_SUBOPTS}],
                channel()
            ),
        ?assertNot(maps:is_key(sub_filter_ast, SharedSubOpts))
    after
        emqx_config:put_zone_conf(default, [mqtt, subscription_message_filter], OldMode)
    end.

t_enrich_connack_caps(_) ->
    ok = meck:new(emqx_mqtt_caps, [passthrough, no_history]),
    ok = meck:expect(
        emqx_mqtt_caps,
        get_caps,
        fun(_Zone) ->
            #{
                max_packet_size => 1024,
                max_qos_allowed => ?QOS_2,
                retain_available => true,
                max_topic_alias => 10,
                shared_subscription => true,
                wildcard_subscription => true
            }
        end
    ),
    AckProps = emqx_channel:enrich_connack_caps(#{}, channel()),
    ?assertMatch(
        #{
            'Retain-Available' := 1,
            'Maximum-Packet-Size' := 1024,
            'Topic-Alias-Maximum' := 10,
            'Wildcard-Subscription-Available' := 1,
            'Subscription-Identifier-Available' := 1,
            'Shared-Subscription-Available' := 1
        },
        AckProps
    ),
    ok = meck:unload(emqx_mqtt_caps).

%%--------------------------------------------------------------------
%% Test cases for terminate
%%--------------------------------------------------------------------

t_terminate(_) ->
    ok = emqx_channel:terminate(normal, channel()),
    ok = emqx_channel:terminate(sock_error, channel(#{conn_state => connected})),
    ok = emqx_channel:terminate({shutdown, kicked}, channel(#{conn_state => connected})).

t_ws_cookie_init(_) ->
    WsCookie = [{<<"session_id">>, <<"xyz">>}],
    ConnInfo = #{
        socktype => ws,
        peername => {{127, 0, 0, 1}, 3456},
        sockname => {{127, 0, 0, 1}, 1883},
        peercert => nossl,
        conn_mod => emqx_ws_connection,
        ws_cookie => WsCookie
    },
    Channel = emqx_channel:init(
        ConnInfo,
        #{
            zone => default,
            limiter => undefined,
            listener => {tcp, default}
        }
    ),
    ?assertMatch(#{ws_cookie := WsCookie}, emqx_channel:info(clientinfo, Channel)).

-doc "peerport must be bound from the real peername ConnInfo, not just copied as a fixture.".
t_init_binds_peerport(_) ->
    ConnInfo = #{
        peername => {{127, 0, 0, 1}, 3456},
        sockname => {{127, 0, 0, 1}, 1883}
    },
    Channel = emqx_channel:init(
        ConnInfo,
        #{
            zone => default,
            limiter => undefined,
            listener => {tcp, default}
        }
    ),
    ?assertMatch(
        #{peerport := 3456, peerhost := {127, 0, 0, 1}, peername := {{127, 0, 0, 1}, 3456}},
        emqx_channel:info(clientinfo, Channel)
    ).

%%--------------------------------------------------------------------
%% Test cases for other mechanisms
%%--------------------------------------------------------------------

t_flapping_detect(_) ->
    emqx_config:put_zone_conf(default, [flapping_detect, window_time], 60000),
    Parent = self(),
    mock_cm_open_session(),
    ok = meck:expect(emqx_flapping, detect, fun(_) -> Parent ! flapping_detect end),
    IdleChannel = channel(
        clientinfo(#{
            username => <<>>,
            enable_authn => quick_deny_anonymous
        }),
        #{conn_state => idle}
    ),
    {shutdown, not_authorized, _ConnAck, _Channel} =
        emqx_channel:handle_in(?CONNECT_PACKET(connpkt()), IdleChannel),
    receive
        flapping_detect -> ok
    after 2000 ->
        ?assert(false, "Flapping detect should be exected in connecting progress")
    end,
    meck:unload([emqx_flapping]).

t_peercert_pp2_cn_with_crlf_rejected(_) ->
    %% PROXY-Protocol v2 surfaces SSL_CN as a raw attacker-controlled binary.
    %% Bytes that would split an HTTP request line (CR/LF/NUL) or any other
    %% C0/C1 control character must cause the connection to be rejected,
    %% mirroring how `emqx_frame:validate_utf8/1` rejects MQTT-ingested
    %% clientid/username/password.
    SmuggledCN =
        <<
            "admin\r\nX-Forwarded-User: ROOT_VIA_PP2"
            "\r\nX-Override-Result: allow\r\nX-Bypass: 1"
        >>,
    PeerCert = [{pp2_ssl_cn, SmuggledCN}],
    ConnInfo = pp2_conn_info(PeerCert),
    Opts = #{zone => default, limiter => undefined, listener => {tcp, default}},
    ?assertExit(
        {shutdown, peercert_field_invalid},
        emqx_channel:init(ConnInfo, Opts)
    ).

t_peercert_pp2_cn_clean_accepted(_) ->
    %% Negative control: a well-formed PP2 SSL_CN is still accepted.
    PeerCert = [{pp2_ssl_cn, <<"alice.example.com">>}],
    ConnInfo = pp2_conn_info(PeerCert),
    Opts = #{zone => default, limiter => undefined, listener => {tcp, default}},
    Channel = emqx_channel:init(ConnInfo, Opts),
    ?assertMatch(
        #{cn := <<"alice.example.com">>},
        emqx_channel:info(clientinfo, Channel)
    ).

t_peersni_with_crlf_rejected(_) ->
    %% `peersni' is sourced from the TLS handshake SNI or, when PROXY-Protocol
    %% v2 is used, from the `pp2_authority' TLV (attacker-controlled). It must
    %% pass the same byte-class gate as `cn' / `dn', since `${peersni}' and
    %% `${client_attrs.tns}' (commonly derived from `peersni') flow into the
    %% same HTTP authn / authz / bridge template paths.
    SmuggledSNI = <<"tenant-a\r\nX-Override-Result: allow">>,
    ConnInfo = (pp2_conn_info(nossl))#{peersni => SmuggledSNI},
    Opts = #{zone => default, limiter => undefined, listener => {tcp, default}},
    ?assertExit(
        {shutdown, clientinfo_field_invalid},
        emqx_channel:init(ConnInfo, Opts)
    ).

t_peersni_clean_accepted(_) ->
    ConnInfo = (pp2_conn_info(nossl))#{peersni => <<"tenant-a.example.com">>},
    Opts = #{zone => default, limiter => undefined, listener => {tcp, default}},
    Channel = emqx_channel:init(ConnInfo, Opts),
    ?assertMatch(
        #{peersni := <<"tenant-a.example.com">>},
        emqx_channel:info(clientinfo, Channel)
    ).

t_client_attrs_with_control_chars_dropped(_) ->
    %% A `client_attrs_init' Variform expression that ends up producing bytes
    %% in the C0/C1 control range (e.g. by pulling from a non-strict-mode
    %% MQTT v5 user property) must be dropped, not propagated to
    %% `client_attrs', otherwise it would re-introduce the CRLF primitive
    %% via `${client_attrs.tns}' in HTTP templates.
    {ok, Good} = emqx_variform:compile(<<"'tenant-a'">>),
    {ok, Bad} = emqx_variform:compile(<<"'tenant-a\r\nsmuggled'">>),
    Attrs = emqx_channel:initialize_client_attrs(
        [
            #{set_as_attr => <<"good">>, expression => Good},
            #{set_as_attr => <<"tns">>, expression => Bad}
        ],
        #{clientid => <<"c1">>}
    ),
    ?assertEqual(#{<<"good">> => <<"tenant-a">>}, Attrs).

pp2_conn_info(PeerCert) ->
    #{
        socktype => tcp,
        peername => {{127, 0, 0, 1}, 3456},
        sockname => {{127, 0, 0, 1}, 1883},
        peercert => PeerCert,
        peersni => undefined,
        conn_mod => emqx_socket_connection,
        sock => self()
    }.

%%--------------------------------------------------------------------
%% Helper functions
%%--------------------------------------------------------------------

channel() -> channel(#{}).
channel(InitFields) -> channel(clientinfo(), InitFields).
channel(ClientInfo, InitFields) -> channel(ClientInfo, InitFields, #{}).
channel(ClientInfo, InitFields, ListenerOpts) ->
    ConnInfo = #{
        peername => {{127, 0, 0, 1}, 3456},
        sockname => {{127, 0, 0, 1}, 1883},
        conn_mod => emqx_connection,
        proto_name => <<"MQTT">>,
        proto_ver => ?MQTT_PROTO_V5,
        clean_start => true,
        keepalive => 30,
        clientid => <<"clientid">>,
        username => maps:get(username, ClientInfo, <<"username">>),
        conn_props => #{},
        receive_maximum => 100,
        expiry_interval => 0
    },
    maps:fold(
        fun(Field, Value, Channel) ->
            emqx_channel:set_field(Field, Value, Channel)
        end,
        emqx_channel:init(
            ConnInfo,
            maps:merge(
                #{
                    zone => default,
                    limiter => undefined,
                    listener => {tcp, default}
                },
                ListenerOpts
            )
        ),
        maps:merge(
            #{
                clientinfo => ClientInfo,
                session => session(ClientInfo, #{}),
                quota => channel_quota(ClientInfo),
                conn_state => connected
            },
            InitFields
        )
    ).

channel_quota(#{zone := Zone, listener := ListenerId}) ->
    emqx_limiter:create_channel_client_container(Zone, ListenerId).

clientinfo() -> clientinfo(#{}).
clientinfo(InitProps) ->
    maps:merge(
        #{
            zone => default,
            listener => 'tcp:default',
            protocol => mqtt,
            peername => {{127, 0, 0, 1}, 3456},
            peerhost => {127, 0, 0, 1},
            peerport => 3456,
            sockport => 1883,
            clientid => <<"clientid">>,
            username => <<"username">>,
            is_superuser => false,
            auth_expire_at => undefined,
            is_bridge => false,
            mountpoint => undefined
        },
        InitProps
    ).

topic_filters() ->
    [{<<"+">>, ?DEFAULT_SUBOPTS}, {<<"#">>, ?DEFAULT_SUBOPTS}].

connpkt() -> connpkt(#{}).
connpkt(Props) ->
    #mqtt_packet_connect{
        proto_name = <<"MQTT">>,
        proto_ver = ?MQTT_PROTO_V4,
        is_bridge = false,
        clean_start = true,
        keepalive = 30,
        properties = Props,
        clientid = <<"clientid">>,
        username = <<"username">>,
        password = <<"passwd">>
    }.

session() -> session(clientinfo(), #{}).
session(InitFields) -> session(clientinfo(), InitFields).
session(ClientInfo, InitFields) when is_map(InitFields) ->
    Session = emqx_session:create(
        ClientInfo,
        #{
            receive_maximum => 0,
            expiry_interval => 0
        },
        _WillMsg = undefined
    ),
    maps:fold(
        fun(Field, Value, SessionAcc) ->
            % TODO: assuming specific session implementation
            emqx_session_mem:set_field(Field, Value, SessionAcc)
        end,
        Session,
        InitFields
    ).

mock_cm_open_session() ->
    on_exit(fun() -> ok = meck:delete(emqx_cm, open_session, 4) end),
    ok = meck:expect(
        emqx_cm,
        open_session,
        fun(true, _ClientInfo, _ConnInfo, _MaybeWillMsg) ->
            {ok, #{session => session(), present => false}}
        end
    ).

v4(Channel) ->
    ConnInfo = emqx_channel:info(conninfo, Channel),
    emqx_channel:set_field(
        conninfo,
        maps:put(proto_ver, ?MQTT_PROTO_V4, ConnInfo),
        Channel
    ).

authenticate_continue(Credential, _DefaultRes, TestRunnerPid, Agent) ->
    TestRunnerPid ! {authenticate, Credential},
    emqx_utils_agent:get(Agent).

on_client_subscribe(_ClientInfo, Properties, TopicFilters, TestPid) ->
    TestPid ! {client_subscribe, Properties, TopicFilters},
    {ok, TopicFilters}.

channel_subscriptions(ClientId) ->
    Subscriptions =
        emqx_cth_broker:connection_info({channel, {session, subscriptions}}, ClientId),
    lists:sort(maps:keys(Subscriptions)).
