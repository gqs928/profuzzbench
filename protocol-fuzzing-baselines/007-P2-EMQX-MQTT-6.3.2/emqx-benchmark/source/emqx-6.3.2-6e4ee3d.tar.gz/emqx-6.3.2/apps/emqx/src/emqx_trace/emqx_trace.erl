%%--------------------------------------------------------------------
%% Copyright (c) 2020-2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------
-module(emqx_trace).

-include("emqx.hrl").
-include("logger.hrl").
-include("emqx_trace.hrl").
-include_lib("emqx/include/emqx_config.hrl").

-include_lib("kernel/include/file.hrl").
-include_lib("snabbkaffe/include/trace.hrl").

%% Trace events:
-export([
    publish/1,
    subscribe/3,
    unsubscribe/2,
    log/3,
    log/4,
    rendered_action_template/2,
    make_rendered_action_template_trace_context/1,
    rendered_action_template_with_ctx/2,
    is_rule_trace_active/0
]).

%% Trace API:
-export([
    %% CRUD:
    list/0,
    list/1,
    get/1,
    create/1,
    delete/1,
    clear/0,
    update/2,
    %% Accessors:
    status/2,
    log_filename/1
]).

%% Trace Log API:
-export([
    log_details/1,
    stream_log/3
]).

%% Manager API:
-export([
    start_link/0,
    check/0
]).

%% Utilities:
-export([
    zip_dir/0,
    trace_dir/0,
    now_second/0
]).

%% Deprecated API:
-export([
    log_filename/2,
    trace_file/1,
    trace_file_detail/1,
    delete_files_after_send/2
]).

-behaviour(gen_server).
-export([init/1, handle_call/3, handle_cast/2, handle_info/2, terminate/2]).

-export_type([trace/0]).
-type trace() :: #{
    enable => boolean(),
    name := name(),
    filter := filter(),
    namespace => ?global_ns | binary(),
    start_at => _TimestampSeconds :: non_neg_integer(),
    end_at => _TimestampSeconds :: non_neg_integer(),
    formatter := text | json,
    payload_encode => text | hex | hidden,
    payload_limit => pos_integer()
}.

-export_type([name/0]).
-type name() :: binary().

-export_type([filter/0]).
-type filter() ::
    {clientid, emqx_types:clientid()}
    | {topic, emqx_types:topic()}
    | {ip_address, ip_address()}
    | {ruleid, ruleid()}.

-type ip_address() :: binary().
-type ruleid() :: binary().

-export_type([rendered_action_template_ctx/0]).
-opaque rendered_action_template_ctx() :: #{
    trace_ctx := map(),
    action_id := any()
}.

-export_type([cursor/0]).

%% Cursor in a log stream.
%% * Can be sent to the outside and received back from it, hence should be
%%   safe against `binary_to_term(term_to_binary(Cursor))`.
%% * Can be forged, however it's generally exposed to trusted user agents.
%%   Still, contains no information to "escape" the log stream.
-opaque cursor() :: #{
    %% Same as `Trace#?TRACE.start_at`:
    s := _Timestamp :: non_neg_integer(),
    p := _Position :: non_neg_integer(),
    f := emqx_trace_handler:log_fragment(),
    %% Deferred stream error:
    e => _Reason
}.

-define(DEFAULT_STREAM_CHUNK_SIZE, 64 * 1024 * 1024).

publish(#message{topic = <<"$SYS/", _/binary>>}) ->
    ignore;
publish(#message{from = From, topic = Topic, payload = Payload} = Msg) when
    is_binary(From); is_atom(From)
->
    ?TRACE(
        "PUBLISH",
        "publish_to",
        maybe_add_namespace(
            #{topic => Topic, payload => Payload},
            maybe
                undefined ?= get_namespace_from_message(Msg),
                undefined ?= get_namespace_from_proc_metadata(),
                ?global_ns
            end
        )
    ).

subscribe(<<"$SYS/", _/binary>>, _SubId, _SubOpts) ->
    ignore;
subscribe(Topic, SubId, SubOpts) ->
    ?TRACE(
        "SUBSCRIBE",
        "subscribe",
        maybe_add_namespace(
            #{
                topic => Topic, sub_opts => SubOpts, sub_id => SubId
            },
            get_namespace_from_proc_metadata()
        )
    ).

unsubscribe(<<"$SYS/", _/binary>>, _SubOpts) ->
    ignore;
unsubscribe(Topic, SubOpts) ->
    ?TRACE(
        "UNSUBSCRIBE",
        "unsubscribe",
        maybe_add_namespace(
            #{topic => Topic, sub_opts => SubOpts},
            get_namespace_from_proc_metadata()
        )
    ).

rendered_action_template(ActionID, RenderResult) when is_binary(ActionID) ->
    try emqx_resource:parse_channel_id(ActionID) of
        _ ->
            do_rendered_action_template(ActionID, RenderResult)
    catch
        throw:{invalid_id, _} ->
            %% Note [Invalid channel ids in trace]
            %% We do nothing if we don't get a valid channel id. This can happen when
            %% called from connectors that are used for actions as well as authz and
            %% authn.  Those applications generate their connector resource ids using
            %% `emqx_resource:generate_id/1`, which does not output a channel id.
            ok
    end;
rendered_action_template(#{mod := _, func := _} = ActionID, RenderResult) ->
    do_rendered_action_template(ActionID, RenderResult);
rendered_action_template(_ActionID, _RenderResult) ->
    %% See Note [Invalid channel ids in trace]
    ok.

do_rendered_action_template(ActionID, RenderResult) ->
    TraceResult = ?TRACE(
        "QUERY_RENDER",
        "action_template_rendered",
        #{
            result => RenderResult,
            action_id => ActionID
        }
    ),
    case logger:get_process_metadata() of
        #{stop_action_after_render := true} ->
            %% We throw an unrecoverable error to stop action before the
            %% resource is called/modified
            ActionIDStr =
                case ActionID of
                    Bin when is_binary(Bin) ->
                        Bin;
                    Term ->
                        ActionIDFormatted = io_lib:format("~tw", [Term]),
                        unicode:characters_to_binary(ActionIDFormatted)
                end,
            StopMsg =
                io_lib:format(
                    "Action ~ts stopped after template rendering due to test setting.",
                    [ActionIDStr]
                ),
            MsgBin = unicode:characters_to_binary(StopMsg),
            error(?EMQX_TRACE_STOP_ACTION(MsgBin));
        _ ->
            ok
    end,
    TraceResult.

%% The following two functions are used for connectors that don't do the
%% rendering in the main process (the one that called on_*query). In this case
%% we need to pass the trace context to the sub process that do the rendering
%% so that the result of the rendering can be traced correctly. It is also
%% important to  ensure that the error that can be thrown from
%% rendered_action_template_with_ctx is handled in the appropriate way in the
%% sub process.
-spec make_rendered_action_template_trace_context(any()) -> rendered_action_template_ctx().
make_rendered_action_template_trace_context(ActionID) ->
    MetaData =
        case logger:get_process_metadata() of
            undefined -> #{};
            M -> M
        end,
    #{trace_ctx => MetaData, action_id => ActionID}.

-spec rendered_action_template_with_ctx(rendered_action_template_ctx(), Result :: term()) -> term().
rendered_action_template_with_ctx(
    #{
        trace_ctx := LogMetaData,
        action_id := ActionID
    },
    RenderResult
) ->
    OldMetaData =
        case logger:get_process_metadata() of
            undefined -> #{};
            M -> M
        end,
    try
        logger:set_process_metadata(LogMetaData),
        emqx_trace:rendered_action_template(
            ActionID,
            RenderResult
        )
    after
        logger:set_process_metadata(OldMetaData)
    end.

is_rule_trace_active() ->
    case logger:get_process_metadata() of
        #{rule_id := RID} when is_binary(RID) ->
            true;
        #{rule_ids := RIDs} when map_size(RIDs) > 0 ->
            true;
        _ ->
            false
    end.

log([], _Msg, _Meta) ->
    ok;
log(LogHandlers, Msg, Meta) ->
    log(debug, LogHandlers, Msg, Meta).

log(Level, LogHandlers, Msg, Meta) ->
    Log = #{level => Level, meta => enrich_meta(Meta), msg => Msg},
    emqx_trace_handler:log(Log, LogHandlers).

enrich_meta(Meta) ->
    case logger:get_process_metadata() of
        undefined -> Meta;
        ProcMeta -> maps:merge(ProcMeta, Meta)
    end.

-spec start_link() -> emqx_types:startlink_ret().
start_link() ->
    gen_server:start_link({local, ?MODULE}, ?MODULE, [], []).

-spec list() -> [trace()].
list() ->
    [format(T) || T <- list_traces()].

-spec list(boolean()) -> [trace()].
list(Enable) ->
    [format(T) || T <- list_traces(Enable)].

list_traces() ->
    ets:match_object(?TRACE, #?TRACE{_ = '_'}).

list_traces(Enable) ->
    ets:match_object(?TRACE, #?TRACE{enable = Enable, _ = '_'}).

-spec create(trace()) ->
    {ok, trace()}
    | {error,
        {already_existed, iodata()}
        | {duplicate_condition, iodata()}
        | {max_limit_reached, non_neg_integer()}
        | {bad_type, any()}
        | iodata()}.
create(Trace) ->
    maybe
        {ok, TraceRecord} ?= mk_trace_record(Trace),
        ok ?= insert_new_trace(TraceRecord),
        {ok, format(TraceRecord)}
    end.

-spec get(name()) ->
    {ok, trace()} | {error, not_found}.
get(Name) ->
    maybe
        {ok, TraceRecord} ?= emqx_trace_dl:get(Name),
        {ok, format(TraceRecord)}
    end.

-spec delete(name()) -> ok | {error, not_found}.
delete(Name) ->
    transaction(fun emqx_trace_dl:delete/1, [Name]).

-spec clear() -> ok | {error, Reason :: term()}.
clear() ->
    case mria:clear_table(?TRACE) of
        {atomic, ok} -> ok;
        {aborted, Reason} -> {error, Reason}
    end.

-spec update(name(), Enable :: boolean()) ->
    ok | {error, not_found | finished}.
update(Name, Enable) ->
    transaction(fun emqx_trace_dl:update/2, [Name, Enable]).

-spec status(trace(), _Now :: non_neg_integer()) -> waiting | running | stopped.
status(#{enable := false}, _Now) ->
    stopped;
status(#{enable := true, start_at := Start, end_at := End}, Now) ->
    if
        Now < Start -> waiting;
        Now >= End -> stopped;
        true -> running
    end.

-spec log_filename(trace()) -> file:filename().
log_filename(#{name := Name, start_at := StartAt}) ->
    log_filename(Name, StartAt).

%%

-spec log_details(name()) ->
    {ok, #{
        size := _Bytes :: non_neg_integer(),
        mtime := _Posix :: non_neg_integer()
    }}
    | {error, not_found | {file_error, file:posix()}}.
log_details(Name) ->
    case emqx_trace_dl:get(Name) of
        {ok, Trace = #?TRACE{start_at = Start}} ->
            _ = emqx_trace_handler:filesync(mk_handler_id(Trace)),
            Basename = log_filepath(Name, Start),
            log_accum_details(first, Basename, 0, 0);
        Error ->
            Error
    end.

log_accum_details(Which, Basename, SizeAcc, MTimeMax) ->
    case emqx_trace_handler:find_log_fragment(Which, Basename) of
        {ok, _, #file_info{size = Size, mtime = MTime}, Fragment} ->
            log_accum_details({next, Fragment}, Basename, Size + SizeAcc, max(MTime, MTimeMax));
        none ->
            {ok, #{size => SizeAcc, mtime => MTimeMax}};
        {error, Reason} ->
            {error, {file_error, Reason}}
    end.

log_is_empty(Basename) ->
    case emqx_trace_handler:find_log_fragment(first, Basename) of
        {ok, _, #file_info{size = Size}, _Fragment} ->
            Size =:= 0;
        none ->
            true;
        {error, Reason} ->
            {error, {file_error, Reason}}
    end.

-spec stream_log(name(), start | {cont, cursor()}, _Limit :: pos_integer() | undefined) ->
    {ok, binary(), {cont | eof | retry, cursor()}}
    | {error, not_found | bad_cursor | stale_cursor | {file_error, file:posix()}}.
stream_log(Name, start, Limit) when Limit > 0 ->
    case emqx_trace_dl:get(Name) of
        {ok, Trace = #?TRACE{start_at = Start}} ->
            _ = emqx_trace_handler:filesync(mk_handler_id(Trace)),
            Basename = log_filepath(Name, Start),
            case emqx_trace_handler:find_log_fragment(first, Basename) of
                {ok, _Filename, _Info, Fragment} ->
                    %% NOTE: Enough information to _safely_ reconstruct the basename.
                    Cursor = #{s => Start, p => 0, f => Fragment},
                    stream_log_cursor(Name, Cursor, Limit);
                none ->
                    {error, {file_error, enoent}};
                {error, Reason} ->
                    {error, {file_error, Reason}}
            end;
        Error ->
            Error
    end;
stream_log(Name, {cont, Cursor}, Limit) when Limit > 0 ->
    stream_log_cursor(Name, Cursor, Limit).

stream_log_cursor(Name, Cursor0 = #{s := Start, p := Pos, f := Fragment0}, Limit) ->
    NBytes = emqx_maybe:define(Limit, ?DEFAULT_STREAM_CHUNK_SIZE),
    Basename = log_filepath(Name, Start),
    case emqx_trace_handler:read_log_fragment_at(Fragment0, Basename, Pos, NBytes) of
        {ok, Chunk, Fragment} ->
            Size = byte_size(Chunk),
            Cursor = Cursor0#{p := Pos + Size, f := Fragment},
            case Size of
                N when N >= NBytes ->
                    Cont = {cont, Cursor};
                _Partial ->
                    case emqx_trace_handler:find_log_fragment({next, Fragment}, Basename) of
                        {ok, _, _, FragmentNext} ->
                            Cont = {cont, Cursor#{p := 0, f := FragmentNext}};
                        none ->
                            Cont = {eof, Cursor};
                        {error, enoent} ->
                            %% Here it can actually mean active log rotation, ask the caller to
                            %% retry. If the error persists, fragments were probably manually
                            %% deleted.
                            %% See `emqx_trace_handler:find_log_fragment/2`.
                            Cont = {retry, Cursor};
                        {error, Reason} ->
                            Cont = {cont, #{e => stream_log_error(Reason)}}
                    end
            end,
            {ok, Chunk, Cont};
        {error, enoent} ->
            %% Same here, see `emqx_trace_handler:find_log_fragment/2`.
            {ok, <<>>, {retry, Cursor0}};
        {error, Reason} ->
            {error, stream_log_error(Reason)}
    end;
stream_log_cursor(_Name, #{e := Reason}, _Limit) ->
    {error, Reason};
stream_log_cursor(_Name, _Cursor, _Limit) ->
    {error, bad_cursor}.

stream_log_error(stale) ->
    stale_cursor;
stream_log_error(Reason) ->
    {file_error, Reason}.

log_filepath(Name, Start) ->
    filename:join(trace_dir(), log_filename(Name, Start)).

log_filename(Name, Start) ->
    lists:flatten(["trace_", binary_to_list(Name), "_", log_start_date(Start), ".log"]).

log_start_date(Start) ->
    hd(string:split(calendar:system_time_to_rfc3339(Start), "T", leading)).

check() ->
    gen_server:call(?MODULE, check).

%% Deprecated RPC target, see `emqx_mgmt_trace_proto_v2`.
trace_file(File) ->
    FileName = filename:join(trace_dir(), File),
    Node = atom_to_list(node()),
    case file:read_file(FileName) of
        {ok, Bin} -> {ok, Node, Bin};
        {error, Reason} -> {error, Node, Reason}
    end.

%% Deprecated RPC target, see `emqx_mgmt_trace_proto_v2`.
trace_file_detail(File) ->
    FileName = filename:join(trace_dir(), File),
    Node = atom_to_binary(node()),
    case file:read_file_info(FileName, [{'time', 'posix'}]) of
        {ok, #file_info{size = Size, mtime = Mtime}} ->
            {ok, #{size => Size, mtime => Mtime, node => Node}};
        {error, Reason} ->
            {error, #{reason => Reason, node => Node, file => File}}
    end.

delete_files_after_send(TraceLog, Zips) ->
    gen_server:cast(?MODULE, {delete_tag, self(), [TraceLog | Zips]}).

-spec format(#?TRACE{}) -> trace().
format(#?TRACE{
    enable = Enable,
    name = Name,
    type = Type,
    filter = Filter,
    start_at = StartAt,
    end_at = EndAt,
    payload_encode = PayloadEncode,
    extra = Extra
}) ->
    #{
        enable => Enable,
        name => Name,
        filter => {Type, Filter},
        namespace => maps:get(namespace, Extra, ?global_ns),
        start_at => StartAt,
        end_at => EndAt,
        payload_encode => PayloadEncode,
        payload_limit => maps:get(payload_limit, Extra, ?MAX_PAYLOAD_FORMAT_SIZE),
        formatter => maps:get(formatter, Extra, text)
    }.

%% gen_server

init([]) ->
    erlang:process_flag(trap_exit, true),
    ok = mria:create_table(?TRACE, [
        {type, set},
        {rlog_shard, ?SHARD},
        {storage, disc_copies},
        {record_name, ?TRACE},
        {attributes, record_info(fields, ?TRACE)}
    ]),
    ok = mria:wait_for_tables([?TRACE]),
    {ok, _} = mnesia:subscribe({table, ?TRACE, simple}),
    ok = filelib:ensure_dir(filename:join([trace_dir(), dummy])),
    ok = filelib:ensure_dir(filename:join([zip_dir(), dummy])),
    Traces = get_enabled_trace(),
    TRef = update_trace(Traces),
    update_trace_handler(),
    _ = clean_zip_dir(),
    {ok, #{timer => TRef, monitors => #{}}}.

handle_call(check, _From, State) ->
    {_, NewState} = handle_info({mnesia_table_event, check}, State),
    {reply, ok, NewState};
handle_call(Req, _From, State) ->
    ?SLOG(error, #{msg => "unexpected_call", req => Req}),
    {reply, ok, State}.

handle_cast({delete_tag, Pid, Files}, State = #{monitors := Monitors}) ->
    erlang:monitor(process, Pid),
    {noreply, State#{monitors => Monitors#{Pid => Files}}};
handle_cast(Msg, State) ->
    ?SLOG(error, #{msg => "unexpected_cast", req => Msg}),
    {noreply, State}.

handle_info({'DOWN', _Ref, process, Pid, _Reason}, State = #{monitors := Monitors}) ->
    case maps:take(Pid, Monitors) of
        error ->
            {noreply, State};
        {Files, NewMonitors} ->
            lists:foreach(fun file:delete/1, Files),
            {noreply, State#{monitors => NewMonitors}}
    end;
handle_info({timeout, TRef, update_trace}, #{timer := TRef} = State) ->
    Traces = get_enabled_trace(),
    NextTRef = update_trace(Traces),
    update_trace_handler(),
    ?tp(update_trace_done, #{}),
    {noreply, State#{timer => NextTRef}};
handle_info({mnesia_table_event, _Events}, State = #{timer := TRef}) ->
    emqx_utils:cancel_timer(TRef),
    handle_info({timeout, TRef, update_trace}, State);
handle_info(Info, State) ->
    ?SLOG(error, #{msg => "unexpected_info", req => Info}),
    {noreply, State}.

terminate(_Reason, #{timer := TRef}) ->
    _ = mnesia:unsubscribe({table, ?TRACE, simple}),
    emqx_utils:cancel_timer(TRef),
    stop_all_trace_handler(),
    update_trace_handler(),
    _ = clean_zip_dir(),
    ok.

insert_new_trace(Trace) ->
    case transaction(fun emqx_trace_dl:insert_new_trace/1, [Trace]) of
        ok ->
            %% We call this to ensure the trace is active when we return
            check();
        {error, _} = Error ->
            Error
    end.

update_trace(Traces) ->
    Now = now_second(),
    {_Waiting, Running, Finished} = classify_by_time(Traces, Now),
    disable_finished(Finished),
    RunningHandlers = emqx_trace_handler:running(),
    {NeedRunning, AllStarted} = start_trace(Running, RunningHandlers),
    NeedStop = filter_cli_handler(AllStarted) -- NeedRunning,
    ok = stop_traces(NeedStop, RunningHandlers),
    clean_stale_trace_files(),
    NextTime = find_closest_time(Traces, Now),
    emqx_utils:start_timer(NextTime, update_trace).

stop_all_trace_handler() ->
    lists:foreach(
        fun(#{id := Id}) -> emqx_trace_handler:uninstall(Id) end,
        emqx_trace_handler:running()
    ).

get_enabled_trace() ->
    {atomic, Traces} =
        mria:ro_transaction(?SHARD, fun emqx_trace_dl:get_enabled_trace/0),
    Traces.

find_closest_time(Traces, Now) ->
    Sec =
        lists:foldl(
            fun
                (#?TRACE{start_at = Start, end_at = End, enable = true}, Closest) ->
                    min(closest(End, Now, Closest), closest(Start, Now, Closest));
                (_, Closest) ->
                    Closest
            end,
            60 * 15,
            Traces
        ),
    timer:seconds(Sec).

closest(Time, Now, Closest) when Now >= Time -> Closest;
closest(Time, Now, Closest) -> min(Time - Now, Closest).

disable_finished([]) ->
    ok;
disable_finished(Traces) ->
    transaction(fun emqx_trace_dl:disable_finished/1, [Traces]).

start_trace(Traces, Started0) ->
    Started = lists:map(fun(#{name := Name}) -> Name end, Started0),
    lists:foldl(
        fun(
            #?TRACE{name = Name} = Trace,
            {Running, StartedAcc}
        ) ->
            case lists:member(Name, StartedAcc) of
                true ->
                    {[Name | Running], StartedAcc};
                false ->
                    case start_trace(Trace) of
                        ok -> {[Name | Running], [Name | StartedAcc]};
                        {error, _Reason} -> {[Name | Running], StartedAcc}
                    end
            end
        end,
        {[], Started},
        Traces
    ).

start_trace(Trace = #?TRACE{name = Name, start_at = Start}) ->
    HandlerID = mk_handler_id(Trace),
    Handler = mk_handler(Trace),
    Filepath = log_filepath(Name, Start),
    emqx_trace_handler:install(HandlerID, Handler, debug, Filepath).

mk_handler(#?TRACE{
    name = Name,
    type = Type,
    filter = Filter,
    payload_encode = PayloadEncode,
    extra = Extra
}) ->
    Formatter = maps:get(formatter, Extra, text),
    PayloadLimit = maps:get(payload_limit, Extra, ?MAX_PAYLOAD_FORMAT_SIZE),
    Namespace = maps:get(namespace, Extra, ?global_ns),
    #{
        name => Name,
        filter => {Type, Filter},
        namespace => Namespace,
        payload_encode => PayloadEncode,
        payload_limit => PayloadLimit,
        formatter => Formatter
    }.

%% Handler ID must be an atom.
mk_handler_id(#?TRACE{extra = #{slot := Slot}}) ->
    %% NOTE
    %% Number of slots is limited by `trace.max_traces`.
    list_to_atom(?MODULE_STRING ++ ":" ++ integer_to_list(Slot));
mk_handler_id(#?TRACE{name = Name}) ->
    %% NOTE
    %% Backward compat: pre-existing traces may lack assigned slots.
    %% To be removed in the next release.
    emqx_trace_handler:fallback_handler_id(?MODULE_STRING, Name).

stop_traces(Finished, RunningHandlers) ->
    lists:foreach(
        fun(#{name := Name} = Handler) ->
            case lists:member(Name, Finished) of
                true -> stop_trace(Handler);
                false -> ok
            end
        end,
        RunningHandlers
    ).

stop_trace(#{id := HandlerID, dst := Basename, filter := {Type, Filter}} = Handler) ->
    _ = emqx_trace_handler:filesync(HandlerID),
    case log_is_empty(Basename) of
        true ->
            ok;
        false ->
            Event = #{
                level => debug,
                meta => #{trace_tag => "API", Type => Filter},
                msg => "trace_stopping"
            },
            emqx_trace_handler:log(Event, [emqx_trace_handler:mk_log_handler(Handler)])
    end,
    emqx_trace_handler:uninstall(HandlerID).

clean_stale_trace_files() ->
    TraceDir = trace_dir(),
    case file:list_dir(TraceDir) of
        {ok, []} ->
            ok;
        {ok, ["zip"]} ->
            ok;
        {ok, Files} ->
            clean_stale_trace_files(TraceDir, Files);
        _Error ->
            ok
    end.

clean_stale_trace_files(TraceDir, Files) ->
    %% NOTE: Cleaning both stale and foreign files.
    TraceFileSet = lists:foldl(
        fun(#?TRACE{name = Name, start_at = StartAt}, Acc) ->
            %% NOTE: If `Name` is unique = filename is unique, `gb_sets:insert/2` is safe.
            gb_sets:insert(log_filename(Name, StartAt), Acc)
        end,
        gb_sets:new(),
        list_traces()
    ),
    StaleFiles = [Filename || Filename <- Files, trace_file_is_stale(Filename, TraceFileSet)],
    lists:foreach(
        fun(Filename) ->
            ?tp(debug, "trace_cleaning_stale_file", #{filename => Filename}),
            file:delete(filename:join(TraceDir, Filename))
        end,
        StaleFiles
    ).

clean_zip_dir() ->
    file:del_dir_r(zip_dir()).

trace_file_is_stale("zip", _TraceFileSet) ->
    false;
trace_file_is_stale(Filename, TraceFileSet) ->
    %% NOTE: Basename should be `Filename` or its nearest predecessor if trace exists.
    case gb_sets:next(gb_sets:iterator_from(Filename, TraceFileSet, reversed)) of
        {Basename, _It} ->
            string:prefix(Filename, Basename) =:= nomatch;
        none ->
            true
    end.

classify_by_time(Traces, Now) ->
    classify_by_time(Traces, Now, [], [], []).

classify_by_time([], _Now, Wait, Run, Finish) ->
    {Wait, Run, Finish};
classify_by_time(
    [Trace = #?TRACE{start_at = Start} | Traces],
    Now,
    Wait,
    Run,
    Finish
) when Start > Now ->
    classify_by_time(Traces, Now, [Trace | Wait], Run, Finish);
classify_by_time(
    [Trace = #?TRACE{end_at = End} | Traces],
    Now,
    Wait,
    Run,
    Finish
) when End =< Now ->
    classify_by_time(Traces, Now, Wait, Run, [Trace | Finish]);
classify_by_time([Trace | Traces], Now, Wait, Run, Finish) ->
    classify_by_time(Traces, Now, Wait, [Trace | Run], Finish).

mk_trace_record(Trace = #{}) ->
    Name = maps:get(name, Trace, undefined),
    Filter = maps:get(filter, Trace, undefined),
    ST = maps:get(start_at, Trace, undefined),
    ET = maps:get(end_at, Trace, undefined),
    maybe
        ok ?= validate_name(Name),
        ok ?= validate_filter(Filter),
        ok ?= validate_end_at(ET),
        {Type, Match} = Filter,
        Record = fill_default(#?TRACE{
            name = Name,
            type = Type,
            filter = Match,
            start_at = ST,
            end_at = ET,
            payload_encode = maps:get(payload_encode, Trace, text),
            extra = maps:merge(
                #{formatter => text},
                maps:with([formatter, payload_limit, namespace], Trace)
            )
        }),
        ok ?= validate_time_range(Record),
        {ok, Record}
    end.

fill_default(Trace = #?TRACE{start_at = undefined}) ->
    fill_default(Trace#?TRACE{start_at = now_second()});
fill_default(Trace = #?TRACE{end_at = undefined, start_at = StartAt}) ->
    fill_default(Trace#?TRACE{end_at = StartAt + 10 * 60});
fill_default(Trace) ->
    Trace.

validate_time_range(#?TRACE{start_at = Start, end_at = End}) when End =< Start ->
    {error, "Start time is ahead of end time"};
validate_time_range(_) ->
    ok.

-define(NAME_RE, "^[A-Za-z]+[A-Za-z0-9-_]*$").

validate_name(undefined) ->
    {error, "name required"};
validate_name(Name) when is_binary(Name) ->
    case
        Name =:= unicode:characters_to_binary(Name, utf8) andalso
            re:run(Name, ?NAME_RE)
    of
        false -> {error, "Name is not a UTF-8 string"};
        nomatch -> {error, "Name should be " ?NAME_RE};
        _ -> ok
    end.

validate_filter({clientid, _ClientId = <<_/binary>>}) ->
    ok;
validate_filter({topic, Topic}) ->
    validate_topic(Topic);
validate_filter({ip_address, Addr}) ->
    validate_ip_address(Addr);
validate_filter({ruleid, _RuleId = <<_/binary>>}) ->
    ok;
validate_filter(_) ->
    {error, "type=[topic,clientid,ip_address,ruleid] required"}.

validate_end_at(undefined) ->
    ok;
validate_end_at(EndAt) ->
    case now_second() of
        Now when Now < EndAt ->
            ok;
        _ ->
            {error, "End time has already passed"}
    end.

validate_topic(TopicName) ->
    try emqx_topic:validate(filter, TopicName) of
        true -> ok
    catch
        error:Error ->
            {error, io_lib:format("topic: ~s invalid by ~p", [TopicName, Error])}
    end.
validate_ip_address(IP) ->
    case inet:parse_address(binary_to_list(IP)) of
        {ok, _} -> ok;
        {error, Reason} -> {error, lists:flatten(io_lib:format("ip address: ~p", [Reason]))}
    end.

zip_dir() ->
    filename:join([trace_dir(), "zip"]).

trace_dir() ->
    filename:join(emqx:data_dir(), "trace").

transaction(Fun, Args) ->
    case mria:transaction(?COMMON_SHARD, Fun, Args) of
        {atomic, Res} -> Res;
        {aborted, Reason} -> {error, Reason}
    end.

update_trace_handler() ->
    case emqx_trace_handler:running() of
        [] ->
            persistent_term:erase(?TRACE_FILTER);
        Running ->
            List = [emqx_trace_handler:mk_log_handler(HandlerInfo) || HandlerInfo <- Running],
            case List =/= persistent_term:get(?TRACE_FILTER, undefined) of
                true -> persistent_term:put(?TRACE_FILTER, List);
                false -> ok
            end
    end.

filter_cli_handler(Names) ->
    lists:filter(
        fun(Name) ->
            nomatch =:= re:run(Name, "^CLI-+.", [])
        end,
        Names
    ).

now_second() ->
    os:system_time(second).

get_namespace_from_proc_metadata() ->
    case logger:get_process_metadata() of
        #{tns := Ns} ->
            Ns;
        _ ->
            undefined
    end.

get_namespace_from_message(#message{headers = Headers}) ->
    case Headers of
        #{client_attrs := #{?CLIENT_ATTR_NAME_TNS := Ns}} ->
            Ns;
        _ ->
            undefined
    end.

%% we don't add the namespace key if it's global to differentiate it from a namespaced
%% called "global"
maybe_add_namespace(Log, Ns) when is_binary(Ns) ->
    Log#{namespace => Ns};
maybe_add_namespace(Log, _) ->
    Log.

%% Tests

-ifdef(TEST).
-include_lib("eunit/include/eunit.hrl").

-define(DEFAULT_MS, 60 * 15000).

find_closest_time_empty_test() ->
    ?assertEqual(?DEFAULT_MS, find_closest_time([], now_second())).

find_closest_time_disabled_test() ->
    Now = now_second(),
    Traces = [
        #emqx_trace{name = <<"disable">>, start_at = Now + 1, end_at = Now + 2, enable = false}
    ],
    ?assertEqual(?DEFAULT_MS, find_closest_time(Traces, Now)).

find_closest_time_ends_soon_test() ->
    Now = now_second(),
    Traces = [
        #emqx_trace{name = <<"running">>, start_at = Now, end_at = Now + 10, enable = true}
    ],
    ?assertEqual(10000, find_closest_time(Traces, Now)).

find_closest_time_starts_soon_test() ->
    Now = now_second(),
    Traces = [
        #emqx_trace{name = <<"waiting">>, start_at = Now + 2, end_at = Now + 10, enable = true}
    ],
    ?assertEqual(2000, find_closest_time(Traces, Now)).

find_closest_time_complex_test() ->
    Now = now_second(),
    Traces = [
        #emqx_trace{name = <<"waiting">>, start_at = Now + 1, end_at = Now + 2, enable = true},
        #emqx_trace{name = <<"running0">>, start_at = Now, end_at = Now + 5, enable = true},
        #emqx_trace{name = <<"running1">>, start_at = Now - 1, end_at = Now + 1, enable = true},
        #emqx_trace{name = <<"finished">>, start_at = Now - 2, end_at = Now - 1, enable = true},
        #emqx_trace{name = <<"waiting">>, start_at = Now + 1, end_at = Now + 1, enable = true},
        #emqx_trace{name = <<"stopped">>, start_at = Now, end_at = Now + 10, enable = false}
    ],
    ?assertEqual(1000, find_closest_time(Traces, Now)).

-endif.
