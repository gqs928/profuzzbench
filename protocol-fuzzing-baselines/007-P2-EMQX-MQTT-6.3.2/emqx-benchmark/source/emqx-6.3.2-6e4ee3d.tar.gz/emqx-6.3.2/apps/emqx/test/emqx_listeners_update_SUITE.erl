%%--------------------------------------------------------------------
%% Copyright (c) 2017-2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------

-module(emqx_listeners_update_SUITE).

-compile(export_all).
-compile(nowarn_export_all).

-include_lib("emqx/include/emqx.hrl").
-include_lib("emqx/include/emqx_schema.hrl").
-include_lib("eunit/include/eunit.hrl").
-include_lib("common_test/include/ct.hrl").
-import(emqx_listeners, [current_conns/2, is_running/1]).

-define(LISTENERS, [listeners]).

all() ->
    [{group, legacy}, {group, hardened}].

groups() ->
    Tests = emqx_common_test_helpers:all(?MODULE),
    [{legacy, [], Tests}, {hardened, [], Tests}].

init_per_suite(Config) ->
    emqx_common_test_helpers:clear_security_profile(),
    Config.

end_per_suite(_Config) ->
    emqx_common_test_helpers:clear_security_profile().

init_per_group(Profile, Config) when Profile =:= legacy; Profile =:= hardened ->
    emqx_common_test_helpers:set_security_profile(Profile),
    Apps = emqx_cth_suite:start(
        [emqx],
        #{work_dir => emqx_cth_suite:work_dir(Profile, Config)}
    ),
    [{apps, Apps}, {security_profile, Profile} | Config].

end_per_group(_Profile, Config) ->
    emqx_cth_suite:stop(?config(apps, Config)),
    emqx_common_test_helpers:clear_security_profile().

init_per_testcase(_TestCase, Config) ->
    Init = emqx:get_raw_config(?LISTENERS),
    [{init_conf, Init} | Config].

end_per_testcase(_TestCase, Config) ->
    Conf = ?config(init_conf, Config),
    {ok, _} = emqx:update_config(?LISTENERS, Conf),
    ok.

t_default_conf(Config) ->
    Profile = ?config(security_profile, Config),
    TcpBind = expected_default_bind(Profile, 1883),
    SslBind = expected_default_bind(Profile, 8883),
    WsBind = expected_default_bind(Profile, 8083),
    WssBind = expected_default_bind(Profile, 8084),
    RawTcpBind = format_raw_bind(TcpBind),
    RawSslBind = format_raw_bind(SslBind),
    RawWsBind = format_raw_bind(WsBind),
    RawWssBind = format_raw_bind(WssBind),
    ?assertMatch(
        #{
            <<"tcp">> := #{<<"default">> := #{<<"bind">> := RawTcpBind}},
            <<"ssl">> := #{<<"default">> := #{<<"bind">> := RawSslBind}},
            <<"ws">> := #{<<"default">> := #{<<"bind">> := RawWsBind}},
            <<"wss">> := #{<<"default">> := #{<<"bind">> := RawWssBind}}
        },
        emqx:get_raw_config(?LISTENERS)
    ),
    ?assertMatch(
        #{
            tcp := #{default := #{bind := TcpBind}},
            ssl := #{default := #{bind := SslBind}},
            ws := #{default := #{bind := WsBind}},
            wss := #{default := #{bind := WssBind}}
        },
        emqx:get_config(?LISTENERS)
    ),
    ok.

t_listener_id_length(_Config) ->
    InvalidNameReason =
        {listener_name_invalid_chars,
            <<"Listener name must start with a letter or digit and contain only letters, digits, '-' and '_'">>},
    InvalidNameError = {error, InvalidNameReason},
    TooLongReason =
        {listener_name_too_long, <<"Listener name must not exceed 64 bytes">>},
    TooLongError = {error, TooLongReason},
    UnsupportedTypeError = {error, {invalid_listener_id, <<"Unsupported listener type">>}},
    InvalidFormatError =
        {error, {invalid_listener_id, <<"Invalid listener ID format, expected type:name">>}},
    lists:foreach(
        fun(NameBin) ->
            lists:foreach(
                fun(Value) ->
                    ?assertEqual(InvalidNameError, emqx_listeners:validate_listener_name(Value))
                end,
                [NameBin, binary_to_atom(NameBin)]
            )
        end,
        [<<"é"/utf8>>, <<"😀"/utf8>>, <<"你"/utf8>>]
    ),
    ?assertEqual(ok, emqx_listeners:validate_listener_name(binary:copy(<<"a">>, 64))),
    UnicodeName = binary:copy(<<"你"/utf8>>, 20),
    UnicodeNameAtom = binary_to_atom(UnicodeName, utf8),
    ?assertEqual(InvalidNameError, emqx_listeners:validate_listener_name(UnicodeName)),
    ?assertEqual(InvalidNameError, emqx_listeners:validate_listener_name(UnicodeNameAtom)),
    UnicodeTooLongName = binary:copy(<<"你"/utf8>>, 22),
    ?assertEqual(
        TooLongError,
        emqx_listeners:validate_listener_name(UnicodeTooLongName)
    ),
    ?assertEqual(
        TooLongError,
        emqx_listeners:validate_listener_name(binary_to_atom(UnicodeTooLongName, utf8))
    ),
    ?assertEqual(
        TooLongError,
        emqx_listeners:validate_listener_name(binary:copy(<<"a">>, 65))
    ),
    Raw = emqx:get_raw_config(?LISTENERS),
    NonAsciiConf = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"é"/utf8>>], Raw, #{<<"bind">> => <<"127.0.0.1:0">>}
    ),
    ?assertEqual(
        {error, {pre_config_update, emqx_listeners, InvalidNameReason}},
        emqx:update_config(?LISTENERS, NonAsciiConf)
    ),
    Name = binary:copy(<<"b">>, 65),
    Tcp = maps:get(<<"tcp">>, Raw),
    RawWithLongListener = Raw#{
        <<"tcp">> => Tcp#{Name => #{<<"bind">> => <<"127.0.0.1:0">>}}
    },
    ?assertEqual(
        {error, {pre_config_update, emqx_listeners, TooLongReason}},
        emqx:update_config(?LISTENERS, RawWithLongListener)
    ),
    ?assertEqual(
        {error, {pre_config_update, emqx_listeners, TooLongReason}},
        emqx:update_config(
            [listeners, tcp, Name],
            {create, #{<<"bind">> => <<"127.0.0.1:0">>}}
        )
    ),
    ?assertEqual(Raw, emqx:get_raw_config(?LISTENERS)),
    ?assertEqual(InvalidNameError, emqx_listeners:validate_listener_name(<<"name/with/slash">>)),
    ?assertEqual(InvalidNameError, emqx_listeners:validate_listener_name(<<"name#with#hash">>)),
    ?assertEqual(
        InvalidNameError, emqx_listeners:validate_listener_name(<<"name:with:delimiter">>)
    ),
    ?assertEqual(
        InvalidNameError, emqx_listeners:validate_listener_name(<<"name\\with\\escape">>)
    ),
    ?assertEqual(ok, emqx_listeners:validate_listener_name(<<"name-with_under">>)),
    ?assertEqual(
        InvalidNameError, emqx_listeners:validate_listener_name(<<"_leading_underscore">>)
    ),
    ?assertEqual(
        UnsupportedTypeError,
        emqx_listeners:parse_listener_id_without_atom(<<"unknown:name">>)
    ),
    ?assertEqual(
        InvalidFormatError,
        emqx_listeners:parse_listener_id_without_atom(<<"missing-delimiter">>)
    ),
    ?assertEqual(
        InvalidFormatError,
        emqx_listeners:parse_listener_id(<<"missing-delimiter">>)
    ),
    ok.

t_update_conf(_Conf) ->
    Raw = emqx:get_raw_config(?LISTENERS),
    Raw1 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"bind">>], Raw, <<"127.0.0.1:1883">>
    ),
    Raw2 = emqx_utils_maps:deep_put(
        [<<"ssl">>, <<"default">>, <<"bind">>], Raw1, <<"127.0.0.1:8883">>
    ),
    Raw3 = emqx_utils_maps:deep_put(
        [<<"ws">>, <<"default">>, <<"bind">>], Raw2, <<"0.0.0.0:8083">>
    ),
    Raw4 = emqx_utils_maps:deep_put(
        [<<"wss">>, <<"default">>, <<"bind">>], Raw3, <<"127.0.0.1:8084">>
    ),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, Raw4)),
    ?assertMatch(
        #{
            <<"tcp">> := #{<<"default">> := #{<<"bind">> := <<"127.0.0.1:1883">>}},
            <<"ssl">> := #{<<"default">> := #{<<"bind">> := <<"127.0.0.1:8883">>}},
            <<"ws">> := #{<<"default">> := #{<<"bind">> := <<"0.0.0.0:8083">>}},
            <<"wss">> := #{<<"default">> := #{<<"bind">> := <<"127.0.0.1:8084">>}}
        },
        emqx:get_raw_config(?LISTENERS)
    ),
    BindTcp = {{127, 0, 0, 1}, 1883},
    BindSsl = {{127, 0, 0, 1}, 8883},
    BindWs = {{0, 0, 0, 0}, 8083},
    BindWss = {{127, 0, 0, 1}, 8084},
    ?assertMatch(
        #{
            tcp := #{default := #{bind := BindTcp}},
            ssl := #{default := #{bind := BindSsl}},
            ws := #{default := #{bind := BindWs}},
            wss := #{default := #{bind := BindWss}}
        },
        emqx:get_config(?LISTENERS)
    ),
    ?assertError(not_found, current_conns(<<"tcp:default">>, {{0, 0, 0, 0}, 1883})),
    ?assertError(not_found, current_conns(<<"ssl:default">>, {{0, 0, 0, 0}, 8883})),

    ?assertEqual(0, current_conns(<<"tcp:default">>, BindTcp)),
    ?assertEqual(0, current_conns(<<"ssl:default">>, BindSsl)),

    ?assertEqual({0, 0, 0, 0}, maps:get(ip, ranch:info('ws:default'))),
    ?assertEqual({127, 0, 0, 1}, maps:get(ip, ranch:info('wss:default'))),
    ?assert(is_running('ws:default')),
    ?assert(is_running('wss:default')),
    ok.

t_update_conf_validate_access_rules(_Conf) ->
    Raw = emqx:get_raw_config(?LISTENERS),
    RawCorrectConf1 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"access_rules">>], Raw, ["allow all"]
    ),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, RawCorrectConf1)),
    RawCorrectConf2 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"access_rules">>], Raw, ["deny all"]
    ),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, RawCorrectConf2)),
    RawCorrectConf3 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"access_rules">>], Raw, ["allow 10.0.1.0/24"]
    ),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, RawCorrectConf3)),
    RawIncorrectConf1 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"access_rules">>], Raw, ["xxx all"]
    ),
    ?assertMatch(
        {error, #{
            reason := <<"invalid_rule(s): xxx all">>,
            value := ["xxx all"],
            path := "listeners.tcp.default.access_rules",
            kind := validation_error,
            matched_type := "emqx:mqtt_tcp_listener"
        }},
        emqx:update_config(?LISTENERS, RawIncorrectConf1)
    ),
    RawIncorrectConf2 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"access_rules">>], Raw, ["allow xxx"]
    ),
    ?assertMatch(
        {error, #{
            reason := <<"invalid_rule(s): allow xxx">>,
            value := ["allow xxx"],
            path := "listeners.tcp.default.access_rules",
            kind := validation_error,
            matched_type := "emqx:mqtt_tcp_listener"
        }},
        emqx:update_config(?LISTENERS, RawIncorrectConf2)
    ),
    ok.

t_update_conf_access_rules_split(_Conf) ->
    Raw = emqx:get_raw_config(?LISTENERS),
    Raw1 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"access_rules">>],
        Raw,
        ["  allow all , deny all  , allow 10.0.1.0/24   "]
    ),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, Raw1)),
    ?assertMatch(
        #{
            tcp := #{
                default := #{
                    access_rules := ["allow all", "deny all", "allow 10.0.1.0/24"]
                }
            }
        },
        emqx:get_config(?LISTENERS)
    ),
    ok.

t_update_tcp_keepalive_conf(_Conf) ->
    Keepalive = <<"240,30,5">>,
    KeepaliveStr = binary_to_list(Keepalive),
    Raw = emqx:get_raw_config(?LISTENERS),
    Raw1 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"bind">>], Raw, <<"127.0.0.1:1883">>
    ),
    Raw2 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"tcp_options">>, <<"keepalive">>], Raw1, Keepalive
    ),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, Raw2)),
    ?assertMatch(
        #{
            <<"tcp">> := #{
                <<"default">> := #{
                    <<"bind">> := <<"127.0.0.1:1883">>,
                    <<"tcp_options">> := #{<<"keepalive">> := Keepalive}
                }
            }
        },
        emqx:get_raw_config(?LISTENERS)
    ),
    ?assertMatch(
        #{tcp := #{default := #{tcp_options := #{keepalive := KeepaliveStr}}}},
        emqx:get_config(?LISTENERS)
    ),
    Keepalive2 = <<" 241, 31, 6 ">>,
    KeepaliveStr2 = binary_to_list(Keepalive2),
    Raw3 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"tcp_options">>, <<"keepalive">>], Raw1, Keepalive2
    ),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, Raw3)),
    ?assertMatch(
        #{
            <<"tcp">> := #{
                <<"default">> := #{
                    <<"bind">> := <<"127.0.0.1:1883">>,
                    <<"tcp_options">> := #{<<"keepalive">> := Keepalive2}
                }
            }
        },
        emqx:get_raw_config(?LISTENERS)
    ),
    ?assertMatch(
        #{tcp := #{default := #{tcp_options := #{keepalive := KeepaliveStr2}}}},
        emqx:get_config(?LISTENERS)
    ),
    ok.

t_tcp_change_parse_unit(_Conf) ->
    Name = ?FUNCTION_NAME,
    Port = emqx_common_test_helpers:select_free_port(tcp),
    test_change_parse_unit(tcp, Name, Port, #{
        hosts => [{{127, 0, 0, 1}, Port}]
    }).

t_ssl_change_parse_unit(_Conf) ->
    Name = ?FUNCTION_NAME,
    Port = emqx_common_test_helpers:select_free_port(tcp),
    test_change_parse_unit(ssl, Name, Port, #{
        hosts => [{{127, 0, 0, 1}, Port}],
        ssl => true,
        ssl_opts => [{verify, verify_none}]
    }).

test_change_parse_unit(Type, Name, Port, ClientOpts) ->
    ConfPath = ?LISTENERS ++ [Type, Name],
    DefaultRawConf = emqx:get_raw_config(?LISTENERS ++ [Type, default]),
    ListenerRawConf0 = maps:merge(
        DefaultRawConf#{
            <<"bind">> => format_bind({{127, 0, 0, 1}, Port}),
            <<"parse_unit">> => <<"chunk">>
        },
        maps:get(Type, #{
            tcp => #{<<"tcp_backend">> => <<"gen_tcp">>},
            ssl => #{}
        })
    ),
    ListenerRawConf1 = ListenerRawConf0#{
        <<"parse_unit">> => <<"frame">>
    },
    %% Update listener and verify `parse_unit` came into effect:
    ?assertMatch({ok, _}, emqx:update_config(ConfPath, {create, ListenerRawConf0})),
    Client1 = emqtt_connect(ClientOpts),
    pong = emqtt:ping(Client1),
    CState1 = emqx_cth_broker:connection_state(Client1),
    emqx_listeners:is_packet_parser_available(mqtt) andalso
        ?assertMatch(
            #{parser := Tuple} when element(1, Tuple) =:= options,
            CState1
        ),
    %% Restore original config and verify original `parse_unit` came into effect as well:
    ?assertMatch({ok, _}, emqx:update_config(ConfPath, {update, ListenerRawConf1})),
    Client2 = emqtt_connect(ClientOpts),
    pong = emqtt:ping(Client2),
    CState2 = emqx_cth_broker:connection_state(Client2),
    emqx_listeners:is_packet_parser_available(mqtt) andalso
        ?assertMatch(
            #{parser := Parser} when Parser =/= map_get(parser, CState1),
            CState2
        ),
    %% Existing connections should be preserved:
    pong = emqtt:ping(Client1),
    ok = emqtt:disconnect(Client1),
    pong = emqtt:ping(Client2),
    ok = emqtt:disconnect(Client2),
    %% Remove the listener:
    {ok, _} = emqx:update_config(ConfPath, ?TOMBSTONE_CONFIG_CHANGE_REQ).

t_update_empty_ssl_options_conf(_Conf) ->
    Raw = emqx:get_raw_config(?LISTENERS),
    Raw1 = emqx_utils_maps:deep_put(
        [<<"tcp">>, <<"default">>, <<"bind">>], Raw, <<"127.0.0.1:1883">>
    ),
    Raw2 = emqx_utils_maps:deep_put(
        [<<"ssl">>, <<"default">>, <<"bind">>], Raw1, <<"127.0.0.1:8883">>
    ),
    Raw3 = emqx_utils_maps:deep_put(
        [<<"ws">>, <<"default">>, <<"bind">>], Raw2, <<"0.0.0.0:8083">>
    ),
    Raw4 = emqx_utils_maps:deep_put(
        [<<"wss">>, <<"default">>, <<"bind">>], Raw3, <<"127.0.0.1:8084">>
    ),
    Raw5 = emqx_utils_maps:deep_put(
        [<<"ssl">>, <<"default">>, <<"ssl_options">>, <<"cacertfile">>], Raw4, <<"">>
    ),
    Raw6 = emqx_utils_maps:deep_put(
        [<<"wss">>, <<"default">>, <<"ssl_options">>, <<"cacertfile">>], Raw5, <<"">>
    ),
    Raw7 = emqx_utils_maps:deep_put(
        [<<"wss">>, <<"default">>, <<"ssl_options">>, <<"ciphers">>], Raw6, <<"">>
    ),
    Ciphers = <<"TLS_AES_256_GCM_SHA384, TLS_AES_128_GCM_SHA256 ">>,
    Raw8 = emqx_utils_maps:deep_put(
        [<<"ssl">>, <<"default">>, <<"ssl_options">>, <<"ciphers">>],
        Raw7,
        Ciphers
    ),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, Raw8)),
    ?assertMatch(
        #{
            <<"tcp">> := #{<<"default">> := #{<<"bind">> := <<"127.0.0.1:1883">>}},
            <<"ssl">> := #{
                <<"default">> := #{
                    <<"bind">> := <<"127.0.0.1:8883">>,
                    <<"ssl_options">> := #{
                        <<"cacertfile">> := <<"">>,
                        <<"ciphers">> := Ciphers
                    }
                }
            },
            <<"ws">> := #{<<"default">> := #{<<"bind">> := <<"0.0.0.0:8083">>}},
            <<"wss">> := #{
                <<"default">> := #{
                    <<"bind">> := <<"127.0.0.1:8084">>,
                    <<"ssl_options">> := #{
                        <<"cacertfile">> := <<"">>,
                        <<"ciphers">> := <<"">>
                    }
                }
            }
        },
        emqx:get_raw_config(?LISTENERS)
    ),
    BindTcp = {{127, 0, 0, 1}, 1883},
    BindSsl = {{127, 0, 0, 1}, 8883},
    BindWs = {{0, 0, 0, 0}, 8083},
    BindWss = {{127, 0, 0, 1}, 8084},
    ?assertMatch(
        #{
            tcp := #{default := #{bind := BindTcp}},
            ssl := #{
                default := #{
                    bind := BindSsl,
                    ssl_options := #{
                        cacertfile := <<"">>,
                        ciphers := ["TLS_AES_256_GCM_SHA384", "TLS_AES_128_GCM_SHA256"]
                    }
                }
            },
            ws := #{default := #{bind := BindWs}},
            wss := #{
                default := #{
                    bind := BindWss,
                    ssl_options := #{
                        cacertfile := <<"">>,
                        ciphers := []
                    }
                }
            }
        },
        emqx:get_config(?LISTENERS)
    ),
    ?assertError(not_found, current_conns(<<"tcp:default">>, {{0, 0, 0, 0}, 1883})),
    ?assertError(not_found, current_conns(<<"ssl:default">>, {{0, 0, 0, 0}, 8883})),

    ?assertEqual(0, current_conns(<<"tcp:default">>, BindTcp)),
    ?assertEqual(0, current_conns(<<"ssl:default">>, BindSsl)),

    ?assertEqual({0, 0, 0, 0}, maps:get(ip, ranch:info('ws:default'))),
    ?assertEqual({127, 0, 0, 1}, maps:get(ip, ranch:info('wss:default'))),
    ?assert(is_running('ws:default')),
    ?assert(is_running('wss:default')),

    Raw9 = emqx_utils_maps:deep_put(
        [<<"ssl">>, <<"default">>, <<"ssl_options">>, <<"ciphers">>], Raw7, [
            "TLS_AES_256_GCM_SHA384",
            "TLS_AES_128_GCM_SHA256",
            "TLS_CHACHA20_POLY1305_SHA256"
        ]
    ),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, Raw9)),

    BadRaw = emqx_utils_maps:deep_put(
        [<<"ssl">>, <<"default">>, <<"ssl_options">>, <<"keyfile">>], Raw4, <<"">>
    ),
    ?assertMatch(
        {error,
            {bad_ssl_config, #{
                reason := pem_file_path_or_string_is_required,
                which_option := <<"keyfile">>
            }}},
        emqx:update_config(?LISTENERS, BadRaw)
    ),
    ok.

t_add_delete_conf(Config) ->
    DefaultSslBind = expected_default_bind(?config(security_profile, Config), 8883),
    Raw = emqx:get_raw_config(?LISTENERS),
    %% add
    #{<<"tcp">> := #{<<"default">> := Tcp}} = Raw,
    NewBind = <<"127.0.0.1:1987">>,
    Raw1 = emqx_utils_maps:deep_put([<<"tcp">>, <<"new">>], Raw, Tcp#{<<"bind">> => NewBind}),
    Raw2 = emqx_utils_maps:deep_put([<<"ssl">>, <<"default">>], Raw1, ?TOMBSTONE_VALUE),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, Raw2)),
    ?assertEqual(0, current_conns(<<"tcp:new">>, {{127, 0, 0, 1}, 1987})),
    ?assertError(not_found, current_conns(<<"ssl:default">>, {{0, 0, 0, 0}, 8883})),
    %% deleted
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, Raw)),
    ?assertError(not_found, current_conns(<<"tcp:new">>, {{127, 0, 0, 1}, 1987})),
    ?assertEqual(0, current_conns(<<"ssl:default">>, DefaultSslBind)),
    ok.

t_delete_default_conf(Config) ->
    Profile = ?config(security_profile, Config),
    DefaultTcpBind = expected_default_bind(Profile, 1883),
    DefaultSslBind = expected_default_bind(Profile, 8883),
    Raw = emqx:get_raw_config(?LISTENERS),
    %% delete default listeners
    Raw1 = emqx_utils_maps:deep_put([<<"tcp">>, <<"default">>], Raw, ?TOMBSTONE_VALUE),
    Raw2 = emqx_utils_maps:deep_put([<<"ssl">>, <<"default">>], Raw1, ?TOMBSTONE_VALUE),
    Raw3 = emqx_utils_maps:deep_put([<<"ws">>, <<"default">>], Raw2, ?TOMBSTONE_VALUE),
    Raw4 = emqx_utils_maps:deep_put([<<"wss">>, <<"default">>], Raw3, ?TOMBSTONE_VALUE),
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, Raw4)),
    ?assertError(not_found, current_conns(<<"tcp:default">>, DefaultTcpBind)),
    ?assertError(not_found, current_conns(<<"ssl:default">>, DefaultSslBind)),
    ?assertMatch({error, not_found}, is_running('ws:default')),
    ?assertMatch({error, not_found}, is_running('wss:default')),

    %% reset
    ?assertMatch({ok, _}, emqx:update_config(?LISTENERS, Raw)),
    ?assertEqual(0, current_conns(<<"tcp:default">>, DefaultTcpBind)),
    ?assertEqual(0, current_conns(<<"ssl:default">>, DefaultSslBind)),
    ?assert(is_running('ws:default')),
    ?assert(is_running('wss:default')),
    ok.

%%

emqtt_connect(Opts) ->
    case emqtt:start_link(Opts) of
        {ok, Client} ->
            true = erlang:unlink(Client),
            case emqtt:connect(Client) of
                {ok, _} -> Client;
                {error, Reason} -> error(Reason, [Opts])
            end;
        {error, Reason} ->
            error(Reason, [Opts])
    end.

format_bind(Bind) ->
    iolist_to_binary(emqx_listeners:format_bind(Bind)).

%% Schema defaults are static bare ports; the profile is applied at
%% listener start, and the keyed accessors translate binds the same way.
expected_default_bind(_Profile, Port) -> Port.

format_raw_bind(Port) when is_integer(Port) -> Port;
format_raw_bind({{127, 0, 0, 1}, Port}) -> <<"127.0.0.1:", (integer_to_binary(Port))/binary>>.
