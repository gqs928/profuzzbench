%%--------------------------------------------------------------------
%% Copyright (c) 2021-2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------

-module(emqx_tls_lib_tests).

-include_lib("eunit/include/eunit.hrl").
-include_lib("emqx/include/emqx_managed_certs.hrl").

-export([do_setup_ssl_files/1]).

%% one of the cipher suite from tlsv1.2 and tlsv1.3 each
-define(TLS_12_CIPHER, "ECDHE-ECDSA-AES256-GCM-SHA384").
-define(TLS_12_CIPHER_RFC, "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384").
-define(TLS_13_CIPHER, "TLS_AES_256_GCM_SHA384").

-define(ns, <<"some_ns">>).
-define(bundle, <<"some_bundle">>).
-define(bundle2, <<"some_bundle2">>).

ensure_tls13_ciphers_added_test() ->
    Ciphers = emqx_tls_lib:integral_ciphers(['tlsv1.3'], [?TLS_12_CIPHER]),
    ?assert(lists:member(?TLS_12_CIPHER, Ciphers)),
    ?assert(lists:member(?TLS_13_CIPHER, Ciphers)).

legacy_cipher_suites_test() ->
    Ciphers = emqx_tls_lib:integral_ciphers(['tlsv1.2'], [?TLS_12_CIPHER]),
    ?assertEqual([?TLS_12_CIPHER], Ciphers).

use_default_ciphers_test() ->
    Ciphers = emqx_tls_lib:integral_ciphers(['tlsv1.3', 'tlsv1.2'], ""),
    ?assert(lists:member(?TLS_12_CIPHER, Ciphers)),
    ?assert(lists:member(?TLS_13_CIPHER, Ciphers)).

ciphers_format_test_() ->
    String = ?TLS_13_CIPHER ++ "," ++ ?TLS_12_CIPHER,
    Binary = bin(String),
    List = [?TLS_13_CIPHER, ?TLS_12_CIPHER],
    [
        {"string", fun() -> test_cipher_format(String) end},
        {"binary", fun() -> test_cipher_format(Binary) end},
        {"string-list", fun() -> test_cipher_format(List) end}
    ].

test_cipher_format(Input) ->
    Ciphers = emqx_tls_lib:integral_ciphers(['tlsv1.3', 'tlsv1.2'], Input),
    ?assertEqual([?TLS_13_CIPHER, ?TLS_12_CIPHER], Ciphers).

tls_versions_test() ->
    ?assert(lists:member('tlsv1.3', emqx_tls_lib:available_versions(tls))).

tls_version_unknown_test_() ->
    lists:flatmap(
        fun(Type) ->
            [
                ?_assertEqual(
                    emqx_tls_lib:available_versions(Type),
                    emqx_tls_lib:integral_versions(Type, [])
                ),
                ?_assertEqual(
                    emqx_tls_lib:available_versions(Type),
                    emqx_tls_lib:integral_versions(Type, <<>>)
                ),
                ?_assertEqual(
                    emqx_tls_lib:available_versions(Type),
                    %% unknown version dropped
                    emqx_tls_lib:integral_versions(Type, "foo")
                ),
                fun() ->
                    ?assertError(
                        #{reason := no_available_tls_version},
                        emqx_tls_lib:integral_versions(Type, [foo])
                    )
                end
            ]
        end,
        [tls, dtls]
    ).

cipher_suites_no_duplication_test() ->
    AllCiphers = emqx_tls_lib:default_ciphers(),
    ?assertEqual(length(AllCiphers), length(lists:usort(AllCiphers))).

%% The cached set used by the schema validator must hold both the OpenSSL and
%% the RFC/IANA name for a TLS 1.2 cipher (TLS 1.3 names are identical).
all_ciphers_set_contains_both_formats_test() ->
    Set = emqx_tls_lib:all_ciphers_set_cached(),
    ?assert(sets:is_element(?TLS_12_CIPHER, Set)),
    ?assert(sets:is_element(?TLS_12_CIPHER_RFC, Set)),
    ?assert(sets:is_element(?TLS_13_CIPHER, Set)).

%% cipher_to_rfc/1 must be idempotent: feeding it an RFC name returns the same
%% RFC name (ssl:str_to_suite/1 accepts both conventions).
cipher_to_rfc_idempotent_test() ->
    ?assertEqual(?TLS_12_CIPHER_RFC, emqx_tls_lib:cipher_to_rfc(?TLS_12_CIPHER)),
    ?assertEqual(?TLS_12_CIPHER_RFC, emqx_tls_lib:cipher_to_rfc(?TLS_12_CIPHER_RFC)).

%% The greptimedb NIF path (convert_ciphers_to_rfc/2) must accept ciphers given
%% in either convention and resolve both to the supported RFC name.
convert_ciphers_to_rfc_accepts_both_formats_test() ->
    Supported = [?TLS_12_CIPHER_RFC],
    ?assertEqual(
        {[?TLS_12_CIPHER_RFC], []},
        emqx_tls_lib:convert_ciphers_to_rfc([?TLS_12_CIPHER], Supported)
    ),
    ?assertEqual(
        {[?TLS_12_CIPHER_RFC], []},
        emqx_tls_lib:convert_ciphers_to_rfc([?TLS_12_CIPHER_RFC], Supported)
    ),
    ?assertMatch(
        {[], [_]},
        emqx_tls_lib:convert_ciphers_to_rfc(["NOT_A_CIPHER"], Supported)
    ).

ssl_files_failure_test_() ->
    lists:flatten([
        {"undefined_is_undefined", fun() ->
            ?assertEqual(
                {ok, undefined},
                emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("dir", undefined)
            )
        end},
        {"no_op_if_disabled", fun() ->
            Disabled = #{<<"enable">> => false, foo => bar},
            ?assertEqual(
                {ok, Disabled},
                emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("dir", Disabled)
            )
        end},
        {"mandatory_keys", fun() ->
            ?assertMatch(
                {error, #{missing_options := [<<"keyfile">>]}},
                emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("dir", #{}, #{
                    required_keys => [[<<"keyfile">>]]
                })
            ),
            ?assertMatch(
                {error, #{missing_options := [<<"keyfile">>]}},
                emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("dir", #{}, #{
                    required_keys => [[keyfile]]
                })
            )
        end},
        {setup, setup_ssl_files(), fun cleanup_ssl_files/1, fun(Context) ->
            #{cert := Cert, cacert := Cacert} = Context,
            {"invalid_file_path", fun() ->
                ?assertMatch(
                    {error, #{
                        pem_check := not_pem,
                        file_path := not_file_path,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        keyfile => <<"abc", $\n, "123">>,
                        certfile => Cert,
                        cacertfile => Cacert
                    })
                )
            end}
        end},
        {setup, setup_ssl_files(), fun cleanup_ssl_files/1, fun(Context) ->
            #{cert := Cert, cacert := Cacert} = Context,
            {"enoent_key_file", fun() ->
                NonExistingFile = filename:join(
                    "/tmp", integer_to_list(erlang:system_time(microsecond))
                ),
                ?assertMatch(
                    {error, #{pem_check := enoent, file_path := _}},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        <<"keyfile">> => NonExistingFile,
                        <<"certfile">> => Cert,
                        <<"cacertfile">> => Cacert
                    })
                )
            end}
        end},
        {setup, setup_ssl_files(), fun cleanup_ssl_files/1, fun(Context) ->
            #{mk_kit := MkKit} = Context,
            #{key := Key, cert := Cert} =
                MkKit(#{name => "emptycacert", password => undefined}),
            {"empty_cacertfile", fun() ->
                ?assertMatch(
                    {ok, _},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        <<"keyfile">> => Key,
                        <<"certfile">> => Cert,
                        <<"cacertfile">> => <<"">>
                    })
                )
            end}
        end},
        {setup, setup_ssl_files(), fun cleanup_ssl_files/1, fun(Context) ->
            #{key := Key, cert := Cert, cacert := Cacert, password := Password} = Context,
            {"bad_pem_string", fun() ->
                %% empty string
                ?assertMatch(
                    {error, #{
                        reason := pem_file_path_or_string_is_required,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        <<"keyfile">> => <<>>,
                        <<"certfile">> => Cert,
                        <<"cacertfile">> => Cacert
                    })
                ),
                %% not valid unicode
                ?assertMatch(
                    {error, #{
                        reason := invalid_file_path_or_pem_string, which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        <<"keyfile">> => <<255, 255>>,
                        <<"certfile">> => Cert,
                        <<"cacertfile">> => Cacert
                    })
                ),
                ?assertMatch(
                    {error, #{
                        reason := invalid_file_path_or_pem_string,
                        which_option := <<"ocsp.issuer_pem">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        <<"password">> => Password,
                        <<"keyfile">> => Key,
                        <<"certfile">> => Cert,
                        <<"cacertfile">> => Cacert,
                        <<"ocsp">> => #{<<"issuer_pem">> => <<255, 255>>}
                    })
                ),
                %% not printable
                ?assertMatch(
                    {error, #{reason := invalid_file_path_or_pem_string}},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        <<"password">> => Password,
                        <<"keyfile">> => <<33, 22>>,
                        <<"certfile">> => Cert,
                        <<"cacertfile">> => Cacert
                    })
                ),
                TmpFile = filename:join("/tmp", integer_to_list(erlang:system_time(microsecond))),
                try
                    ok = file:write_file(TmpFile, <<"not a valid pem">>),
                    ?assertMatch(
                        {error, #{pem_check := not_pem}},
                        emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                            "/tmp",
                            #{
                                <<"password">> => Password,
                                <<"cacertfile">> => bin(TmpFile),
                                <<"keyfile">> => bin(TmpFile),
                                <<"certfile">> => bin(TmpFile),
                                <<"ocsp">> => #{<<"issuer_pem">> => bin(TmpFile)}
                            }
                        )
                    )
                after
                    file:delete(TmpFile)
                end
            end}
        end},
        [
            {setup, setup_ssl_files(#{key_type => KeyType}), fun cleanup_ssl_files/1,
                fun do_test_file_validations/1}
         || KeyType <- [ec, rsa]
        ]
    ]).

do_test_file_validations(Context) ->
    #{mk_kit := MkKit, password := Password} = Context,
    [
        {"corrupt certfile",
            ?_test(begin
                #{cert := Cert, certfile_path := CertfilePath} = MkKit(#{name => "corruptcert"}),
                MangledCert = mangle(Cert),
                %% Using PEM contents directly
                ?assertMatch(
                    {error, #{
                        reason := failed_to_parse_certfile,
                        which_option := <<"certfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{<<"certfile">> => MangledCert}
                    )
                ),
                %% Using filepath
                ok = file:write_file(CertfilePath, MangledCert),
                ?assertMatch(
                    {error, #{
                        reason := failed_to_parse_certfile,
                        which_option := <<"certfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{<<"certfile">> => CertfilePath}
                    )
                )
            end)},
        {"corrupt certfile (more than one certificate inside file)",
            ?_test(begin
                #{cert := Cert, certfile_path := CertfilePath} = MkKit(#{name => "corruptcert"}),
                MangledCert0 = mangle(Cert),
                MangledCert = iolist_to_binary([MangledCert0, "\n", MangledCert0]),
                %% Using PEM contents directly
                ?assertMatch(
                    {error, #{
                        reason := failed_to_parse_certfile,
                        which_option := <<"certfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{<<"certfile">> => MangledCert}
                    )
                ),
                %% Using filepath
                ok = file:write_file(CertfilePath, MangledCert),
                ?assertMatch(
                    {error, #{
                        reason := failed_to_parse_certfile,
                        which_option := <<"certfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{<<"certfile">> => CertfilePath}
                    )
                )
            end)},
        {"valid certfile (more than one certificate inside file)",
            ?_test(begin
                #{cert := Cert0, certfile_path := CertfilePath} = MkKit(#{name => "multicert"}),
                Cert = iolist_to_binary([Cert0, "\n", Cert0]),
                %% Using PEM contents directly
                ?assertMatch(
                    {ok, #{<<"certfile">> := _}},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{<<"certfile">> => Cert}
                    )
                ),
                %% Using filepath
                ok = file:write_file(CertfilePath, Cert),
                ?assertMatch(
                    {ok, #{<<"certfile">> := _}},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{<<"certfile">> => CertfilePath}
                    )
                )
            end)},
        {"corrupt keyfile (with correct password)",
            ?_test(begin
                #{key := Key, keyfile_path := KeyfilePath} = MkKit(#{name => "corruptkey"}),
                MangledKey = mangle(Key),
                %% Using PEM contents directly
                ?assertMatch(
                    {error, #{
                        reason := bad_password_or_invalid_keyfile,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{
                            <<"keyfile">> => MangledKey,
                            <<"password">> => Password
                        }
                    )
                ),
                %% Using filepath
                ok = file:write_file(KeyfilePath, MangledKey),
                ?assertMatch(
                    {error, #{
                        reason := bad_password_or_invalid_keyfile,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{
                            <<"keyfile">> => KeyfilePath,
                            <<"password">> => Password
                        }
                    )
                )
            end)},
        {"corrupt keyfile (with incorrect password)",
            ?_test(begin
                #{key := Key, keyfile_path := KeyfilePath} = MkKit(#{name => "corruptkey"}),
                WrongPassword = <<"wrongpass">>,
                MangledKey = mangle(Key),
                %% Using PEM contents directly
                ?assertMatch(
                    {error, #{
                        reason := bad_password_or_invalid_keyfile,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{
                            <<"keyfile">> => MangledKey,
                            <<"password">> => WrongPassword
                        }
                    )
                ),
                %% Using filepath
                ok = file:write_file(KeyfilePath, MangledKey),
                ?assertMatch(
                    {error, #{
                        reason := bad_password_or_invalid_keyfile,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{
                            <<"keyfile">> => KeyfilePath,
                            <<"password">> => WrongPassword
                        }
                    )
                )
            end)},
        {"valid encrypted keyfile with incorrect password",
            ?_test(begin
                #{key := Key, keyfile_path := KeyfilePath} = MkKit(#{name => "corruptkey"}),
                WrongPassword = <<"wrongpass">>,
                %% Using PEM contents directly
                ?assertMatch(
                    {error, #{
                        reason := bad_password_or_invalid_keyfile,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{
                            <<"keyfile">> => Key,
                            <<"password">> => WrongPassword
                        }
                    )
                ),
                %% Using filepath
                ?assertMatch(
                    {error, #{
                        reason := bad_password_or_invalid_keyfile,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{
                            <<"keyfile">> => KeyfilePath,
                            <<"password">> => WrongPassword
                        }
                    )
                )
            end)},
        {"valid encrypted keyfile missing password",
            ?_test(begin
                #{key := Key, keyfile_path := KeyfilePath} = MkKit(#{name => "corruptkey"}),
                %% Using PEM contents directly
                ?assertMatch(
                    {error, #{
                        reason := encrypted_keyfile_missing_password,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{<<"keyfile">> => Key}
                    )
                ),
                %% Using filepath
                ?assertMatch(
                    {error, #{
                        reason := encrypted_keyfile_missing_password,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{<<"keyfile">> => KeyfilePath}
                    )
                )
            end)},
        {"corrupt unencrypted keyfile",
            ?_test(begin
                #{key := Key, keyfile_path := KeyfilePath} =
                    MkKit(#{name => "corruptplainkey", password => undefined}),
                MangledKey = mangle(Key, 0, 10),
                %% Using PEM contents directly
                ?assertMatch(
                    {error, #{
                        reason := failed_to_decode,
                        type := 'PrivateKeyInfo',
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{<<"keyfile">> => MangledKey}
                    )
                ),
                %% Using filepath
                ok = file:write_file(KeyfilePath, MangledKey),
                ?assertMatch(
                    {error, #{
                        reason := failed_to_decode,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
                        "/tmp",
                        #{<<"keyfile">> => KeyfilePath}
                    )
                )
            end)}
    ].

ssl_file_replace_test() ->
    {setup, setup_ssl_files(), fun cleanup_ssl_files/1, fun do_test_ssl_file_replace/1}.
do_test_ssl_file_replace(Context) ->
    #{
        key := Key1,
        cert := Cert1,
        cacert := Cacert1,
        mk_kit := MkKit
    } = Context,
    #{
        key := Key2,
        cert := Cert2,
        cacert := Cacert2
    } = MkKit(#{name => "client2"}),
    SSL0 = #{
        <<"keyfile">> => Key1,
        <<"certfile">> => Cert1,
        <<"cacertfile">> => Cacert1,
        <<"ocsp">> => #{<<"issuer_pem">> => Key1}
    },
    SSL1 = #{
        <<"keyfile">> => Key2,
        <<"certfile">> => Cert2,
        <<"cacertfile">> => Cacert2,
        <<"ocsp">> => #{<<"issuer_pem">> => Key2}
    },
    Dir = filename:join(["/tmp", "ssl-test-dir2"]),
    {ok, SSL2} = emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(Dir, SSL0),
    {ok, SSL3} = emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(Dir, SSL1),
    File1 = maps:get(<<"keyfile">>, SSL2),
    File2 = maps:get(<<"keyfile">>, SSL3),
    IssuerPem1 = emqx_utils_maps:deep_get([<<"ocsp">>, <<"issuer_pem">>], SSL2),
    IssuerPem2 = emqx_utils_maps:deep_get([<<"ocsp">>, <<"issuer_pem">>], SSL3),
    ?assert(filelib:is_regular(File1)),
    ?assert(filelib:is_regular(File2)),
    ?assert(filelib:is_regular(IssuerPem1)),
    ?assert(filelib:is_regular(IssuerPem2)),
    ok.

ssl_file_deterministic_names_test_() ->
    {setup, setup_ssl_files(#{key_type => ec, password => undefined}), fun cleanup_ssl_files/1,
        fun do_test_ssl_file_deterministic_names/1}.
do_test_ssl_file_deterministic_names(Context) ->
    ?_test(begin
        #{
            key := Key,
            cert := Cert
        } = Context,
        SSL0 = #{
            <<"keyfile">> => Key,
            <<"certfile">> => Cert
        },
        Dir0 = filename:join(["/tmp", ?FUNCTION_NAME, "ssl0"]),
        Dir1 = filename:join(["/tmp", ?FUNCTION_NAME, "ssl1"]),
        {ok, SSLFiles0} = emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(Dir0, SSL0),
        ?assertEqual(
            {ok, SSLFiles0},
            emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(Dir0, SSL0)
        ),
        ?assertNotEqual(
            {ok, SSLFiles0},
            emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(Dir1, SSL0)
        ),
        _ = file:del_dir_r(filename:join(["/tmp", ?FUNCTION_NAME]))
    end).

ssl_file_name_hash_test() ->
    ?assertMatch(
        {ok, #{
            <<"cacertfile">> := <<"data/certs/authz/http/cacert-C62234D748AB82B0">>,
            <<"certfile">> := <<"data/certs/authz/http/cert-0D6E53DBDEF594A4">>,
            <<"enable">> := true,
            <<"keyfile">> := <<"data/certs/authz/http/key-D5BB7F027841FA62">>,
            <<"verify">> := <<"verify_peer">>
        }},
        emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir(
            <<"authz/http">>,
            #{
                <<"cacertfile">> => test_name_hash_cacert(),
                <<"certfile">> => test_name_hash_cert(),
                <<"keyfile">> => test_name_hash_key(),
                <<"enable">> => true,
                <<"verify">> => <<"verify_peer">>
            }
        )
    ),
    ok.

to_client_opts_test() ->
    VersionsAll = [tlsv1, 'tlsv1.1', 'tlsv1.2', 'tlsv1.3'],
    Versions13Only = ['tlsv1.3'],
    Options = #{
        enable => true,
        verify => verify_none,
        server_name_indication => "SNI",
        ciphers => "Ciphers",
        depth => "depth",
        password => "password",
        versions => VersionsAll,
        secure_renegotiate => "secure_renegotiate",
        reuse_sessions => "reuse_sessions"
    },
    Expected0 = lists:usort(maps:keys(Options) -- [enable]),
    Expected1 = lists:sort(Expected0 ++ [customize_hostname_check]),
    ?assertEqual(
        Expected0, lists:usort(proplists:get_keys(emqx_tls_lib:to_client_opts(tls, Options)))
    ),
    ?assertEqual(
        Expected1,
        lists:usort(
            proplists:get_keys(emqx_tls_lib:to_client_opts(tls, Options#{verify => verify_peer}))
        )
    ),
    Expected2 =
        lists:usort(
            maps:keys(Options) --
                [enable, reuse_sessions, secure_renegotiate]
        ),
    ?assertEqual(
        Expected2,
        lists:usort(
            proplists:get_keys(
                emqx_tls_lib:to_client_opts(tls, Options#{versions := Versions13Only})
            )
        )
    ),
    Expected3 = lists:usort(maps:keys(Options) -- [enable, depth, password]),
    ?assertEqual(
        Expected3,
        lists:usort(
            proplists:get_keys(
                emqx_tls_lib:to_client_opts(tls, Options#{depth := undefined, password := ""})
            )
        )
    ),
    ok.

pem_validation_encryption_test_() ->
    {setup,
        fun() ->
            Context = do_setup_ssl_files(#{password => "foobar", key_type => ec}),
            setup_pem_validation_files(Context)
        end,
        fun cleanup_ssl_files/1, fun pem_validation_cases/1}.

pem_validation_no_encyprtion_test_() ->
    {setup,
        fun() ->
            Context = do_setup_ssl_files(#{password => undefined, key_type => rsa}),
            setup_pem_validation_files(Context)
        end,
        fun cleanup_ssl_files/1, fun pem_validation_cases/1}.

setup_pem_validation_files(Context) ->
    #{temp_dir := TmpDir} = Context,
    InvalidKeyPath = filename:join(TmpDir, "invalid_key.pem"),
    InvalidCertPath = filename:join(TmpDir, "invalid_cert.pem"),
    InvalidCacertPath = filename:join(TmpDir, "invalid_cacert.pem"),
    BadPemPath = filename:join(TmpDir, "bad_pem.pem"),
    NonExistentPath = filename:join(TmpDir, "nonexistent.pem"),
    ok = file:write_file(InvalidKeyPath, <<"not a valid private key">>),
    ok = file:write_file(InvalidCertPath, <<"not a valid certificate">>),
    ok = file:write_file(InvalidCacertPath, <<"not a valid certificate">>),
    ok = file:write_file(
        BadPemPath, "-----BEGIN CERTIFICATE-----\ninvalid\n-----END CERTIFICATE-----\n"
    ),
    Context#{
        invalid_key_path => InvalidKeyPath,
        invalid_cert_path => InvalidCertPath,
        invalid_cacert_path => InvalidCacertPath,
        bad_pem_path => BadPemPath,
        non_existent_path => NonExistentPath
    }.

pem_validation_cases(Context) ->
    #{
        keyfile_path := ValidKeyPath,
        certfile_path := ValidCertPath,
        cacertfile_path := ValidCacertPath,
        temp_dir := TmpDir,
        invalid_key_path := InvalidKeyPath,
        invalid_cert_path := InvalidCertPath,
        invalid_cacert_path := InvalidCacertPath,
        non_existent_path := NonExistentPath,
        bad_pem_path := BadPemPath,
        password := Password
    } = Context,
    T =
        case Password of
            undefined -> fun(S) -> "[not encrypted]: " ++ S end;
            _ -> fun(S) -> "[encrypted]: " ++ S end
        end,

    [
        {
            T("with valid keyfile, certfile, and cacertfile"),
            ?_test(begin
                Options = #{
                    keyfile => ValidKeyPath,
                    certfile => ValidCertPath,
                    cacertfile => ValidCacertPath,
                    password => Password
                },
                ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
                ?assertNotEqual(undefined, proplists:get_value(keyfile, ServerOpts)),
                ?assertNotEqual(undefined, proplists:get_value(certfile, ServerOpts)),
                ?assertNotEqual(undefined, proplists:get_value(cacertfile, ServerOpts))
            end)
        },
        {
            T("with invalid keyfile (should omit keyfile)"),
            ?_test(begin
                Options = #{
                    enable => true,
                    keyfile => InvalidKeyPath,
                    certfile => ValidCertPath,
                    cacertfile => ValidCacertPath,
                    password => Password
                },
                ClientOpts = emqx_tls_lib:to_client_opts(tls, Options),
                ?assertEqual(undefined, proplists:get_value(keyfile, ClientOpts)),
                ?assertNotEqual(undefined, proplists:get_value(certfile, ClientOpts)),
                ?assertNotEqual(undefined, proplists:get_value(cacertfile, ClientOpts))
            end)
        },
        {
            T("with invalid certfile (should omit certfile)"),
            ?_test(begin
                Options = #{
                    enable => true,
                    keyfile => ValidKeyPath,
                    certfile => InvalidCertPath,
                    cacertfile => ValidCacertPath,
                    password => Password
                },
                ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
                ?assertNotEqual(undefined, proplists:get_value(keyfile, ServerOpts)),
                ?assertEqual(undefined, proplists:get_value(certfile, ServerOpts)),
                ?assertNotEqual(undefined, proplists:get_value(cacertfile, ServerOpts))
            end)
        },
        {
            T("with non-existent keyfile (should omit keyfile)"),
            ?_test(begin
                Options = #{
                    enable => true,
                    keyfile => NonExistentPath,
                    certfile => ValidCertPath,
                    cacertfile => ValidCacertPath,
                    password => Password
                },
                ClientOpts = emqx_tls_lib:to_client_opts(tls, Options),
                ?assertEqual(undefined, proplists:get_value(keyfile, ClientOpts)),
                ?assertNotEqual(undefined, proplists:get_value(certfile, ClientOpts)),
                ?assertNotEqual(undefined, proplists:get_value(cacertfile, ClientOpts))
            end)
        },
        {
            T("with certificate file as keyfile (wrong type, should omit keyfile)"),
            ?_test(begin
                Options = #{
                    enable => true,
                    keyfile => ValidCertPath,
                    certfile => ValidCertPath,
                    cacertfile => ValidCacertPath,
                    password => Password
                },
                ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
                ?assertEqual(undefined, proplists:get_value(keyfile, ServerOpts)),
                ?assertNotEqual(undefined, proplists:get_value(certfile, ServerOpts)),
                ?assertNotEqual(undefined, proplists:get_value(cacertfile, ServerOpts))
            end)
        },
        {
            T("with private key file as certfile (wrong type, should omit certfile)"),
            ?_test(begin
                Options = #{
                    enable => true,
                    keyfile => ValidKeyPath,
                    certfile => ValidKeyPath,
                    cacertfile => ValidCacertPath,
                    password => Password
                },
                ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
                ?assertNotEqual(undefined, proplists:get_value(keyfile, ServerOpts)),
                ?assertEqual(undefined, proplists:get_value(certfile, ServerOpts)),
                ?assertNotEqual(undefined, proplists:get_value(cacertfile, ServerOpts))
            end)
        },
        {
            T("with undefined certfile"),
            ?_test(begin
                Options = #{
                    enable => true,
                    keyfile => ValidKeyPath,
                    cacertfile => ValidCacertPath,
                    password => Password
                },
                ClientOpts = emqx_tls_lib:to_client_opts(tls, Options),
                ?assertNotEqual(undefined, proplists:get_value(keyfile, ClientOpts)),
                ?assertEqual(undefined, proplists:get_value(certfile, ClientOpts)),
                ?assertNotEqual(undefined, proplists:get_value(cacertfile, ClientOpts))
            end)
        },
        {
            T("with all invalid files (should omit all)"),
            ?_test(begin
                Options = #{
                    enable => true,
                    keyfile => InvalidKeyPath,
                    certfile => InvalidCertPath,
                    cacertfile => InvalidCacertPath,
                    password => Password
                },
                ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
                ?assertEqual(undefined, proplists:get_value(keyfile, ServerOpts)),
                ?assertEqual(undefined, proplists:get_value(certfile, ServerOpts)),
                ?assertEqual(undefined, proplists:get_value(cacertfile, ServerOpts))
            end)
        },
        {
            T("with directory path as cacertfile (should be omitted)"),
            ?_test(begin
                %% Use a separate empty directory to avoid conflicts
                EmptyDir = filename:join(
                    TmpDir, integer_to_list(erlang:system_time(microsecond)) ++ "_dir"
                ),
                ok = filelib:ensure_dir(filename:join(EmptyDir, "dummy")),
                try
                    Options = #{
                        enable => true,
                        keyfile => ValidKeyPath,
                        certfile => ValidCertPath,
                        cacertfile => EmptyDir,
                        password => Password
                    },
                    ClientOpts = emqx_tls_lib:to_client_opts(tls, Options),
                    %% Directory path is not a regular file, so cacertfile should be omitted
                    ?assertNotEqual(undefined, proplists:get_value(keyfile, ClientOpts)),
                    ?assertNotEqual(undefined, proplists:get_value(certfile, ClientOpts)),
                    ?assertEqual(undefined, proplists:get_value(cacertfile, ClientOpts))
                after
                    catch file:del_dir(EmptyDir)
                end
            end)
        },
        {
            T("bad pem file (should be omitted)"),
            ?_test(begin
                Options = #{
                    enable => true,
                    keyfile => ValidKeyPath,
                    certfile => ValidCertPath,
                    cacertfile => BadPemPath,
                    password => Password
                },
                ClientOpts = emqx_tls_lib:to_client_opts(tls, Options),
                %% Directory path is not a regular file, so cacertfile should be omitted
                ?assertNotEqual(undefined, proplists:get_value(keyfile, ClientOpts)),
                ?assertNotEqual(undefined, proplists:get_value(certfile, ClientOpts)),
                ?assertEqual(undefined, proplists:get_value(cacertfile, ClientOpts))
            end)
        }
        | case os:type() of
            {unix, _} ->
                pem_validation_cases_unix(T, Context);
            _ ->
                []
        end
    ].

pem_validation_cases_unix(TitleFn, Context) ->
    #{
        keyfile_path := ValidKeyPath,
        certfile_path := ValidCertPath,
        cacertfile_path := ValidCacertPath,
        temp_dir := TmpDir,
        password := Password
    } = Context,
    [
        {
            TitleFn("with file without read permission (file:read_file should fail)"),
            ?_test(begin
                NoPermFile = filename:join(TmpDir, "no_permission.pem"),
                %% Read key content, handling potential errors
                KeyContent =
                    case file:read_file(ValidKeyPath) of
                        {ok, Content} -> Content;
                        {error, _} -> <<"dummy key content">>
                    end,
                ok = file:write_file(NoPermFile, KeyContent),
                %% Remove read permission
                os:cmd("chmod 000 " ++ NoPermFile),
                try
                    %% Verify that file:read_file actually fails
                    %% (in some CI environments, root can still read files with 000 permissions)
                    case file:read_file(NoPermFile) of
                        {error, _Reason} ->
                            %% File is actually unreadable, test should work
                            Options = #{
                                enable => true,
                                keyfile => NoPermFile,
                                certfile => ValidCertPath,
                                cacertfile => ValidCacertPath,
                                password => Password
                            },
                            ClientOpts = emqx_tls_lib:to_client_opts(tls, Options),
                            %% File without read permission should cause file:read_file to fail
                            %% so keyfile should be omitted
                            ?assertEqual(undefined, proplists:get_value(keyfile, ClientOpts)),
                            ?assertNotEqual(
                                undefined, proplists:get_value(certfile, ClientOpts)
                            ),
                            ?assertNotEqual(
                                undefined, proplists:get_value(cacertfile, ClientOpts)
                            );
                        {ok, _} ->
                            %% File is still readable (e.g., running as root in CI)
                            %% Skip this test as permissions don't work as expected
                            ok
                    end
                after
                    %% Restore permissions so we can delete the file
                    os:cmd("chmod 644 " ++ NoPermFile),
                    file:delete(NoPermFile)
                end
            end)
        },
        {
            TitleFn("with broken symlink as keyfile (should be omitted)"),
            ?_test(begin
                SymlinkDir = filename:join(
                    TmpDir,
                    integer_to_list(erlang:system_time(microsecond)) ++ "_symlink"
                ),
                ok = filelib:ensure_dir(filename:join(SymlinkDir, "dummy")),
                BrokenSymlink = filename:join(SymlinkDir, "broken_symlink.pem"),
                TargetPath = filename:join(SymlinkDir, "nonexistent_target.pem"),
                %% Create a symlink pointing to a non-existent file
                ok = file:make_symlink(TargetPath, BrokenSymlink),
                try
                    %% Verify the symlink exists and points to non-existent file
                    %% filelib:is_file returns false for broken symlinks, so we check read_file instead
                    {error, enoent} = file:read_file(BrokenSymlink),
                    Options = #{
                        enable => true,
                        keyfile => BrokenSymlink,
                        certfile => ValidCertPath,
                        cacertfile => ValidCacertPath,
                        password => Password
                    },
                    ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
                    %% Broken symlink points to non-existent file, so keyfile should be omitted
                    ?assertEqual(undefined, proplists:get_value(keyfile, ServerOpts))
                after
                    file:delete(BrokenSymlink),
                    catch file:del_dir(SymlinkDir)
                end
            end)
        }
    ].

password_file_test() ->
    T = integer_to_list(erlang:system_time(microsecond)),
    TmpFile = filename:join("/tmp", "secret-" ++ T ++ ".txt"),
    ok = file:write_file(TmpFile, T),
    ConfigValue = emqx_schema_secret:convert_secret("file://" ++ TmpFile, #{}),
    Options = #{enable => true, password => ConfigValue},
    ClientOpts = emqx_tls_lib:to_client_opts(tls, Options),
    ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
    {password, PasswordResolved} = lists:keyfind(password, 1, ClientOpts),
    ?assertEqual({password, PasswordResolved}, lists:keyfind(password, 1, ServerOpts)),
    ?assertEqual(T, PasswordResolved),
    ok.

%% Reproduce https://github.com/emqx/emqx/issues/17523:
%% `emqx ctl conf load --merge' runs `ensure_ssl_files_in_mutable_certs_dir' on
%% RawConf BEFORE the schema converter wraps the password, so the password may
%% still be a literal `<<"file://...">>' binary at validation time. The library
%% must resolve it from disk, not treat the URL as the passphrase.
ensure_ssl_files_resolves_file_url_password_test_() ->
    {setup, setup_ssl_files(), fun cleanup_ssl_files/1, fun ensure_ssl_files_file_url_cases/1}.

ensure_ssl_files_file_url_cases(Context) ->
    #{
        key := EncKey,
        keyfile_path := KeyfilePath,
        cert := Cert,
        cacert := Cacert,
        password := Password,
        temp_dir := TmpDir
    } = Context,
    PwdFile = filename:join(TmpDir, "pwd.txt"),
    ok = file:write_file(PwdFile, [Password, $\n]),
    FileUrlBin = iolist_to_binary(["file://", PwdFile]),
    [
        {"raw file:// password resolved from PEM contents",
            ?_test(
                ?assertMatch(
                    {ok, _},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        <<"keyfile">> => EncKey,
                        <<"certfile">> => Cert,
                        <<"cacertfile">> => Cacert,
                        <<"password">> => FileUrlBin
                    })
                )
            )},
        {"raw file:// password resolved from keyfile path",
            ?_test(
                ?assertMatch(
                    {ok, _},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        <<"keyfile">> => KeyfilePath,
                        <<"certfile">> => Cert,
                        <<"cacertfile">> => Cacert,
                        <<"password">> => FileUrlBin
                    })
                )
            )},
        {"raw file:// password with wrong content fails as bad password",
            ?_test(begin
                WrongPwdFile = filename:join(TmpDir, "wrong-pwd.txt"),
                ok = file:write_file(WrongPwdFile, <<"not-the-password">>),
                WrongUrl = iolist_to_binary(["file://", WrongPwdFile]),
                ?assertMatch(
                    {error, #{
                        reason := bad_password_or_invalid_keyfile,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        <<"keyfile">> => EncKey,
                        <<"certfile">> => Cert,
                        <<"cacertfile">> => Cacert,
                        <<"password">> => WrongUrl
                    })
                )
            end)},
        {"raw file:// password pointing at non-existent file",
            ?_test(begin
                Missing = filename:join(TmpDir, "no-such-pwd-file"),
                MissingUrl = iolist_to_binary(["file://", Missing]),
                %% The secret-loader throw is currently swallowed by the
                %% wrapping ?catching in der_decode_file; the user sees a
                %% bad-password error rather than failed_to_read_secret_file.
                ?assertMatch(
                    {error, #{
                        reason := bad_password_or_invalid_keyfile,
                        which_option := <<"keyfile">>
                    }},
                    emqx_tls_lib:ensure_ssl_files_in_mutable_certs_dir("/tmp", #{
                        <<"keyfile">> => EncKey,
                        <<"certfile">> => Cert,
                        <<"cacertfile">> => Cacert,
                        <<"password">> => MissingUrl
                    })
                )
            end)}
    ].

to_server_opts_test() ->
    VersionsAll = [tlsv1, 'tlsv1.1', 'tlsv1.2', 'tlsv1.3'],
    Versions13Only = ['tlsv1.3'],
    Options = #{
        verify => "Verify",
        ciphers => "Ciphers",
        versions => VersionsAll,
        user_lookup_fun => "funfunfun",
        client_renegotiation => "client_renegotiation"
    },
    Expected1 = lists:usort(maps:keys(Options)),
    ?assertEqual(
        Expected1, lists:usort(proplists:get_keys(emqx_tls_lib:to_server_opts(tls, Options)))
    ),
    Expected2 = lists:usort(maps:keys(Options) -- [user_lookup_fun, client_renegotiation]),
    ?assertEqual(
        Expected2,
        lists:usort(
            proplists:get_keys(
                emqx_tls_lib:to_server_opts(tls, Options#{versions := Versions13Only})
            )
        )
    ).

-doc """
Checks the final transformation made by `to_server_opts` on managed certs options.
""".
to_server_opts_managed_certs_test_() ->
    AssertMatchesFiles = fun(SSLOpts, Ns, Bundle) ->
        {ok, Files} = emqx_managed_certs:list_managed_files(Ns, Bundle),
        Get = fun(Kind) ->
            emqx_utils_conv:str(maps:get(path, maps:get(Kind, Files)))
        end,
        lists:foreach(
            fun
                ({cacertfile, Path}) ->
                    ?assertEqual(Get(?FILE_KIND_CA), Path);
                ({certfile, Path}) ->
                    ?assertEqual(Get(?FILE_KIND_CHAIN), Path);
                ({keyfile, Path}) ->
                    ?assertEqual(Get(?FILE_KIND_KEY), Path);
                (_) ->
                    ok
            end,
            SSLOpts
        )
    end,
    {setup, setup_managed_certs(#{}), fun(_) -> emqx_managed_certs:clean_certs_dir() end, fun(_) ->
        [
            {"multiple managed certs (1)",
                ?_test(begin
                    #{} = (setup_managed_certs(#{namespace => ?ns, bundle_name => ?bundle2}))(),
                    SNI1 = <<"ex1.emqx.io">>,
                    SNI2 = <<"ex2.emqx.io">>,
                    RawOpts = #{
                        <<"managed_certs">> => [
                            #{
                                <<"namespace">> => ?ns,
                                <<"sni">> => SNI1,
                                <<"bundle_name">> => ?bundle
                            },
                            #{
                                <<"namespace">> => ?ns,
                                <<"sni">> => SNI2,
                                <<"bundle_name">> => ?bundle2
                            }
                        ]
                    },
                    SSLOpts0 = emqx_tls_lib:to_server_opts(tls, RawOpts),
                    SSLOpts1 = maps:from_list(SSLOpts0),
                    %% It contains the files from the bundle; when there are more than one
                    %% managed cert bundle specified, it takes the first one as the
                    %% default.
                    ?assertMatch(
                        #{
                            cacertfile := "" ++ _,
                            certfile := "" ++ _,
                            keyfile := "" ++ _
                        },
                        SSLOpts1
                    ),
                    AssertMatchesFiles(SSLOpts0, ?ns, ?bundle),

                    %% It contains an SNI fun that resolves to the managed files when given the
                    %% configured SNI.
                    ?assertMatch(#{sni_fun := _}, SSLOpts1),
                    #{sni_fun := SNIFn} = SSLOpts1,

                    ?assertMatch([_, _, _], SNIFn(str(SNI1))),
                    AssertMatchesFiles(SNIFn(str(SNI1)), ?ns, ?bundle),

                    ?assertMatch([_, _, _], SNIFn(str(SNI2))),
                    AssertMatchesFiles(SNIFn(str(SNI2)), ?ns, ?bundle2),

                    %% Uses the default config for unknown domains
                    ?assertMatch(undefined, SNIFn("some.unknown.domain")),
                    ok
                end)}
        ]
    end}.

session_tickets_integrity_test_() ->
    {foreach, fun setup_meck/0, fun cleanup_meck/1, [
        {"session_tickets disabled, seed empty - seed should not be added",
            fun test_session_tickets_disabled_seed_empty/0},
        {"session_tickets enabled, seed empty - session_tickets should be removed",
            fun test_session_tickets_enabled_seed_empty/0},
        {"session_tickets enabled, seed configured - both should be present",
            fun test_session_tickets_enabled_seed_configured/0},
        {"session_tickets not configured, seed configured - seed should be removed",
            fun test_session_tickets_not_configured_seed_configured/0},
        {"session_tickets disabled, seed configured - seed should be removed",
            fun test_session_tickets_disabled_seed_configured/0}
    ]}.

setup_meck() ->
    meck:new(emqx_config, [passthrough, no_history, no_link]),
    ok.

cleanup_meck(_) ->
    meck:unload(emqx_config).

test_session_tickets_disabled_seed_empty() ->
    meck:expect(emqx_config, get, fun([node, tls_stateless_tickets_seed], _) -> <<>> end),
    Options = #{
        versions => ['tlsv1.3'],
        session_tickets => disabled
    },
    ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
    ?assertNot(lists:keyfind(stateless_tickets_seed, 1, ServerOpts)),
    ?assertNot(lists:keyfind(session_tickets, 1, ServerOpts)).

test_session_tickets_enabled_seed_empty() ->
    meck:expect(emqx_config, get, fun([node, tls_stateless_tickets_seed], _) -> <<>> end),
    Options = #{
        versions => ['tlsv1.3'],
        session_tickets => stateless
    },
    ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
    %% session_tickets should be removed because seed is empty
    ?assertNot(lists:keyfind(session_tickets, 1, ServerOpts)),
    ?assertNot(lists:keyfind(stateless_tickets_seed, 1, ServerOpts)).

test_session_tickets_enabled_seed_configured() ->
    %% 32 bytes
    Seed = <<"0123456789abcdef0123456789abcdef">>,
    meck:expect(emqx_config, get, fun([node, tls_stateless_tickets_seed], _) -> Seed end),
    Options = #{
        versions => ['tlsv1.3'],
        session_tickets => stateless
    },
    ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
    %% Both should be present
    ?assertNotEqual(false, lists:keyfind(session_tickets, 1, ServerOpts)),
    ?assertNotEqual(false, lists:keyfind(stateless_tickets_seed, 1, ServerOpts)),
    {_, FoundSeed} = lists:keyfind(stateless_tickets_seed, 1, ServerOpts),
    ?assertEqual(Seed, FoundSeed).

test_session_tickets_not_configured_seed_configured() ->
    %% 32 bytes
    Seed = <<"0123456789abcdef0123456789abcdef">>,
    meck:expect(emqx_config, get, fun([node, tls_stateless_tickets_seed], _) -> Seed end),
    Options = #{
        %% session_tickets not configured - omitted intentionally
        versions => ['tlsv1.3']
    },
    ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
    %% seed should be removed because session_tickets is not configured
    ?assertNot(lists:keyfind(stateless_tickets_seed, 1, ServerOpts)),
    ?assertNot(lists:keyfind(session_tickets, 1, ServerOpts)).

test_session_tickets_disabled_seed_configured() ->
    %% 32 bytes
    Seed = <<"0123456789abcdef0123456789abcdef">>,
    meck:expect(emqx_config, get, fun([node, tls_stateless_tickets_seed], _) -> Seed end),
    Options = #{
        versions => ['tlsv1.3'],
        session_tickets => disabled
    },
    ServerOpts = emqx_tls_lib:to_server_opts(tls, Options),
    %% seed should be removed because session_tickets is disabled
    ?assertNot(lists:keyfind(stateless_tickets_seed, 1, ServerOpts)),
    ?assertNot(lists:keyfind(session_tickets, 1, ServerOpts)).

bin(X) -> iolist_to_binary(X).
str(X) -> emqx_utils_conv:str(X).

test_name_hash_cacert() ->
    <<
        "-----BEGIN CERTIFICATE-----\n"
        "MIIDUTCCAjmgAwIBAgIJAPPYCjTmxdt/MA0GCSqGSIb3DQEBCwUAMD8xCzAJBgNV\n"
        "BAYTAkNOMREwDwYDVQQIDAhoYW5nemhvdTEMMAoGA1UECgwDRU1RMQ8wDQYDVQQD\n"
        "DAZSb290Q0EwHhcNMjAwNTA4MDgwNjUyWhcNMzAwNTA2MDgwNjUyWjA/MQswCQYD\n"
        "VQQGEwJDTjERMA8GA1UECAwIaGFuZ3pob3UxDDAKBgNVBAoMA0VNUTEPMA0GA1UE\n"
        "AwwGUm9vdENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAzcgVLex1\n"
        "EZ9ON64EX8v+wcSjzOZpiEOsAOuSXOEN3wb8FKUxCdsGrsJYB7a5VM/Jot25Mod2\n"
        "juS3OBMg6r85k2TWjdxUoUs+HiUB/pP/ARaaW6VntpAEokpij/przWMPgJnBF3Ur\n"
        "MjtbLayH9hGmpQrI5c2vmHQ2reRZnSFbY+2b8SXZ+3lZZgz9+BaQYWdQWfaUWEHZ\n"
        "uDaNiViVO0OT8DRjCuiDp3yYDj3iLWbTA/gDL6Tf5XuHuEwcOQUrd+h0hyIphO8D\n"
        "tsrsHZ14j4AWYLk1CPA6pq1HIUvEl2rANx2lVUNv+nt64K/Mr3RnVQd9s8bK+TXQ\n"
        "KGHd2Lv/PALYuwIDAQABo1AwTjAdBgNVHQ4EFgQUGBmW+iDzxctWAWxmhgdlE8Pj\n"
        "EbQwHwYDVR0jBBgwFoAUGBmW+iDzxctWAWxmhgdlE8PjEbQwDAYDVR0TBAUwAwEB\n"
        "/zANBgkqhkiG9w0BAQsFAAOCAQEAGbhRUjpIred4cFAFJ7bbYD9hKu/yzWPWkMRa\n"
        "ErlCKHmuYsYk+5d16JQhJaFy6MGXfLgo3KV2itl0d+OWNH0U9ULXcglTxy6+njo5\n"
        "CFqdUBPwN1jxhzo9yteDMKF4+AHIxbvCAJa17qcwUKR5MKNvv09C6pvQDJLzid7y\n"
        "E2dkgSuggik3oa0427KvctFf8uhOV94RvEDyqvT5+pgNYZ2Yfga9pD/jjpoHEUlo\n"
        "88IGU8/wJCx3Ds2yc8+oBg/ynxG8f/HmCC1ET6EHHoe2jlo8FpU/SgGtghS1YL30\n"
        "IWxNsPrUP+XsZpBJy/mvOhE5QXo6Y35zDqqj8tI7AGmAWu22jg==\n"
        "-----END CERTIFICATE-----\n"
    >>.

test_name_hash_cert() ->
    <<
        "-----BEGIN CERTIFICATE-----\n"
        "MIIDEzCCAfugAwIBAgIBAjANBgkqhkiG9w0BAQsFADA/MQswCQYDVQQGEwJDTjER\n"
        "MA8GA1UECAwIaGFuZ3pob3UxDDAKBgNVBAoMA0VNUTEPMA0GA1UEAwwGUm9vdENB\n"
        "MB4XDTIwMDUwODA4MDcwNVoXDTMwMDUwNjA4MDcwNVowPzELMAkGA1UEBhMCQ04x\n"
        "ETAPBgNVBAgMCGhhbmd6aG91MQwwCgYDVQQKDANFTVExDzANBgNVBAMMBlNlcnZl\n"
        "cjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALNeWT3pE+QFfiRJzKmn\n"
        "AMUrWo3K2j/Tm3+Xnl6WLz67/0rcYrJbbKvS3uyRP/stXyXEKw9CepyQ1ViBVFkW\n"
        "Aoy8qQEOWFDsZc/5UzhXUnb6LXr3qTkFEjNmhj+7uzv/lbBxlUG1NlYzSeOB6/RT\n"
        "8zH/lhOeKhLnWYPXdXKsa1FL6ij4X8DeDO1kY7fvAGmBn/THh1uTpDizM4YmeI+7\n"
        "4dmayA5xXvARte5h4Vu5SIze7iC057N+vymToMk2Jgk+ZZFpyXrnq+yo6RaD3ANc\n"
        "lrc4FbeUQZ5a5s5Sxgs9a0Y3WMG+7c5VnVXcbjBRz/aq2NtOnQQjikKKQA8GF080\n"
        "BQkCAwEAAaMaMBgwCQYDVR0TBAIwADALBgNVHQ8EBAMCBeAwDQYJKoZIhvcNAQEL\n"
        "BQADggEBAJefnMZpaRDHQSNUIEL3iwGXE9c6PmIsQVE2ustr+CakBp3TZ4l0enLt\n"
        "iGMfEVFju69cO4oyokWv+hl5eCMkHBf14Kv51vj448jowYnF1zmzn7SEzm5Uzlsa\n"
        "sqjtAprnLyof69WtLU1j5rYWBuFX86yOTwRAFNjm9fvhAcrEONBsQtqipBWkMROp\n"
        "iUYMkRqbKcQMdwxov+lHBYKq9zbWRoqLROAn54SRqgQk6c15JdEfgOOjShbsOkIH\n"
        "UhqcwRkQic7n1zwHVGVDgNIZVgmJ2IdIWBlPEC7oLrRrBD/X1iEEXtKab6p5o22n\n"
        "KB5mN+iQaE+Oe2cpGKZJiJRdM+IqDDQ=\n"
        "-----END CERTIFICATE-----\n"
    >>.

test_name_hash_key() ->
    <<
        "-----BEGIN RSA PRIVATE KEY-----\n"
        "MIIEowIBAAKCAQEAs15ZPekT5AV+JEnMqacAxStajcraP9Obf5eeXpYvPrv/Stxi\n"
        "sltsq9Le7JE/+y1fJcQrD0J6nJDVWIFUWRYCjLypAQ5YUOxlz/lTOFdSdvotevep\n"
        "OQUSM2aGP7u7O/+VsHGVQbU2VjNJ44Hr9FPzMf+WE54qEudZg9d1cqxrUUvqKPhf\n"
        "wN4M7WRjt+8AaYGf9MeHW5OkOLMzhiZ4j7vh2ZrIDnFe8BG17mHhW7lIjN7uILTn\n"
        "s36/KZOgyTYmCT5lkWnJeuer7KjpFoPcA1yWtzgVt5RBnlrmzlLGCz1rRjdYwb7t\n"
        "zlWdVdxuMFHP9qrY206dBCOKQopADwYXTzQFCQIDAQABAoIBAQCuvCbr7Pd3lvI/\n"
        "n7VFQG+7pHRe1VKwAxDkx2t8cYos7y/QWcm8Ptwqtw58HzPZGWYrgGMCRpzzkRSF\n"
        "V9g3wP1S5Scu5C6dBu5YIGc157tqNGXB+SpdZddJQ4Nc6yGHXYERllT04ffBGc3N\n"
        "WG/oYS/1cSteiSIrsDy/91FvGRCi7FPxH3wIgHssY/tw69s1Cfvaq5lr2NTFzxIG\n"
        "xCvpJKEdSfVfS9I7LYiymVjst3IOR/w76/ZFY9cRa8ZtmQSWWsm0TUpRC1jdcbkm\n"
        "ZoJptYWlP+gSwx/fpMYftrkJFGOJhHJHQhwxT5X/ajAISeqjjwkWSEJLwnHQd11C\n"
        "Zy2+29lBAoGBANlEAIK4VxCqyPXNKfoOOi5dS64NfvyH4A1v2+KaHWc7lqaqPN49\n"
        "ezfN2n3X+KWx4cviDD914Yc2JQ1vVJjSaHci7yivocDo2OfZDmjBqzaMp/y+rX1R\n"
        "/f3MmiTqMa468rjaxI9RRZu7vDgpTR+za1+OBCgMzjvAng8dJuN/5gjlAoGBANNY\n"
        "uYPKtearBmkqdrSV7eTUe49Nhr0XotLaVBH37TCW0Xv9wjO2xmbm5Ga/DCtPIsBb\n"
        "yPeYwX9FjoasuadUD7hRvbFu6dBa0HGLmkXRJZTcD7MEX2Lhu4BuC72yDLLFd0r+\n"
        "Ep9WP7F5iJyagYqIZtz+4uf7gBvUDdmvXz3sGr1VAoGAdXTD6eeKeiI6PlhKBztF\n"
        "zOb3EQOO0SsLv3fnodu7ZaHbUgLaoTMPuB17r2jgrYM7FKQCBxTNdfGZmmfDjlLB\n"
        "0xZ5wL8ibU30ZXL8zTlWPElST9sto4B+FYVVF/vcG9sWeUUb2ncPcJ/Po3UAktDG\n"
        "jYQTTyuNGtSJHpad/YOZctkCgYBtWRaC7bq3of0rJGFOhdQT9SwItN/lrfj8hyHA\n"
        "OjpqTV4NfPmhsAtu6j96OZaeQc+FHvgXwt06cE6Rt4RG4uNPRluTFgO7XYFDfitP\n"
        "vCppnoIw6S5BBvHwPP+uIhUX2bsi/dm8vu8tb+gSvo4PkwtFhEr6I9HglBKmcmog\n"
        "q6waEQKBgHyecFBeM6Ls11Cd64vborwJPAuxIW7HBAFj/BS99oeG4TjBx4Sz2dFd\n"
        "rzUibJt4ndnHIvCN8JQkjNG14i9hJln+H3mRss8fbZ9vQdqG+2vOWADYSzzsNI55\n"
        "RFY7JjluKcVkp/zCDeUxTU3O6sS+v6/3VE11Cob6OYQx3lN5wrZ3\n"
        "-----END RSA PRIVATE KEY-----\n"
    >>.

setup_ssl_files() ->
    DefaultOpts = #{key_type => ec},
    setup_ssl_files(DefaultOpts).

setup_ssl_files(Opts) ->
    fun() -> do_setup_ssl_files(Opts) end.

do_setup_ssl_files(InOpts) ->
    DefaultKeyType = maps:get(key_type, InOpts),
    BaseTmpDir = maps:get(base_tmp_dir, InOpts, "/tmp"),
    Dir = mktemp_dir(BaseTmpDir),
    DefaultPassword = maps:get(password, InOpts, <<"foobar">>),
    emqx_test_tls_certs_helper:gen_ca(Dir, "root", InOpts),
    MkKit = fun(Opts) ->
        #{name := Name} = Opts,
        Password = maps:get(password, Opts, DefaultPassword),
        KeyType = maps:get(key_type, Opts, DefaultKeyType),
        IntermediateName = "intermediate-" ++ Name,
        GenOpts = #{key_type => KeyType, password => Password},
        %% No password for intermediate key cert
        emqx_test_tls_certs_helper:gen_host_cert(IntermediateName, "root", Dir, GenOpts#{
            password => undefined
        }),
        emqx_test_tls_certs_helper:gen_host_cert(Name, IntermediateName, Dir, GenOpts),
        KeyfilePath = filename:join(Dir, Name ++ ".key"),
        CertfilePath = filename:join(Dir, Name ++ ".pem"),
        CacertfilePath = filename:join(Dir, IntermediateName ++ ".pem"),
        {ok, Key} = file:read_file(KeyfilePath),
        {ok, Cert} = file:read_file(CertfilePath),
        {ok, Cacert} = file:read_file(CacertfilePath),
        #{
            key => Key,
            keyfile_path => KeyfilePath,
            cert => Cert,
            certfile_path => CertfilePath,
            cacert => Cacert,
            cacertfile_path => CacertfilePath
        }
    end,
    #{
        key := Key,
        keyfile_path := KeyfilePath,
        cert := Cert,
        certfile_path := CertfilePath,
        cacert := Cacert,
        cacertfile_path := CacertfilePath
    } = MkKit(#{name => "client"}),
    #{
        cacertfile_path => CacertfilePath,
        certfile_path => CertfilePath,
        keyfile_path => KeyfilePath,
        key => Key,
        cert => Cert,
        cacert => Cacert,
        password => DefaultPassword,
        mk_kit => MkKit,
        temp_dir => Dir
    }.

cleanup_ssl_files(#{temp_dir := Dir}) ->
    file:del_dir_r(Dir).

mktemp_dir(BaseDir) ->
    Dir = os:cmd("mktemp -dp " ++ BaseDir ++ " emqx_tls_lib_tests.XXXXXXXXXXX"),
    string:trim(Dir).

mangle(PEM) ->
    mangle(PEM, 10, 5).

mangle(PEM, Pos, Len) ->
    [{Type, DER, CryptoInfo}] = public_key:pem_decode(PEM),
    CorruptDER = iolist_to_binary([
        binary:part(DER, 0, Pos),
        binary:copy(<<255>>, Len),
        binary:part(DER, Pos + Len, byte_size(DER) - Pos - Len)
    ]),
    public_key:pem_encode([{Type, CorruptDER, CryptoInfo}]).

setup_managed_certs(Opts0) ->
    fun() ->
        Namespace = maps:get(namespace, Opts0, ?ns),
        BundleName = maps:get(bundle_name, Opts0, ?bundle),
        #{
            cert := CertRoot,
            key := KeyRoot,
            cert_pem := CAPEM
        } = emqx_cth_tls:gen_cert_pem(#{key => ec, issuer => root}),
        Opts = maps:with([password], Opts0),
        #{
            cert_pem := CertPEM,
            key_pem := KeyPEM
        } = emqx_cth_tls:gen_cert_pem(Opts#{key => ec, issuer => {CertRoot, KeyRoot}}),
        Files0 = #{
            ?FILE_KIND_CA => CAPEM,
            ?FILE_KIND_CHAIN => CertPEM,
            ?FILE_KIND_KEY => KeyPEM
        },
        Files =
            case Opts of
                #{password := Password} ->
                    Files0#{?FILE_KIND_KEY_PASSWORD => Password};
                _ ->
                    Files0
            end,
        %% Note: we call the RPC target directly because the BPAPI app is not started, and
        %% hence the list of nodes supporting the API is `[]`.
        ok = emqx_managed_certs:add_managed_files_v1(Namespace, BundleName, Files),
        #{namespace => Namespace, bundle_name => BundleName}
    end.
