%%--------------------------------------------------------------------
%% Copyright (c) 2019-2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------

-module(emqx_access_control_SUITE).

-compile(export_all).
-compile(nowarn_export_all).

-include_lib("emqx/include/emqx_hooks.hrl").
-include_lib("emqx/include/emqx_access_control.hrl").
-include_lib("eunit/include/eunit.hrl").

all() -> emqx_common_test_helpers:all(?MODULE).

init_per_suite(Config) ->
    Apps = emqx_cth_suite:start(
        [{emqx, #{override_env => [{boot_modules, [broker]}]}}],
        #{work_dir => emqx_cth_suite:work_dir(Config)}
    ),
    ok = emqx_access_control:set_default_authn_restrictive(),
    [{apps, Apps} | Config].

end_per_suite(Config) ->
    ok = emqx_access_control:set_default_authn_permissive(),
    emqx_cth_suite:stop(proplists:get_value(apps, Config)).

init_per_testcase(_, Config) ->
    Config.

end_per_testcase(_, _Config) ->
    ok = emqx_hooks:del('client.authorize', {?MODULE, authz_stub}),
    ok = emqx_hooks:del('client.authorize', {?MODULE, authz_stub_cache}),
    ok = emqx_hooks:del('client.authorize', {?MODULE, authz_stub_non_cacheable}),
    ok = emqx_hooks:del('client.authorize', {?MODULE, crashing_authz}),
    ok = emqx_hooks:del('client.authorize', {?MODULE, permissive_authz_stop}),
    ok = emqx_hooks:del('client.authorize', {?MODULE, permissive_authz_ok}),
    ok = emqx_hooks:del('client.authorize', {?MODULE, capture_authz_context}),
    ok = emqx_hooks:del('client.authenticate', {?MODULE, quick_deny_anonymous_authn}),
    ok = emqx_hooks:del('client.authenticate', {?MODULE, crashing_authn}),
    ok = emqx_hooks:del('client.authenticate', {?MODULE, permissive_authn_stop}),
    ok = emqx_hooks:del('client.authenticate', {?MODULE, permissive_authn_ok}).

t_authenticate(_) ->
    ClientInfo = clientinfo(),
    ?assertMatch({error, not_authorized}, emqx_access_control:authenticate(ClientInfo)),
    ?assertMatch(
        {error, not_authorized}, emqx_access_control:authenticate(ClientInfo#{enable_authn => true})
    ),
    ?assertMatch(
        {error, not_authorized},
        emqx_access_control:authenticate(ClientInfo#{enable_authn => quick_deny_anonymous})
    ),
    ?assertMatch({ok, _}, emqx_access_control:authenticate(ClientInfo#{enable_authn => false})).

t_authorize(_) ->
    ?assertEqual(
        allow,
        emqx_access_control:authorize(
            emqx_authz_context:make(clientinfo()), ?AUTHZ_PUBLISH, <<"t">>
        )
    ).

t_authorize_cache_store(_) ->
    Topic = <<"cache/store">>,
    ok = emqx_authz_cache:empty_authz_cache(),
    ok = emqx_hooks:put('client.authorize', {?MODULE, authz_stub_cache, []}, ?HP_AUTHZ),
    ?assertEqual(
        deny,
        emqx_access_control:authorize(
            emqx_authz_context:make(clientinfo()), ?AUTHZ_PUBLISH, Topic
        )
    ),
    ?assertEqual(deny, emqx_authz_cache:get_authz_cache(?AUTHZ_PUBLISH, Topic)).

t_authorize_cache_skip_non_cacheable(_) ->
    Topic = <<"cache/skip">>,
    ok = emqx_authz_cache:empty_authz_cache(),
    ok = emqx_hooks:put('client.authorize', {?MODULE, authz_stub_non_cacheable, []}, ?HP_AUTHZ),
    ?assertEqual(
        deny,
        emqx_access_control:authorize(
            emqx_authz_context:make(clientinfo()), ?AUTHZ_PUBLISH, Topic
        )
    ),
    ?assertEqual(not_found, emqx_authz_cache:get_authz_cache(?AUTHZ_PUBLISH, Topic)).

t_authorize_cache_bypass(_) ->
    Topic = <<"cache/bypass">>,
    ok = emqx_authz_cache:empty_authz_cache(),
    ok = emqx_authz_cache:put_authz_cache(?AUTHZ_PUBLISH, Topic, deny),
    ok = emqx_hooks:put('client.authorize', {?MODULE, authz_stub, [Topic]}, ?HP_AUTHZ),
    ?assertEqual(
        allow,
        emqx_access_control:authorize(
            emqx_authz_context:make(clientinfo()), ?AUTHZ_PUBLISH, Topic, #{cache => false}
        )
    ),
    ?assertEqual(deny, emqx_authz_cache:get_authz_cache(?AUTHZ_PUBLISH, Topic)).

t_authz_context_security_profile(_) ->
    ClientInfo = clientinfo(#{
        is_superuser => true,
        peername => {{127, 0, 0, 1}, 1883},
        cert_pem => <<"certificate">>,
        client_attrs => #{<<"role">> => <<"reader">>},
        custom_authz_field => custom_value
    }),
    RestrictedContext = maps:remove(custom_authz_field, maps:remove(password, ClientInfo)),
    Cases = [
        {"legacy", ClientInfo},
        {"hardened", RestrictedContext}
    ],
    lists:foreach(
        fun({Profile, ExpectedContext}) ->
            emqx_common_test_helpers:with_security_profile(Profile, fun() ->
                ok = emqx_hooks:put(
                    'client.authorize', {?MODULE, capture_authz_context, []}, ?HP_AUTHZ
                ),
                ?assertEqual(
                    allow,
                    emqx_access_control:authorize(
                        emqx_authz_context:make(ClientInfo),
                        ?AUTHZ_PUBLISH,
                        <<"context/topic">>,
                        #{cache => false}
                    )
                ),
                receive
                    {authz_context, Context} -> ?assertEqual(ExpectedContext, Context)
                after 1000 ->
                    ct:fail(authz_context_not_captured)
                end
            end)
        end,
        Cases
    ).

t_quick_deny_anonymous(_) ->
    ok = emqx_hooks:put(
        'client.authenticate',
        {?MODULE, quick_deny_anonymous_authn, []},
        ?HP_AUTHN
    ),

    RawClient0 = clientinfo(),
    RawClient = RawClient0#{username => undefined},

    %% No name, No authn
    Client1 = RawClient#{enable_authn => false},
    ?assertMatch({ok, _}, emqx_access_control:authenticate(Client1)),

    %% No name, With quick_deny_anonymous
    Client2 = RawClient#{enable_authn => quick_deny_anonymous},
    ?assertMatch({error, _}, emqx_access_control:authenticate(Client2)),

    %% Bad name, With quick_deny_anonymous
    Client3 = RawClient#{enable_authn => quick_deny_anonymous, username => <<"badname">>},
    ?assertMatch({error, _}, emqx_access_control:authenticate(Client3)),

    %% Good name, With quick_deny_anonymous
    Client4 = RawClient#{enable_authn => quick_deny_anonymous, username => <<"goodname">>},
    ?assertMatch({ok, _}, emqx_access_control:authenticate(Client4)),

    %% Name, With authn
    Client5 = RawClient#{enable_authn => true, username => <<"badname">>},
    ?assertMatch({error, _}, emqx_access_control:authenticate(Client5)),
    ok.

t_authn_hook_crash_security_profile(_) ->
    Cases = [
        {"legacy", [crashing_authn, permissive_authn_stop], ok},
        {"legacy", [permissive_authn_stop, crashing_authn], ok},
        {"legacy", [crashing_authn, permissive_authn_ok], ok},
        {"legacy", [permissive_authn_ok, crashing_authn], ok},
        {"hardened", [crashing_authn, permissive_authn_stop], error},
        {"hardened", [permissive_authn_stop, crashing_authn], ok},
        {"hardened", [crashing_authn, permissive_authn_ok], error},
        {"hardened", [permissive_authn_ok, crashing_authn], error}
    ],
    lists:foreach(fun check_authn_hook_crash_case/1, Cases).

t_authz_hook_crash_security_profile(_) ->
    Cases = [
        {"legacy", [crashing_authz, permissive_authz_stop], allow},
        {"legacy", [permissive_authz_stop, crashing_authz], allow},
        {"legacy", [crashing_authz, permissive_authz_ok], allow},
        {"legacy", [permissive_authz_ok, crashing_authz], allow},
        {"hardened", [crashing_authz, permissive_authz_stop], deny},
        {"hardened", [permissive_authz_stop, crashing_authz], allow},
        {"hardened", [crashing_authz, permissive_authz_ok], deny},
        {"hardened", [permissive_authz_ok, crashing_authz], deny}
    ],
    lists:foreach(fun check_authz_hook_crash_case/1, Cases).

%%--------------------------------------------------------------------
%% Helper functions
%%--------------------------------------------------------------------

check_authn_hook_crash_case({Profile, Hooks, Expected}) ->
    cleanup_crash_test_hooks(),
    emqx_common_test_helpers:with_security_profile(Profile, fun() ->
        ok = add_crash_test_hooks('client.authenticate', ?HP_AUTHN, Hooks),
        Result = emqx_access_control:authenticate(clientinfo()),
        assert_authn_result(Expected, Result)
    end),
    cleanup_crash_test_hooks().

check_authz_hook_crash_case({Profile, Hooks, Expected}) ->
    cleanup_crash_test_hooks(),
    emqx_common_test_helpers:with_security_profile(Profile, fun() ->
        ok = emqx_authz_cache:empty_authz_cache(),
        ok = add_crash_test_hooks('client.authorize', ?HP_AUTHZ, Hooks),
        ?assertEqual(
            Expected,
            emqx_access_control:authorize(
                emqx_authz_context:make(clientinfo()), ?AUTHZ_PUBLISH, <<"t">>
            )
        )
    end),
    cleanup_crash_test_hooks().

add_crash_test_hooks(HookPoint, BasePriority, [HookFirst, HookSecond]) ->
    ok = emqx_hooks:put(HookPoint, {?MODULE, HookFirst, []}, BasePriority + 1),
    ok = emqx_hooks:put(HookPoint, {?MODULE, HookSecond, []}, BasePriority),
    ok.

assert_authn_result(ok, Result) ->
    ?assertMatch({ok, _}, Result);
assert_authn_result(error, Result) ->
    ?assertEqual({error, not_authorized}, Result).

cleanup_crash_test_hooks() ->
    ok = emqx_hooks:del('client.authenticate', {?MODULE, crashing_authn}),
    ok = emqx_hooks:del('client.authenticate', {?MODULE, permissive_authn_stop}),
    ok = emqx_hooks:del('client.authenticate', {?MODULE, permissive_authn_ok}),
    ok = emqx_hooks:del('client.authorize', {?MODULE, crashing_authz}),
    ok = emqx_hooks:del('client.authorize', {?MODULE, permissive_authz_stop}),
    ok = emqx_hooks:del('client.authorize', {?MODULE, permissive_authz_ok}),
    ok.

authz_stub(_Client, _Action, ValidTopic, _DefaultResult, ValidTopic) -> {stop, #{result => allow}};
authz_stub(_Client, _Action, _Topic, _DefaultResult, _ValidTopic) -> {stop, #{result => deny}}.

authz_stub_cache(_Client, _Action, _Topic, _DefaultResult) ->
    {stop, #{result => deny, from => test}}.

authz_stub_non_cacheable(_Client, _Action, _Topic, _DefaultResult) ->
    {stop, #{result => deny, from => test, is_cacheable => false}}.

quick_deny_anonymous_authn(#{username := <<"badname">>}, _AuthResult) ->
    {stop, {error, not_authorized}};
quick_deny_anonymous_authn(_ClientInfo, _AuthResult) ->
    {stop, {ok, #{is_superuser => false}}}.

crashing_authn(_ClientInfo, _AuthResult) ->
    erlang:error(authn_hook_crashed).

permissive_authn_stop(_ClientInfo, _AuthResult) ->
    {stop, {ok, #{is_superuser => false}}}.

permissive_authn_ok(_ClientInfo, _AuthResult) ->
    {ok, {ok, #{is_superuser => false}}}.

crashing_authz(_ClientInfo, _Action, _Topic, _AuthzResult) ->
    erlang:error(authz_hook_crashed).

permissive_authz_stop(_ClientInfo, _Action, _Topic, _AuthzResult) ->
    {stop, #{result => allow, from => test}}.

permissive_authz_ok(_ClientInfo, _Action, _Topic, _AuthzResult) ->
    {ok, #{result => allow, from => test}}.

capture_authz_context(ClientInfo, _Action, _Topic, _AuthzResult) ->
    self() ! {authz_context, ClientInfo},
    {stop, #{result => allow, from => test}}.

clientinfo() -> clientinfo(#{}).
clientinfo(InitProps) ->
    maps:merge(
        #{
            zone => default,
            listener => 'tcp:default',
            protocol => mqtt,
            peerhost => {127, 0, 0, 1},
            sockport => 1883,
            clientid => <<"clientid">>,
            username => <<"username">>,
            password => <<"passwd">>,
            is_bridge => false,
            is_superuser => false,
            mountpoint => undefined
        },
        InitProps
    ).
