%%--------------------------------------------------------------------
%% Copyright (c) 2019-2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------

-module(emqx_vm_mon).

-behaviour(gen_server).

-include("logger.hrl").

%% APIs
-export([start_link/0]).

%% gen_server callbacks
-export([
    init/1,
    handle_call/3,
    handle_cast/2,
    handle_info/2,
    terminate/2,
    code_change/3
]).

-define(VM_MON, ?MODULE).

%%--------------------------------------------------------------------
%% API
%%--------------------------------------------------------------------
start_link() ->
    gen_server:start_link({local, ?VM_MON}, ?MODULE, [], []).

%%--------------------------------------------------------------------
%% gen_server callbacks
%%--------------------------------------------------------------------

init([]) ->
    _ = start_check_timer(),
    {ok, #{}}.

handle_call(Req, _From, State) ->
    ?SLOG(error, #{msg => "unexpected_call", call => Req}),
    {reply, ignored, State}.

handle_cast(Msg, State) ->
    ?SLOG(error, #{msg => "unexpected_cast", cast => Msg}),
    {noreply, State}.

handle_info({timeout, _Timer, check}, State) ->
    ProcHighWatermark = emqx:get_config([sysmon, vm, process_high_watermark]),
    ProcLowWatermark = emqx:get_config([sysmon, vm, process_low_watermark]),
    ProcessCount = erlang:system_info(process_count),
    case ProcessCount / erlang:system_info(process_limit) of
        Percent when Percent > ProcHighWatermark ->
            Usage = usage(Percent),
            Message = [Usage, " process usage"],
            emqx_alarm:activate(
                too_many_processes,
                #{
                    usage => Usage,
                    high_watermark => ProcHighWatermark,
                    low_watermark => ProcLowWatermark
                },
                Message
            );
        Percent when Percent < ProcLowWatermark ->
            Usage = usage(Percent),
            Message = [Usage, " process usage"],
            emqx_alarm:ensure_deactivated(
                too_many_processes,
                #{
                    usage => Usage,
                    high_watermark => ProcHighWatermark,
                    low_watermark => ProcLowWatermark
                },
                Message
            );
        _Percent ->
            ok
    end,
    _ = start_check_timer(),
    {noreply, State};
handle_info(Info, State) ->
    ?SLOG(error, #{msg => "unexpected_info", info => Info}),
    {noreply, State}.

terminate(_Reason, _State) ->
    ok.

code_change(_OldVsn, State, _Extra) ->
    {ok, State}.

%%--------------------------------------------------------------------
%% Internal functions
%%--------------------------------------------------------------------

start_check_timer() ->
    Interval = emqx:get_config([sysmon, vm, process_check_interval]),
    emqx_utils:start_timer(Interval, check).

usage(Percent) ->
    integer_to_list(floor(Percent * 100)) ++ "%".
