%%--------------------------------------------------------------------
%% Copyright (c) 2026 EMQ Technologies Co., Ltd. All Rights Reserved.
%%--------------------------------------------------------------------
-ifndef(__EMQX_A2A_REGISTRY_HRL__).
-define(__EMQX_A2A_REGISTRY_HRL__, true).

-define(A2A_TOPIC_NS, <<"$a2a">>).
-define(A2A_TOPIC_V1, <<"v1">>).
-define(A2A_TOPIC_DISCOVERY, <<"discovery">>).

-define(A2A_PROP_STATUS_KEY, <<"a2a-status">>).
-define(A2A_PROP_STATUS_SOURCE_KEY, <<"a2a-status-source">>).
-define(A2A_PROP_ONLINE_VAL, <<"online">>).
-define(A2A_PROP_ONLINE_VAL_ATOM, online).
-define(A2A_PROP_OFFLINE_VAL, <<"offline">>).
-define(A2A_PROP_OFFLINE_VAL_ATOM, offline).

-define(A2A_SCHEMA_REGISTRY_SERDE_NAME, <<"__sdKn7w9B3UuI7LAmkQSHP__a2a_agent_card">>).

-define(SEGMENT_ID_RE, <<"^[A-Za-z0-9._-]+$">>).

%% END ifndef(__EMQX_A2A_REGISTRY_HRL__)
-endif.
